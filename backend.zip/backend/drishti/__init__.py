"""ARTHA DRISHTI -- MPLADS risk-intelligence platform."""

__version__ = "0.1.0"

__all__ = ["__version__"]
