"""Silver: canonical reference tables built from the one real dataset.

Bronze rows become `state`, `constituency` and `mp` -- the spine the synthetic
generator is anchored to in Block 4. Anchoring generation to real geography
and real per-member entitlement ceilings is what makes the generated data
defensible; inventing states and constituencies would not be.

Every repair Bronze refused to make happens here, and is recorded:

  D-02  a constituency is not a key. Nanded carries two members in the 18th
        Lok Sabha after the 2024 by-election, and the file gives no dates to
        separate their terms, so both are stored with an open term and the
        collision is reported rather than resolved by guesswork.
  D-03  reservation comes from the name marker where present. The file tags
        82 SC and 44 ST against a constitutional allocation of 84 and 47, so
        roughly five reserved seats are indistinguishable from general ones.
        Each row records which of the two it is.
  D-04  member names arrive in two casings and with inconsistent honorifics;
        `name_canonical` is the join key, `name` stays as recorded.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any

import pandas as pd

from .names import (
    ParsedConstituency,
    canonical_person,
    canonical_state,
    clean_display,
    parse_constituency,
)

__all__ = [
    "EIGHTEENTH_LS_START",
    "ReferenceTables",
    "build_reference_tables",
    "STATE_COLUMNS",
    "CONSTITUENCY_COLUMNS",
    "MP_COLUMNS",
]

# The 18th Lok Sabha was constituted on 4 June 2024. Used as the term start
# for every member, because the source carries no per-member dates.
EIGHTEENTH_LS_START = date(2024, 6, 4)

STATE_COLUMNS: tuple[str, ...] = ("state_id", "name", "name_canonical", "ls_seats")
CONSTITUENCY_COLUMNS: tuple[str, ...] = (
    "constituency_id",
    "state_id",
    "name",
    "name_canonical",
    "house",
    "reservation",
    "reservation_source",
    "raw_name",
    "n_members",
)
MP_COLUMNS: tuple[str, ...] = (
    "mp_id",
    "name",
    "name_canonical",
    "house",
    "constituency_id",
    "state_id",
    "term_start",
    "term_end",
    "allocated_limit",
    "source_row",
    "resolution_method",
    "resolution_confidence",
)


@dataclass
class ReferenceTables:
    """The Silver layer, plus what went wrong building it."""

    states: pd.DataFrame
    constituencies: pd.DataFrame
    mps: pd.DataFrame
    notes: list[dict[str, Any]] = field(default_factory=list)

    def note(self, code: str, detail: str, **extra: Any) -> None:
        self.notes.append({"code": code, "detail": detail, **extra})

    @property
    def summary(self) -> dict[str, int]:
        return {
            "states": len(self.states),
            "constituencies": len(self.constituencies),
            "mps": len(self.mps),
            "notes": len(self.notes),
        }


def _build_states(accepted: pd.DataFrame) -> pd.DataFrame:
    frame = (
        accepted.assign(
            name=lambda f: f["state_raw"].map(clean_display),
            name_canonical=lambda f: f["state_raw"].map(canonical_state),
        )
        .groupby("name_canonical", as_index=False)
        .agg(name=("name", "first"), ls_seats=("name", "size"))
        .sort_values("name")
        .reset_index(drop=True)
    )
    frame.insert(0, "state_id", range(1, len(frame) + 1))
    return frame[list(STATE_COLUMNS)]


def _build_constituencies(
    accepted: pd.DataFrame, states: pd.DataFrame, parsed: list[ParsedConstituency]
) -> pd.DataFrame:
    state_ids = dict(zip(states["name_canonical"], states["state_id"], strict=True))

    rows: list[dict[str, Any]] = []
    for parsed_name, state_raw in zip(parsed, accepted["state_raw"], strict=True):
        # A state hint in the constituency name (AURANGABAD_BR) exists to
        # disambiguate a collision, so it wins over the row's own state only
        # when the two disagree -- which they should not, and the quality
        # report says so if they do.
        state_key = canonical_state(state_raw)
        rows.append(
            {
                "state_id": state_ids.get(state_key),
                "name": parsed_name.name,
                "name_canonical": parsed_name.canonical,
                "house": "LS",
                "reservation": parsed_name.reservation.value,
                "reservation_source": parsed_name.reservation_source.value,
                "raw_name": parsed_name.raw,
                "state_hint": parsed_name.state_hint,
            }
        )

    frame = pd.DataFrame(rows)
    grouped = (
        frame.groupby(["state_id", "name_canonical"], as_index=False)
        .agg(
            name=("name", "first"),
            house=("house", "first"),
            reservation=("reservation", "first"),
            reservation_source=("reservation_source", "first"),
            raw_name=("raw_name", "first"),
            n_members=("name", "size"),
        )
        .sort_values(["state_id", "name"])
        .reset_index(drop=True)
    )
    grouped.insert(0, "constituency_id", range(1, len(grouped) + 1))
    return grouped[list(CONSTITUENCY_COLUMNS)]


def _build_mps(
    accepted: pd.DataFrame,
    states: pd.DataFrame,
    constituencies: pd.DataFrame,
    parsed: list[ParsedConstituency],
) -> pd.DataFrame:
    state_ids = dict(zip(states["name_canonical"], states["state_id"], strict=True))
    constituency_ids = {
        (int(row.state_id), row.name_canonical): int(row.constituency_id)
        for row in constituencies.itertuples(index=False)
    }

    rows: list[dict[str, Any]] = []
    for position, record in enumerate(accepted.itertuples(index=False)):
        state_id = state_ids.get(canonical_state(record.state_raw))
        constituency_id = constituency_ids.get((int(state_id), parsed[position].canonical))
        amount = record.allocated_amount_raw
        rows.append(
            {
                "name": clean_display(record.mp_name_raw),
                "name_canonical": canonical_person(record.mp_name_raw),
                "house": "LS",
                "constituency_id": constituency_id,
                "state_id": state_id,
                "term_start": EIGHTEENTH_LS_START,
                "term_end": None,
                "allocated_limit": None if pd.isna(amount) else float(amount),
                "source_row": int(record.source_row),
                # Exact because the source is authoritative for its own rows:
                # nothing here was fuzzy-matched against another dataset.
                "resolution_method": "exact",
                "resolution_confidence": 1.0,
            }
        )

    frame = pd.DataFrame(rows).sort_values("source_row").reset_index(drop=True)
    frame.insert(0, "mp_id", range(1, len(frame) + 1))
    return frame[list(MP_COLUMNS)]


def build_reference_tables(accepted: pd.DataFrame) -> ReferenceTables:
    """Turn accepted Bronze rows into the canonical reference tables."""
    if accepted.empty:
        raise ValueError("no accepted rows to build reference tables from")

    parsed = [parse_constituency(value) for value in accepted["constituency_raw"]]

    states = _build_states(accepted)
    constituencies = _build_constituencies(accepted, states, parsed)
    mps = _build_mps(accepted, states, constituencies, parsed)

    tables = ReferenceTables(states=states, constituencies=constituencies, mps=mps)

    # ---- D-02: a constituency is not a key ----
    contested = constituencies.loc[constituencies["n_members"] > 1]
    for row in contested.itertuples(index=False):
        members = mps.loc[mps["constituency_id"] == row.constituency_id, "name"].tolist()
        tables.note(
            "multiple_members_one_constituency",
            f"{row.name} has {row.n_members} members in this term ({', '.join(members)}). "
            "The source carries no dates to separate the terms, so both are stored with an "
            "open term. A by-election date from an external source is needed to close the "
            "first one.",
            constituency=row.name,
            members=members,
        )

    # ---- D-03: reservation status is partly unrecoverable ----
    counts = constituencies["reservation"].value_counts().to_dict()
    sc, st = int(counts.get("SC", 0)), int(counts.get("ST", 0))
    if (sc, st) != (84, 47):
        tables.note(
            "reservation_counts_below_allocation",
            f"Name markers identify {sc} SC and {st} ST constituencies against a "
            f"constitutional allocation of 84 and 47. About {84 - sc + 47 - st} reserved "
            "seats carry no marker and are indistinguishable from general seats in this "
            "source. Rows record reservation_source so an earmark check can tell an "
            "observed marker from an inferred absence.",
            sc_marked=sc,
            st_marked=st,
        )

    # ---- D-01: identifiable members with no allocation ----
    missing = mps.loc[mps["allocated_limit"].isna()]
    for row in missing.itertuples(index=False):
        tables.note(
            "missing_allocation",
            f"{row.name} has no allocated limit recorded. Kept as null rather than "
            "imputed; any utilisation percentage for this member is undefined.",
            mp=row.name,
            source_row=int(row.source_row),
        )

    # ---- integrity: nothing should have failed to join ----
    orphan_mps = int(mps["constituency_id"].isna().sum())
    if orphan_mps:
        tables.note(
            "unresolved_constituency",
            f"{orphan_mps} members could not be linked to a constituency.",
            count=orphan_mps,
        )

    duplicates = mps["name_canonical"].duplicated(keep=False)
    if bool(duplicates.any()):
        names = sorted(set(mps.loc[duplicates, "name"]))
        tables.note(
            "duplicate_member_names",
            f"{len(names)} members share a canonical name after normalisation: {names}. "
            "Verify these are genuinely different people before joining on name.",
            names=names,
        )

    return tables
