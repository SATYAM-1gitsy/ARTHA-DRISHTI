"""Name canonicalisation and constituency parsing.

The one real dataset records 311 MP names in ALL CAPS and 232 in mixed case
(audit finding D-04), embeds reservation status inside constituency names, and
disambiguates six collisions with a two-letter state suffix. None of that is
usable for joining until it is parsed, and all of it must be parsed the same
way in every module or the graph and duplicate detectors silently split one
entity into several.

Canonicalisation is lossy on purpose, so the original is always retained
alongside it. `display` is what an officer reads; `canonical` is what the
system joins on.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from enum import Enum

__all__ = [
    "Reservation",
    "ReservationSource",
    "ParsedConstituency",
    "canonical_key",
    "clean_display",
    "canonical_person",
    "parse_constituency",
    "canonical_state",
    "STATE_SUFFIXES",
    "HONORIFICS",
]

_WS = re.compile(r"\s+")
_PUNCT = re.compile(r"[^\w\s]", flags=re.UNICODE)
_RESERVATION = re.compile(r"\(\s*(SC|ST)\s*\)\s*$", flags=re.IGNORECASE)
_STATE_SUFFIX = re.compile(r"_([A-Z]{2})$")

# Titles carried inconsistently -- "DR. HEMANG JOSHI" and "Hemang Joshi" are
# one person, and a join on the raw string would miss that.
HONORIFICS: frozenset[str] = frozenset(
    {"dr", "shri", "smt", "prof", "adv", "mr", "mrs", "ms", "md", "sri", "kum"}
)

# The six constituency-name collisions the source disambiguates itself, and
# inconsistently: AURANGABAD_BR / AURANGABAD_MH but plain NANDED.
STATE_SUFFIXES: dict[str, str] = {
    "AP": "Andhra Pradesh",
    "AR": "Arunachal Pradesh",
    "AS": "Assam",
    "BR": "Bihar",
    "CG": "Chhattisgarh",
    "GA": "Goa",
    "GJ": "Gujarat",
    "HP": "Himachal Pradesh",
    "HR": "Haryana",
    "JH": "Jharkhand",
    "JK": "Jammu And Kashmir",
    "KA": "Karnataka",
    "KL": "Kerala",
    "MH": "Maharashtra",
    "ML": "Meghalaya",
    "MP": "Madhya Pradesh",
    "MN": "Manipur",
    "MZ": "Mizoram",
    "NL": "Nagaland",
    "OD": "Odisha",
    "PB": "Punjab",
    "RJ": "Rajasthan",
    "SK": "Sikkim",
    "TN": "Tamil Nadu",
    "TG": "Telangana",
    "TR": "Tripura",
    "UK": "Uttarakhand",
    "UP": "Uttar Pradesh",
    "WB": "West Bengal",
}


class Reservation(str, Enum):
    """Constituency reservation category."""

    SC = "SC"
    ST = "ST"
    GEN = "GEN"
    UNKNOWN = "UNKNOWN"


class ReservationSource(str, Enum):
    """How the reservation was determined -- provenance, not decoration.

    NAME_MARKER is reliable. INFERRED_ABSENT means the name carried no marker,
    which is *usually* general but is wrong for roughly five seats: the file
    tags 82 SC and 44 ST against a constitutional allocation of 84 and 47
    (audit finding D-03), and the missing ones cannot be identified from the
    name alone. Anything consuming reservation for an earmark check has to be
    able to see which of the two it is looking at.
    """

    NAME_MARKER = "name_marker"
    INFERRED_ABSENT = "inferred_absent"
    EXTERNAL_JOIN = "external_join"


def canonical_key(text: str | None) -> str:
    """Lowercase, punctuation-free, whitespace-collapsed. The join key."""
    if not text:
        return ""
    normalised = unicodedata.normalize("NFKC", str(text)).casefold()
    return _WS.sub(" ", _PUNCT.sub(" ", normalised)).strip()


def clean_display(text: str | None) -> str:
    """Tidy a name for display without destroying it.

    Collapses whitespace and normalises spacing around punctuation. Casing is
    left alone -- "C.M.RAMESH" is how the record reads, and silently
    title-casing it would misrepresent the source.
    """
    if not text:
        return ""
    cleaned = unicodedata.normalize("NFKC", str(text)).strip()
    cleaned = re.sub(r"\s*\.\s*", ". ", cleaned)
    cleaned = re.sub(r"\s*&\s*", " & ", cleaned)
    return _WS.sub(" ", cleaned).strip(" .")


def canonical_person(name: str | None) -> str:
    """Join key for a person, with honorifics and initial spacing removed.

    "DR. HEMANG JOSHI", "Dr Hemang Joshi" and "Hemang Joshi" all collapse to
    "hemang joshi". Initials are joined so "C.M.RAMESH", "C. M. Ramesh" and
    "CM Ramesh" agree.
    """
    key = canonical_key(name)
    if not key:
        return ""
    tokens = [t for t in key.split() if t not in HONORIFICS]
    if not tokens:
        return ""

    # Merge runs of single letters: ["c", "m", "ramesh"] -> ["cm", "ramesh"].
    merged: list[str] = []
    initials: list[str] = []
    for token in tokens:
        if len(token) == 1:
            initials.append(token)
            continue
        if initials:
            merged.append("".join(initials))
            initials = []
        merged.append(token)
    if initials:
        merged.append("".join(initials))
    return " ".join(merged)


def canonical_state(name: str | None) -> str:
    """Join key for a state or union territory."""
    return canonical_key(name)


@dataclass(frozen=True)
class ParsedConstituency:
    """A constituency name decomposed into its parts."""

    raw: str
    name: str
    reservation: Reservation
    reservation_source: ReservationSource
    state_hint: str | None = None

    @property
    def canonical(self) -> str:
        return canonical_key(self.name)

    @property
    def reservation_is_certain(self) -> bool:
        return self.reservation_source is not ReservationSource.INFERRED_ABSENT


def parse_constituency(raw: str | None) -> ParsedConstituency:
    """Split a constituency name into name, reservation and state hint.

        "NORTH WEST DELHI(SC)" -> name "NORTH WEST DELHI", reservation SC
        "AURANGABAD_BR"        -> name "AURANGABAD", state hint Bihar
        "TAMLUK"               -> name "TAMLUK", reservation GEN (inferred)

    An unmarked name yields GEN with source INFERRED_ABSENT rather than
    UNKNOWN: 412 of the 417 unmarked seats really are general, so calling them
    all unknown would make the earmark check useless. But the source field
    keeps the uncertainty visible, and the data-quality report names the exact
    discrepancy so nobody mistakes the inference for a fact.
    """
    original = str(raw or "").strip()
    if not original:
        return ParsedConstituency("", "", Reservation.UNKNOWN, ReservationSource.INFERRED_ABSENT)

    working = original
    reservation = Reservation.GEN
    source = ReservationSource.INFERRED_ABSENT

    match = _RESERVATION.search(working)
    if match:
        reservation = Reservation(match.group(1).upper())
        source = ReservationSource.NAME_MARKER
        working = working[: match.start()].strip()

    state_hint: str | None = None
    suffix = _STATE_SUFFIX.search(working)
    if suffix:
        state_hint = STATE_SUFFIXES.get(suffix.group(1).upper())
        working = working[: suffix.start()].strip()

    return ParsedConstituency(
        raw=original,
        name=clean_display(working),
        reservation=reservation,
        reservation_source=source,
        state_hint=state_hint,
    )
