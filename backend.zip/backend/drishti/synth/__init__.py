"""Synthetic MPLADS data: base population and injected anomalies.

Split deliberately. `generate()` produces a realistic anomaly-free population
anchored to the real allocation file; `inject()` applies the labelled patterns
on top. Keeping them apart means the normal population can be inspected on its
own, and no injection parameter can reach a data column by accident.
"""

from .generator import SynthDataset, generate, load_reference
from .inject import INJECTORS, InjectionReport, inject

__all__ = [
    "SynthDataset",
    "generate",
    "load_reference",
    "inject",
    "InjectionReport",
    "INJECTORS",
]
