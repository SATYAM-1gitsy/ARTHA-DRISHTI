"""Base population: realistic MPLADS records with no anomalies injected.

Anchored to the real spine from Block 3 -- 36 real states, 542 real
constituencies, and each member's actual allocated limit. That anchoring is
the difference between synthetic data that is defensible and synthetic data
that is invented: state seat counts, constituency names, reservation status
and per-member budgets all come from the published allocation file, and only
the transactional layer beneath them is generated.

Two things this file deliberately does *not* do:

* It injects nothing. Anomalies live in `inject.py`, so the normal population
  can be generated and inspected on its own, and so no injection parameter can
  leak into a base-population column by accident.
* It invents no district boundaries. MPLADS funds flow through a nodal
  district, which the source file does not carry, so districts are generated
  per state in proportion to seat count and marked as synthetic. Nothing
  downstream may present a district as a real administrative unit.

Determinism is a hard requirement: `seed=42` must reproduce byte-identical
frames, or no experiment comparing two models means anything.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Any

import numpy as np
import pandas as pd

from ..config import GenConfig, settings
from ..domain import AGENCY_TYPES, SECTORS, SOR_UNIT_COST, quantity_range
from ..encoders.corpus import TEMPLATES_EN, TEMPLATES_HI, WORK_HI
from ..transform.names import canonical_key

__all__ = ["SynthDataset", "generate", "load_reference", "FY_START_MONTH"]

# Indian fiscal year runs April to March.
FY_START_MONTH = 4
_TERM_START = date(2024, 6, 4)
_SCORING_DATE = date(2026, 4, 1)

# Districts per state, as a share of its Lok Sabha seats. India has roughly
# 780 districts across 543 constituencies, so slightly more than one per seat.
_DISTRICTS_PER_SEAT = 1.4

_VENDOR_SUFFIXES = ("Constructions", "Enterprises", "Infra", "Builders", "Works", "Traders")
_VENDOR_PREFIXES = (
    "Shree", "Maa", "Jai", "Sai", "Balaji", "Ganesh", "Krishna", "Anand",
    "Bharat", "Vishwa", "Om", "Nav", "Surya", "Ashok", "Laxmi", "Ratna",
)


@dataclass
class SynthDataset:
    """Every generated table, plus the provenance of the run that made it."""

    districts: pd.DataFrame
    agencies: pd.DataFrame
    vendors: pd.DataFrame
    works: pd.DataFrame
    payments: pd.DataFrame
    progress: pd.DataFrame
    assets: pd.DataFrame
    photos: pd.DataFrame
    labels: pd.DataFrame = field(default_factory=pd.DataFrame)
    config: dict[str, Any] = field(default_factory=dict)

    @property
    def tables(self) -> dict[str, pd.DataFrame]:
        return {
            "synth_district": self.districts,
            "synth_agency": self.agencies,
            "synth_vendor": self.vendors,
            "synth_work": self.works,
            "synth_payment": self.payments,
            "synth_progress": self.progress,
            "synth_asset": self.assets,
            "synth_photo": self.photos,
            "fraud_label": self.labels,
        }

    @property
    def summary(self) -> dict[str, int]:
        return {name: len(frame) for name, frame in self.tables.items()}


def load_reference() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Load the Silver reference tables produced by Block 3."""
    seeds = settings.paths.seeds
    missing = [
        name
        for name in ("silver_state", "silver_constituency", "silver_mp")
        if not (seeds / f"{name}.parquet").is_file()
    ]
    if missing:
        raise FileNotFoundError(
            f"reference tables not found: {missing}. Run `drishti ingest` first -- "
            "the generator is anchored to the real allocation file, not to invented geography."
        )
    return (
        pd.read_parquet(seeds / "silver_state.parquet"),
        pd.read_parquet(seeds / "silver_constituency.parquet"),
        pd.read_parquet(seeds / "silver_mp.parquet"),
    )


# --------------------------------------------------------------------------
# geography
# --------------------------------------------------------------------------
# Approximate centroid and spread per state, so generated coordinates land
# somewhere plausible rather than uniformly across the subcontinent. Coarse by
# design -- these are stand-ins for real boundaries, and `geo_method` records
# that anything derived from them is an approximation.
_STATE_CENTROIDS: dict[str, tuple[float, float]] = {
    "andhra pradesh": (15.9, 79.7), "arunachal pradesh": (28.2, 94.7),
    "assam": (26.2, 92.9), "bihar": (25.6, 85.1), "chhattisgarh": (21.3, 81.9),
    "goa": (15.3, 74.1), "gujarat": (22.6, 71.6), "haryana": (29.1, 76.1),
    "himachal pradesh": (31.9, 77.2), "jharkhand": (23.6, 85.3),
    "karnataka": (15.3, 75.7), "kerala": (10.5, 76.3),
    "madhya pradesh": (23.5, 78.7), "maharashtra": (19.7, 75.7),
    "manipur": (24.7, 93.9), "meghalaya": (25.5, 91.4), "mizoram": (23.2, 92.9),
    "nagaland": (26.2, 94.6), "odisha": (20.9, 85.1), "punjab": (31.1, 75.3),
    "rajasthan": (27.0, 74.2), "sikkim": (27.5, 88.5), "tamil nadu": (11.1, 78.7),
    "telangana": (18.1, 79.0), "tripura": (23.9, 91.7), "uttar pradesh": (26.8, 80.9),
    "uttarakhand": (30.1, 79.2), "west bengal": (22.9, 87.9), "delhi": (28.7, 77.1),
    "jammu and kashmir": (33.8, 76.6), "ladakh": (34.2, 77.6),
    "chandigarh": (30.7, 76.8), "puducherry": (11.9, 79.8),
    "andaman and nicobar islands": (11.7, 92.7), "lakshadweep": (10.6, 72.6),
    "the dadra and nagar haveli and daman and diu": (20.3, 73.0),
}
_DEFAULT_CENTROID = (22.0, 79.0)


def _centroid(state_name: str) -> tuple[float, float]:
    return _STATE_CENTROIDS.get(canonical_key(state_name), _DEFAULT_CENTROID)


def _build_districts(states: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    district_id = 1
    for state in states.itertuples(index=False):
        count = max(1, int(round(int(state.ls_seats) * _DISTRICTS_PER_SEAT)))
        base_lat, base_lon = _centroid(state.name)
        for index in range(count):
            # Spread districts around the state centroid; the box is the
            # point_in_bbox fallback used when no real polygon is loaded.
            lat = base_lat + float(rng.normal(0, 1.1))
            lon = base_lon + float(rng.normal(0, 1.1))
            rows.append(
                {
                    "district_id": district_id,
                    "state_id": int(state.state_id),
                    "state": state.name,
                    "name": f"{state.name} District {index + 1}",
                    "centroid_lat": round(lat, 5),
                    "centroid_lon": round(lon, 5),
                    "bbox_half_deg": 0.45,
                    "sc_pop_pct": round(float(rng.uniform(4, 28)), 2),
                    "st_pop_pct": round(float(rng.uniform(0, 22)), 2),
                    "is_synthetic": True,
                }
            )
            district_id += 1
    return pd.DataFrame(rows)


def _build_agencies(districts: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    agency_id = 1
    for district in districts.itertuples(index=False):
        # Between three and six agencies per district: enough for
        # concentration to be a meaningful signal, few enough to be realistic.
        for _ in range(int(rng.integers(3, 7))):
            agency_type = str(rng.choice(AGENCY_TYPES))
            rows.append(
                {
                    "agency_id": agency_id,
                    "district_id": int(district.district_id),
                    "state_id": int(district.state_id),
                    "name": f"{agency_type}, {district.name}",
                    "agency_type": agency_type,
                }
            )
            agency_id += 1
    return pd.DataFrame(rows)


def _build_vendors(
    districts: pd.DataFrame, per_district: int, rng: np.random.Generator
) -> pd.DataFrame:
    """Payees, scoped to a home district.

    Vendors were originally drawn uniformly across the whole country, which
    produced payees operating in a median of 17 states and 39 agencies. That is
    not a contractor, it is a random draw -- and it made the payee
    co-occurrence graph near-complete, so L3's clustering and community
    features carried no information at all (measured: 1 community, clustering
    range 0.415-0.443).
    
    A real MPLADS contractor works a handful of nearby districts. Each vendor
    gets a home district and is drawn preferentially from there, which gives
    the payee network the locality that makes its structure meaningful.
    """
    rows: list[dict[str, Any]] = []
    vendor_id = 1
    for district in districts.itertuples(index=False):
        for _ in range(per_district):
            prefix = str(rng.choice(_VENDOR_PREFIXES))
            suffix = str(rng.choice(_VENDOR_SUFFIXES))
            rows.append(
                {
                    "vendor_id": vendor_id,
                    "district_id": int(district.district_id),
                    "state_id": int(district.state_id),
                    "name": f"{prefix} {suffix}",
                    "gstin": f"{int(district.state_id):02d}AAAAA{vendor_id:04d}A1Z5",
                }
            )
            vendor_id += 1
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# works
# --------------------------------------------------------------------------
def _works_per_mp(mps: pd.DataFrame, target: int, rng: np.random.Generator) -> np.ndarray:
    """Allocate the work budget across members by their real entitlement.

    A member with a larger allocated limit funds more works. The one member
    with no recorded allocation (audit finding D-01) gets the median share
    rather than zero -- excluding them would silently drop a real member from
    every downstream table.
    """
    limits = mps["allocated_limit"].to_numpy(dtype=float)
    median_limit = float(np.nanmedian(limits))
    limits = np.where(np.isnan(limits), median_limit, limits)

    shares = limits / limits.sum()
    counts = np.maximum(1, np.round(shares * target).astype(int))
    # Jitter so every member does not have a suspiciously smooth work count.
    counts = np.maximum(1, counts + rng.integers(-2, 3, size=len(counts)))
    return counts


def _sanction_dates(count: int, rng: np.random.Generator) -> list[date]:
    """Sanction dates across the term, with a mild and *legitimate* year-end lift.

    Real government spending does rise before a fiscal year closes. The base
    population carries that ordinary seasonality so the injected
    `year_end_bunching` pattern has to be distinguishable from normal
    behaviour rather than from a flat baseline -- otherwise the detector is
    solving a problem that does not exist in the real world.
    """
    span_days = (_SCORING_DATE - _TERM_START).days - 30
    offsets = rng.integers(0, span_days, size=count).astype(float)
    dates: list[date] = []
    for offset in offsets:
        candidate = _TERM_START + timedelta(days=int(offset))
        if candidate.month == 3 and rng.random() < 0.25:
            candidate = candidate.replace(day=min(28, candidate.day + 2))
        dates.append(candidate)
    return dates


def _describe(
    place: str, work_type: str, ward: int, hindi: bool
) -> tuple[str, str]:
    """Compose a work description, in English or Devanagari.

    Reuses the templates the encoder benchmark already validated, so the
    generated corpus has the same script mix and token-length profile that L4
    was measured against. Returns the text and its language tag.
    """
    if hindi:
        template = TEMPLATES_HI[ward % len(TEMPLATES_HI)]
        return (
            template.format(place=place, work=WORK_HI.get(work_type, work_type), ward=ward),
            "hi",
        )
    template = TEMPLATES_EN[ward % len(TEMPLATES_EN)]
    return template.format(place=place, work=work_type.replace("_", " "), ward=ward), "en"


def _build_works(
    mps: pd.DataFrame,
    constituencies: pd.DataFrame,
    districts: pd.DataFrame,
    agencies: pd.DataFrame,
    config: GenConfig,
    rng: np.random.Generator,
) -> pd.DataFrame:
    counts = _works_per_mp(mps, config.n_works, rng)

    districts_by_state: dict[int, list[tuple[int, float, float, float]]] = {}
    for row in districts.itertuples(index=False):
        districts_by_state.setdefault(int(row.state_id), []).append(
            (int(row.district_id), row.centroid_lat, row.centroid_lon, row.bbox_half_deg)
        )
    agencies_by_district: dict[int, list[int]] = {}
    for row in agencies.itertuples(index=False):
        agencies_by_district.setdefault(int(row.district_id), []).append(int(row.agency_id))

    reservation = dict(
        zip(constituencies["constituency_id"], constituencies["reservation"], strict=True)
    )
    place_of = dict(
        zip(constituencies["constituency_id"], constituencies["name"], strict=True)
    )

    rows: list[dict[str, Any]] = []
    work_id = 1
    for position, member in enumerate(mps.itertuples(index=False)):
        state_id = int(member.state_id)
        pool = districts_by_state.get(state_id)
        if not pool:
            continue
        n = int(counts[position])
        dates = _sanction_dates(n, rng)
        member_reservation = reservation.get(member.constituency_id, "GEN")
        place = str(place_of.get(member.constituency_id, "Unknown")).title()

        for sanction_date in dates:
            district_id, lat, lon, half = pool[int(rng.integers(0, len(pool)))]
            agency_pool = agencies_by_district[district_id]
            sector = str(rng.choice(list(SECTORS)))
            work_type = str(rng.choice(SECTORS[sector]))

            benchmark = SOR_UNIT_COST[work_type].value
            # Log-normal spread around the benchmark: most works land near it,
            # a legitimate minority are genuinely expensive.
            unit_cost = float(benchmark * rng.lognormal(mean=0.0, sigma=0.28))
            low, high = quantity_range(work_type)
            quantity = float(np.round(rng.uniform(low, high), 1))
            sanctioned = float(np.round(unit_cost * quantity, 2))

            fiscal_year = sanction_date.year if sanction_date.month >= FY_START_MONTH else sanction_date.year - 1
            elapsed = (_SCORING_DATE - sanction_date).days

            ward = int(rng.integers(1, 31))
            description, language = _describe(
                place, work_type, ward, bool(rng.random() < 0.35)
            )

            rows.append(
                {
                    "work_id": work_id,
                    "mp_id": int(member.mp_id),
                    "constituency_id": int(member.constituency_id),
                    "district_id": district_id,
                    "state_id": state_id,
                    "agency_id": int(rng.choice(agency_pool)),
                    "sector": sector,
                    "work_type": work_type,
                    "description": description,
                    "description_lang": language,
                    "ward": ward,
                    "quantity": quantity,
                    "sanctioned_cost": sanctioned,
                    "estimated_cost": float(np.round(sanctioned * rng.uniform(0.88, 1.06), 2)),
                    "sanction_date": sanction_date,
                    "recommended_on": sanction_date - timedelta(days=int(rng.integers(15, 110))),
                    "expected_completion_date": sanction_date + timedelta(days=int(rng.integers(180, 540))),
                    "financial_year": fiscal_year,
                    "days_since_sanction": elapsed,
                    "latitude": round(float(lat + rng.uniform(-half, half)), 5),
                    "longitude": round(float(lon + rng.uniform(-half, half)), 5),
                    "is_sc_area": int(member_reservation == "SC" or rng.random() < 0.12),
                    "is_st_area": int(member_reservation == "ST" or rng.random() < 0.06),
                }
            )
            work_id += 1

    works = pd.DataFrame(rows)
    return _apply_execution(works, rng)


def _apply_execution(works: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    """Derive progress and status from elapsed time on an S-curve.

    Works do not progress linearly: they start slowly, accelerate, then taper.
    A logistic curve over the expected duration reproduces that, and it makes
    `spend_progress_gap` a meaningful signal rather than noise.
    """
    elapsed = works["days_since_sanction"].to_numpy(dtype=float)
    expected = (
        pd.to_datetime(works["expected_completion_date"]) - pd.to_datetime(works["sanction_date"])
    ).dt.days.to_numpy(dtype=float)

    fraction = np.clip(elapsed / np.maximum(expected, 1.0), 0.0, 3.0)
    # Steepness varies per work: some agencies simply move faster.
    steepness = rng.uniform(4.0, 8.0, size=len(works))
    progress = 100.0 / (1.0 + np.exp(-steepness * (fraction - 0.5)))
    progress = np.clip(progress + rng.normal(0, 6.0, size=len(works)), 0.0, 100.0)

    # A realistic minority stall or are abandoned outright.
    stalled = rng.random(len(works)) < 0.07
    progress = np.where(stalled, progress * rng.uniform(0.05, 0.35, size=len(works)), progress)

    status = np.where(
        progress >= 99.0, "completed",
        np.where(progress <= 1.0, "sanctioned",
                 np.where(stalled & (fraction > 1.5), "abandoned", "in_progress")),
    )

    works = works.copy()
    works["progress_pct"] = np.round(progress, 1)
    works["status"] = status
    works["actual_completion_date"] = pd.NaT
    completed = works["status"] == "completed"
    works.loc[completed, "actual_completion_date"] = pd.to_datetime(
        works.loc[completed, "sanction_date"]
    ) + pd.to_timedelta(
        (expected[completed.to_numpy()] * rng.uniform(0.8, 1.4, size=int(completed.sum()))).astype(int),
        unit="D",
    )
    return works


# --------------------------------------------------------------------------
# payments, progress, assets
# --------------------------------------------------------------------------
def _build_payments(
    works: pd.DataFrame, vendors: pd.DataFrame, rng: np.random.Generator
) -> pd.DataFrame:
    # Payees are drawn from the work's own district, occasionally from
    # elsewhere in the state, so the payee network has real locality rather
    # than being a uniform random graph.
    by_district: dict[int, np.ndarray] = {
        int(key): group["vendor_id"].to_numpy()
        for key, group in vendors.groupby("district_id")
    }
    by_state: dict[int, np.ndarray] = {
        int(key): group["vendor_id"].to_numpy()
        for key, group in vendors.groupby("state_id")
    }
    all_vendors = vendors["vendor_id"].to_numpy()

    rows: list[dict[str, Any]] = []
    payment_id = 1

    for work in works.itertuples(index=False):
        progress = float(work.progress_pct)
        if progress <= 0.5:
            continue

        # Expenditure tracks progress, with ordinary slippage in both directions.
        spent_fraction = float(np.clip(progress / 100.0 * rng.uniform(0.85, 1.12), 0.0, 1.15))
        total = float(work.sanctioned_cost) * spent_fraction
        if total <= 0:
            continue

        n_payments = int(np.clip(rng.integers(1, 6), 1, 6))
        # First payment is an advance more often than not, which is normal
        # practice; an advance is only suspicious when progress never follows.
        has_advance = rng.random() < 0.6
        weights = rng.dirichlet(np.ones(n_payments) * 2.0)
        amounts = np.round(total * weights, 2)
        # One work in five goes to a contractor from elsewhere in the state,
        # so the network is local without being disconnected.
        pool = by_district.get(int(work.district_id)) if rng.random() > 0.20 else None
        if pool is None or not len(pool):
            pool = by_state.get(int(work.state_id))
        if pool is None or not len(pool):
            pool = all_vendors
        vendor_id = int(rng.choice(pool))

        elapsed = int(work.days_since_sanction)
        offsets = np.sort(rng.integers(5, max(6, elapsed), size=n_payments))
        for index in range(n_payments):
            if index == 0:
                payment_type = "advance" if has_advance else "running"
            elif index == n_payments - 1 and work.status == "completed":
                payment_type = "final"
            else:
                payment_type = "running"
            rows.append(
                {
                    "payment_id": payment_id,
                    "work_id": int(work.work_id),
                    "vendor_id": vendor_id,
                    "amount": float(amounts[index]),
                    "payment_date": work.sanction_date + timedelta(days=int(offsets[index])),
                    "payment_type": payment_type,
                }
            )
            payment_id += 1
    return pd.DataFrame(rows)


def _build_progress(works: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    """Monotone progress updates approaching the work's current value."""
    rows: list[dict[str, Any]] = []
    update_id = 1
    for work in works.itertuples(index=False):
        elapsed = int(work.days_since_sanction)
        if elapsed < 45:
            continue
        n_updates = int(np.clip(elapsed // 75, 1, 8))
        final = float(work.progress_pct)
        offsets = np.sort(rng.integers(30, max(31, elapsed), size=n_updates))
        for index, offset in enumerate(offsets):
            share = (index + 1) / n_updates
            value = float(np.clip(final * share + rng.normal(0, 2.5), 0.0, 100.0))
            rows.append(
                {
                    "update_id": update_id,
                    "work_id": int(work.work_id),
                    "update_date": work.sanction_date + timedelta(days=int(offset)),
                    "progress_pct": round(value, 1),
                }
            )
            update_id += 1
    return pd.DataFrame(rows)


def _build_assets(
    works: pd.DataFrame, config: GenConfig, rng: np.random.Generator
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Assets and their photograph metadata.

    Metadata only -- there are no image files and none are invented (ADR-0002).
    `phash` and the EXIF coordinates are what L6 actually consumes, and both
    are synthesised here so duplicate-hash and geo-consistency checks have
    something real to run against.
    """
    asset_rows: list[dict[str, Any]] = []
    photo_rows: list[dict[str, Any]] = []
    asset_id = photo_id = 1

    for work in works.itertuples(index=False):
        if float(work.progress_pct) < 20.0:
            continue
        asset_rows.append(
            {
                "asset_id": asset_id,
                "work_id": int(work.work_id),
                "asset_type": work.work_type,
                "latitude": work.latitude,
                "longitude": work.longitude,
                "created_on": work.sanction_date + timedelta(days=int(work.days_since_sanction * 0.8)),
            }
        )

        # Photo coverage is imperfect in the real scheme; missing_rate is a
        # difficulty knob, not an accident.
        if rng.random() > config.missing_rate * 2.5:
            drift = 0.004
            photo_rows.append(
                {
                    "photo_id": photo_id,
                    "asset_id": asset_id,
                    "work_id": int(work.work_id),
                    "phash": f"{int(rng.integers(0, 2**32)):08x}{int(rng.integers(0, 2**32)):08x}",
                    "exif_lat": round(float(work.latitude + rng.normal(0, drift)), 6),
                    "exif_lon": round(float(work.longitude + rng.normal(0, drift)), 6),
                    "captured_on": work.sanction_date
                    + timedelta(days=int(work.days_since_sanction * 0.85)),
                }
            )
            photo_id += 1
        asset_id += 1

    return pd.DataFrame(asset_rows), pd.DataFrame(photo_rows)


# --------------------------------------------------------------------------
# entry point
# --------------------------------------------------------------------------
def generate(config: GenConfig | None = None) -> SynthDataset:
    """Generate the anomaly-free base population."""
    cfg = config or settings.gen
    rng = np.random.default_rng(cfg.seed)

    states, constituencies, mps = load_reference()

    districts = _build_districts(states, rng)
    agencies = _build_agencies(districts, rng)
    vendors = _build_vendors(districts, per_district=3, rng=rng)
    works = _build_works(mps, constituencies, districts, agencies, cfg, rng)
    payments = _build_payments(works, vendors, rng)
    progress = _build_progress(works, rng)
    assets, photos = _build_assets(works, cfg, rng)

    return SynthDataset(
        districts=districts,
        agencies=agencies,
        vendors=vendors,
        works=works,
        payments=payments,
        progress=progress,
        assets=assets,
        photos=photos,
        labels=pd.DataFrame(columns=["work_id", "pattern", "injected", "visibility", "severity", "source", "parameters"]),
        config={
            "seed": cfg.seed,
            "n_works_target": cfg.n_works,
            "inject_rate": cfg.inject_rate,
            "noise_level": cfg.noise_level,
            "missing_rate": cfg.missing_rate,
            "held_out_share": cfg.held_out_share,
            "anchored_to": "silver_state, silver_constituency, silver_mp",
        },
    )
