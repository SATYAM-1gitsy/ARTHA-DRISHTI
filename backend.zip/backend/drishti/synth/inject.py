"""Anomaly injection, and the ground truth it writes.

Kept strictly separate from `generator.py` so the base population can be
generated and inspected without anomalies, and so no injection parameter can
find its way into a data column by accident. Everything an injector knows
about what it did goes to `fraud_label` and nowhere else.

**The rule-visible / held-out split (audit finding R-03) is enforced here.**
If the generator injects `pre_sanction_payment` and L0 has a
`pre_sanction_payment` rule, recall on that pattern is ~1.0 by construction --
it measures a rule agreeing with its own injector, not detection. Held-out
patterns are injected but no detector may be written against them, so held-out
recall is the only figure in this project that carries a detection claim.

Injectors mutate rows in place on copies of the generated frames. Each returns
the work ids it touched plus the parameters it used, and the caller records
both in the label table.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import timedelta
from typing import Any

import numpy as np
import pandas as pd

from ..config import GenConfig, settings
from ..contracts.labels import LabelSource
from ..domain import (
    FRAUD_PATTERNS,
    INELIGIBLE_KEYWORDS,
    PER_WORK_CEILING,
    FraudPattern,
    PatternVisibility,
    held_out_patterns,
    rule_visible_patterns,
)
from .generator import FY_START_MONTH, SynthDataset

__all__ = ["InjectionReport", "inject", "INJECTORS"]

_BY_NAME: dict[str, FraudPattern] = {p.name: p for p in FRAUD_PATTERNS}


@dataclass
class InjectionReport:
    """What was injected, and how much of the population it touched."""

    labels: pd.DataFrame
    counts: dict[str, int]
    prevalence: float
    held_out_share: float

    def describe(self) -> str:
        lines = [
            f"injected {len(self.labels)} labels across {self.labels['work_id'].nunique()} works "
            f"({self.prevalence:.2%} of the population)",
            f"held-out share {self.held_out_share:.0%} -- the only quotable recall",
            "",
        ]
        for pattern, count in sorted(self.counts.items(), key=lambda kv: -kv[1]):
            visibility = _BY_NAME[pattern].visibility.value
            marker = "  " if visibility == "held_out" else " *"
            lines.append(f"  {marker} {pattern:<26} {count:>5}  {visibility}")
        lines.append("")
        lines.append("  * rule-visible: a detector may be written against it. Recall on these")
        lines.append("    is a pipeline check, never a detection claim.")
        return "\n".join(lines)


# --------------------------------------------------------------------------
# injectors
# --------------------------------------------------------------------------
# Each takes (dataset, work_ids, rng) and returns the parameters it applied.
Injector = Callable[[SynthDataset, np.ndarray, np.random.Generator], dict[str, Any]]


def _inject_cost_inflation(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """Inflate unit cost well above comparable works, leaving quantity intact."""
    multipliers = rng.uniform(1.6, 3.2, size=len(work_ids))
    mask = data.works["work_id"].isin(work_ids)
    order = data.works.loc[mask].index
    data.works.loc[order, "sanctioned_cost"] = np.round(
        data.works.loc[order, "sanctioned_cost"].to_numpy() * multipliers, 2
    )
    return {"multiplier_range": [1.6, 3.2]}


def _inject_pre_sanction_payment(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """Move the earliest payment to before the work was sanctioned."""
    sanctions = dict(zip(data.works["work_id"], data.works["sanction_date"], strict=True))
    payments = data.payments
    touched = 0
    for work_id in work_ids:
        rows = payments.index[payments["work_id"] == work_id]
        if not len(rows):
            continue
        first = rows[0]
        lead = int(rng.integers(5, 60))
        payments.loc[first, "payment_date"] = sanctions[work_id] - timedelta(days=lead)
        touched += 1
    return {"lead_days_range": [5, 60], "works_with_payments": touched}


def _inject_ghost_work(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """Reported complete and paid, with no asset or photograph behind it."""
    mask = data.works["work_id"].isin(work_ids)
    data.works.loc[mask, "progress_pct"] = 100.0
    data.works.loc[mask, "status"] = "completed"
    data.assets.drop(data.assets.index[data.assets["work_id"].isin(work_ids)], inplace=True)
    data.photos.drop(data.photos.index[data.photos["work_id"].isin(work_ids)], inplace=True)
    return {"asset_removed": True, "photo_removed": True}


def _inject_duplicate_work(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """Clone another work in the same district, in one of three flavours.

    An earlier version copied the description verbatim. That made the pattern
    trivial -- TF-IDF matched every pair at similarity 1.00 -- and, worse, it
    meant the benchmark never tested the one capability the multilingual
    encoder exists for. A duplicate you can find with string equality does not
    justify a transformer.

    Three flavours in roughly equal measure, modelling how a work actually
    gets recorded twice:

      verbatim     the same text re-entered. Easy, and genuinely common.
      paraphrase   reworded in the same language: a different clerk, same work.
      translated   recorded in the other language. Lexical similarity for
                   these is about 0.04, so *only* a semantic model finds them.

    Both halves of every pair are labelled -- an investigator shown one half
    of a duplicate cannot act on it.
    """
    from .generator import _describe

    works = data.works
    labelled: list[int] = []
    flavours: list[str] = []

    for work_id in work_ids:
        row = works.index[works["work_id"] == work_id]
        if not len(row):
            continue
        target = works.loc[row[0]]
        siblings = works.index[
            (works["district_id"] == target["district_id"]) & (works["work_id"] != work_id)
        ]
        if not len(siblings):
            continue
        twin = siblings[int(rng.integers(0, len(siblings)))]

        flavour = ("verbatim", "paraphrase", "translated")[int(rng.integers(0, 3))]
        place = str(target["description"]).split(" in ")[-1].split(",")[0][:40] or "Ward"
        ward = int(target["ward"]) if "ward" in works.columns else 1

        if flavour == "verbatim":
            description = str(target["description"])
            language = str(target["description_lang"])
        else:
            # translated flips the script; paraphrase keeps it and relies on
            # the template rotation to reword.
            hindi = (
                str(target["description_lang"]) != "hi"
                if flavour == "translated"
                else str(target["description_lang"]) == "hi"
            )
            offset = 0 if flavour == "translated" else int(rng.integers(1, 4))
            description, language = _describe(
                place, str(target["work_type"]), ward + offset, hindi
            )

        works.loc[twin, "description"] = description
        works.loc[twin, "description_lang"] = language
        works.loc[twin, "work_type"] = target["work_type"]
        works.loc[twin, "sector"] = target["sector"]
        works.loc[twin, "latitude"] = float(target["latitude"]) + float(rng.normal(0, 0.002))
        works.loc[twin, "longitude"] = float(target["longitude"]) + float(rng.normal(0, 0.002))
        labelled.append(int(works.loc[twin, "work_id"]))
        flavours.append(flavour)

    counts: dict[str, int] = {}
    for flavour in flavours:
        counts[flavour] = counts.get(flavour, 0) + 1
    return {
        "geo_jitter_deg": 0.002,
        "flavours": counts,
        "twin_work_ids": labelled,
    }


def _inject_advance_without_progress(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """A large advance released, then progress never follows."""
    mask = data.works["work_id"].isin(work_ids)
    data.works.loc[mask, "progress_pct"] = np.round(rng.uniform(0.0, 3.0, size=int(mask.sum())), 1)
    data.works.loc[mask, "status"] = "in_progress"

    payments = data.payments
    rows = payments.index[payments["work_id"].isin(work_ids)]
    payments.loc[rows, "payment_type"] = "advance"

    updates = data.progress
    stale = updates.index[updates["work_id"].isin(work_ids)]
    updates.loc[stale, "progress_pct"] = np.round(rng.uniform(0.0, 3.0, size=len(stale)), 1)
    return {"progress_ceiling_pct": 3.0}


def _inject_agency_concentration(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """Route most of a district's works to a single agency.

    This anomaly only exists in the aggregate, so it is district-level: every
    work in a captured district is genuinely affected and must be labelled.

    That makes it the one pattern that can blow up the label budget. Capturing
    one district per target work produced 2063 labels against a budget of
    ~90 -- 61% of the whole ground-truth set -- which would let a model that
    learned nothing but agency share look excellent. So `work_ids` is read as
    a *budget* here, not as a list of targets: districts are captured until
    roughly that many works are affected, and then it stops.
    """
    works = data.works
    budget = len(work_ids)
    if budget == 0:
        return {"captured_work_ids": []}

    # Prefer districts large enough for concentration to be measurable.
    sizes = works.groupby("district_id").size()
    # copy(): a pandas Index exposes a read-only array, which shuffle rejects.
    eligible = sizes[sizes >= 8].index.to_numpy().copy()
    if not len(eligible):
        return {"captured_work_ids": []}
    rng.shuffle(eligible)

    share = float(rng.uniform(0.65, 0.85))
    captured: list[int] = []
    districts_used = 0

    for district_id in eligible:
        if len(captured) >= budget:
            break
        rows = works.index[works["district_id"] == district_id]
        agencies = works.loc[rows, "agency_id"].unique()
        hub = int(agencies[int(rng.integers(0, len(agencies)))])
        chosen = rng.choice(rows, size=max(1, int(len(rows) * share)), replace=False)
        works.loc[chosen, "agency_id"] = hub
        captured.extend(int(w) for w in works.loc[chosen, "work_id"])
        districts_used += 1

    return {
        "target_share": round(share, 3),
        "districts_captured": districts_used,
        "captured_work_ids": captured,
    }


def _inject_ineligible_work(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """Rewrite the description into a category outside the scheme's scope."""
    categories = list(INELIGIBLE_KEYWORDS)
    works = data.works
    used: list[str] = []
    for work_id in work_ids:
        rows = works.index[works["work_id"] == work_id]
        if not len(rows):
            continue
        category = categories[int(rng.integers(0, len(categories)))]
        keyword = INELIGIBLE_KEYWORDS[category][
            int(rng.integers(0, len(INELIGIBLE_KEYWORDS[category])))
        ]
        works.loc[rows[0], "description"] = f"Construction of boundary wall for the {keyword}"
        works.loc[rows[0], "description_lang"] = "en"
        used.append(category)
    return {"categories_used": sorted(set(used))}


def _inject_split_payment(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """Replace payments with many small ones summing just under the ceiling."""
    ceiling = PER_WORK_CEILING.value
    payments = data.payments
    sanctions = dict(zip(data.works["work_id"], data.works["sanction_date"], strict=True))
    new_rows: list[dict[str, Any]] = []
    next_id = int(payments["payment_id"].max()) + 1 if len(payments) else 1

    for work_id in work_ids:
        rows = payments.index[payments["work_id"] == work_id]
        if not len(rows):
            continue
        vendor_id = int(payments.loc[rows[0], "vendor_id"])
        payments.drop(rows, inplace=True)

        total = float(ceiling * rng.uniform(0.93, 0.99))
        count = int(rng.integers(6, 11))
        weights = rng.dirichlet(np.ones(count) * 8.0)
        offsets = np.sort(rng.integers(10, 120, size=count))
        for index in range(count):
            new_rows.append(
                {
                    "payment_id": next_id,
                    "work_id": int(work_id),
                    "vendor_id": vendor_id,
                    "amount": round(float(total * weights[index]), 2),
                    "payment_date": sanctions[work_id] + timedelta(days=int(offsets[index])),
                    "payment_type": "running",
                }
            )
            next_id += 1

    if new_rows:
        data.payments = pd.concat([payments, pd.DataFrame(new_rows)], ignore_index=True)
    return {"ceiling": ceiling, "fraction_of_ceiling": [0.93, 0.99]}


# ---- held-out patterns: no detector may be written against these ----
def _inject_vendor_round_tripping(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """Cycle payments among a small closed set of related payees."""
    vendors = data.vendors["vendor_id"].to_numpy()
    ring = rng.choice(vendors, size=int(rng.integers(3, 6)), replace=False)
    payments = data.payments
    rows = payments.index[payments["work_id"].isin(work_ids)]
    payments.loc[rows, "vendor_id"] = [
        int(ring[i % len(ring)]) for i in range(len(rows))
    ]
    return {"ring_size": int(len(ring)), "ring": [int(v) for v in ring]}


def _inject_year_end_bunching(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """Pull sanctions into the closing weeks of the fiscal year.

    **The whole timeline shifts together.** An earlier version moved
    `sanction_date` alone, leaving `recommended_on` and the payments where they
    were, and that manufactured two violations this pattern does not mean:

    * the recommendation-to-sanction lag jumped to a median 245 days against 62
      elsewhere -- the 100th percentile of its own peer distribution -- so
      `sanction_delay_above_peers` recovered the pattern at recall 0.863; and
    * 73.7% of injected works ended up with a payment dated before their new
      sanction date, against a 0.6% baseline, so `pre_sanction_payment`
      recovered it at 0.737.

    Neither rule targets this pattern and neither was written against it. They
    were detecting what the injector did. Held-out recall of 83.2% was
    therefore measuring the generator, not detection -- R-03's failure mode
    arriving from the generator side instead of the rule side.

    Year-end bunching is a statement about *calendar position*, not about
    delay: a work recommended and executed perfectly normally, whose sanction
    happens to land in the closing days of March. Shifting every date for the
    work by the same delta changes exactly that and nothing else. Every
    interval -- recommendation to sanction, sanction to first payment, the
    progress cadence -- is preserved, so a detector has to find the calendar
    signal rather than a side effect.
    """
    works = data.works
    rows = works.index[works["work_id"].isin(work_ids)]

    date_columns = [
        column
        for column in (
            "sanction_date",
            "recommended_on",
            "expected_completion_date",
            "actual_completion_date",
        )
        if column in works.columns
    ]

    shifts: dict[int, pd.Timedelta] = {}
    for row in rows:
        current = works.loc[row, "sanction_date"]
        if pd.isna(current):
            continue
        fiscal_year = current.year if current.month >= FY_START_MONTH else current.year - 1
        target = current.replace(
            year=fiscal_year + 1, month=3, day=int(rng.integers(18, 31))
        )
        delta = target - current
        shifts[int(works.loc[row, "work_id"])] = delta
        for column in date_columns:
            value = works.loc[row, column]
            if pd.notna(value):
                works.loc[row, column] = value + delta

    # The dependent frames move by the same delta, which is what keeps
    # "paid before sanction" and "slow to sanction" out of the pattern.
    #
    # The whole column is converted before any row is shifted. These arrive as
    # object columns of `datetime.date`, and shifting only the touched rows
    # leaves `date` and `Timestamp` mixed in one object column -- which reads
    # back fine and then fails the moment anything sorts or groups on it.
    for frame, column in ((data.payments, "payment_date"), (data.progress, "update_date")):
        if frame is None or frame.empty or column not in frame.columns:
            continue
        offsets = frame["work_id"].map(shifts)
        touched = offsets.notna()
        if not touched.any():
            continue
        frame[column] = pd.to_datetime(frame[column])
        frame.loc[touched, column] = frame.loc[touched, column] + offsets[touched]

    return {"window": "March 18-30", "shifted": "whole timeline"}


def _inject_geographic_displacement(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """Move the asset well outside the district that sanctioned it."""
    works = data.works
    rows = works.index[works["work_id"].isin(work_ids)]
    offsets = rng.uniform(1.5, 4.0, size=len(rows)) * rng.choice([-1, 1], size=len(rows))
    works.loc[rows, "latitude"] = works.loc[rows, "latitude"].to_numpy() + offsets
    works.loc[rows, "longitude"] = works.loc[rows, "longitude"].to_numpy() + offsets
    return {"displacement_deg_range": [1.5, 4.0]}


def _inject_progress_reversal(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """Reported progress falls between updates, then recovers."""
    updates = data.progress
    reversed_count = 0
    for work_id in work_ids:
        rows = updates.index[updates["work_id"] == work_id]
        if len(rows) < 3:
            continue
        middle = rows[len(rows) // 2]
        updates.loc[middle, "progress_pct"] = round(
            float(updates.loc[middle, "progress_pct"]) * float(rng.uniform(0.3, 0.6)), 1
        )
        reversed_count += 1
    return {"works_with_enough_updates": reversed_count}


def _inject_photo_reuse(data: SynthDataset, work_ids: np.ndarray, rng) -> dict[str, Any]:
    """One photograph certifying several unrelated works."""
    photos = data.photos
    rows = photos.index[photos["work_id"].isin(work_ids)]
    if not len(rows):
        return {"reused": 0}
    shared = str(photos.loc[rows[0], "phash"])
    photos.loc[rows, "phash"] = shared
    return {"shared_phash": shared, "reused": int(len(rows))}


INJECTORS: dict[str, Injector] = {
    "cost_inflation": _inject_cost_inflation,
    "pre_sanction_payment": _inject_pre_sanction_payment,
    "ghost_work": _inject_ghost_work,
    "duplicate_work": _inject_duplicate_work,
    "advance_without_progress": _inject_advance_without_progress,
    "agency_concentration": _inject_agency_concentration,
    "ineligible_work": _inject_ineligible_work,
    "split_payment": _inject_split_payment,
    "vendor_round_tripping": _inject_vendor_round_tripping,
    "year_end_bunching": _inject_year_end_bunching,
    "geographic_displacement": _inject_geographic_displacement,
    "progress_reversal": _inject_progress_reversal,
    "photo_reuse": _inject_photo_reuse,
}


# --------------------------------------------------------------------------
# orchestration
# --------------------------------------------------------------------------
def _allocate_targets(
    work_ids: np.ndarray, config: GenConfig, rng: np.random.Generator
) -> dict[str, np.ndarray]:
    """Choose which works receive which pattern.

    `pattern_overlap` lets a work carry more than one pattern, which is what
    makes the benchmark hard: a real case rarely presents one clean signal,
    and a detector tuned on single-pattern works overstates its own precision.
    """
    visible = [p.name for p in rule_visible_patterns()]
    held = [p.name for p in held_out_patterns()]

    n_targets = max(len(visible) + len(held), int(len(work_ids) * config.inject_rate))
    chosen = rng.choice(work_ids, size=min(n_targets, len(work_ids)), replace=False)

    n_held = int(len(chosen) * config.held_out_share)
    held_pool, visible_pool = chosen[:n_held], chosen[n_held:]

    assignment: dict[str, list[int]] = {name: [] for name in visible + held}
    for pool, names in ((visible_pool, visible), (held_pool, held)):
        if not len(pool) or not names:
            continue
        for index, work_id in enumerate(pool):
            assignment[names[index % len(names)]].append(int(work_id))
            # Overlap: a second, different pattern on the same work.
            if rng.random() < config.pattern_overlap:
                other = names[int(rng.integers(0, len(names)))]
                if other != names[index % len(names)]:
                    assignment[other].append(int(work_id))

    return {name: np.array(ids, dtype=np.int64) for name, ids in assignment.items() if ids}


def inject(
    data: SynthDataset, config: GenConfig | None = None
) -> tuple[SynthDataset, InjectionReport]:
    """Apply every registered pattern and write the ground-truth table."""
    cfg = config or settings.gen
    # A separate stream from the generator's, so changing the injection rate
    # does not perturb the base population.
    rng = np.random.default_rng(cfg.seed + 1)

    work_ids = data.works["work_id"].to_numpy()
    assignment = _allocate_targets(work_ids, cfg, rng)

    label_rows: list[dict[str, Any]] = []
    counts: dict[str, int] = {}

    for pattern_name, targets in assignment.items():
        pattern = _BY_NAME[pattern_name]
        parameters = INJECTORS[pattern_name](data, targets, rng)

        # Some injectors touch works beyond the ones they were handed --
        # a duplicate has two halves, a captured district has many works --
        # and every affected work must be labelled or evaluation undercounts.
        extra = parameters.pop("twin_work_ids", None) or parameters.pop(
            "captured_work_ids", None
        )
        affected = set(int(w) for w in targets)
        if extra:
            affected |= {int(w) for w in extra}

        for work_id in sorted(affected):
            label_rows.append(
                {
                    "work_id": work_id,
                    "pattern": pattern_name,
                    "injected": True,
                    "visibility": pattern.visibility.value,
                    "severity": pattern.severity,
                    "source": LabelSource.SYNTHETIC_INJECTION.value,
                    "parameters": parameters,
                }
            )
        counts[pattern_name] = len(affected)

    labels = pd.DataFrame(label_rows)
    data.labels = labels

    # Recompute derived execution fields the injectors invalidated.
    data.works["days_since_sanction"] = (
        pd.Timestamp("2026-04-01") - pd.to_datetime(data.works["sanction_date"])
    ).dt.days
    data.works["financial_year"] = pd.to_datetime(data.works["sanction_date"]).apply(
        lambda d: d.year if d.month >= FY_START_MONTH else d.year - 1
    )

    n_affected = labels["work_id"].nunique() if len(labels) else 0
    held_labels = (
        int((labels["visibility"] == PatternVisibility.HELD_OUT.value).sum()) if len(labels) else 0
    )
    report = InjectionReport(
        labels=labels,
        counts=counts,
        prevalence=n_affected / len(work_ids) if len(work_ids) else 0.0,
        held_out_share=held_labels / len(labels) if len(labels) else 0.0,
    )
    return data, report
