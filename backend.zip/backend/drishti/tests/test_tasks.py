"""Tests for the async job layer.

Task bodies are tested by calling them directly -- no broker, no worker. That
is deliberate: a task should be a thin wrapper around a plain function, and if
it cannot be tested without Redis running then too much logic has leaked into
the wrapper.
"""

from __future__ import annotations

import pytest

from drishti.config import CeleryConfig
from drishti.tasks.jobs import TASK_NAMES, gpu_benchmark, gpu_probe, ping


class TestTaskRegistry:
    def test_allowlist_is_populated(self):
        assert TASK_NAMES

    def test_names_are_namespaced(self):
        # Unprefixed task names collide with anything else sharing the broker.
        for name in TASK_NAMES.values():
            assert name.startswith("drishti.")

    def test_registry_keys_match_callables(self):
        for key in ("ping", "gpu_probe", "gpu_benchmark"):
            assert key in TASK_NAMES


class TestPing:
    def test_returns_worker_identity(self):
        result = _call(ping)
        assert result["pong"] is True
        assert result["worker_host"]
        assert result["python"]


class TestGpuProbe:
    def test_reports_usability_as_a_bool(self):
        result = _call(gpu_probe)
        assert isinstance(result["usable"], bool)

    def test_includes_a_human_summary(self):
        assert len(_call(gpu_probe)["summary"]) > 10

    def test_is_json_serialisable(self):
        import json

        json.dumps(_call(gpu_probe))

    def test_names_the_worker_it_ran_on(self):
        # The whole point of this task: the api container has no GPU, so the
        # answer is only meaningful together with where it was produced.
        assert _call(gpu_probe)["worker_host"]


class TestGpuBenchmark:
    def test_produces_a_cpu_baseline_without_a_gpu(self):
        result = _call(gpu_benchmark, size=64, iterations=2)
        if "error" in result:
            pytest.skip("torch not installed in this environment")
        assert result["cpu_seconds"] > 0

    def test_speedup_is_none_when_cuda_is_unusable(self):
        result = _call(gpu_benchmark, size=64, iterations=2)
        if "error" in result:
            pytest.skip("torch not installed in this environment")
        if result["cuda_seconds"] is None:
            assert result["speedup"] is None
            assert "note" in result

    def test_rejects_degenerate_arguments(self):
        pytest.importorskip("torch", reason="validation happens after the torch import")
        with pytest.raises(ValueError, match="size must be"):
            _call(gpu_benchmark, size=1, iterations=1)

    def test_reports_missing_torch_as_data_not_an_exception(self):
        result = _call(gpu_benchmark, size=64, iterations=1)
        assert "error" in result or "cpu_seconds" in result


class TestCeleryConfig:
    def test_gpu_jobs_have_their_own_queue(self):
        # An 8 GB card cannot host two concurrent training jobs, so GPU work
        # must not share the default queue.
        config = CeleryConfig()
        assert config.gpu_queue != config.default_queue

    def test_soft_limit_precedes_hard_limit(self):
        config = CeleryConfig()
        assert config.task_soft_time_limit < config.task_time_limit

    def test_rejects_inverted_time_limits(self):
        with pytest.raises(ValueError, match="soft time limit"):
            CeleryConfig(task_time_limit=100, task_soft_time_limit=200)

    def test_rejects_zero_concurrency(self):
        with pytest.raises(ValueError, match="concurrency"):
            CeleryConfig(worker_concurrency=0)


def _call(task, **kwargs):
    """Invoke a task body directly, whether or not Celery wrapped it."""
    target = getattr(task, "run", task)
    return target(**kwargs)
