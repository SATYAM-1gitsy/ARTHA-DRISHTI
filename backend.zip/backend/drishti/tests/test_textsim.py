"""Tests for text normalization and similarity.

The Devanagari cases are not decoration: multilingual descriptions are a
headline project claim, and a normalizer that strips non-ASCII would delete
the Hindi text while every test on English strings still passed.
"""

from __future__ import annotations

import numpy as np
import pytest

from drishti.textsim import (
    TfidfLite,
    char_ngrams,
    cosine,
    jaccard,
    normalize_text,
    script_profile,
    token_set_ratio,
    tokens,
)

HINDI_ROAD = "ग्रामीण सड़क"  # gramin sadak


class TestNormalizeText:
    def test_lowercases_and_strips_punctuation(self):
        assert normalize_text("Village Road, Phase-II!") == "village road phase ii"

    def test_collapses_whitespace(self):
        assert normalize_text("  a \t\n b  ") == "a b"

    def test_handles_none_and_empty(self):
        assert normalize_text(None) == ""
        assert normalize_text("") == ""

    def test_preserves_devanagari(self):
        out = normalize_text(HINDI_ROAD)
        assert "सड़क" in out

    def test_mixed_script_survives(self):
        out = normalize_text(f"Construction of {HINDI_ROAD} - Ward 4")
        assert "construction" in out
        assert "सड़क" in out

    def test_normalizes_composed_and_decomposed_forms_equally(self):
        composed = "नि"          # NI as a single sequence
        decomposed = "न" + "ि"   # same, explicitly built
        assert normalize_text(composed) == normalize_text(decomposed)


class TestTokens:
    def test_splits_on_whitespace(self):
        assert tokens("Repair of village road") == ["repair", "of", "village", "road"]

    def test_empty_input(self):
        assert tokens(None) == []


class TestCharNgrams:
    def test_produces_padded_trigrams(self):
        grams = char_ngrams("ab", n=3)
        assert " ab" in grams

    def test_empty_input(self):
        assert char_ngrams("") == []


class TestJaccard:
    def test_identical_sets(self):
        assert jaccard(["a", "b"], ["b", "a"]) == 1.0

    def test_disjoint_sets(self):
        assert jaccard(["a"], ["b"]) == 0.0

    def test_two_empties_are_identical(self):
        assert jaccard([], []) == 1.0

    def test_one_empty_is_zero(self):
        assert jaccard(["a"], []) == 0.0


class TestTokenSetRatio:
    def test_identical_strings_score_one(self):
        assert token_set_ratio("village road", "village road") == pytest.approx(1.0)

    def test_word_order_is_ignored(self):
        assert token_set_ratio("road village", "village road") > 0.85

    def test_unrelated_strings_score_low(self):
        assert token_set_ratio("village road", "solar street light") < 0.25

    def test_near_duplicate_scores_high(self):
        a = "Construction of village road in Ward 4"
        b = "Construction of village road at Ward 4"
        assert token_set_ratio(a, b) > 0.7

    def test_spelling_drift_degrades_gracefully(self):
        # Character trigrams keep this above the unrelated-string floor.
        assert token_set_ratio("panchayat bhavan", "panchyat bhawan") > 0.3

    def test_cross_language_pair_scores_near_zero(self):
        # Documents the limitation that forces L4 to combine signals: a
        # lexical measure cannot see that these describe the same thing.
        assert token_set_ratio("village road", HINDI_ROAD) < 0.15

    def test_empty_handling(self):
        assert token_set_ratio(None, None) == 1.0
        assert token_set_ratio("road", None) == 0.0


class TestCosine:
    def test_identical_vectors(self):
        v = np.array([1.0, 2.0, 3.0])
        assert cosine(v, v) == pytest.approx(1.0)

    def test_orthogonal_vectors(self):
        assert cosine(np.array([1.0, 0.0]), np.array([0.0, 1.0])) == pytest.approx(0.0)

    def test_zero_vector_is_safe(self):
        assert cosine(np.zeros(3), np.array([1.0, 2.0, 3.0])) == 0.0

    def test_length_mismatch_raises(self):
        with pytest.raises(ValueError, match="equal lengths"):
            cosine(np.zeros(2), np.zeros(3))


class TestScriptProfile:
    def test_pure_latin(self):
        profile = script_profile("village road")
        assert profile["latin"] == pytest.approx(1.0)
        assert profile["devanagari"] == 0.0

    def test_pure_devanagari(self):
        profile = script_profile(HINDI_ROAD)
        assert profile["devanagari"] == pytest.approx(1.0)

    def test_mixed_script_splits(self):
        profile = script_profile(f"road {HINDI_ROAD}")
        assert 0.0 < profile["latin"] < 1.0
        assert 0.0 < profile["devanagari"] < 1.0
        assert sum(profile.values()) == pytest.approx(1.0)

    def test_digits_only_has_no_script(self):
        assert script_profile("12345") == {"latin": 0.0, "devanagari": 0.0, "other": 0.0}


class TestTfidfLite:
    CORPUS = [
        "Construction of village road in Ward 4",
        "Construction of village road at Ward 4",
        "Installation of solar street light",
        "Repair of community hall roof",
    ]

    def test_rows_are_l2_normalised(self):
        matrix = TfidfLite().fit_transform(self.CORPUS)
        norms = np.linalg.norm(matrix, axis=1)
        assert np.allclose(norms, 1.0)

    def test_near_duplicates_are_most_similar_pair(self):
        model = TfidfLite()
        matrix = model.fit_transform(self.CORPUS)
        sim = model.similarity_matrix(matrix)
        np.fill_diagonal(sim, -1.0)
        assert int(np.argmax(sim[0])) == 1

    def test_unrelated_pair_scores_below_duplicate_pair(self):
        model = TfidfLite()
        matrix = model.fit_transform(self.CORPUS)
        sim = model.similarity_matrix(matrix)
        assert sim[0, 1] > sim[0, 2]

    def test_vocabulary_is_deterministic_across_fits(self):
        first = TfidfLite().fit(self.CORPUS).vocabulary_
        second = TfidfLite().fit(self.CORPUS).vocabulary_
        assert first == second

    def test_transform_before_fit_raises(self):
        with pytest.raises(RuntimeError, match="before fit"):
            TfidfLite().transform(["anything"])

    def test_out_of_vocabulary_document_yields_zero_row(self):
        model = TfidfLite().fit(self.CORPUS)
        row = model.transform(["ग्राम"])[0]
        assert np.allclose(row, 0.0)
        assert cosine(row, model.transform([self.CORPUS[0]])[0]) == 0.0

    def test_min_df_filters_rare_terms(self):
        model = TfidfLite(min_df=2).fit(self.CORPUS)
        assert "solar" not in model.vocabulary_
        assert "construction" in model.vocabulary_

    def test_max_features_caps_vocabulary(self):
        model = TfidfLite(max_features=3).fit(self.CORPUS)
        assert len(model.vocabulary_) == 3

    def test_invalid_min_df_raises(self):
        with pytest.raises(ValueError, match="min_df"):
            TfidfLite(min_df=0)

    def test_similarity_matrix_rejects_non_2d(self):
        with pytest.raises(ValueError, match="2-D"):
            TfidfLite().similarity_matrix(np.zeros(4))

    def test_handles_devanagari_corpus(self):
        corpus = [HINDI_ROAD, HINDI_ROAD, "solar street light"]
        model = TfidfLite()
        matrix = model.fit_transform(corpus)
        assert cosine(matrix[0], matrix[1]) == pytest.approx(1.0)
        assert cosine(matrix[0], matrix[2]) == pytest.approx(0.0)
