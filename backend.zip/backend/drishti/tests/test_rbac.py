"""Roles and jurisdiction scoping — Blueprint §3, §12.

The property under test is the one §12 actually asks for: a District Authority
sees only its district. Scoping is applied to the *data*, so it holds on every
endpoint rather than on the ones somebody remembered to guard.
"""

from __future__ import annotations

import pytest
from fastapi import HTTPException

from drishti.api.rbac import (
    ANONYMOUS,
    Principal,
    Role,
    Scope,
    principal_from_headers,
    require_write,
)
from drishti.api.store import Store
from drishti.config import settings

READY = (settings.paths.out / "gold.parquet").is_file() and (
    settings.paths.out / "risk_score.parquet"
).is_file()


class TestRoles:
    def test_the_four_blueprint_stakeholders_exist(self):
        assert {r.value for r in Role} >= {"ministry", "state_nodal", "district", "mp"}

    def test_an_mp_does_not_adjudicate_their_own_portfolio(self):
        """The scheme separates recommending a work from reviewing it.

        An MP recommends; the District Authority sanctions and reviews. The
        product must not collapse that separation into one screen.
        """
        assert not Role.MP.can_review
        assert Role.DISTRICT.can_review
        assert Role.STATE_NODAL.can_review
        assert Role.MINISTRY.can_review

    def test_anonymous_cannot_write(self):
        """The read path is open in development; the write path is not."""
        assert not ANONYMOUS.can_review
        with pytest.raises(HTTPException) as exc:
            require_write(ANONYMOUS)
        assert exc.value.status_code == 403


class TestHeaderClaims:
    def test_no_role_header_is_anonymous(self):
        assert principal_from_headers(None, None, None, None, None).role is Role.ANONYMOUS

    def test_an_unknown_role_is_refused_not_downgraded(self):
        """A typo must not silently widen or narrow what a caller sees."""
        with pytest.raises(HTTPException) as exc:
            principal_from_headers("emperor", None, None, None, None)
        assert exc.value.status_code == 400

    @pytest.mark.parametrize(
        "role,header",
        [("state_nodal", "X-Drishti-State"), ("district", "X-Drishti-District"), ("mp", "X-Drishti-MP")],
    )
    def test_a_scoped_role_without_its_scope_is_refused(self, role, header):
        """Otherwise a missing claim reads as national access."""
        with pytest.raises(HTTPException) as exc:
            principal_from_headers(role, None, None, None, None)
        assert exc.value.status_code == 400
        assert header in exc.value.detail

    def test_ministry_is_unscoped(self):
        principal = principal_from_headers("ministry", None, None, None, None)
        assert principal.scope.is_national

    def test_a_district_claim_ignores_a_wider_one(self):
        """Honouring both would let a malformed pair widen rather than narrow."""
        principal = principal_from_headers("mp", "Kerala", 7, 42, None)
        assert principal.scope.mp_id == 42
        assert principal.scope.state is None


@pytest.fixture(scope="module")
def store():
    return Store.from_parquet()


@pytest.mark.skipif(not READY, reason="run the pipeline first")
class TestScopingNarrowsTheData:
    def test_national_scope_sees_everything(self, store):
        assert store.national_analytics(Scope())["kpis"]["n_works"] == len(store.features)

    def test_a_state_scope_sees_only_that_state(self, store):
        state = str(store.features["state"].iloc[0])
        frame = store.joined(Scope(state=state))
        assert len(frame) < len(store.features)
        assert set(frame["state"].unique()) == {state}

    def test_a_district_scope_sees_only_that_district(self, store):
        district = int(store.features["district_id"].iloc[0])
        frame = store.joined(Scope(district_id=district))
        assert set(frame["district_id"].unique()) == {district}

    def test_an_mp_scope_sees_only_their_works(self, store):
        mp_id = int(store.features["mp_id"].iloc[0])
        frame = store.joined(Scope(mp_id=mp_id))
        assert set(frame["mp_id"].unique()) == {mp_id}

    def test_the_same_endpoint_narrows_rather_than_refusing(self, store):
        """A district officer asking for national analytics gets their district.

        Refusing would mean the same dashboard code cannot serve four roles,
        which is the whole reason the Blueprint's four views are one engine.
        """
        district = int(store.features["district_id"].iloc[0])
        scoped = store.national_analytics(Scope(district_id=district))
        national = store.national_analytics(Scope())
        assert scoped["kpis"]["n_works"] < national["kpis"]["n_works"]
        assert scoped["scope"] == f"district {district}"

    def test_a_work_outside_scope_is_not_visible(self, store):
        district = int(store.features["district_id"].iloc[0])
        outside = store.features[store.features["district_id"] != district]
        other_work = int(outside["work_id"].iloc[0])
        assert not store.alert_row_visible(other_work, scope=Scope(district_id=district))

    def test_scope_describes_itself_for_the_audit_trail(self):
        assert Scope().describe() == "national"
        assert Scope(state="Kerala").describe() == "Kerala"
        assert Scope(district_id=7).describe() == "district 7"
        assert Scope(mp_id=42).describe() == "constituency of MP 42"


class TestPrincipalSerialisation:
    def test_principal_reports_what_it_may_do(self):
        principal = Principal(role=Role.DISTRICT, scope=Scope(district_id=7), subject="dc.pune")
        payload = principal.to_dict()
        assert payload["role"] == "district"
        assert payload["scope"] == "district 7"
        assert payload["can_review"] is True
