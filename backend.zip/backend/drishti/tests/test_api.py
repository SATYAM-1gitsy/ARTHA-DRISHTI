"""Tests for the walking-skeleton API.

The health contract is small but load-bearing: it is what proves, on day one,
that the frontend, the API and the environment are actually connected, and it
is where a teammate's silently CPU-only torch install becomes visible.
"""

from __future__ import annotations

import json

import pytest

fastapi = pytest.importorskip("fastapi", reason="fastapi not installed")
from fastapi.testclient import TestClient  # noqa: E402

from drishti import __version__  # noqa: E402
from drishti.api.app import app  # noqa: E402
from drishti.config import settings  # noqa: E402

client = TestClient(app)


class TestHealth:
    def test_returns_ok(self):
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json()["status"] == "ok"

    def test_reports_the_service_version(self):
        assert client.get("/health").json()["version"] == __version__

    def test_exposes_gpu_state(self):
        body = client.get("/health").json()
        assert isinstance(body["gpu_usable"], bool)
        assert body["accelerator"]

    def test_lists_available_fixtures(self):
        assert isinstance(client.get("/health").json()["fixtures_available"], list)

    def test_response_is_json_serialisable(self):
        json.dumps(client.get("/health").json())


class TestFixtureEndpoint:
    def test_unknown_fixture_returns_404(self):
        assert client.get("/api/fixtures/definitely_not_here").status_code == 404

    def test_rejects_path_traversal(self):
        response = client.get("/api/fixtures/..%2F..%2Fsecrets")
        assert response.status_code in (400, 404)

    def test_serves_a_committed_fixture(self, tmp_path):
        target = settings.paths.api / "smoke_test.json"
        target.write_text(json.dumps({"hello": "drishti"}), encoding="utf-8")
        try:
            response = client.get("/api/fixtures/smoke_test")
            assert response.status_code == 200
            assert response.json() == {"hello": "drishti"}
        finally:
            target.unlink(missing_ok=True)


class TestOpenAPI:
    def test_schema_is_generated(self):
        schema = client.get("/openapi.json")
        assert schema.status_code == 200
        assert "/health" in schema.json()["paths"]

    def test_description_states_the_system_does_not_issue_verdicts(self):
        # Not cosmetic: "flags for review, never a verdict" is a design
        # constraint the whole product rests on, and the API is where an
        # integrator reads it first.
        description = client.get("/openapi.json").json()["info"]["description"]
        assert "verdict" in description.lower()
