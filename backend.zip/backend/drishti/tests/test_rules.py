"""Tests for L0, the deterministic compliance engine.

Three groups, and the middle one is the reason this file is long.

**Per-rule unit tests** fire each rule on a crafted work. That is the Block 6
acceptance criterion, and it is what lets a threshold be retuned without fear.

**Governance tests** encode decisions that would otherwise decay into
convention: no rule may target a held-out pattern, every rule must carry a
citation, and `config.critical_rules` must name rules that actually exist.
That last one caught dead config escalating `ghost_no_asset`, which no rule
implements.

**Behavioural tests** check the engine itself -- abstention, saturation, and
the Seam B contract.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from drishti.config import settings
from drishti.contracts.gold import GOLD_COLUMNS
from drishti.contracts.layer import EvidenceFamily, Severity
from drishti.detect.rules import (
    FORBIDDEN_TARGETS,
    LAYER,
    RULES,
    SEVERITY_WEIGHT,
    Rule,
    evaluate_rules,
    run,
)
from drishti.domain import PER_WORK_CEILING, PatternVisibility, Provenance

BY_CODE = {rule.code: rule for rule in RULES}


def make_work(**overrides) -> pd.DataFrame:
    """A single compliant work. Override one field to trip one rule."""
    base = {
        "work_id": 1,
        "mp_id": 1,
        "agency_id": 1,
        "district_id": 1,
        "vendor_id": 1.0,
        "state": "Bihar",
        "constituency": "Somewhere",
        "sector": "roads_bridges",
        "work_type": "village_road",
        "financial_year": 2025,
        "estimated_cost": 900_000.0,
        "sanctioned_cost": 1_000_000.0,
        "expenditure_to_date": 500_000.0,
        "quantity": 700.0,
        "unit_cost": 1_428.57,
        "unit_cost_vs_sor": 1.02,
        "unit_cost_peer_percentile": 0.5,
        "cost_deviation_ratio": 0.5,
        "estimated_to_sanctioned_ratio": 1.1,
        "status": "in_progress",
        "progress_pct": 50.0,
        "spend_progress_gap": 0.0,
        "progress_velocity": 5.0,
        "progress_acceleration": 0.0,
        "recommended_on": pd.Timestamp("2025-01-01"),
        "sanction_date": pd.Timestamp("2025-02-01"),
        "expected_completion_date": pd.Timestamp("2026-02-01"),
        "actual_completion_date": pd.NaT,
        "days_since_sanction": 300.0,
        "days_recommendation_to_sanction": 31.0,
        "sanction_delay_peer_percentile": 0.5,
        "time_to_first_payment": 20.0,
        "is_year_end_sanction": 0,
        "n_payments": 3,
        "advance_ratio": 0.2,
        "payment_velocity": 50_000.0,
        "max_payment_gap_days": 40.0,
        "has_pre_sanction_payment": 0,
        "agency_district_share": 0.2,
        "agency_hhi": 0.2,
        "agency_centrality": 0.1,
        "mp_agency_affinity": 0.2,
        "n_works_same_agency": 5,
        "latitude": 25.0,
        "longitude": 85.0,
        "geo_in_district": 1,
        "geo_method": "bbox",
        "distance_to_district_centroid_km": 10.0,
        "description": "Construction of village road at Ward 4",
        "description_lang": "en",
        "description_length": 37,
        "photo_present": 1,
        "phash": "abc123",
        "phash_duplicate_count": 0,
        "exif_latitude": 25.0,
        "exif_longitude": 85.0,
        "exif_consistent": 1,
        "is_sc_area": 0,
        "is_st_area": 0,
        "mp_sc_share_pct": 20.0,
        "mp_st_share_pct": 10.0,
        "n_missing_fields": 0,
        "data_quality": 1.0,
    }
    base.update(overrides)
    # Any Gold column this fixture does not name defaults to "no data".
    #
    # It used to list all of them, which meant every Seam A addition broke
    # twenty rules tests at once -- twice in two blocks. Rules abstain on
    # missing inputs by design, so a column no rule reads is inert here, and a
    # column a *new* rule reads will make that rule abstain rather than
    # silently pass on a stray default.
    row = {column: np.nan for column in GOLD_COLUMNS}
    row.update({k: v for k, v in base.items() if k in row})
    return pd.DataFrame([row])[list(GOLD_COLUMNS)]


def fires(code: str, frame: pd.DataFrame) -> bool:
    hits, _ = evaluate_rules(frame)
    return bool(hits[code].iloc[0])


def abstains(code: str, frame: pd.DataFrame) -> bool:
    _, abstained = evaluate_rules(frame)
    return bool(abstained[code].iloc[0])


# ==========================================================================
# governance
# ==========================================================================
class TestGovernance:
    def test_no_rule_targets_a_held_out_pattern(self):
        """R-03. A rule here makes the only quotable recall a tautology."""
        offenders = [r.code for r in RULES if r.targets in FORBIDDEN_TARGETS]
        assert not offenders, f"rules targeting held-out patterns: {offenders}"

    def test_constructing_such_a_rule_is_rejected(self):
        with pytest.raises(ValueError, match="held-out"):
            Rule(
                code="geo_outside_district",
                description="d",
                family=EvidenceFamily.COMPLIANCE,
                severity=Severity.HIGH,
                provenance=Provenance.ASSUMED,
                citation="c",
                requires=("geo_in_district",),
                predicate=lambda f: f["geo_in_district"] == 0,
                reason=lambda r: "outside",
                targets="geographic_displacement",
            )

    def test_every_rule_carries_a_citation(self):
        for rule in RULES:
            assert rule.citation.strip(), f"{rule.code} has no citation"

    def test_a_rule_without_a_citation_is_rejected(self):
        with pytest.raises(ValueError, match="not evidence"):
            Rule(
                code="x",
                description="d",
                family=EvidenceFamily.FINANCIAL,
                severity=Severity.LOW,
                provenance=Provenance.ASSUMED,
                citation="   ",
                requires=(),
                predicate=lambda f: pd.Series([False] * len(f)),
                reason=lambda r: "n",
            )

    def test_assumed_rules_say_so_in_their_provenance_note(self):
        for rule in RULES:
            if rule.provenance is Provenance.ASSUMED:
                assert "assumption" in rule.provenance_note.lower()

    def test_rule_codes_are_unique(self):
        codes = [r.code for r in RULES]
        assert len(codes) == len(set(codes))

    def test_critical_rules_config_names_real_rules(self):
        """Caught dead config escalating a rule that does not exist."""
        unknown = [c for c in settings.fusion.critical_rules if c not in BY_CODE]
        assert not unknown, f"critical_rules names non-existent rules: {unknown}"

    def test_only_deterministic_precise_rules_escalate(self):
        """A low-precision rule must not force a critical band."""
        for code in settings.fusion.critical_rules:
            assert BY_CODE[code].severity is Severity.CRITICAL
            assert BY_CODE[code].provenance is not Provenance.ASSUMED

    def test_photo_rule_does_not_escalate(self):
        # 6.8% measured precision: absence of a photo screens, it does not prove.
        assert "completed_without_asset_photo" not in settings.fusion.critical_rules

    def test_rules_span_multiple_evidence_families(self):
        """R-01: corroboration needs independent families, not many rules."""
        assert len({r.family for r in RULES}) >= 4


# ==========================================================================
# one unit test per rule -- the acceptance criterion
# ==========================================================================
class TestEachRuleFires:
    def test_pre_sanction_payment(self):
        assert fires("pre_sanction_payment", make_work(has_pre_sanction_payment=1))
        assert not fires("pre_sanction_payment", make_work())

    def test_ceiling_breach(self):
        breach = PER_WORK_CEILING.value * 1.5
        assert fires("ceiling_breach", make_work(sanctioned_cost=breach))
        assert not fires("ceiling_breach", make_work(sanctioned_cost=PER_WORK_CEILING.value * 0.5))

    def test_unit_cost_above_peers(self):
        assert fires("unit_cost_above_peers", make_work(unit_cost_peer_percentile=0.995))
        assert not fires("unit_cost_above_peers", make_work(unit_cost_peer_percentile=0.90))

    def test_advance_without_progress(self):
        tripped = make_work(advance_ratio=0.9, progress_pct=1.0, days_since_sanction=200.0)
        assert fires("advance_without_progress", tripped)
        # All three conditions are required: a recent work is not yet stalled.
        assert not fires(
            "advance_without_progress",
            make_work(advance_ratio=0.9, progress_pct=1.0, days_since_sanction=30.0),
        )

    def test_spend_ahead_of_progress(self):
        assert fires("spend_ahead_of_progress", make_work(spend_progress_gap=60.0, progress_pct=20.0))
        assert not fires("spend_ahead_of_progress", make_work(spend_progress_gap=5.0))

    def test_completed_without_asset_photo(self):
        ghost = make_work(photo_present=0, progress_pct=100.0, expenditure_to_date=800_000.0)
        assert fires("completed_without_asset_photo", ghost)
        # A photo-less work that is not complete is not a ghost candidate.
        assert not fires("completed_without_asset_photo", make_work(photo_present=0, progress_pct=30.0))

    def test_split_payment_near_ceiling(self):
        near = PER_WORK_CEILING.value * 0.95
        assert fires("split_payment_near_ceiling", make_work(n_payments=8, expenditure_to_date=near))
        # Same total, few payments: not a split.
        assert not fires("split_payment_near_ceiling", make_work(n_payments=2, expenditure_to_date=near))

    def test_potentially_ineligible_description(self):
        assert fires(
            "potentially_ineligible_description",
            make_work(description="Construction of boundary wall for the village temple"),
        )
        assert not fires("potentially_ineligible_description", make_work())

    def test_agency_concentration(self):
        assert fires("agency_concentration", make_work(agency_district_share=0.8))
        assert not fires("agency_concentration", make_work(agency_district_share=0.3))

    def test_sanction_delay_above_peers(self):
        """Peer-relative, not an absolute window.

        The absolute 75-day version sat at the 64th percentile of its own
        distribution and fired on 36.1% of the corpus -- a rule cutting the
        middle of its data measures "typical", not "exceptional". A long delay
        that is *normal for its peers* must no longer fire.
        """
        assert fires(
            "sanction_delay_above_peers",
            make_work(days_recommendation_to_sanction=400.0, sanction_delay_peer_percentile=0.99),
        )
        assert not fires(
            "sanction_delay_above_peers",
            make_work(days_recommendation_to_sanction=400.0, sanction_delay_peer_percentile=0.50),
        )
        assert not fires(
            "sanction_delay_above_peers",
            make_work(days_recommendation_to_sanction=30.0, sanction_delay_peer_percentile=0.10),
        )

    def test_every_rule_has_a_test_here(self):
        """A rule with no unit test is a rule nobody can safely retune."""
        tested = {
            name.replace("test_", "")
            for name in dir(TestEachRuleFires)
            if name.startswith("test_") and name != "test_every_rule_has_a_test_here"
        }
        assert {r.code for r in RULES} <= tested


# ==========================================================================
# abstention
# ==========================================================================
class TestAbstention:
    def test_null_input_abstains_rather_than_passing(self):
        """"We cannot tell" is not "compliant"."""
        frame = make_work(unit_cost_peer_percentile=np.nan)
        assert abstains("unit_cost_above_peers", frame)
        assert not fires("unit_cost_above_peers", frame)

    def test_abstention_lowers_confidence(self):
        complete = run(make_work())[0]
        partial = run(make_work(unit_cost_peer_percentile=np.nan, agency_district_share=np.nan))[0]
        assert partial.confidence < complete.confidence

    def test_complete_data_gives_full_confidence(self):
        assert run(make_work())[0].confidence == pytest.approx(1.0)

    def test_abstention_count_is_reported(self):
        output = run(make_work(unit_cost_peer_percentile=np.nan))[0]
        assert output.factors["rules_abstained"] == 1

    def test_a_rule_never_fires_on_null_input(self):
        for rule in RULES:
            frame = make_work(**{column: np.nan for column in rule.requires})
            assert not fires(rule.code, frame), f"{rule.code} fired on null input"


# ==========================================================================
# scoring and Seam B
# ==========================================================================
class TestScoring:
    def test_no_hits_scores_zero(self):
        output = run(make_work())[0]
        assert output.score == 0.0
        assert output.reasons == ()

    def test_a_hit_produces_a_reason(self):
        output = run(make_work(has_pre_sanction_payment=1))[0]
        assert output.score > 0
        assert output.reasons

    def test_more_hits_score_higher(self):
        one = run(make_work(agency_district_share=0.8))[0]
        # The second hit is tripped through the peer percentile, not a raw day
        # count: `sanction_delay_above_peers` is peer-relative since Block 14.
        two = run(
            make_work(agency_district_share=0.8, sanction_delay_peer_percentile=0.99)
        )[0]
        assert two.score > one.score

    def test_score_saturates_below_one(self):
        everything = make_work(
            has_pre_sanction_payment=1,
            sanctioned_cost=PER_WORK_CEILING.value * 3,
            unit_cost_peer_percentile=0.999,
            advance_ratio=0.9,
            progress_pct=1.0,
            days_since_sanction=400.0,
            spend_progress_gap=80.0,
            agency_district_share=0.9,
            days_recommendation_to_sanction=300.0,
            description="boundary wall for the temple",
        )
        assert run(everything)[0].score <= 1.0

    def test_critical_outranks_many_low_severity_hits(self):
        critical = run(make_work(has_pre_sanction_payment=1))[0]
        low = run(make_work(days_recommendation_to_sanction=300.0))[0]
        assert critical.score > low.score

    def test_severity_weights_are_monotone(self):
        ordered = [SEVERITY_WEIGHT[s] for s in (Severity.LOW, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL)]
        assert ordered == sorted(ordered)


class TestSeamB:
    def test_emits_the_declared_layer(self):
        assert run(make_work())[0].layer == LAYER

    def test_emits_one_row_per_work_including_silent_ones(self):
        frame = pd.concat([make_work(work_id=1), make_work(work_id=2, has_pre_sanction_payment=1)])
        outputs = run(frame)
        assert len(outputs) == 2
        assert {o.work_id for o in outputs} == {1, 2}

    def test_scores_are_bounded(self):
        for output in run(make_work(has_pre_sanction_payment=1)):
            assert 0.0 <= output.score <= 1.0
            assert 0.0 <= output.confidence <= 1.0

    def test_reasons_carry_provenance(self):
        output = run(make_work(sanctioned_cost=PER_WORK_CEILING.value * 2))[0]
        reason = next(r for r in output.reasons if r.code == "ceiling_breach")
        assert reason.provenance == Provenance.ASSUMED.value
        assert "assumption" in reason.factors["provenance_note"].lower()

    def test_reasons_are_human_readable(self):
        output = run(make_work(agency_district_share=0.8))[0]
        text = output.reasons[0].text
        assert len(text) > 30
        assert "%" in text

    def test_reason_text_states_an_observation_not_a_verdict(self):
        output = run(make_work(has_pre_sanction_payment=1, description="boundary wall for the temple"))[0]
        for reason in output.reasons:
            lowered = reason.text.lower()
            assert "fraud" not in lowered
            assert "corrupt" not in lowered

    def test_ineligible_reason_defers_to_review(self):
        output = run(make_work(description="Construction of boundary wall for the village temple"))[0]
        reason = next(r for r in output.reasons if r.code == "potentially_ineligible_description")
        assert "review" in reason.text.lower()

    def test_photo_reason_admits_it_may_be_a_reporting_gap(self):
        output = run(make_work(photo_present=0, progress_pct=100.0, expenditure_to_date=500_000.0))[0]
        reason = next(r for r in output.reasons if r.code == "completed_without_asset_photo")
        assert "verification" in reason.text.lower()

    def test_factors_name_the_rules_that_fired(self):
        output = run(make_work(has_pre_sanction_payment=1))[0]
        assert output.factors["rule:pre_sanction_payment"] is True
        assert "pre_sanction_payment" in output.factors["rules_fired"]

    def test_output_is_json_serialisable(self):
        import json

        json.dumps(run(make_work(has_pre_sanction_payment=1))[0].to_row())


# ==========================================================================
# against the real Gold view
# ==========================================================================
GOLD = settings.paths.out / "gold.parquet"
LABELS = settings.paths.seeds / "fraud_label.parquet"


@pytest.fixture(scope="module")
def gold():
    return pd.read_parquet(GOLD)


@pytest.fixture(scope="module")
def labels():
    return pd.read_parquet(LABELS)


@pytest.mark.skipif(
    not (GOLD.is_file() and LABELS.is_file()),
    reason="run `drishti seed` then `drishti features` first",
)
class TestAgainstRealData:
    def test_no_rule_fires_on_nearly_everything(self, gold):
        """A rule that fires on most works is a threshold bug, not a finding.

        This caught ceiling_breach at 80%: the generator was drawing one
        quantity range for every work type, producing 455-unit hospitals.
        """
        hits, _ = evaluate_rules(gold)
        noisy = {code: float(hits[code].mean()) for code in hits.columns if hits[code].mean() > 0.5}
        assert not noisy, f"rules firing on over half the population: {noisy}"

    def test_each_targeted_rule_recovers_its_pattern(self, gold, labels):
        hits, _ = evaluate_rules(gold)
        for rule in RULES:
            if not rule.targets:
                continue
            targeted = set(labels.loc[labels["pattern"] == rule.targets, "work_id"])
            fired = set(hits.index[hits[rule.code]])
            recall = len(fired & targeted) / max(len(targeted), 1)
            assert recall > 0.4, f"{rule.code} recovers only {recall:.1%} of {rule.targets}"

    def test_runs_over_the_population_quickly(self, gold):
        import time

        start = time.perf_counter()
        evaluate_rules(gold)
        assert time.perf_counter() - start < 10.0

    def test_emits_one_output_per_work(self, gold):
        sample = gold.head(500)
        assert len(run(sample)) == 500


@pytest.mark.skipif(
    not (settings.paths.out / "gold.parquet").is_file(),
    reason="run the pipeline first",
)
class TestNoRuleSilentlyTargetsAHeldOutPattern:
    """The behavioural half of the R-03 safeguard.

    `Rule.__post_init__` catches a rule that *declares* a held-out target.
    It cannot catch one that does the same thing without saying so:

        Rule(code="geo_check", requires=("geo_in_district",),
             predicate=lambda f: f["geo_in_district"] == 0,
             targets=None)          # <- no exception, and no detection claim left

    Declaration is a promise; this measures behaviour. Every rule is scored
    against every held-out pattern on the real Gold view, and a rule that
    recovers one at a rate no general rule should reach has to be explained
    here or it fails.

    Labels are read at test time only. They never reach a detector, which is
    what makes this measurement legitimate rather than the leak it guards.
    """

    # Ordinary incidental overlap between an honest rule and a held-out pattern
    # tops out at 0.17 in the current corpus. The gate sits well above that and
    # well below the two known artifacts below, so it catches targeting without
    # firing on coincidence.
    MAX_INCIDENTAL_RECALL = 0.35

    # Pairs that exceed the gate for a measured, mechanical reason rather than
    # because a rule targets a pattern. Empty, and it should stay that way.
    #
    # It briefly held two entries. `_inject_year_end_bunching` used to move
    # `sanction_date` alone, leaving `recommended_on` and the payments behind,
    # which manufactured an inflated sanction lag and retroactively pre-sanction
    # payments -- so `sanction_delay_above_peers` and `pre_sanction_payment`
    # recovered the pattern at 0.863 and 0.737 without targeting it. The
    # injector now shifts the whole timeline together and both fell to 0.063 and
    # 0.000, which `test_the_known_artifacts_are_still_real` detected by
    # failing. An entry here is a debt, not a licence: it means a number is
    # being explained rather than earned.
    KNOWN_MECHANICAL: dict[tuple[str, str], str] = {}

    def test_no_undeclared_rule_recovers_a_held_out_pattern(self, gold, labels):
        held = labels[labels["visibility"] == PatternVisibility.HELD_OUT.value]
        if held.empty:
            pytest.skip("no held-out labels in this run")

        hits, _ = evaluate_rules(gold)
        work_ids = gold["work_id"].to_numpy()

        offenders: list[str] = []
        for pattern, group in held.groupby("pattern"):
            target = set(group["work_id"].astype(int))
            if not target:
                continue
            for code in hits.columns:
                fired = set(int(w) for w in work_ids[hits[code].fillna(False).to_numpy(dtype=bool)])
                recall = len(fired & target) / len(target)
                if recall <= self.MAX_INCIDENTAL_RECALL:
                    continue
                if (code, str(pattern)) in self.KNOWN_MECHANICAL:
                    continue
                offenders.append(f"{code} recovers {pattern} at recall {recall:.3f}")

        assert not offenders, (
            "a rule is recovering a held-out pattern at a rate that only targeting "
            "explains, which converts the project's only quotable recall figures "
            "into a tautology (R-03). Either the rule targets the pattern and must "
            "go, or the generator is manufacturing a side effect the rule legitimately "
            "detects -- in which case explain it in KNOWN_MECHANICAL with the "
            "measurement.\n  " + "\n  ".join(offenders)
        )

    def test_the_known_artifacts_are_still_real(self, gold, labels):
        """A recorded exception that stops being true is stale, and stale
        exceptions are how a real leak gets waved through later."""
        held = labels[labels["visibility"] == PatternVisibility.HELD_OUT.value]
        hits, _ = evaluate_rules(gold)
        work_ids = gold["work_id"].to_numpy()

        for (code, pattern), reason in self.KNOWN_MECHANICAL.items():
            if code not in hits.columns:
                continue
            target = set(held[held["pattern"] == pattern]["work_id"].astype(int))
            if not target:
                continue
            fired = set(int(w) for w in work_ids[hits[code].fillna(False).to_numpy(dtype=bool)])
            recall = len(fired & target) / len(target)
            assert recall > self.MAX_INCIDENTAL_RECALL, (
                f"{code}/{pattern} no longer exceeds the gate (recall {recall:.3f}) -- "
                f"the recorded reason was {reason!r}. If the injector was fixed, "
                "delete this entry so the gate protects the pair again."
            )

    def test_neither_known_artifact_declares_the_pattern(self):
        """The exceptions above must not become a back door.

        A rule may appear there for a measured, mechanical reason. It may never
        appear there *and* declare the pattern as its target -- that is the
        thing R-03 forbids outright.
        """
        by_code = {rule.code: rule for rule in RULES}
        for code, pattern in self.KNOWN_MECHANICAL:
            rule = by_code.get(code)
            if rule is not None:
                assert rule.targets != pattern
                assert rule.targets not in FORBIDDEN_TARGETS
