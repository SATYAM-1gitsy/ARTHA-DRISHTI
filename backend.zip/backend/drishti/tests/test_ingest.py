"""Tests for Bronze ingest, Silver reference tables and the quality report.

These run against the real allocation file, because it is committed and it is
the only real data the project has. That makes them slower than pure unit
tests and far more valuable: they assert on the actual defects (D-01 to D-04),
so a change to the parser that silently drops a member or imputes a missing
allocation fails here rather than in Block 4.
"""

from __future__ import annotations

import pandas as pd
import pytest

from drishti.config import settings
from drishti.ingest.allocation import (
    BRONZE_COLUMNS,
    IngestResult,
    ingest,
    read_allocation_file,
    validate_rows,
)
from drishti.pipeline import PostgresWrite, run_ingest, write_postgres
from drishti.quality import build_report
from drishti.transform.names import (
    STATE_SUFFIXES,
    Reservation,
    ReservationSource,
    canonical_key,
    canonical_person,
    clean_display,
    parse_constituency,
)
from drishti.transform.reference import (
    CONSTITUENCY_COLUMNS,
    EIGHTEENTH_LS_START,
    MP_COLUMNS,
    STATE_COLUMNS,
    build_reference_tables,
)

SOURCE = settings.paths.raw / "Allocated Limit for Honble MPs.xlsx"
pytestmark = pytest.mark.skipif(not SOURCE.is_file(), reason="allocation file not in data/raw")


@pytest.fixture(scope="module")
def result() -> IngestResult:
    return ingest()


@pytest.fixture(scope="module")
def tables(result: IngestResult):
    return build_reference_tables(result.accepted)


# ==========================================================================
# name parsing
# ==========================================================================
class TestCanonicalKey:
    def test_strips_case_and_punctuation(self):
        assert canonical_key("North-West Delhi (SC)") == "north west delhi sc"

    def test_handles_none(self):
        assert canonical_key(None) == ""

    def test_collapses_whitespace(self):
        assert canonical_key("  a   b  ") == "a b"


class TestCleanDisplay:
    def test_preserves_source_casing(self):
        # Title-casing "C.M.RAMESH" would misrepresent the record.
        assert clean_display("C.M.RAMESH").startswith("C.")

    def test_normalises_ampersand_spacing(self):
        assert clean_display("DADRA&NAGAR") == "DADRA & NAGAR"

    def test_empty_input(self):
        assert clean_display(None) == ""


class TestCanonicalPerson:
    def test_casing_difference_collapses(self):
        """D-04: 311 ALL-CAPS names against 232 mixed case."""
        assert canonical_person("CHAVAN VASANTRAO BALWANTRAO") == canonical_person(
            "Chavan Vasantrao Balwantrao"
        )

    def test_honorifics_are_dropped(self):
        assert canonical_person("DR. HEMANG JOSHI") == canonical_person("Hemang Joshi")

    def test_initials_are_joined_consistently(self):
        assert canonical_person("C.M.RAMESH") == canonical_person("C. M. Ramesh")

    def test_distinct_people_stay_distinct(self):
        # The two Nanded members share a surname; merging them would erase one.
        assert canonical_person("CHAVAN VASANTRAO BALWANTRAO") != canonical_person(
            "Ravindra Vasantrao Chavan"
        )

    def test_empty_input(self):
        assert canonical_person(None) == ""

    def test_honorific_only_name_yields_empty(self):
        assert canonical_person("Dr.") == ""


class TestParseConstituency:
    def test_extracts_sc_marker(self):
        parsed = parse_constituency("NORTH WEST DELHI(SC)")
        assert parsed.name == "NORTH WEST DELHI"
        assert parsed.reservation is Reservation.SC
        assert parsed.reservation_source is ReservationSource.NAME_MARKER
        assert parsed.reservation_is_certain

    def test_extracts_st_marker(self):
        assert parse_constituency("BASTAR(ST)").reservation is Reservation.ST

    def test_state_suffix_disambiguates_collisions(self):
        bihar = parse_constituency("AURANGABAD_BR")
        maharashtra = parse_constituency("AURANGABAD_MH")
        assert bihar.name == maharashtra.name == "AURANGABAD"
        assert bihar.state_hint == "Bihar"
        assert maharashtra.state_hint == "Maharashtra"

    def test_unmarked_name_is_general_but_flagged_as_inferred(self):
        """D-03: about five reserved seats carry no marker."""
        parsed = parse_constituency("TAMLUK")
        assert parsed.reservation is Reservation.GEN
        assert parsed.reservation_source is ReservationSource.INFERRED_ABSENT
        assert not parsed.reservation_is_certain

    def test_empty_input_is_unknown_not_general(self):
        assert parse_constituency("").reservation is Reservation.UNKNOWN

    def test_every_suffix_maps_to_a_state(self):
        assert all(STATE_SUFFIXES.values())


# ==========================================================================
# Bronze
# ==========================================================================
class TestReadAllocationFile:
    def test_reads_expected_row_count(self):
        frame, _ = read_allocation_file()
        assert len(frame) == 543, "the 18th Lok Sabha has 543 members"

    def test_has_the_bronze_columns(self):
        frame, _ = read_allocation_file()
        assert tuple(frame.columns) == BRONZE_COLUMNS

    def test_grand_total_is_removed_from_the_body(self):
        frame, total = read_allocation_file()
        assert total is not None
        assert not frame["sr_no"].astype(str).str.lower().eq("grand total").any()

    def test_row_hash_is_stable(self):
        first, _ = read_allocation_file()
        second, _ = read_allocation_file()
        assert first["row_hash"].tolist() == second["row_hash"].tolist()

    def test_missing_file_is_a_clear_error(self, tmp_path):
        with pytest.raises(FileNotFoundError, match="only real data"):
            read_allocation_file(tmp_path / "nope.xlsx")


class TestValidation:
    def test_all_real_rows_are_accepted(self, result: IngestResult):
        assert result.n_accepted == 543
        assert result.n_quarantined == 0

    def test_missing_allocation_is_flagged_not_rejected(self, result: IngestResult):
        """D-01: rejecting the row would lose a genuine member."""
        flagged = [i for i in result.flagged_issues if i.code == "missing_allocation"]
        assert len(flagged) == 1
        assert not flagged[0].rejected

    def test_totals_reconcile_with_the_source(self, result: IngestResult):
        assert result.reconciles() is True

    def test_unidentifiable_row_is_rejected(self):
        bronze = pd.DataFrame(
            {
                "source_row": [1],
                "sr_no": [1],
                "state_raw": [None],
                "mp_name_raw": ["Someone"],
                "constituency_raw": ["Somewhere"],
                "allocated_amount_raw": [100.0],
                "row_hash": ["abc"],
            }
        )
        outcome = validate_rows(bronze)
        assert outcome.n_quarantined == 1
        assert any(i.code == "missing_identifier" for i in outcome.issues)

    def test_negative_allocation_is_rejected(self):
        bronze = pd.DataFrame(
            {
                "source_row": [1],
                "sr_no": [1],
                "state_raw": ["Bihar"],
                "mp_name_raw": ["Someone"],
                "constituency_raw": ["Somewhere"],
                "allocated_amount_raw": [-5.0],
                "row_hash": ["abc"],
            }
        )
        assert validate_rows(bronze).n_quarantined == 1


# ==========================================================================
# Silver
# ==========================================================================
class TestReferenceTables:
    def test_table_shapes(self, tables):
        assert tuple(tables.states.columns) == STATE_COLUMNS
        assert tuple(tables.constituencies.columns) == CONSTITUENCY_COLUMNS
        assert tuple(tables.mps.columns) == MP_COLUMNS

    def test_counts_match_the_source(self, tables):
        """The Block 3 acceptance criterion."""
        assert len(tables.states) == 36
        assert len(tables.mps) == 543
        assert len(tables.constituencies) == 542

    def test_more_members_than_constituencies(self, tables):
        # Because one constituency has two members, not because of a bug.
        assert len(tables.mps) == len(tables.constituencies) + 1

    def test_state_seat_counts_match_reality(self, tables):
        seats = dict(zip(tables.states["name"], tables.states["ls_seats"], strict=True))
        assert seats["Uttar Pradesh"] == 80
        assert seats["Maharashtra"] == 49
        assert seats["West Bengal"] == 42

    def test_every_member_resolves_to_a_constituency(self, tables):
        assert tables.mps["constituency_id"].notna().all()

    def test_every_member_resolves_to_a_state(self, tables):
        assert tables.mps["state_id"].notna().all()

    def test_ids_are_unique(self, tables):
        for frame, column in (
            (tables.states, "state_id"),
            (tables.constituencies, "constituency_id"),
            (tables.mps, "mp_id"),
        ):
            assert not frame[column].duplicated().any()

    def test_term_start_is_the_eighteenth_lok_sabha(self, tables):
        assert (tables.mps["term_start"] == EIGHTEENTH_LS_START).all()

    def test_missing_allocation_stays_null(self, tables):
        """D-01: never imputed."""
        assert int(tables.mps["allocated_limit"].isna().sum()) == 1

    def test_reservation_markers_are_counted_from_the_source(self, tables):
        counts = tables.constituencies["reservation"].value_counts().to_dict()
        assert counts.get("SC") == 82
        assert counts.get("ST") == 44

    def test_reservation_source_distinguishes_observed_from_inferred(self, tables):
        """D-03: the earmark rule has to be able to tell these apart."""
        sources = set(tables.constituencies["reservation_source"])
        assert "name_marker" in sources
        assert "inferred_absent" in sources

    def test_empty_input_raises(self):
        with pytest.raises(ValueError, match="no accepted rows"):
            build_reference_tables(pd.DataFrame())


class TestQualityNotes:
    def test_reports_the_shared_constituency(self, tables):
        """D-02: a constituency is not a key."""
        notes = [n for n in tables.notes if n["code"] == "multiple_members_one_constituency"]
        assert len(notes) == 1
        assert notes[0]["constituency"] == "NANDED"
        assert len(notes[0]["members"]) == 2

    def test_reports_the_reservation_shortfall(self, tables):
        notes = [n for n in tables.notes if n["code"] == "reservation_counts_below_allocation"]
        assert len(notes) == 1
        assert notes[0]["sc_marked"] == 82 and notes[0]["st_marked"] == 44

    def test_reports_the_missing_allocation_by_name(self, tables):
        notes = [n for n in tables.notes if n["code"] == "missing_allocation"]
        assert len(notes) == 1
        assert "CHAVAN" in notes[0]["mp"].upper()

    def test_no_unresolved_joins(self, tables):
        assert not [n for n in tables.notes if n["code"] == "unresolved_constituency"]


# ==========================================================================
# report and pipeline
# ==========================================================================
class TestQualityReport:
    def test_is_usable(self, result, tables):
        assert build_report(result, tables).is_usable

    def test_acceptance_rate_is_total(self, result, tables):
        assert build_report(result, tables).acceptance_rate == pytest.approx(1.0)

    def test_records_the_reconciliation(self, result, tables):
        report = build_report(result, tables)
        assert report.reconciles is True
        assert report.declared_total == pytest.approx(report.computed_total, abs=0.01)

    def test_completeness_shows_the_allocation_gap(self, result, tables):
        completeness = build_report(result, tables).completeness
        assert completeness["allocated_amount_raw"] < 1.0
        assert completeness["mp_name_raw"] == pytest.approx(1.0)

    def test_reservation_completeness_is_visible(self, result, tables):
        # 126 of 542 carry a marker: the report must not hide that.
        value = build_report(result, tables).completeness["constituency_reservation_observed"]
        assert 0.2 < value < 0.3

    def test_render_names_the_unresolved_items(self, result, tables):
        rendered = build_report(result, tables).render()
        assert "NANDED" in rendered
        assert "reconciliation" in rendered

    def test_is_json_serialisable(self, result, tables, tmp_path):
        path = build_report(result, tables).write(tmp_path / "q.json")
        assert path.is_file() and path.stat().st_size > 0


class TestPipeline:
    def test_dry_run_writes_nothing(self):
        outcome = run_ingest(to_parquet=False, to_postgres=False)
        assert outcome.written == {}
        assert outcome.ok

    def test_writes_bronze_and_silver(self):
        outcome = run_ingest(to_parquet=True, to_postgres=False)
        for name in (
            "bronze_allocation",
            "bronze_quarantine",
            "silver_state",
            "silver_constituency",
            "silver_mp",
        ):
            assert name in outcome.written

    def test_parquet_round_trips(self):
        run_ingest(to_parquet=True, to_postgres=False)
        frame = pd.read_parquet(settings.paths.seeds / "silver_mp.parquet")
        assert len(frame) == 543

    def test_is_idempotent(self):
        first = run_ingest(to_parquet=True, to_postgres=False)
        second = run_ingest(to_parquet=True, to_postgres=False)
        assert first.tables.summary == second.tables.summary


class TestPostgresWrite:
    def test_reports_the_reason_when_unavailable(self, tables):
        """A bare 'unavailable' costs the next person the same debugging."""
        outcome = write_postgres(tables, url="postgresql+psycopg2://x:x@127.0.0.1:1/none")
        assert not outcome.ok
        assert outcome.error
        assert "skipped --" in outcome.describe()

    def test_success_describes_counts(self):
        assert PostgresWrite(counts={"state": 36}).describe() == "state=36"

    def test_defaults_to_empty_counts(self):
        assert PostgresWrite().counts == {}
