"""The analyst copilot — Blueprint §6, §10, §16.6.

The property under test is not "does it answer". It is that the copilot cannot
put a guideline in front of an officer that the guidelines do not contain, and
cannot issue the verdict the rest of the system refuses to issue.
"""

from __future__ import annotations

import pytest

from drishti.copilot import answer_question, get_corpus
from drishti.copilot.corpus import load_corpus
from drishti.copilot.service import SYSTEM_RULES, CopilotAnswer, api_key

CORPUS_READY = get_corpus().available


class TestCorpusHonesty:
    def test_an_absent_corpus_is_a_state_not_a_crash(self, tmp_path):
        corpus = load_corpus(tmp_path / "nothing")
        assert not corpus.available
        assert corpus.unavailable and "no guidelines corpus" in corpus.unavailable

    def test_a_pdf_without_extracted_text_is_reported(self, tmp_path):
        """A PDF alone is not searchable, and silence here would look like
        'the guidelines say nothing about that'."""
        (tmp_path / "guidelines.pdf").write_bytes(b"%PDF-1.4 not really")
        corpus = load_corpus(tmp_path)
        assert not corpus.available
        assert "no extracted text" in (corpus.unavailable or "")

    def test_with_no_corpus_the_copilot_refuses_rather_than_recalls(self, tmp_path, monkeypatch):
        """The failure mode that matters.

        Answering a guidelines question from model memory is how an invented
        clause reaches an investigator wearing the same authority as a real one.
        """
        import drishti.copilot.service as service

        monkeypatch.setattr(service, "get_corpus", lambda: load_corpus(tmp_path / "none"))
        answer = service.answer_question("What is the per-work ceiling?")
        assert answer.generated_by == "unavailable"
        assert not answer.sources
        assert "from memory" in answer.answer


@pytest.mark.skipif(not CORPUS_READY, reason="no guidelines corpus on disk")
class TestRetrievalIsCitable:
    def test_clauses_carry_their_paragraph_number_and_page(self):
        corpus = get_corpus()
        chunk = corpus.chunks[0]
        assert chunk.clause and chunk.page >= 1
        assert "Para" in chunk.citation

    def test_the_edition_comes_from_the_source_note_not_the_path(self):
        """The retrieved file sits under /uploads/2023/ and is the June 2016
        edition. Citing the path's year would be a false citation."""
        assert "2016" in get_corpus().source

    def test_it_finds_the_earmark_clause(self):
        hits = get_corpus().search("share earmarked for Scheduled Caste areas", k=3)
        assert hits
        assert any(chunk.clause.startswith("2.5") for chunk, _ in hits)

    def test_every_answer_carries_what_it_rests_on(self):
        answer = answer_question("What are the SC and ST earmarking requirements?")
        assert answer.sources
        assert all(source["citation"] for source in answer.sources)
        assert answer.corpus


class TestItNeverIssuesAVerdict:
    def test_the_disclaimer_is_on_every_answer(self):
        assert "not a finding" in CopilotAnswer(question="q", answer="a").disclaimer

    def test_the_model_is_forbidden_from_adjudicating(self):
        """The instruction is part of the contract, not a suggestion.

        A chat box is where 'flags for review, never a verdict' erodes first,
        because a model asked 'is this fraud?' will happily answer.
        """
        assert "does not" in SYSTEM_RULES and "verdicts" in SYSTEM_RULES
        assert "fraudulent" in SYSTEM_RULES
        assert "ONLY from the numbered guideline extracts" in SYSTEM_RULES

    def test_the_model_may_not_supply_clauses_of_its_own(self):
        assert "from your own knowledge" in SYSTEM_RULES


class TestDegradesWithoutAKey:
    def test_generation_is_optional(self, monkeypatch):
        """Retrieval is the substance; the model is a phrasing layer."""
        monkeypatch.delenv("GEMINI_API_KEY", raising=False)
        monkeypatch.delenv("LLM_API_KEY", raising=False)
        assert api_key() is None

    @pytest.mark.skipif(not CORPUS_READY, reason="no guidelines corpus on disk")
    def test_it_still_answers_and_says_how(self, monkeypatch):
        monkeypatch.delenv("GEMINI_API_KEY", raising=False)
        monkeypatch.delenv("LLM_API_KEY", raising=False)
        answer = answer_question("What are the SC earmarking requirements?")
        assert answer.generated_by == "retrieval"
        assert answer.sources
        # A reader is entitled to know whether a sentence was phrased by a
        # model or handed over verbatim.
        assert "GEMINI_API_KEY" in (answer.warning or "")

    def test_a_blank_key_counts_as_absent(self, monkeypatch):
        monkeypatch.setenv("GEMINI_API_KEY", "   ")
        monkeypatch.delenv("LLM_API_KEY", raising=False)
        assert api_key() is None


class _StubResponse:
    def __init__(self, status_code: int, payload: dict | None = None):
        self.status_code = status_code
        self._payload = payload or {}

    def json(self) -> dict:
        return self._payload


class _StubClient:
    """Captures the outbound request so its shape can be asserted.

    Stands in for `httpx.Client` so the Gemini path is exercised without a real
    key, a network, or a bill. The captured call is what proves the key travels
    as a header rather than a query string -- a key in a URL ends up in proxy
    logs and browser history.
    """

    captured: dict = {}

    def __init__(self, response: _StubResponse | Exception):
        self._response = response

    def __call__(self, *args, **kwargs):
        return self

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def post(self, url, headers=None, json=None):
        type(self).captured = {"url": url, "headers": headers or {}, "json": json or {}}
        if isinstance(self._response, Exception):
            raise self._response
        return self._response


def _gemini_saying(text: str) -> _StubResponse:
    return _StubResponse(200, {"candidates": [{"content": {"parts": [{"text": text}]}}]})


def _install(monkeypatch, response):
    """Point the service at a stub client with a fake key configured."""
    import httpx

    monkeypatch.setenv("GEMINI_API_KEY", "test-key-not-a-real-credential")
    monkeypatch.setattr(httpx, "Client", _StubClient(response))
    _StubClient.captured = {}


@pytest.mark.skipif(not CORPUS_READY, reason="no guidelines corpus on disk")
class TestGeminiIntegration:
    """The generation path, exercised without a real credential."""

    def test_a_configured_key_produces_a_phrased_answer(self, monkeypatch):
        _install(monkeypatch, _gemini_saying("Works must be sanctioned within 75 days (Para 3.12)."))
        answer = answer_question("How long to sanction a work?")
        assert answer.generated_by == "gemini"
        assert "75 days" in answer.answer
        assert answer.sources, "a phrased answer still carries the clauses it rests on"
        assert answer.warning is None

    def test_the_key_travels_as_a_header_not_a_query_string(self, monkeypatch):
        _install(monkeypatch, _gemini_saying("ok"))
        answer_question("What is the SC earmark?")
        captured = _StubClient.captured
        assert captured["headers"].get("x-goog-api-key") == "test-key-not-a-real-credential"
        assert "key=" not in captured["url"], "a key in a URL lands in proxy logs"

    def test_the_model_is_given_the_rules_and_the_extracts(self, monkeypatch):
        """It is told what the guidelines say; it is never asked."""
        _install(monkeypatch, _gemini_saying("ok"))
        answer_question("What is the SC earmark?")
        body = _StubClient.captured["json"]
        system = body["systemInstruction"]["parts"][0]["text"]
        assert "ONLY from the numbered guideline extracts" in system
        assert "fraudulent" in system
        prompt = body["contents"][0]["parts"][0]["text"]
        assert "Guideline extracts:" in prompt
        assert "Para" in prompt, "retrieved clauses are in the prompt, not left to memory"

    def test_temperature_is_low(self, monkeypatch):
        """Creative phrasing of a legal clause is not a feature."""
        _install(monkeypatch, _gemini_saying("ok"))
        answer_question("What is the SC earmark?")
        assert _StubClient.captured["json"]["generationConfig"]["temperature"] <= 0.2

    @pytest.mark.parametrize("status", [400, 401, 429, 500, 503])
    def test_an_api_failure_degrades_to_retrieval(self, monkeypatch, status):
        """A rate limit or a dead key must not take the endpoint down.

        The clauses are the substance; the model is a convenience.
        """
        _install(monkeypatch, _StubResponse(status))
        answer = answer_question("What is the SC earmark?")
        assert answer.generated_by == "retrieval"
        assert answer.sources
        assert "Para" in answer.answer

    def test_a_network_error_degrades_to_retrieval(self, monkeypatch):
        _install(monkeypatch, ConnectionError("no route to host"))
        answer = answer_question("What is the SC earmark?")
        assert answer.generated_by == "retrieval"
        assert answer.sources

    def test_an_empty_candidate_list_degrades_rather_than_answering_blank(self, monkeypatch):
        _install(monkeypatch, _StubResponse(200, {"candidates": []}))
        answer = answer_question("What is the SC earmark?")
        assert answer.generated_by == "retrieval"
        assert answer.answer.strip()

    def test_the_key_never_reaches_the_response(self, monkeypatch):
        """A credential must not leak into a payload a browser will render."""
        _install(monkeypatch, _gemini_saying("ok"))
        payload = repr(answer_question("What is the SC earmark?").to_dict())
        assert "test-key-not-a-real-credential" not in payload

    def test_the_key_is_never_logged(self, monkeypatch, caplog):
        import logging

        _install(monkeypatch, _StubResponse(401))
        with caplog.at_level(logging.WARNING):
            answer_question("What is the SC earmark?")
        assert "test-key-not-a-real-credential" not in caplog.text
        assert "401" in caplog.text, "the status is useful; the body and key are not"


def _google_error(reason: str, status: str = "PERMISSION_DENIED") -> dict:
    """The error shape the Generative Language API actually returns."""
    return {
        "error": {
            "code": 403,
            "message": "Requests to this API are blocked.",
            "status": status,
            "details": [
                {
                    "@type": "type.googleapis.com/google.rpc.ErrorInfo",
                    "reason": reason,
                    "domain": "googleapis.com",
                    "metadata": {"service": "generativelanguage.googleapis.com"},
                }
            ],
        }
    }


@pytest.mark.skipif(not CORPUS_READY, reason="no guidelines corpus on disk")
class TestAFailureSaysWhatToFix:
    """A 403 on this API has three unrelated causes and three unrelated fixes.

    The copilot used to log a bare status code and tell every caller to "set
    GEMINI_API_KEY". On the reference project the real cause was a valid key on
    a Google Cloud project with the Generative Language API switched off, and
    no amount of setting or regenerating the key would ever have fixed it.
    """

    def test_a_blocked_api_is_named_and_not_confused_with_a_missing_key(self, monkeypatch):
        _install(monkeypatch, _StubResponse(403, _google_error("API_KEY_SERVICE_BLOCKED")))
        answer = answer_question("What is the SC earmark?")
        assert answer.generated_by == "retrieval"
        warning = answer.warning or ""
        assert "API_KEY_SERVICE_BLOCKED" in warning
        # The old sentence told an operator to set a key they had already set.
        assert "Set GEMINI_API_KEY" not in warning

    def test_a_blocked_key_is_sent_to_ai_studio_not_to_the_restrictions_page(self, monkeypatch):
        """Since September 2026 the Gemini API takes only service-account-bound
        'authorization' keys. A standard key cannot be repaired by editing its
        API restrictions -- the console greys the entry out -- so advice that
        points at the restrictions page sends an operator somewhere with no
        working option on it. The remedy is a new key from AI Studio.
        """
        _install(monkeypatch, _StubResponse(403, _google_error("API_KEY_SERVICE_BLOCKED")))
        warning = answer_question("What is the SC earmark?").warning or ""
        assert "aistudio.google.com/apikey" in warning
        assert "service account" in warning

    def test_an_invalid_key_points_at_ai_studio(self, monkeypatch):
        _install(monkeypatch, _StubResponse(400, _google_error("API_KEY_INVALID", "INVALID_ARGUMENT")))
        assert "aistudio.google.com" in (answer_question("What is the SC earmark?").warning or "")

    def test_an_exhausted_quota_is_reported_as_temporary(self, monkeypatch):
        _install(monkeypatch, _StubResponse(429, {}))
        warning = answer_question("What is the SC earmark?").warning or ""
        assert "quota" in warning and "resets" in warning

    def test_an_unknown_model_names_the_model_rather_than_the_key(self, monkeypatch):
        _install(monkeypatch, _StubResponse(404, {}))
        warning = answer_question("What is the SC earmark?").warning or ""
        assert "GEMINI_MODEL" in warning

    def test_the_reason_code_is_logged_and_the_key_is_not(self, monkeypatch, caplog):
        import logging

        _install(monkeypatch, _StubResponse(403, _google_error("API_KEY_SERVICE_BLOCKED")))
        with caplog.at_level(logging.WARNING):
            answer_question("What is the SC earmark?")
        assert "API_KEY_SERVICE_BLOCKED" in caplog.text
        assert "test-key-not-a-real-credential" not in caplog.text

    def test_the_provider_message_is_never_echoed(self, monkeypatch):
        """A provider error body can quote the request back, and the request
        carries the guideline extracts. Only the enum is read out of it."""
        body = _google_error("API_KEY_SERVICE_BLOCKED")
        body["error"]["message"] = "leaked-request-echo-should-not-appear"
        _install(monkeypatch, _StubResponse(403, body))
        payload = repr(answer_question("What is the SC earmark?").to_dict())
        assert "leaked-request-echo-should-not-appear" not in payload

    def test_the_clauses_survive_every_failure(self, monkeypatch):
        _install(monkeypatch, _StubResponse(403, _google_error("API_KEY_SERVICE_BLOCKED")))
        answer = answer_question("What is the SC earmark?")
        assert answer.sources and "Para" in answer.answer


class TestTheModelNameIsReadPerCall:
    def test_it_follows_the_environment(self, monkeypatch):
        """Bound at import, a deployment that set GEMINI_MODEL after the first
        import kept calling the old model with nothing to show why."""
        from drishti.copilot.service import DEFAULT_GEMINI_MODEL, gemini_model

        monkeypatch.delenv("GEMINI_MODEL", raising=False)
        assert gemini_model() == DEFAULT_GEMINI_MODEL
        monkeypatch.setenv("GEMINI_MODEL", "gemini-2.5-flash")
        assert gemini_model() == "gemini-2.5-flash"

    def test_a_blank_value_falls_back_to_the_default(self, monkeypatch):
        from drishti.copilot.service import DEFAULT_GEMINI_MODEL, gemini_model

        monkeypatch.setenv("GEMINI_MODEL", "  ")
        assert gemini_model() == DEFAULT_GEMINI_MODEL


class TestDiagnose:
    def test_it_reports_retrieval_and_generation_separately(self, monkeypatch):
        """Collapsing them would either call a working copilot broken or hide
        a dead key behind an answer that still arrives."""
        from drishti.copilot import diagnose

        monkeypatch.delenv("GEMINI_API_KEY", raising=False)
        monkeypatch.delenv("LLM_API_KEY", raising=False)
        status = diagnose(probe=False)
        assert status.key_configured is False
        assert status.ok is status.corpus_available

    def test_probe_false_makes_no_network_call(self, monkeypatch):
        """A status endpoint a dashboard polls must not spend free-tier quota."""
        import httpx

        from drishti.copilot import diagnose

        monkeypatch.setenv("GEMINI_API_KEY", "test-key-not-a-real-credential")

        def explode(*args, **kwargs):
            raise AssertionError("diagnose(probe=False) must not call the provider")

        monkeypatch.setattr(httpx, "Client", explode)
        status = diagnose(probe=False)
        assert status.key_configured is True
        assert "not probed" in (status.generation_problem or "")

    def test_a_probe_failure_is_rendered_with_its_remedy(self, monkeypatch):
        from drishti.copilot import diagnose

        _install(monkeypatch, _StubResponse(403, _google_error("API_KEY_SERVICE_BLOCKED")))
        status = diagnose(probe=True)
        assert status.generation_ok is False
        assert "API_KEY_SERVICE_BLOCKED" in status.render()
        assert "test-key-not-a-real-credential" not in status.render()
