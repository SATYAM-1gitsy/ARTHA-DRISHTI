"""Tests for experiment tracking.

The central property is that tracking never fails a run. These tests deliberately
exercise the no-server path, because that is the state on every developer laptop
and in CI -- and a tracking call that raises there would break every training
script written from Block 11 onward.
"""

from __future__ import annotations

import pytest

from drishti.tracking import RunContext, environment_tags, git_commit, is_available, run


class TestGitCommit:
    def test_returns_a_string(self):
        assert isinstance(git_commit(), str)

    def test_never_empty(self):
        assert git_commit()

    def test_is_short_hash_or_unknown(self):
        commit = git_commit()
        assert commit == "unknown" or (4 <= len(commit) <= 12)


class TestEnvironmentTags:
    def test_records_what_could_change_a_result(self):
        tags = environment_tags()
        for key in ("git_commit", "host", "python", "seed", "gpu", "torch", "mixed_precision"):
            assert key in tags, f"missing reproducibility tag: {key}"

    def test_all_values_are_strings(self):
        # MLflow tags must be strings; a non-string here fails at log time.
        assert all(isinstance(v, str) for v in environment_tags().values())

    def test_records_gpu_usability_not_just_presence(self):
        # A run on a CPU-only torch build is not comparable to a GPU run, so
        # the distinction has to survive into the experiment record.
        assert environment_tags()["gpu_usable"] in ("True", "False")


class TestRunContext:
    def test_collects_params_locally(self):
        context = RunContext(name="t")
        context.log_params(lr=0.01, depth=6)
        assert context.params == {"lr": 0.01, "depth": 6}

    def test_collects_metrics_as_floats(self):
        context = RunContext(name="t")
        context.log_metrics(pr_auc=0.87, recall=1)
        assert context.metrics == {"pr_auc": 0.87, "recall": 1.0}

    def test_drops_none_metrics(self):
        context = RunContext(name="t")
        context.log_metrics(good=0.5, missing=None)
        assert "missing" not in context.metrics
        assert context.metrics["good"] == 0.5

    def test_stringifies_tags(self):
        context = RunContext(name="t")
        context.set_tags(seed=42)
        assert context.tags == {"seed": "42"}

    def test_records_artifacts(self):
        context = RunContext(name="t")
        context.log_artifact("data/out/pr_curve.png")
        assert context.artifacts == ["data/out/pr_curve.png"]

    def test_untracked_context_swallows_forwarding(self):
        context = RunContext(name="t", tracked=False)
        context.log_params(a=1)
        context.log_metrics(b=2.0)
        assert context.errors == []

    def test_elapsed_is_non_negative(self):
        assert RunContext(name="t").elapsed_seconds >= 0.0


class TestRun:
    def test_yields_a_context_without_a_server(self):
        with run("unit-test", lr=0.1) as context:
            assert isinstance(context, RunContext)
            assert context.params["lr"] == 0.1

    def test_never_raises_when_tracking_is_unavailable(self):
        with run("unit-test") as context:
            context.log_metrics(pr_auc=0.5)
            context.log_params(model="lightgbm")
            context.log_artifact("nonexistent.png")
        assert context.metrics["pr_auc"] == 0.5

    def test_always_records_duration(self):
        with run("unit-test") as context:
            pass
        assert "duration_seconds" in context.metrics

    def test_marks_completed_runs(self):
        with run("unit-test") as context:
            pass
        assert context.tags["status"] == "completed"

    def test_marks_failed_runs_and_reraises(self):
        with pytest.raises(ValueError, match="boom"), run("unit-test") as context:
            raise ValueError("boom")
        assert context.tags["status"] == "failed"
        assert "duration_seconds" in context.metrics

    def test_stamps_environment_tags_automatically(self):
        with run("unit-test") as context:
            pass
        assert context.tags["git_commit"]
        assert context.tags["seed"]

    def test_reports_why_it_is_untracked(self):
        with run("unit-test") as context:
            pass
        if not context.tracked:
            assert context.errors, "an untracked run must say why"


def test_is_available_is_a_bool():
    assert isinstance(is_available(), bool)
