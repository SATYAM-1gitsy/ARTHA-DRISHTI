"""Tests for accelerator detection.

These must pass on three different machines: one with a correctly-built CUDA
wheel, one with the CPU-only wheel (finding G-01), and a teammate's laptop
with no torch at all. So they assert on the shape and safety of the report
rather than on the presence of a GPU.
"""

from __future__ import annotations

import json

import pytest

from drishti.gpu import (
    INSTALL_HINT,
    MIN_COMPUTE_CAPABILITY,
    GPUReport,
    autocast_dtype,
    detect,
    require_cuda,
    resolve_device,
)


class TestDetect:
    def test_never_raises(self):
        report = detect()
        assert isinstance(report, GPUReport)

    def test_report_is_json_serialisable(self):
        # /health returns this, so it has to survive JSON encoding.
        json.dumps(detect().to_dict())

    def test_summary_is_human_readable(self):
        assert len(detect().summary()) > 10

    def test_unusable_report_explains_why(self):
        report = detect()
        if not report.usable:
            assert report.problems, "an unusable accelerator must say what is wrong"

    def test_problems_mention_the_fix_when_torch_is_present_without_cuda(self):
        report = detect()
        if report.torch_installed and not report.cuda_available:
            assert "download.pytorch.org" in " ".join(report.problems)


class TestGPUReport:
    def test_usable_requires_cuda_and_no_problems(self):
        assert GPUReport(torch_installed=True, cuda_available=True).usable is True
        assert GPUReport(torch_installed=True, cuda_available=False).usable is False
        assert (
            GPUReport(torch_installed=True, cuda_available=True, problems=["bad wheel"]).usable
            is False
        )

    def test_missing_torch_summary(self):
        assert "not installed" in GPUReport(torch_installed=False).summary()

    def test_capability_is_rendered_as_a_string(self):
        report = GPUReport(
            torch_installed=True, cuda_available=True, compute_capability=(12, 0)
        )
        assert report.to_dict()["compute_capability"] == "12.0"


class TestRequireCuda:
    def test_raises_on_unusable_device(self):
        unusable = GPUReport(torch_installed=True, cuda_available=False, problems=["cpu build"])
        with pytest.raises(RuntimeError, match="GPU required"):
            require_cuda(unusable)

    def test_returns_report_when_usable(self):
        usable = GPUReport(torch_installed=True, cuda_available=True)
        assert require_cuda(usable) is usable


class TestResolveDevice:
    def test_cpu_is_always_available(self):
        assert resolve_device("cpu") == "cpu"

    def test_auto_never_raises(self):
        assert resolve_device("auto") in ("cpu", "cuda")

    def test_rejects_unknown_preference(self):
        with pytest.raises(ValueError, match="unrecognised"):
            resolve_device("tpu")

    def test_explicit_cuda_raises_when_unavailable(self):
        if not detect().usable:
            with pytest.raises(RuntimeError, match="CUDA is unusable"):
                resolve_device("cuda")


class TestAutocastDtype:
    def test_off_returns_none(self):
        assert autocast_dtype("off") is None

    def test_returns_none_without_a_usable_device(self):
        unusable = GPUReport(torch_installed=True, cuda_available=False)
        assert autocast_dtype("bf16", unusable) is None

    def test_bf16_downgrades_to_fp16_when_unsupported(self):
        report = GPUReport(
            torch_installed=True, cuda_available=True, bf16_supported=False, fp16_supported=True
        )
        assert autocast_dtype("bf16", report) == "float16"

    def test_bf16_selected_when_supported(self):
        report = GPUReport(
            torch_installed=True, cuda_available=True, bf16_supported=True, fp16_supported=True
        )
        assert autocast_dtype("bf16", report) == "bfloat16"

    def test_rejects_unknown_mode(self):
        report = GPUReport(torch_installed=True, cuda_available=True)
        with pytest.raises(ValueError, match="mixed_precision"):
            autocast_dtype("int8", report)


def test_min_capability_targets_blackwell():
    """The audited machine is sm_120; guarding below that defeats the check."""
    assert MIN_COMPUTE_CAPABILITY == (12, 0)


def test_install_hint_names_a_cuda_index():
    assert "cu130" in INSTALL_HINT or "cu128" in INSTALL_HINT
