"""Tests for the numeric substrate.

These target the degenerate inputs a real MPLADS extract produces -- constant
peer groups, all-missing columns, zero denominators -- because that is where a
detector silently starts emitting NaN into the Layer Output Contract.
"""

from __future__ import annotations

import math

import numpy as np
import pytest

from drishti.util import (
    DisjointSet,
    dumps,
    ecdf_tail,
    ecod_scores,
    haversine_km,
    minmax,
    percentile_rank,
    point_in_bbox,
    robust_z,
    safe_ratio,
    set_seed,
    to_jsonable,
    winsorize,
)


class TestMinmax:
    def test_scales_to_unit_range(self):
        assert minmax([0.0, 5.0, 10.0]) == pytest.approx([0.0, 0.5, 1.0])

    def test_constant_vector_is_zero_not_nan(self):
        out = minmax([7.0, 7.0, 7.0])
        assert np.all(out == 0.0)
        assert not np.isnan(out).any()

    def test_empty_input(self):
        assert minmax([]).size == 0

    def test_nan_becomes_zero_and_is_ignored_in_range(self):
        out = minmax([0.0, np.nan, 10.0])
        assert out[1] == 0.0
        assert out[0] == pytest.approx(0.0)
        assert out[2] == pytest.approx(1.0)

    def test_all_nan_returns_zeros(self):
        out = minmax([np.nan, np.nan])
        assert np.all(out == 0.0)

    def test_output_always_within_unit_interval(self):
        rng = np.random.default_rng(0)
        out = minmax(rng.normal(size=500) * 1e6)
        assert out.min() >= 0.0 and out.max() <= 1.0


class TestRobustZ:
    def test_outlier_separates_from_body(self):
        data = [10.0] * 20 + [1000.0]
        out = robust_z(data)
        assert abs(out[-1]) > 10
        assert np.all(np.abs(out[:-1]) < 1e-9)

    def test_constant_vector_is_zero(self):
        assert np.all(robust_z([3.0] * 10) == 0.0)

    def test_separates_outlier_when_mad_is_zero(self):
        # 11 identical values give MAD == 0. The fallback scale must not be
        # inflated by the outlier itself, or the outlier masks its own
        # deviation -- which is what a std-based fallback would do.
        out = robust_z([5.0] * 11 + [99.0])
        assert out[-1] > 10.0

    def test_zero_mad_fallback_beats_standard_deviation(self):
        data = [10.0] * 20 + [1000.0]
        out = robust_z(data)
        naive = (1000.0 - 10.0) / float(np.asarray(data).std())
        assert out[-1] > 4 * naive

    def test_never_returns_nan(self):
        assert not np.isnan(robust_z([1.0, np.nan, 3.0])).any()


class TestPercentileRank:
    def test_monotone(self):
        out = percentile_rank([1.0, 2.0, 3.0, 4.0])
        assert list(out) == pytest.approx([0.25, 0.5, 0.75, 1.0])

    def test_ties_share_an_averaged_rank(self):
        out = percentile_rank([5.0, 5.0, 9.0])
        assert out[0] == pytest.approx(out[1])
        assert out[2] > out[0]

    def test_bounded(self):
        out = percentile_rank(np.random.default_rng(1).normal(size=200))
        assert out.min() > 0.0 and out.max() <= 1.0


class TestEcdfTail:
    def test_extremes_get_smallest_tail(self):
        out = ecdf_tail([1.0, 2.0, 3.0, 4.0, 100.0])
        assert out[-1] == pytest.approx(min(out))

    def test_central_value_has_larger_tail_than_extreme(self):
        data = list(range(101))
        out = ecdf_tail(data)
        assert out[50] > out[0]
        assert out[50] > out[-1]

    def test_bounded_open_unit_interval(self):
        out = ecdf_tail(np.random.default_rng(2).normal(size=100))
        assert out.min() > 0.0 and out.max() <= 1.0

    def test_all_nan_returns_ones(self):
        assert np.all(ecdf_tail([np.nan, np.nan]) == 1.0)


class TestEcodScores:
    def test_returns_unit_interval_per_row(self):
        rng = np.random.default_rng(3)
        matrix = rng.normal(size=(120, 4))
        out = ecod_scores(matrix)
        assert out.shape == (120,)
        assert out.min() >= 0.0 and out.max() <= 1.0

    def test_planted_outlier_ranks_top(self):
        rng = np.random.default_rng(4)
        matrix = rng.normal(size=(200, 3))
        matrix[7] = [12.0, -11.0, 13.0]
        out = ecod_scores(matrix)
        assert int(np.argmax(out)) == 7

    def test_rejects_non_2d(self):
        with pytest.raises(ValueError, match="2-D"):
            ecod_scores(np.zeros(5))


class TestSafeRatio:
    def test_normal_division(self):
        assert safe_ratio(10.0, 4.0) == pytest.approx(2.5)

    def test_zero_denominator_returns_default(self):
        assert safe_ratio(10.0, 0.0) == 0.0
        assert safe_ratio(10.0, 0.0, default=1.0) == 1.0

    def test_vectorised_never_emits_inf_or_nan(self):
        out = safe_ratio(np.array([1.0, 2.0, 3.0]), np.array([0.0, 1.0, np.nan]))
        assert np.isfinite(out).all()


class TestWinsorize:
    def test_clips_extremes(self):
        data = [1.0] * 98 + [-500.0, 500.0]
        out = winsorize(data)
        assert out.max() < 500.0
        assert out.min() > -500.0

    def test_empty(self):
        assert winsorize([]).size == 0


class TestDisjointSet:
    def test_union_and_find(self):
        ds = DisjointSet([1, 2, 3])
        assert ds.union(1, 2) is True
        assert ds.union(1, 2) is False  # already joined
        assert ds.find(1) == ds.find(2)
        assert ds.find(3) != ds.find(1)

    def test_transitive_clustering(self):
        ds = DisjointSet()
        ds.union("a", "b")
        ds.union("b", "c")
        ds.union("x", "y")
        clusters = sorted(sorted(members) for members in ds.clusters().values())
        assert clusters == [["a", "b", "c"], ["x", "y"]]

    def test_singletons_appear_in_clusters(self):
        ds = DisjointSet(["solo"])
        assert list(ds.clusters().values()) == [["solo"]]


class TestGeo:
    def test_haversine_zero_distance(self):
        assert haversine_km(19.07, 72.87, 19.07, 72.87) == pytest.approx(0.0)

    def test_haversine_known_pair(self):
        # Mumbai to Delhi is roughly 1150 km.
        km = haversine_km(19.0760, 72.8777, 28.6139, 77.2090)
        assert 1100 < km < 1200

    def test_haversine_is_symmetric(self):
        a = haversine_km(12.97, 77.59, 22.57, 88.36)
        b = haversine_km(22.57, 88.36, 12.97, 77.59)
        assert a == pytest.approx(b)

    def test_point_in_bbox(self):
        bbox = (18.0, 72.0, 20.0, 74.0)
        assert point_in_bbox(19.0, 73.0, bbox) is True
        assert point_in_bbox(21.0, 73.0, bbox) is False

    def test_point_in_bbox_rejects_non_finite(self):
        assert point_in_bbox(float("nan"), 73.0, (18.0, 72.0, 20.0, 74.0)) is False


class TestJson:
    def test_converts_numpy_scalars(self):
        out = to_jsonable({"i": np.int64(3), "f": np.float64(1.5), "b": np.bool_(True)})
        assert out == {"i": 3, "f": 1.5, "b": True}
        assert isinstance(out["i"], int) and isinstance(out["f"], float)

    def test_converts_arrays_and_nested_structures(self):
        out = to_jsonable({"a": np.array([1, 2]), "n": [np.float32(0.5)]})
        assert out == {"a": [1, 2], "n": [0.5]}

    def test_non_finite_becomes_null(self):
        assert to_jsonable(float("nan")) is None
        assert to_jsonable(np.float64("inf")) is None

    def test_dumps_produces_valid_json(self):
        text = dumps({"score": np.float64(0.91), "bad": float("nan")})
        assert '"score": 0.91' in text
        assert "NaN" not in text


def test_set_seed_is_reproducible():
    set_seed(42)
    first = np.random.rand(5)
    set_seed(42)
    assert np.allclose(first, np.random.rand(5))


def test_module_imports_without_torch():
    """The fallback promise: this substrate must work on numpy alone."""
    import drishti.util as module

    assert "torch" not in module.__dict__
    assert math.isfinite(haversine_km(0, 0, 1, 1))
