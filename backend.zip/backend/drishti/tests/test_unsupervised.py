"""Tests for L1, peer-relative anomaly detection.

The governance tests here matter as much as the behavioural ones. L1's entire
claim is "no labels required"; the moment it sees ground truth that claim is
false and every number it produces is worthless. So the label boundary is
asserted rather than trusted.

The peer-group tests exist because of a real bug. Gating findings on an
absolute tail probability looked correct and passed every unit test, but
`ecdf_tail` floors at 1/group_size -- so any threshold below that silently
disabled L1 for every narrow peer group while continuing to work on wide ones.
Only a sweep across group sizes exposes that class of bug, so one is encoded
here.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from drishti.config import settings
from drishti.contracts.gold import GOLD_COLUMNS
from drishti.contracts.labels import LAYERS_DENIED_LABELS
from drishti.detect import unsupervised as l1
from drishti.detect.unsupervised import (
    FEATURE_FAMILY,
    L1_FEATURES,
    LAYER,
    MIN_GROUP_SIZE,
    OUTLIER_QUANTILE,
    USE_ISOLATION_FOREST,
    assign_peer_groups,
    run,
    score_group,
)

GOLD = settings.paths.out / "gold.parquet"
LABELS = settings.paths.seeds / "fraud_label.parquet"
READY = GOLD.is_file() and LABELS.is_file()


def synthetic_frame(n: int = 240, seed: int = 3) -> pd.DataFrame:
    """A frame with the Gold columns and a few planted outliers."""
    rng = np.random.default_rng(seed)
    frame = pd.DataFrame({column: 0.0 for column in GOLD_COLUMNS}, index=range(n))
    frame["work_id"] = np.arange(1, n + 1)
    frame["sector"] = "roads_bridges"
    frame["work_type"] = np.where(np.arange(n) % 2 == 0, "village_road", "culvert")
    frame["state"] = "Bihar"
    frame["data_quality"] = 1.0
    for column in L1_FEATURES:
        frame[column] = rng.normal(100.0, 10.0, n)
    # Two unmistakable outliers.
    frame.loc[0, "unit_cost"] = 5_000.0
    frame.loc[1, "advance_ratio"] = 4_000.0
    return frame


@pytest.fixture(scope="module")
def gold():
    if not READY:
        pytest.skip("run the pipeline first")
    return pd.read_parquet(GOLD)


@pytest.fixture(scope="module")
def labels():
    if not READY:
        pytest.skip("run the pipeline first")
    return pd.read_parquet(LABELS)


# ==========================================================================
# governance
# ==========================================================================
class TestGovernance:
    def test_layer_is_denied_labels_by_contract(self):
        assert LAYER in LAYERS_DENIED_LABELS

    def test_module_never_imports_ground_truth(self):
        """The claim "requires no labels" has to be true, not aspirational.

        Checks the AST rather than the source text: a docstring saying "never
        touches fraud_label" is not a reference to fraud_label, and a test that
        cannot tell the difference is a test people learn to ignore.
        """
        import ast
        from pathlib import Path

        tree = ast.parse(Path(l1.__file__).read_text(encoding="utf-8"))
        forbidden = {"fraud_label", "FraudLabel", "held_out_patterns", "labels"}

        imported: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                imported.add(node.module or "")
                imported.update(alias.name for alias in node.names)
            elif isinstance(node, ast.Import):
                imported.update(alias.name for alias in node.names)
        assert not (imported & forbidden), f"L1 imports ground truth: {imported & forbidden}"

        # And no string literal that could be a path to the label table.
        literals = [
            n.value for n in ast.walk(tree)
            if isinstance(n, ast.Constant) and isinstance(n.value, str)
        ]
        assert not [s for s in literals if "fraud_label" in s and ".parquet" in s]

    def test_features_avoid_counting_one_quantity_three_times(self):
        """R-01 applied at the feature layer."""
        assert "unit_cost" in L1_FEATURES
        assert "unit_cost_vs_sor" not in L1_FEATURES
        assert "unit_cost_peer_percentile" not in L1_FEATURES

    def test_every_feature_declares_an_evidence_family(self):
        missing = [f for f in L1_FEATURES if f not in FEATURE_FAMILY]
        assert not missing, f"features without a family: {missing}"

    def test_features_span_several_families(self):
        families = {FEATURE_FAMILY[f] for f in L1_FEATURES}
        assert len(families) >= 4

    def test_isolation_forest_is_off_by_measurement(self):
        """It improved L1 alone and contributed nothing fused, at 5.9x cost."""
        assert USE_ISOLATION_FOREST is False

    def test_every_feature_is_a_gold_column(self):
        missing = [f for f in L1_FEATURES if f not in GOLD_COLUMNS]
        assert not missing, f"L1 reads columns not in Seam A: {missing}"


# ==========================================================================
# peer grouping
# ==========================================================================
class TestPeerGrouping:
    def test_assigns_every_work_a_group(self):
        frame = synthetic_frame().set_index("work_id", drop=False)
        grouping = assign_peer_groups(frame)
        assert grouping.keys.notna().all()

    def test_narrow_group_used_when_large_enough(self):
        frame = synthetic_frame(n=400).set_index("work_id", drop=False)
        grouping = assign_peer_groups(frame)
        assert "sector x work_type x state" in set(grouping.level)

    def test_falls_back_when_a_group_is_too_small(self):
        frame = synthetic_frame(n=240).set_index("work_id", drop=False)
        # Make every work its own state: the narrowest group becomes size 1.
        frame["state"] = [f"State {i}" for i in range(len(frame))]
        grouping = assign_peer_groups(frame)
        assert "sector x work_type x state" not in set(grouping.level)

    def test_falls_back_all_the_way_to_global(self):
        frame = synthetic_frame(n=40).set_index("work_id", drop=False)
        frame["sector"] = [f"S{i}" for i in range(len(frame))]
        grouping = assign_peer_groups(frame)
        assert set(grouping.level) == {"all works"}

    def test_no_group_is_smaller_than_the_minimum(self):
        frame = synthetic_frame(n=400).set_index("work_id", drop=False)
        grouping = assign_peer_groups(frame)
        narrow = {
            key: size
            for key, size in grouping.sizes.items()
            if not key.startswith("all works")
        }
        assert all(size >= MIN_GROUP_SIZE for size in narrow.values())

    @pytest.mark.skipif(not READY, reason="run the pipeline first")
    def test_real_data_mostly_uses_the_narrowest_group(self, gold):
        grouping = assign_peer_groups(gold.set_index("work_id", drop=False))
        counts = grouping.level_counts
        narrowest = counts.get("sector x work_type x state", 0)
        assert narrowest / sum(counts.values()) > 0.5


# ==========================================================================
# scoring
# ==========================================================================
class TestScoreGroup:
    def test_scores_are_bounded(self):
        frame = synthetic_frame()
        scores, tails, imputed, _ = score_group(frame[list(L1_FEATURES)])
        assert scores.min() >= 0.0 and scores.max() <= 1.0

    def test_planted_outlier_scores_highest(self):
        frame = synthetic_frame()
        scores, _, _, _ = score_group(frame[list(L1_FEATURES)])
        assert int(np.argmax(scores)) in (0, 1)

    def test_tails_are_probabilities(self):
        frame = synthetic_frame()
        _, tails, _, _ = score_group(frame[list(L1_FEATURES)])
        assert tails.min() > 0.0 and tails.max() <= 1.0

    def test_missing_values_are_recorded_as_imputed(self):
        frame = synthetic_frame()
        frame.loc[0:9, "unit_cost"] = np.nan
        _, _, imputed, _ = score_group(frame[list(L1_FEATURES)])
        assert imputed[:10, list(L1_FEATURES).index("unit_cost")].all()

    def test_reports_which_detectors_ran(self):
        frame = synthetic_frame()
        _, _, _, diagnostics = score_group(frame[list(L1_FEATURES)])
        assert "ecod" in diagnostics["detectors"]
        assert "mad" in diagnostics["detectors"]

    def test_is_deterministic(self):
        frame = synthetic_frame()
        first, _, _, _ = score_group(frame[list(L1_FEATURES)])
        second, _, _, _ = score_group(frame[list(L1_FEATURES)])
        assert np.allclose(first, second)


class TestGroupSizeInvariance:
    """The regression test for the absolute-tail bug.

    A fixed tail threshold could never be met in a group smaller than
    1/threshold, silently disabling the layer for narrow peer groups. Rank
    gating must behave the same way at every group size.
    """

    @pytest.mark.parametrize("n", [40, 60, 120, 400])
    def test_findings_are_produced_at_every_group_size(self, n):
        frame = synthetic_frame(n=n)
        frame["work_type"] = "village_road"  # one group of size n
        outputs = run(frame)
        firing = [o for o in outputs if o.score > 0]
        assert firing, f"no findings in a group of {n} works"

    @pytest.mark.parametrize("n", [40, 120, 400])
    def test_fire_rate_is_stable_across_group_sizes(self, n):
        frame = synthetic_frame(n=n)
        frame["work_type"] = "village_road"
        outputs = run(frame)
        rate = sum(1 for o in outputs if o.score > 0) / len(outputs)
        # Rank gating means roughly OUTLIER_QUANTILE regardless of size.
        assert rate <= OUTLIER_QUANTILE * 4


# ==========================================================================
# Seam B
# ==========================================================================
class TestSeamB:
    def test_emits_the_declared_layer(self):
        assert all(o.layer == LAYER for o in run(synthetic_frame()))

    def test_one_output_per_work_including_silent_ones(self):
        frame = synthetic_frame(n=240)
        outputs = run(frame)
        assert len(outputs) == 240
        assert {o.work_id for o in outputs} == set(frame["work_id"])

    def test_scores_and_confidence_are_bounded(self):
        for output in run(synthetic_frame()):
            assert 0.0 <= output.score <= 1.0
            assert 0.0 <= output.confidence <= 1.0

    def test_a_score_always_has_a_reason(self):
        for output in run(synthetic_frame()):
            if output.score > 0:
                assert output.reasons

    def test_reasons_are_peer_relative_comparisons(self):
        """"2.4x the median of 340 comparable works", not "score 0.87"."""
        outputs = [o for o in run(synthetic_frame()) if o.reasons]
        assert outputs
        text = outputs[0].reasons[0].text
        assert "comparable works" in text
        assert "median" in text or "against a median" in text

    def test_reasons_name_the_peer_group_level(self):
        outputs = [o for o in run(synthetic_frame()) if o.reasons]
        assert any(
            level in outputs[0].reasons[0].text
            for level in ("sector x work_type x state", "sector x work_type", "sector", "all works")
        )

    def test_reasons_carry_peer_derived_provenance(self):
        outputs = [o for o in run(synthetic_frame()) if o.reasons]
        assert outputs[0].reasons[0].provenance == "peer_derived"

    def test_factors_record_the_peer_group(self):
        output = next(o for o in run(synthetic_frame()) if o.reasons)
        assert output.factors["peer_group_size"] >= MIN_GROUP_SIZE
        assert "peer_group_level" in output.factors

    def test_smaller_peer_groups_lower_confidence(self):
        wide = synthetic_frame(n=400)
        wide["work_type"] = "village_road"
        narrow = synthetic_frame(n=40)
        narrow["work_type"] = "village_road"
        assert np.mean([o.confidence for o in run(narrow)]) < np.mean(
            [o.confidence for o in run(wide)]
        )

    def test_imputed_features_lower_confidence(self):
        clean = synthetic_frame()
        gappy = synthetic_frame()
        for column in L1_FEATURES[:8]:
            gappy.loc[0:100, column] = np.nan
        assert np.mean([o.confidence for o in run(gappy)]) < np.mean(
            [o.confidence for o in run(clean)]
        )

    def test_empty_input(self):
        assert run(pd.DataFrame()) == []

    def test_output_is_json_serialisable(self):
        import json

        output = next(o for o in run(synthetic_frame()) if o.reasons)
        json.dumps(output.to_row())


# ==========================================================================
# against the real data
# ==========================================================================
@pytest.mark.skipif(not READY, reason="run the pipeline first")
class TestAgainstRealData:
    def test_fire_rate_is_a_workable_queue(self, gold):
        outputs = run(gold)
        rate = sum(1 for o in outputs if o.score > 0) / len(outputs)
        assert 0.005 < rate < 0.10, f"L1 fires on {rate:.1%} of works"

    def test_beats_random_on_held_out_patterns(self, gold, labels):
        """The only quotable kind of figure: patterns no detector targets."""
        from drishti.domain import held_out_patterns

        held = set(
            labels.loc[
                labels["pattern"].isin({p.name for p in held_out_patterns()}), "work_id"
            ]
        )
        scores = pd.Series({o.work_id: o.score for o in run(gold)})
        top = set(scores.sort_values(ascending=False).head(500).index)
        precision = len(top & held) / 500
        baseline = len(held) / len(gold)
        assert precision > baseline * 3, (
            f"P@500 {precision:.1%} against a {baseline:.1%} baseline -- "
            "L1 is not finding held-out patterns"
        )

    def test_finds_photo_reuse_better_than_rules_do(self, gold, labels):
        """L1's distinctive contribution: no rule targets phash duplication."""
        from drishti.detect import rules as l0

        targeted = set(labels.loc[labels["pattern"] == "photo_reuse", "work_id"])
        rule_scores = pd.Series({o.work_id: o.score for o in l0.run(gold)})
        l1_scores = pd.Series({o.work_id: o.score for o in run(gold)})

        def recall(scores):
            top = set(scores.sort_values(ascending=False).head(2000).index)
            return len(top & targeted) / max(len(targeted), 1)

        assert recall(l1_scores) > recall(rule_scores)

    def test_runs_in_reasonable_time(self, gold):
        import time

        start = time.perf_counter()
        run(gold)
        assert time.perf_counter() - start < 60.0
