"""The four role views and the review endpoint — Blueprint §10, §11.

Covers the endpoints that were missing from Seam D, and the two judgement
calls inside them that a future change is most likely to undo: ranked tables
need a denominator floor, and the earmark check is an aggregate rather than a
per-work rule.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from drishti.api.app import app
from drishti.api.review import AuditLog, ReviewStore
from drishti.config import settings

READY = (settings.paths.out / "gold.parquet").is_file() and (
    settings.paths.out / "risk_score.parquet"
).is_file()

pytestmark = pytest.mark.skipif(not READY, reason="run the pipeline first")

MINISTRY = {"X-Drishti-Role": "ministry", "X-Drishti-Subject": "mospi.analyst"}


@pytest.fixture
def client(tmp_path, monkeypatch):
    """A client whose review log is a temporary file, not the project's."""
    import drishti.api.review as review

    audit = AuditLog(tmp_path / "audit.jsonl")
    store = ReviewStore(path=tmp_path / "reviews.jsonl", audit=audit)
    monkeypatch.setattr(review, "_review_store", store)
    monkeypatch.setattr(review, "_audit_log", audit)
    return TestClient(app)


class TestNationalView:
    def test_it_answers_where_are_the_systemic_problems(self, client):
        payload = client.get("/api/analytics/national", headers=MINISTRY).json()
        assert payload["kpis"]["n_works"] > 0
        assert payload["by_state"], "the Ministry view is a state comparison"
        assert payload["worst_districts"]
        assert payload["pattern_mix"], "which findings drive the flags"

    def test_ranked_tables_have_a_denominator_worth_ranking_on(self, client):
        """A one-work agency at 100% flagged is arithmetic, not a lead.

        Without a floor the worst-agency list was entirely single-work
        agencies, every one at 100%.
        """
        payload = client.get("/api/analytics/national", headers=MINISTRY).json()
        assert all(row["n_works"] >= 10 for row in payload["worst_agencies"])
        assert all(row["n_works"] >= 10 for row in payload["worst_districts"])

    def test_full_tables_are_not_truncated_by_that_floor(self, client):
        """`by_state` is a complete population, not a top ten."""
        payload = client.get("/api/analytics/national", headers=MINISTRY).json()
        assert len(payload["by_state"]) > 10

    def test_every_aggregate_carries_the_disclaimer(self, client):
        """An aggregate has no reasons attached for a reader to argue with."""
        payload = client.get("/api/analytics/national", headers=MINISTRY).json()
        assert "not findings of wrongdoing" in payload["disclaimer"]

    def test_value_flagged_is_value_under_review(self, client):
        payload = client.get("/api/analytics/national", headers=MINISTRY).json()
        assert payload["kpis"]["value_flagged"] >= 0


class TestStateDistrictAndMpViews:
    def test_state_view_compares_districts(self, client):
        national = client.get("/api/analytics/national", headers=MINISTRY).json()
        state = national["by_state"][0]["key"]
        payload = client.get(f"/api/analytics/state/{state}", headers=MINISTRY).json()
        assert payload["state"] == state
        assert payload["by_district"]

    def test_district_view_reports_agency_concentration(self, client):
        national = client.get("/api/analytics/national", headers=MINISTRY).json()
        district = national["worst_districts"][0]["key"]
        payload = client.get(f"/api/analytics/district/{district}", headers=MINISTRY).json()
        assert 0.0 <= payload["agency_hhi"] <= 1.0
        assert payload["top_agency_share_pct"] > 0

    def test_mp_view_separates_recommending_from_executing(self, client):
        """The framing note ships in the payload, not in frontend copy.

        A second client rendering this view must not be able to omit it.
        """
        payload = client.get("/api/analytics/mp/1", headers=MINISTRY).json()
        assert "recommends" in payload["note"]
        assert "District Authority sanctions" in payload["note"]

    def test_unknown_scopes_are_404_not_empty_payloads(self, client):
        assert client.get("/api/analytics/state/Atlantis", headers=MINISTRY).status_code == 404
        assert client.get("/api/analytics/district/99999999", headers=MINISTRY).status_code == 404
        assert client.get("/api/analytics/mp/99999999", headers=MINISTRY).status_code == 404


class TestEarmark:
    def test_it_is_an_aggregate_check_not_a_per_work_rule(self, client):
        """Blueprint §6.1 says MP/entitlement level, and measurement agrees.

        As a per-work predicate this fires on 87% of the corpus. It is a
        portfolio fact and belongs in a portfolio view.
        """
        from drishti.detect.rules import RULES

        codes = {rule.code for rule in RULES}
        assert not {c for c in codes if "earmark" in c}

        payload = client.get("/api/analytics/earmark", headers=MINISTRY).json()
        assert payload["sc_threshold_pct"] == 15.0
        assert payload["st_threshold_pct"] == 7.5

    def test_the_denominator_caveat_travels_with_the_number(self, client):
        """The Guidelines earmark a share of entitlement; this is not that."""
        payload = client.get("/api/analytics/earmark", headers=MINISTRY).json()
        assert "not of the annual entitlement" in payload["basis"]
        assert payload["provenance"] == "guideline_clause"

    def test_shortfall_only_is_a_subset_of_all_members(self, client):
        short = client.get("/api/analytics/earmark", headers=MINISTRY).json()["total"]
        every = client.get(
            "/api/analytics/earmark?shortfall_only=false", headers=MINISTRY
        ).json()["total"]
        assert 0 < short <= every


class TestGraphAndDuplicates:
    def test_the_agency_subgraph_is_inspectable_evidence(self, client):
        national = client.get("/api/analytics/national", headers=MINISTRY).json()
        agency = national["worst_agencies"][0]["key"]
        payload = client.get(f"/api/graph/agency/{agency}", headers=MINISTRY).json()
        assert payload["n_works"] > 0
        assert payload["members"], "which members' works this agency executes"
        assert "legitimate reasons" in payload["note"]

    def test_duplicate_pairs_name_their_twin_and_their_backend(self, client):
        """Sparse and dense similarities are not on the same scale."""
        payload = client.get("/api/duplicates?limit=5", headers=MINISTRY).json()
        if not payload["items"]:
            pytest.skip("no duplicate findings in the current scoring run")
        pair = payload["items"][0]
        assert pair["match_work_id"] is not None
        assert pair["similarity"] is not None
        assert pair["method"]


class TestReviewEndpoint:
    def _first_alert(self, client, headers=MINISTRY):
        return client.get("/api/alerts?limit=1", headers=headers).json()["items"][0]

    def test_the_alert_id_is_the_work_id(self, client):
        """It used to be the row's position, which changes on every re-score.

        A decision has to be keyed on something that survives the next run.
        """
        alert = self._first_alert(client)
        assert alert["alert_id"] == alert["work_id"]

    def test_a_decision_moves_the_alert_and_returns_the_event(self, client):
        alert = self._first_alert(client)
        response = client.post(
            f"/api/alerts/{alert['alert_id']}/action",
            json={"status": "under_review", "note": "site visit booked"},
            headers=MINISTRY,
        )
        assert response.status_code == 200
        body = response.json()
        assert body["alert"]["status"] == "under_review"
        assert body["event"]["from_status"] == "open"
        assert body["event"]["reviewer"] == "mospi.analyst"

    def test_status_survives_into_the_queue_and_the_stats(self, client):
        alert = self._first_alert(client)
        client.post(
            f"/api/alerts/{alert['alert_id']}/action",
            json={"status": "resolved", "outcome": "confirmed_issue"},
            headers=MINISTRY,
        )
        stats = client.get("/api/alerts/stats", headers=MINISTRY).json()
        assert stats["by_status"]["resolved"] >= 1
        resolved = client.get("/api/alerts?status=resolved", headers=MINISTRY).json()
        assert alert["alert_id"] in {item["alert_id"] for item in resolved["items"]}

    def test_an_invalid_decision_is_refused(self, client):
        alert = self._first_alert(client)
        assert (
            client.post(
                f"/api/alerts/{alert['alert_id']}/action",
                json={"status": "banana"},
                headers=MINISTRY,
            ).status_code
            == 422
        )

    def test_an_unknown_alert_explains_the_id_scheme(self, client):
        response = client.post(
            "/api/alerts/99999999/action", json={"status": "resolved"}, headers=MINISTRY
        )
        assert response.status_code == 404
        assert "work ids" in response.json()["detail"]

    def test_an_mp_may_not_action_an_alert(self, client):
        alert = self._first_alert(client)
        response = client.post(
            f"/api/alerts/{alert['alert_id']}/action",
            json={"status": "dismissed"},
            headers={"X-Drishti-Role": "mp", "X-Drishti-MP": "1"},
        )
        assert response.status_code == 403

    def test_acting_outside_a_jurisdiction_is_refused_and_audited(self, client):
        import drishti.api.review as review

        alert = self._first_alert(client)
        elsewhere = {"X-Drishti-Role": "district", "X-Drishti-District": "999999", "X-Drishti-Subject": "dc.elsewhere"}
        response = client.post(
            f"/api/alerts/{alert['alert_id']}/action",
            json={"status": "dismissed"},
            headers=elsewhere,
        )
        assert response.status_code == 403
        refusals = [
            e for e in review.get_audit_log().entries() if e["action"] == "alert.action.refused"
        ]
        assert refusals, "a refused action is exactly what an audit wants to see"
