"""Tests for the Gold feature builder.

Two kinds of assertion here, and the second kind is the one that earns its
keep. Contract conformance catches a missing column loudly. **Separation**
catches something far worse: a feature that computes cleanly, validates
cleanly, and carries no signal.

That is not hypothetical. `_geo_features` originally built its DataFrame with
`index=work_id` while the value Series still carried a positional index, so
pandas silently *aligned* rather than assigned and shifted every value by one
row. Contract validation passed. A 3.7-degree injected displacement read as
identical to the base population. Only a separation check finds that.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from drishti.config import settings
from drishti.contracts.gold import GOLD_COLUMNS, REQUIRED_COLUMNS
from drishti.contracts.labels import assert_no_label_leakage
from drishti.features import MIN_PEER_GROUP, build_features, build_from_seeds

SEEDS_READY = (settings.paths.seeds / "synth_work.parquet").is_file()
pytestmark = pytest.mark.skipif(
    not SEEDS_READY, reason="run `drishti ingest` then `drishti seed` first"
)


@pytest.fixture(scope="module")
def built():
    return build_from_seeds()


@pytest.fixture(scope="module")
def gold(built):
    return built.features.set_index("work_id")


@pytest.fixture(scope="module")
def labels():
    return pd.read_parquet(settings.paths.seeds / "fraud_label.parquet")


def _targets(labels: pd.DataFrame, pattern: str) -> set[int]:
    return set(labels.loc[labels["pattern"] == pattern, "work_id"])


# ==========================================================================
# contract conformance
# ==========================================================================
class TestContract:
    def test_satisfies_the_gold_contract(self, built):
        assert built.problems == []

    def test_has_every_column_in_order(self, built):
        assert list(built.features.columns) == list(GOLD_COLUMNS)

    def test_one_row_per_work(self, built):
        assert not built.features["work_id"].duplicated().any()

    def test_required_columns_have_no_nulls(self, built):
        for column in REQUIRED_COLUMNS:
            assert built.features[column].notna().all(), f"{column} has nulls"

    def test_no_ground_truth_reached_the_feature_space(self, built):
        assert_no_label_leakage(list(built.features.columns))

    def test_no_infinities(self, built):
        numeric = built.features.select_dtypes(include=[np.number])
        assert not np.isinf(numeric.to_numpy(dtype=float, na_value=0.0)).any()

    def test_matches_the_committed_fixture_schema(self, built):
        """Block 5 acceptance criterion.

        The fixture is only usable as a stand-in while it is schema-identical
        to the real frame -- otherwise code written against it breaks on the
        swap, which is the entire failure the fixture exists to prevent.
        """
        fixture = pd.read_parquet(settings.paths.fixtures / "sample_gold.parquet")
        assert list(fixture.columns) == list(built.features.columns)
        for column in GOLD_COLUMNS:
            assert fixture[column].dtype.kind == built.features[column].dtype.kind, (
                f"{column}: fixture {fixture[column].dtype} vs real "
                f"{built.features[column].dtype}"
            )


# ==========================================================================
# peer-relative computation
# ==========================================================================
class TestPeerRelative:
    def test_percentiles_are_bounded(self, gold):
        values = gold["unit_cost_peer_percentile"].dropna()
        assert values.between(0.0, 1.0).all()

    def test_thin_peer_groups_yield_null_not_a_number(self, built):
        """"99th percentile of four works" is arithmetic, not evidence."""
        frame = built.features
        sizes = frame.groupby(["sector", "work_type", "state"])["work_id"].transform("size")
        thin = sizes < MIN_PEER_GROUP
        if thin.any():
            assert frame.loc[thin, "unit_cost_peer_percentile"].isna().all()

    def test_coverage_is_high_enough_to_be_useful(self, built):
        assert built.peer_group_stats["coverage"] > 0.8

    def test_percentile_is_relative_not_global(self, gold):
        """A cheap work in a cheap sector must not rank low globally."""
        sample = gold.dropna(subset=["unit_cost", "unit_cost_peer_percentile"])
        global_rank = sample["unit_cost"].rank(pct=True)
        # If the peer percentile were just a global rank, these would agree.
        assert global_rank.corr(sample["unit_cost_peer_percentile"]) < 0.98

    def test_concentration_is_null_for_small_districts(self, built):
        frame = built.features
        sizes = frame.groupby("district_id")["work_id"].transform("size")
        small = sizes < 10
        if small.any():
            assert frame.loc[small, "agency_district_share"].isna().all()


# ==========================================================================
# missingness is null, never zero
# ==========================================================================
class TestMissingness:
    def test_data_quality_is_bounded(self, gold):
        assert gold["data_quality"].between(0.0, 1.0).all()

    def test_data_quality_varies(self, gold):
        assert gold["data_quality"].nunique() > 1, "a constant nobody will notice is wrong"

    def test_missing_coordinates_yield_null_not_zero(self):
        """"Outside the district" and "we do not know" are different alerts."""
        works = pd.read_parquet(settings.paths.seeds / "synth_work.parquet").head(50).copy()
        works.loc[works.index[:10], ["latitude", "longitude"]] = np.nan
        result = build_features(
            works=works,
            payments=pd.read_parquet(settings.paths.seeds / "synth_payment.parquet"),
            progress=pd.read_parquet(settings.paths.seeds / "synth_progress.parquet"),
            photos=pd.read_parquet(settings.paths.seeds / "synth_photo.parquet"),
            districts=pd.read_parquet(settings.paths.seeds / "synth_district.parquet"),
            constituencies=pd.read_parquet(settings.paths.seeds / "silver_constituency.parquet"),
            states=pd.read_parquet(settings.paths.seeds / "silver_state.parquet"),
        )
        frame = result.features.set_index("work_id")
        blank = frame.loc[frame["geo_method"] == "unknown"]
        assert len(blank) == 10
        assert blank["geo_in_district"].isna().all()
        assert blank["distance_to_district_centroid_km"].isna().all()

    def test_geo_method_records_the_approximation(self, gold):
        """bbox is weaker than point-in-polygon and evidence must say so."""
        assert set(gold["geo_method"].dropna()) <= {"bbox", "postgis", "unknown"}

    def test_works_without_payments_report_zero_not_null(self, gold):
        assert gold["n_payments"].notna().all()
        assert gold["expenditure_to_date"].notna().all()


# ==========================================================================
# does each feature actually carry signal?
# ==========================================================================
class TestSeparation:
    """A feature that validates cleanly but carries no signal is worse than a
    missing one: nothing downstream can tell the difference."""

    @staticmethod
    def _split(gold, labels, pattern, column):
        targets = gold.index.isin(_targets(labels, pattern))
        values = gold[column].astype(float)
        return values[targets], values[~targets]

    def test_cost_inflation_lifts_the_peer_percentile(self, gold, labels):
        hit, rest = self._split(gold, labels, "cost_inflation", "unit_cost_peer_percentile")
        assert hit.median() > 0.9
        assert rest.median() < 0.7

    def test_pre_sanction_payment_is_flagged(self, gold, labels):
        hit, rest = self._split(gold, labels, "pre_sanction_payment", "has_pre_sanction_payment")
        assert hit.mean() > 0.8
        assert rest.mean() < 0.05

    def test_ghost_work_has_no_photo(self, gold, labels):
        hit, rest = self._split(gold, labels, "ghost_work", "photo_present")
        assert hit.mean() == 0.0
        assert rest.mean() > 0.5

    def test_advance_without_progress_opens_the_spend_gap(self, gold, labels):
        hit, rest = self._split(
            gold, labels, "advance_without_progress", "spend_progress_gap"
        )
        assert hit.median() > 40.0
        assert abs(rest.median()) < 15.0

    def test_agency_concentration_raises_share_and_hhi(self, gold, labels):
        share_hit, share_rest = self._split(
            gold, labels, "agency_concentration", "agency_district_share"
        )
        hhi_hit, hhi_rest = self._split(gold, labels, "agency_concentration", "agency_hhi")
        assert share_hit.median() > share_rest.median() * 2
        assert hhi_hit.median() > hhi_rest.median() * 1.5

    def test_split_payment_raises_payment_count(self, gold, labels):
        hit, rest = self._split(gold, labels, "split_payment", "n_payments")
        assert hit.median() >= 6
        assert rest.median() < 6

    def test_photo_reuse_raises_the_duplicate_hash_count(self, gold, labels):
        hit, rest = self._split(gold, labels, "photo_reuse", "phash_duplicate_count")
        assert hit.median() > 0
        assert rest.median() == 0

    def test_year_end_bunching_sets_the_flag(self, gold, labels):
        hit, rest = self._split(gold, labels, "year_end_bunching", "is_year_end_sanction")
        assert hit.mean() == 1.0
        assert rest.mean() < 0.2

    def test_geographic_displacement_leaves_the_district(self, gold, labels):
        """The regression test for the index-alignment bug."""
        inside_hit, inside_rest = self._split(
            gold, labels, "geographic_displacement", "geo_in_district"
        )
        assert inside_hit.mean() < 0.1, "displaced works must not read as inside"
        assert inside_rest.mean() > 0.9

    def test_geographic_displacement_raises_distance(self, gold, labels):
        hit, rest = self._split(
            gold, labels, "geographic_displacement", "distance_to_district_centroid_km"
        )
        assert hit.median() > rest.median() * 5

    def test_descriptions_are_aligned_to_their_own_work(self, gold):
        """The other half of the alignment bug: a one-row shift is invisible
        to every other check."""
        works = pd.read_parquet(settings.paths.seeds / "synth_work.parquet").set_index("work_id")
        aligned = gold["description"].astype(str) == works["description"].reindex(gold.index).astype(str)
        assert aligned.mean() == 1.0


# ==========================================================================
# derived quantities
# ==========================================================================
class TestDerived:
    def test_unit_cost_is_cost_over_quantity(self, gold):
        sample = gold.dropna(subset=["unit_cost", "quantity"]).head(200)
        expected = sample["sanctioned_cost"] / sample["quantity"]
        assert np.allclose(sample["unit_cost"], expected, rtol=1e-6)

    def test_cost_deviation_is_spend_over_sanction(self, gold):
        sample = gold.head(200)
        expected = sample["expenditure_to_date"] / sample["sanctioned_cost"]
        assert np.allclose(sample["cost_deviation_ratio"], expected, rtol=1e-6)

    def test_advance_ratio_is_bounded(self, gold):
        assert gold["advance_ratio"].between(0.0, 1.0001).all()

    def test_centrality_is_non_negative(self, gold):
        assert (gold["agency_centrality"] >= 0).all()

    def test_centrality_discriminates_between_agencies(self, gold):
        assert gold["agency_centrality"].nunique() > 10

    def test_days_since_sanction_is_positive(self, gold):
        assert (gold["days_since_sanction"] > 0).all()

    def test_description_language_is_detected(self, gold):
        shares = gold["description_lang"].value_counts(normalize=True)
        assert shares.get("hi", 0) > 0.1, "multilingual detection should fire"
        assert shares.get("en", 0) > 0.4


class TestBuildFromSeeds:
    def test_missing_seeds_raise_a_clear_error(self, monkeypatch, tmp_path):
        monkeypatch.setattr(type(settings.paths), "seeds", property(lambda self: tmp_path))
        with pytest.raises(FileNotFoundError, match="drishti seed"):
            build_from_seeds()

    def test_is_deterministic(self):
        first = build_from_seeds().features
        second = build_from_seeds().features
        assert first.equals(second)

    def test_empty_payments_does_not_crash(self):
        works = pd.read_parquet(settings.paths.seeds / "synth_work.parquet").head(30)
        result = build_features(
            works=works,
            payments=pd.DataFrame(
                columns=["payment_id", "work_id", "vendor_id", "amount", "payment_date", "payment_type"]
            ),
            progress=pd.DataFrame(columns=["update_id", "work_id", "update_date", "progress_pct"]),
            photos=pd.DataFrame(columns=["photo_id", "asset_id", "work_id", "phash", "exif_lat", "exif_lon", "captured_on"]),
            districts=pd.read_parquet(settings.paths.seeds / "synth_district.parquet"),
            constituencies=pd.read_parquet(settings.paths.seeds / "silver_constituency.parquet"),
            states=pd.read_parquet(settings.paths.seeds / "silver_state.parquet"),
        )
        assert len(result.features) == 30
        assert (result.features["n_payments"] == 0).all()
        assert (result.features["photo_present"] == 0).all()
