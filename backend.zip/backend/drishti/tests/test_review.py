"""The review workflow and the audit log — Blueprint §11, §12, §16.5.

These pin the two properties the workflow exists for: a decision is keyed on
something stable, and the history of who decided what is never overwritten.
"""

from __future__ import annotations

import pytest

from drishti.api.review import AuditLog, ReviewStore


@pytest.fixture
def store(tmp_path):
    audit = AuditLog(tmp_path / "audit.jsonl")
    return ReviewStore(path=tmp_path / "reviews.jsonl", audit=audit)


class TestStatusIsReplayed:
    def test_an_unreviewed_alert_is_open(self, store):
        assert store.status_of(4242) == "open"

    def test_the_latest_decision_wins(self, store):
        store.record(1, to_status="under_review", reviewer="dc")
        store.record(1, to_status="resolved", reviewer="dc", outcome="confirmed_issue")
        assert store.status_of(1) == "resolved"

    def test_history_is_appended_never_replaced(self, store):
        """The sequence is the point. A status field would keep only the last one."""
        for status in ("under_review", "dismissed", "under_review", "resolved"):
            store.record(7, to_status=status, reviewer="dc")
        history = store.history(7)
        assert [e["to_status"] for e in history] == [
            "under_review",
            "dismissed",
            "under_review",
            "resolved",
        ]
        assert [e["from_status"] for e in history] == [
            "open",
            "under_review",
            "dismissed",
            "under_review",
        ]

    def test_alerts_are_independent(self, store):
        store.record(1, to_status="resolved", reviewer="dc")
        assert store.status_of(2) == "open"

    def test_counts_include_untouched_alerts_as_open(self, store):
        store.record(1, to_status="resolved", reviewer="dc")
        store.record(2, to_status="under_review", reviewer="dc")
        counts = store.counts()
        assert counts["resolved"] == 1
        assert counts["under_review"] == 1

    def test_state_survives_a_new_store_over_the_same_file(self, store, tmp_path):
        """A restart must not lose a reviewer's work."""
        store.record(9, to_status="dismissed", reviewer="dc", outcome="false_positive")
        reopened = ReviewStore(path=store.path, audit=AuditLog(tmp_path / "a2.jsonl"))
        assert reopened.status_of(9) == "dismissed"
        assert reopened.outcomes()[9] == "false_positive"


class TestOutcomesAreWeakLabels:
    def test_outcomes_are_tracked_separately_from_status(self, store):
        """Workflow state and judgement are different things.

        `under_review` says where an alert sits; only an outcome says whether
        the flag was right, and only the second carries any training signal.
        """
        store.record(1, to_status="under_review", reviewer="dc")
        assert store.status_of(1) == "under_review"
        assert 1 not in store.outcomes()

        store.record(1, to_status="dismissed", reviewer="dc", outcome="false_positive")
        assert store.outcomes()[1] == "false_positive"


class TestValidation:
    def test_an_unknown_status_is_refused(self, store):
        """The file backend has to enforce what the CHECK constraint would."""
        with pytest.raises(ValueError, match="unknown status"):
            store.record(1, to_status="banana", reviewer="dc")

    def test_an_unknown_outcome_is_refused(self, store):
        with pytest.raises(ValueError, match="unknown outcome"):
            store.record(1, to_status="resolved", reviewer="dc", outcome="vibes")

    def test_a_refused_decision_is_not_recorded(self, store):
        with pytest.raises(ValueError):
            store.record(1, to_status="banana", reviewer="dc")
        assert store.history(1) == []

    def test_a_truncated_final_line_does_not_lose_the_history(self, store):
        """A crash mid-append costs one event, never the whole log."""
        store.record(1, to_status="under_review", reviewer="dc")
        with store.path.open("a", encoding="utf-8") as handle:
            handle.write('{"alert_id": 2, "to_stat')
        assert store.status_of(1) == "under_review"


class TestAuditLog:
    def test_every_decision_is_audited(self, store):
        store.record(5, to_status="resolved", reviewer="dc.pune", outcome="confirmed_issue")
        entries = store.audit.entries(entity_id="5")
        assert len(entries) == 1
        assert entries[0]["actor"] == "dc.pune"
        assert entries[0]["action"] == "alert.resolved"
        assert entries[0]["detail"]["outcome"] == "confirmed_issue"

    def test_the_audit_records_the_transition_not_just_the_result(self, store):
        store.record(5, to_status="under_review", reviewer="dc")
        store.record(5, to_status="dismissed", reviewer="supervisor")
        detail = store.audit.entries(entity_id="5")[0]["detail"]
        assert detail["from"] == "under_review"
        assert detail["to"] == "dismissed"

    def test_entries_are_newest_first(self, store):
        store.record(1, to_status="under_review", reviewer="a")
        store.record(1, to_status="resolved", reviewer="b")
        assert [e["actor"] for e in store.audit.entries()] == ["b", "a"]
