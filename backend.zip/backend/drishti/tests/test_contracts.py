"""Tests for the five seams.

These are the most valuable tests in the project right now. A contract that
drifts silently costs six people a day of debugging; a contract with a test
costs whoever changed it thirty seconds.

Several tests encode audit findings as executable rules rather than prose:

  R-01  corroboration counts independent evidence families, not layers
  R-02  risk, confidence, severity and data_quality stay separate
  R-03  ground truth never reaches the feature space
  R-05  benchmark provenance travels with the number
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest

from drishti.config import settings
from drishti.contracts.gold import (
    GOLD_COLUMNS,
    GOLD_FEATURES,
    NUMERIC_FEATURES,
    PEER_GROUP_KEYS,
    REQUIRED_COLUMNS,
    Leakage,
    leakage_report,
    missingness,
    model_input_columns,
    spec_for,
    validate_frame,
)
from drishti.contracts.labels import (
    LABEL_COLUMNS,
    LAYERS_DENIED_LABELS,
    FraudLabel,
    LabelSource,
    PatternRecall,
    assert_no_label_leakage,
    split_by_visibility,
)
from drishti.contracts.layer import (
    LAYER_NAMES,
    EvidenceFamily,
    LayerOutput,
    Reason,
    Severity,
    empty_output,
    independent_families,
    validate_layer_frame,
)
from drishti.contracts.risk import (
    Band,
    assess,
    build_narrative,
    corroboration_confidence,
    entropy_of_agreement,
)
from drishti.domain import PatternVisibility


def _reason(code="r", family=EvidenceFamily.FINANCIAL, severity=Severity.MEDIUM, **kw):
    return Reason(
        code=code,
        text=f"{code}: an observation long enough to be evidence",
        family=family,
        severity=severity,
        **kw,
    )


# ==========================================================================
# Seam A
# ==========================================================================
class TestGoldContract:
    def test_columns_are_unique(self):
        assert len(GOLD_COLUMNS) == len(set(GOLD_COLUMNS))

    def test_work_id_is_the_spine(self):
        assert GOLD_COLUMNS[0] == "work_id"
        assert "work_id" in REQUIRED_COLUMNS

    def test_peer_group_keys_are_declared_columns(self):
        for key in PEER_GROUP_KEYS:
            assert key in GOLD_COLUMNS

    def test_every_feature_documents_missing_behaviour(self):
        for spec in GOLD_FEATURES:
            assert spec.missing_behavior, f"{spec.name} does not say what happens when it is null"

    def test_every_feature_names_its_source(self):
        for spec in GOLD_FEATURES:
            assert spec.source

    def test_required_columns_cannot_be_nullable(self):
        for spec in GOLD_FEATURES:
            if spec.required:
                assert not spec.nullable

    def test_post_outcome_columns_are_excluded_from_model_inputs(self):
        """actual_completion_date is fine for an eval join, fatal as an input."""
        post = [s.name for s in GOLD_FEATURES if s.leakage is Leakage.POST_OUTCOME]
        assert post, "at least one post-outcome column should be declared"
        for name in post:
            assert name not in NUMERIC_FEATURES

    def test_leakage_report_covers_every_column(self):
        counted = sum(len(v) for v in leakage_report().values())
        assert counted == len(GOLD_FEATURES)

    def test_model_input_columns_honours_exclusions(self):
        columns = model_input_columns(exclude=["progress_pct"])
        assert "progress_pct" not in columns

    def test_unknown_column_lookup_is_loud(self):
        with pytest.raises(KeyError, match="not in the Gold contract"):
            spec_for("invented_column")

    def test_sor_feature_warns_about_its_provenance(self):
        # R-05: the assumption has to be visible where the column is defined.
        assert "ASSUMPTION" in spec_for("unit_cost_vs_sor").description.upper()

    def test_peer_percentile_exists_as_the_defensible_alternative(self):
        assert spec_for("unit_cost_peer_percentile").peer_relative


class TestGoldValidation:
    def test_accepts_a_conforming_frame(self):
        frame = pd.DataFrame({c: [1] for c in GOLD_COLUMNS})
        assert validate_frame(frame) == []

    def test_reports_missing_columns(self):
        frame = pd.DataFrame({"work_id": [1]})
        problems = validate_frame(frame)
        assert any("missing columns" in p for p in problems)

    def test_rejects_undeclared_columns_in_strict_mode(self):
        frame = pd.DataFrame({c: [1] for c in GOLD_COLUMNS})
        frame["surprise"] = 1
        assert any("undeclared" in p for p in validate_frame(frame))

    def test_allows_undeclared_columns_when_not_strict(self):
        frame = pd.DataFrame({c: [1] for c in GOLD_COLUMNS})
        frame["surprise"] = 1
        assert validate_frame(frame, strict=False) == []

    def test_flags_nulls_in_required_columns(self):
        frame = pd.DataFrame({c: [1] for c in GOLD_COLUMNS})
        frame["sanctioned_cost"] = [None]
        assert any("sanctioned_cost is required" in p for p in validate_frame(frame))

    def test_missingness_covers_optional_columns_only(self):
        frame = pd.DataFrame({c: [1] for c in GOLD_COLUMNS})
        report = missingness(frame)
        assert "sanctioned_cost" not in report
        assert "quantity" in report


# ==========================================================================
# Seam B
# ==========================================================================
class TestLayerOutput:
    def test_accepts_a_valid_output(self):
        out = LayerOutput(1, "rules", 0.5, reasons=(_reason(),))
        assert out.score == 0.5

    def test_rejects_unknown_layer(self):
        with pytest.raises(ValueError, match="unknown layer"):
            LayerOutput(1, "astrology", 0.5, reasons=(_reason(),))

    @pytest.mark.parametrize("field", ["score", "confidence", "data_quality"])
    def test_rejects_out_of_range_values(self, field):
        kwargs = {"work_id": 1, "layer": "rules", "score": 0.5, "reasons": (_reason(),)}
        kwargs[field] = 1.4
        with pytest.raises(ValueError, match=field):
            LayerOutput(**kwargs)

    def test_a_score_without_a_reason_is_rejected(self):
        # An unexplained score cannot be shown to an investigator.
        with pytest.raises(ValueError, match="no reason"):
            LayerOutput(1, "rules", 0.9)

    def test_zero_score_needs_no_reason(self):
        assert LayerOutput(1, "rules", 0.0).score == 0.0

    def test_empty_output_helper(self):
        out = empty_output(5, "graph", data_quality=0.6)
        assert out.score == 0.0 and out.data_quality == 0.6

    def test_reason_texts_preserves_the_manual_shape(self):
        out = LayerOutput(1, "rules", 0.5, reasons=(_reason("a"), _reason("b")))
        assert out.reason_texts == [r.text for r in out.reasons]
        assert all(isinstance(t, str) for t in out.reason_texts)

    def test_families_deduplicates(self):
        out = LayerOutput(
            1, "rules", 0.5,
            reasons=(_reason("a"), _reason("b"), _reason("c", family=EvidenceFamily.NETWORK)),
        )
        assert out.families == frozenset({EvidenceFamily.FINANCIAL, EvidenceFamily.NETWORK})

    def test_max_severity(self):
        out = LayerOutput(
            1, "rules", 0.5,
            reasons=(_reason("a", severity=Severity.LOW), _reason("b", severity=Severity.CRITICAL)),
        )
        assert out.max_severity is Severity.CRITICAL

    def test_to_row_is_json_serialisable(self):
        json.dumps(LayerOutput(1, "rules", 0.5, reasons=(_reason(),)).to_row())

    def test_all_seven_layers_are_named(self):
        assert len(LAYER_NAMES) == 7


class TestReason:
    def test_rejects_empty_text(self):
        with pytest.raises(ValueError, match="code and human-readable text"):
            Reason(code="x", text="", family=EvidenceFamily.FINANCIAL)

    def test_rejects_text_too_short_to_be_evidence(self):
        with pytest.raises(ValueError, match="too short"):
            Reason(code="x", text="bad", family=EvidenceFamily.FINANCIAL)

    def test_carries_provenance(self):
        # R-05: an assumed benchmark must be distinguishable from a cited one.
        assert _reason(provenance="assumed").to_dict()["provenance"] == "assumed"


class TestLayerFrameValidation:
    def _frame(self, **overrides):
        base = {
            "work_id": [1, 2],
            "layer": ["rules", "rules"],
            "score": [0.1, 0.2],
            "confidence": [1.0, 1.0],
            "data_quality": [1.0, 1.0],
            "reasons": [[], []],
            "factors": [{}, {}],
        }
        base.update(overrides)
        return pd.DataFrame(base)

    def test_accepts_a_valid_frame(self):
        assert validate_layer_frame(self._frame()) == []

    def test_rejects_scores_outside_unit_interval(self):
        problems = validate_layer_frame(self._frame(score=[0.1, 1.9]))
        assert any("outside [0, 1]" in p for p in problems)

    def test_rejects_null_scores(self):
        problems = validate_layer_frame(self._frame(score=[0.1, None]))
        assert any("nulls" in p for p in problems)

    def test_rejects_duplicate_work_ids(self):
        problems = validate_layer_frame(self._frame(work_id=[1, 1]))
        assert any("duplicate work_id" in p for p in problems)

    def test_detects_wrong_layer(self):
        problems = validate_layer_frame(self._frame(layer=["rules", "graph"]), layer="rules")
        assert any("expected layer" in p for p in problems)


# ==========================================================================
# Seam C -- the four quantities
# ==========================================================================
class TestCorroboration:
    def test_saturates_below_certainty(self):
        assert corroboration_confidence(20) < 1.0

    def test_more_families_means_more_confidence(self):
        values = [corroboration_confidence(n) for n in range(1, 6)]
        assert values == sorted(values)

    def test_no_evidence_means_no_confidence(self):
        assert corroboration_confidence(0) == 0.0

    def test_second_family_is_worth_more_than_the_fifth(self):
        gain_2 = corroboration_confidence(2) - corroboration_confidence(1)
        gain_5 = corroboration_confidence(5) - corroboration_confidence(4)
        assert gain_2 > gain_5


class TestAssess:
    WEIGHTS = {"rules": 0.4, "unsupervised": 0.3, "graph": 0.3}
    BANDS = {"low": 0.0, "medium": 0.35, "high": 0.60, "critical": 0.80}

    def _assess(self, outputs, **kw):
        return assess(1, outputs, self.WEIGHTS, self.BANDS, **kw)

    def test_three_layers_one_family_counts_once(self):
        """R-01. Three views of unit_cost are not three confirmations."""
        outputs = [
            LayerOutput(1, layer, 0.8, reasons=(_reason(layer, EvidenceFamily.FINANCIAL),))
            for layer in ("rules", "unsupervised", "graph")
        ]
        result = self._assess(outputs)
        assert result.n_corroborating_families == 1
        assert result.corroborating_families == ("financial",)

    def test_three_families_beat_three_layers_for_confidence(self):
        same = [
            LayerOutput(1, layer, 0.8, reasons=(_reason(layer, EvidenceFamily.FINANCIAL),))
            for layer in ("rules", "unsupervised", "graph")
        ]
        varied = [
            LayerOutput(1, "rules", 0.8, reasons=(_reason("a", EvidenceFamily.FINANCIAL),)),
            LayerOutput(1, "unsupervised", 0.8, reasons=(_reason("b", EvidenceFamily.TEMPORAL),)),
            LayerOutput(1, "graph", 0.8, reasons=(_reason("c", EvidenceFamily.NETWORK),)),
        ]
        assert self._assess(varied).confidence > self._assess(same).confidence

    def test_risk_and_confidence_are_independent(self):
        """R-02. Identical risk, different evidence breadth."""
        thin = self._assess(
            [LayerOutput(1, "rules", 0.8, reasons=(_reason("a", EvidenceFamily.FINANCIAL),))]
        )
        broad = self._assess(
            [
                LayerOutput(1, "rules", 0.8, reasons=(_reason("a", EvidenceFamily.FINANCIAL),)),
                LayerOutput(1, "graph", 0.8, reasons=(_reason("b", EvidenceFamily.NETWORK),)),
                LayerOutput(1, "duplicate", 0.8, reasons=(_reason("c", EvidenceFamily.TEXTUAL),)),
            ]
        )
        assert broad.confidence > thin.confidence

    def test_missing_layer_contributes_nothing(self):
        """Fusion runs on day one with only L0."""
        result = self._assess([LayerOutput(1, "rules", 1.0, reasons=(_reason(),))])
        assert result.overall_risk == pytest.approx(1.0)

    def test_data_quality_is_the_weakest_link(self):
        outputs = [
            LayerOutput(1, "rules", 0.8, data_quality=0.9, reasons=(_reason("a"),)),
            LayerOutput(1, "graph", 0.8, data_quality=0.4,
                        reasons=(_reason("b", EvidenceFamily.NETWORK),)),
        ]
        assert self._assess(outputs).data_quality == pytest.approx(0.4)

    def test_critical_rule_escalates_regardless_of_score(self):
        outputs = [
            LayerOutput(1, "rules", 0.15,
                        reasons=(_reason("pre_sanction_payment", EvidenceFamily.COMPLIANCE,
                                         Severity.CRITICAL),))
        ]
        result = self._assess(outputs, critical_rules=("pre_sanction_payment",))
        assert result.band is Band.CRITICAL
        assert result.escalated_by_rule == "pre_sanction_payment"

    def test_low_data_quality_caps_the_critical_band(self):
        outputs = [
            LayerOutput(1, "rules", 0.15, data_quality=0.2,
                        reasons=(_reason("pre_sanction_payment", EvidenceFamily.COMPLIANCE,
                                         Severity.CRITICAL),))
        ]
        result = self._assess(outputs, critical_rules=("pre_sanction_payment",))
        assert result.band is Band.HIGH
        assert result.escalated_by_rule is None

    def test_severity_is_the_worst_reason_not_an_average(self):
        outputs = [
            LayerOutput(1, "rules", 0.5,
                        reasons=(_reason("a", severity=Severity.LOW),
                                 _reason("b", severity=Severity.CRITICAL))),
        ]
        assert self._assess(outputs).severity is Severity.CRITICAL

    def test_no_signals_yields_zero_risk_and_zero_confidence(self):
        result = self._assess([empty_output(1, "rules")])
        assert result.overall_risk == 0.0
        assert result.confidence == 0.0

    def test_actionable_requires_both_band_and_confidence(self):
        thin = self._assess(
            [LayerOutput(1, "rules", 0.95, reasons=(_reason("a", EvidenceFamily.FINANCIAL),))]
        )
        assert thin.band.rank >= Band.HIGH.rank
        assert not thin.is_actionable, "a high band on one family is a lead, not a case"

    def test_output_is_json_serialisable(self):
        result = self._assess([LayerOutput(1, "rules", 0.5, reasons=(_reason(),))])
        json.dumps(result.to_dict())

    def test_narrative_never_asserts_wrongdoing(self):
        result = self._assess([LayerOutput(1, "rules", 0.9, reasons=(_reason(),))])
        assert "not a finding of wrongdoing" in result.narrative.lower()

    def test_single_family_narrative_asks_for_verification(self):
        result = self._assess([LayerOutput(1, "rules", 0.9, reasons=(_reason(),))])
        assert "verification" in result.narrative.lower()


class TestNarrativeAndAgreement:
    def test_empty_reasons_narrative(self):
        assert "No risk signals" in build_narrative((), 0, 0.0)

    def test_entropy_is_zero_for_a_single_layer(self):
        assert entropy_of_agreement([LayerOutput(1, "rules", 0.9, reasons=(_reason(),))]) == 0.0

    def test_entropy_is_one_when_layers_agree_evenly(self):
        outputs = [
            LayerOutput(1, layer, 0.5, reasons=(_reason(layer),))
            for layer in ("rules", "unsupervised", "graph")
        ]
        assert entropy_of_agreement(outputs) == pytest.approx(1.0)


def test_independent_families_unions_across_layers():
    outputs = [
        LayerOutput(1, "rules", 0.5, reasons=(_reason("a", EvidenceFamily.FINANCIAL),)),
        LayerOutput(1, "graph", 0.5, reasons=(_reason("b", EvidenceFamily.NETWORK),)),
    ]
    assert independent_families(outputs) == frozenset(
        {EvidenceFamily.FINANCIAL, EvidenceFamily.NETWORK}
    )


# ==========================================================================
# Seam E
# ==========================================================================
class TestLabels:
    def test_rejects_unregistered_pattern(self):
        with pytest.raises(ValueError, match="unknown pattern"):
            FraudLabel(1, "made_up", True, PatternVisibility.HELD_OUT, "high")

    def test_held_out_flag(self):
        label = FraudLabel(1, "photo_reuse", True, PatternVisibility.HELD_OUT, "critical")
        assert label.is_held_out

    def test_synthetic_injection_is_the_only_certain_source(self):
        assert LabelSource.SYNTHETIC_INJECTION.is_ground_truth
        assert not LabelSource.HUMAN_REVIEW.is_ground_truth

    def test_split_by_visibility(self):
        labels = [
            FraudLabel(1, "cost_inflation", True, PatternVisibility.RULE_VISIBLE, "high"),
            FraudLabel(2, "photo_reuse", True, PatternVisibility.HELD_OUT, "critical"),
        ]
        visible, held = split_by_visibility(labels)
        assert len(visible) == 1 and len(held) == 1

    def test_unsupervised_and_rules_are_denied_labels(self):
        assert "unsupervised" in LAYERS_DENIED_LABELS
        assert "rules" in LAYERS_DENIED_LABELS


class TestLeakageGuard:
    def test_passes_clean_columns(self):
        assert_no_label_leakage(list(GOLD_COLUMNS))

    def test_catches_a_label_column(self):
        with pytest.raises(ValueError, match="leaked"):
            assert_no_label_leakage(["work_id", "pattern"])

    def test_catches_a_pattern_name(self):
        with pytest.raises(ValueError, match="leaked"):
            assert_no_label_leakage(["work_id", "ghost_work"])

    def test_catches_common_target_names(self):
        for name in ("is_fraud", "label", "target", "y"):
            with pytest.raises(ValueError, match="leaked"):
                assert_no_label_leakage(["work_id", name])

    def test_label_columns_are_declared(self):
        assert "work_id" in LABEL_COLUMNS and "visibility" in LABEL_COLUMNS


class TestPatternRecall:
    def test_held_out_recall_is_quotable(self):
        recall = PatternRecall("photo_reuse", PatternVisibility.HELD_OUT, 10, 7)
        assert recall.quotable
        assert recall.recall == pytest.approx(0.7)

    def test_rule_visible_recall_is_not_quotable(self):
        """R-03. It measures the rule agreeing with its own injector."""
        recall = PatternRecall("cost_inflation", PatternVisibility.RULE_VISIBLE, 10, 10)
        assert not recall.quotable
        assert "not a detection claim" in recall.describe()

    def test_zero_injected_yields_nan_not_a_crash(self):
        import math

        assert math.isnan(PatternRecall("x", PatternVisibility.HELD_OUT, 0, 0).recall)


# ==========================================================================
# fixtures
# ==========================================================================
class TestFixtures:
    def test_gold_fixture_exists_and_conforms(self):
        path = settings.paths.fixtures / "sample_gold.parquet"
        if not path.exists():
            pytest.skip("run scripts/build_fixtures.py first")
        frame = pd.read_parquet(path)
        assert validate_frame(frame) == []
        assert len(frame) >= 100

    def test_gold_fixture_contains_planted_anomalies(self):
        path = settings.paths.fixtures / "sample_gold.parquet"
        if not path.exists():
            pytest.skip("run scripts/build_fixtures.py first")
        frame = pd.read_parquet(path)
        assert frame["unit_cost_vs_sor"].max() > 2.0, "no obvious cost outlier to detect"
        assert (frame["photo_present"] == 0).any(), "no ghost-work candidate"

    def test_gold_fixture_exercises_data_quality(self):
        path = settings.paths.fixtures / "sample_gold.parquet"
        if not path.exists():
            pytest.skip("run scripts/build_fixtures.py first")
        frame = pd.read_parquet(path)
        assert frame["data_quality"].min() < 1.0, "data_quality is a constant nobody will notice"

    def test_api_fixtures_match_the_response_models(self):
        directory = settings.paths.fixtures / "sample_api"
        if not directory.exists():
            pytest.skip("run scripts/build_fixtures.py first")
        from drishti.api.models import AlertStats, RiskOut

        risk = json.loads((directory / "work_risk.json").read_text(encoding="utf-8"))
        RiskOut.model_validate(risk)
        stats = json.loads((directory / "alerts_stats.json").read_text(encoding="utf-8"))
        AlertStats.model_validate(stats)

    def test_risk_fixture_carries_all_four_quantities(self):
        path = settings.paths.fixtures / "sample_api" / "work_risk.json"
        if not path.exists():
            pytest.skip("run scripts/build_fixtures.py first")
        payload = json.loads(path.read_text(encoding="utf-8"))
        for key in ("overall_risk", "confidence", "severity", "data_quality"):
            assert key in payload

    def test_ddl_exists_and_declares_the_four_quantities(self):
        ddl = Path(__file__).resolve().parents[1] / "db" / "ddl.sql"
        text = ddl.read_text(encoding="utf-8")
        for column in ("overall_risk", "confidence", "data_quality", "severity"):
            assert column in text
        assert "corroborating_families" in text
