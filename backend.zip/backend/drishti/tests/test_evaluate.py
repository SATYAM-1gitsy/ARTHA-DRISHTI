"""Tests for the evaluation harness.

Two groups. The metric tests check the arithmetic against cases with known
answers, because a metric that is subtly wrong is worse than no metric — it
produces confident, reproducible, incorrect numbers.

The governance tests check that the harness cannot be *used* to produce a
dishonest figure: pooling rule-visible and held-out results has to raise rather
than return, and every quotable number has to be labelled as such.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from drishti.config import settings
from drishti.evaluate import (
    EvaluationReport,
    average_precision,
    build_label_sets,
    calibration,
    evaluate_scores,
    precision_at_k,
    rank_metrics,
    recall_at_k,
    roc_auc,
)
from drishti.evaluate.harness import (
    independent_with_reason,
    ranking_score,
    run_evaluation,
    write_report,
)

READY = all(
    p.is_file()
    for p in (
        settings.paths.out / "gold.parquet",
        settings.paths.out / "risk_score.parquet",
        settings.paths.seeds / "fraud_label.parquet",
    )
)


# ==========================================================================
# metric arithmetic
# ==========================================================================
class TestAveragePrecision:
    def test_perfect_ranking_scores_one(self):
        scores = np.array([0.9, 0.8, 0.7, 0.2, 0.1])
        labels = np.array([1, 1, 1, 0, 0])
        assert average_precision(scores, labels) == pytest.approx(1.0)

    def test_worst_ranking_scores_near_the_floor(self):
        scores = np.array([0.9, 0.8, 0.7, 0.2, 0.1])
        labels = np.array([0, 0, 0, 1, 1])
        assert average_precision(scores, labels) < 0.6

    def test_known_value(self):
        # positives at ranks 1 and 3: (1/1 + 2/3) / 2
        scores = np.array([0.9, 0.8, 0.7, 0.6])
        labels = np.array([1, 0, 1, 0])
        assert average_precision(scores, labels) == pytest.approx((1.0 + 2 / 3) / 2)

    def test_ties_are_scored_at_worst_case(self):
        """A detector giving one score to everything must not win by luck."""
        scores = np.full(100, 0.5)
        labels = np.zeros(100, dtype=int)
        labels[:10] = 1
        # Every item tied: precision can only be the prevalence.
        assert average_precision(scores, labels) == pytest.approx(0.10, abs=1e-9)

    def test_no_positives_is_nan_not_zero(self):
        result = average_precision(np.array([0.5, 0.2]), np.array([0, 0]))
        assert np.isnan(result), "no positives means undefined, not perfect failure"

    def test_rejects_mismatched_shapes(self):
        with pytest.raises(ValueError, match="disagree"):
            average_precision(np.array([0.1, 0.2]), np.array([1]))

    def test_rejects_non_binary_labels(self):
        with pytest.raises(ValueError, match="0 or 1"):
            average_precision(np.array([0.1, 0.2]), np.array([0, 2]))

    def test_rejects_empty(self):
        with pytest.raises(ValueError, match="empty"):
            average_precision(np.array([]), np.array([]))


class TestRocAuc:
    def test_perfect_separation(self):
        assert roc_auc(np.array([0.9, 0.8, 0.2, 0.1]), np.array([1, 1, 0, 0])) == 1.0

    def test_random_ranking_is_a_half(self):
        rng = np.random.default_rng(0)
        scores = rng.random(4000)
        labels = rng.integers(0, 2, 4000)
        assert roc_auc(scores, labels) == pytest.approx(0.5, abs=0.05)

    def test_all_ties_is_a_half(self):
        assert roc_auc(np.full(50, 0.5), np.tile([0, 1], 25)) == pytest.approx(0.5)


class TestPrecisionRecallAtK:
    def test_precision_at_k(self):
        scores = np.array([0.9, 0.8, 0.7, 0.6, 0.5])
        labels = np.array([1, 0, 1, 0, 0])
        assert precision_at_k(scores, labels, 2) == pytest.approx(0.5)
        assert precision_at_k(scores, labels, 4) == pytest.approx(0.5)

    def test_recall_at_k(self):
        scores = np.array([0.9, 0.8, 0.7, 0.6])
        labels = np.array([1, 0, 1, 0])
        assert recall_at_k(scores, labels, 1) == pytest.approx(0.5)
        assert recall_at_k(scores, labels, 4) == pytest.approx(1.0)

    def test_k_larger_than_population_is_clamped(self):
        scores = np.array([0.9, 0.1])
        labels = np.array([1, 0])
        assert precision_at_k(scores, labels, 100) == pytest.approx(0.5)


class TestRankMetrics:
    def test_reports_prevalence_and_lift(self):
        scores = np.linspace(1.0, 0.0, 1000)
        labels = np.zeros(1000, dtype=int)
        labels[:50] = 1  # the 50 highest-scoring works
        metrics = rank_metrics(scores, labels, ks=(50, 100))
        assert metrics.prevalence == pytest.approx(0.05)
        assert metrics.precision_at[50] == pytest.approx(1.0)
        assert metrics.lift_at[50] == pytest.approx(20.0)

    def test_false_positives_per_100_is_the_complement(self):
        scores = np.linspace(1.0, 0.0, 200)
        labels = np.zeros(200, dtype=int)
        labels[:20] = 1
        metrics = rank_metrics(scores, labels, ks=(50,))
        assert metrics.false_positives_per_100[50] == pytest.approx(
            100 * (1 - metrics.precision_at[50])
        )

    def test_pr_auc_lift_is_against_prevalence(self):
        scores = np.linspace(1.0, 0.0, 500)
        labels = np.zeros(500, dtype=int)
        labels[:25] = 1
        metrics = rank_metrics(scores, labels, ks=(50,))
        assert metrics.pr_auc_lift == pytest.approx(metrics.pr_auc / 0.05)

    def test_summary_row_names_false_positives(self):
        scores = np.linspace(1.0, 0.0, 600)
        labels = np.zeros(600, dtype=int)
        labels[:30] = 1
        assert "false positives per 100" in rank_metrics(scores, labels).summary_row(500)


class TestCalibration:
    def test_perfectly_calibrated_scores(self):
        rng = np.random.default_rng(1)
        scores = rng.random(20000)
        labels = (rng.random(20000) < scores).astype(int)
        result = calibration(scores, labels)
        assert result.is_calibrated
        assert result.bias == "roughly calibrated"

    def test_detects_over_confidence(self):
        scores = np.full(1000, 0.9)
        labels = np.zeros(1000, dtype=int)
        labels[:100] = 1
        result = calibration(scores, labels)
        assert not result.is_calibrated
        assert result.bias == "over-confident"

    def test_detects_under_confidence(self):
        scores = np.full(1000, 0.1)
        labels = np.ones(1000, dtype=int)
        assert calibration(scores, labels).bias == "under-confident"

    def test_brier_is_zero_for_a_perfect_predictor(self):
        scores = np.array([1.0, 0.0, 1.0, 0.0])
        labels = np.array([1, 0, 1, 0])
        assert calibration(scores, labels).brier == pytest.approx(0.0)

    def test_bins_cover_the_population(self):
        rng = np.random.default_rng(2)
        scores = rng.random(500)
        labels = rng.integers(0, 2, 500)
        result = calibration(scores, labels)
        assert sum(b["n"] for b in result.bins) == 500


# ==========================================================================
# the honesty rules
# ==========================================================================
def _labels_frame() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {"work_id": 1, "pattern": "photo_reuse", "visibility": "held_out"},
            {"work_id": 2, "pattern": "year_end_bunching", "visibility": "held_out"},
            {"work_id": 3, "pattern": "cost_inflation", "visibility": "rule_visible"},
            {"work_id": 4, "pattern": "ghost_work", "visibility": "rule_visible"},
        ]
    )


class TestLabelSets:
    def test_splits_by_visibility(self):
        held, visible = build_label_sets(_labels_frame())
        assert held.work_ids == frozenset({1, 2})
        assert visible.work_ids == frozenset({3, 4})

    def test_only_held_out_is_quotable(self):
        held, visible = build_label_sets(_labels_frame())
        assert held.quotable is True
        assert visible.quotable is False

    def test_rule_visible_caveat_is_explicit(self):
        _, visible = build_label_sets(_labels_frame())
        assert "not a detection claim" in visible.caveat.lower()

    def test_sets_do_not_overlap(self):
        held, visible = build_label_sets(_labels_frame())
        assert not (held.work_ids & visible.work_ids)


class TestPoolingIsImpossible:
    """R-03 enforced in code, not by convention."""

    def test_pooled_metrics_raises(self):
        report = EvaluationReport(
            held_out=rank_metrics(np.array([0.9, 0.1]), np.array([1, 0])),
            rule_visible=rank_metrics(np.array([0.9, 0.1]), np.array([0, 1])),
            per_pattern=[],
            calibration=calibration(np.array([0.9, 0.1]), np.array([1, 0])),
        )
        with pytest.raises(NotImplementedError, match="must not be pooled"):
            report.pooled_metrics()

    def test_the_error_explains_why(self):
        report = EvaluationReport(
            held_out=rank_metrics(np.array([0.9, 0.1]), np.array([1, 0])),
            rule_visible=rank_metrics(np.array([0.9, 0.1]), np.array([0, 1])),
            per_pattern=[],
            calibration=calibration(np.array([0.9, 0.1]), np.array([1, 0])),
        )
        with pytest.raises(NotImplementedError, match="agreeing with its own injector"):
            report.pooled_metrics()

    def test_report_has_no_combined_metric_field(self):
        fields = set(EvaluationReport.__dataclass_fields__)
        for forbidden in ("combined", "overall", "pooled", "all_patterns"):
            assert forbidden not in fields

    def test_quotable_headline_uses_held_out_only(self):
        report = EvaluationReport(
            held_out=rank_metrics(np.array([0.9, 0.1]), np.array([1, 0])),
            rule_visible=rank_metrics(np.array([0.9, 0.1]), np.array([0, 1])),
            per_pattern=[],
            calibration=calibration(np.array([0.9, 0.1]), np.array([1, 0])),
        )
        assert "held-out" in report.quotable_headline


class TestEvaluateScores:
    def test_computes_both_sets_separately(self):
        scores = pd.Series({1: 0.9, 2: 0.8, 3: 0.2, 4: 0.1})
        held, visible = evaluate_scores(scores, _labels_frame(), ks=(2,))
        assert held.precision_at[2] == pytest.approx(1.0)
        assert visible.precision_at[2] == pytest.approx(0.0)

    def test_the_two_sets_can_disagree(self):
        """Which is the entire point of keeping them apart."""
        scores = pd.Series({1: 0.9, 2: 0.8, 3: 0.2, 4: 0.1})
        held, visible = evaluate_scores(scores, _labels_frame(), ks=(2,))
        assert held.pr_auc != visible.pr_auc


# ==========================================================================
# against the real run
# ==========================================================================
@pytest.fixture(scope="module")
def report():
    if not READY:
        pytest.skip("run the pipeline first")
    return run_evaluation(with_ablation=True)


@pytest.mark.skipif(not READY, reason="run the pipeline first")
class TestRealEvaluation:
    def test_produces_both_label_sets(self, report):
        assert report.held_out.n_positive > 0
        assert report.rule_visible.n_positive > 0

    def test_beats_prevalence_on_held_out_patterns(self, report):
        """The only claim this project can make about detection.

        The floor is prevalence: a ranker that does not beat the base rate has
        no detection claim at all, whatever else is true of it.

        This asserted `prevalence * 2` until Block 18, and the 2x was not an
        invariant -- it was calibrated against a figure that turned out to be
        inflated. `_inject_year_end_bunching` moved `sanction_date` without
        moving `recommended_on` or the payments, so two rules that target
        nothing were recovering the pattern off the resulting artifacts.
        Fixing the injector took held-out PR-AUC from 7.35x prevalence to
        1.94x. The old threshold was measuring the generator (ADR-0017).

        Lowering a threshold to make a suite green is usually the wrong move,
        so the number that moved is recorded below rather than removed: the
        floor tests the invariant, and the guard band tests for regression
        against what is actually being achieved.
        """
        assert report.held_out.pr_auc > report.held_out.prevalence, (
            "held-out PR-AUC is at or below the base rate -- the ranking carries "
            "no detection signal at all"
        )

    def test_held_out_performance_has_not_regressed(self, report):
        """Guards the measured figure, which the floor above is too loose to catch.

        Measured 2026-09-03 with the injector fixed: PR-AUC 0.0407 at 2.10%
        prevalence, a 1.94x lift. The band is deliberately tight; a real
        improvement should fail this and be recorded, not slip through.
        """
        lift = report.held_out.pr_auc / report.held_out.prevalence
        assert 1.5 < lift < 3.0, (
            f"held-out lift is {lift:.2f}x against a recorded 1.94x. If a change "
            "improved it, update this band and ADR-0017's table. If it dropped, "
            "something regressed."
        )

    def test_reports_layers_that_actually_ran(self, report):
        assert "rules" in report.layers_run

    def test_per_pattern_marks_rule_visible_as_unquotable(self, report):
        visible = [r for r in report.per_pattern if not r.quotable]
        assert visible
        assert all("not a detection claim" in r.describe() for r in visible)

    def test_ablation_covers_every_layer_alone(self, report):
        names = {r.name for r in report.ablation}
        assert any(n.endswith(" only") for n in names)
        assert "all layers" in names

    def test_ablation_includes_leave_one_out(self, report):
        assert any(r.name.startswith("without ") for r in report.ablation)

    def test_marginal_value_is_computed_per_layer(self, report):
        marginal = report.marginal_value()
        assert "rules" in marginal
        assert "unsupervised" in marginal

    def test_every_layer_is_justified_on_one_of_two_grounds(self, report):
        """The governance rule a targeted detector forced into existence.

        This test previously asserted that the full stack beats every single
        layer on held-out PR-AUC. L4 disproved it: a *targeted* detector
        trades against generalisation by construction -- no held-out pattern
        is textual, so any weight L4 receives displaces held-out positives.
        Measured, and monotonic in the weight.

        The invariant that does hold: a layer must either improve held-out
        generalisation, or carry independent-corpus evidence measured on data
        the generator never produced. A layer with neither has not earned its
        place.
        """
        justified_layers = {r.layer for r in report.independent if r.justified}
        unjustified = [
            layer
            for layer, delta in report.marginal_value().items()
            if delta <= 0 and layer not in justified_layers
        ]
        if not report.independent:
            pytest.skip("independent corpora need sentence-transformers (ml-worker)")
        assert not unjustified, (
            f"layers with neither positive held-out marginal value nor independent "
            f"evidence: {unjustified}"
        )

    def test_a_targeted_layer_may_cost_held_out_performance(self, report):
        """Documents the trade rather than pretending it does not exist."""
        marginal = report.marginal_value()
        if "duplicate" in marginal:
            assert marginal["duplicate"] < 0.01, (
                "L4 was measured as costing held-out PR-AUC; if that has changed, "
                "re-read ADR-0010 before relaxing this"
            )

    def test_calibration_is_measured_and_reported_honestly(self, report):
        # The score is a priority ordering, not a probability, and the report
        # says so rather than presenting Brier as a quality score.
        assert report.calibration.brier >= 0.0
        assert report.calibration.bias in (
            "roughly calibrated",
            "over-confident",
            "under-confident",
        )
        assert "not a probability" in report.to_dict()["calibration"]["note"]

    def test_report_serialises_with_the_quotable_flags(self, report):
        import json

        payload = report.to_dict()
        assert payload["held_out"]["quotable"] is True
        assert payload["rule_visible"]["quotable"] is False
        json.dumps(payload)

    def test_render_labels_the_unquotable_section(self, report):
        rendered = report.render()
        assert "NOT a detection claim" in rendered
        assert "quotable" in rendered

    def test_writes_metrics_json(self, report, tmp_path):
        path = write_report(report)
        assert path.endswith("metrics.json")


class TestQueueOrderingIsWhatGetsMeasured:
    """The harness must rank works the way the review queue presents them.

    `api.store` sorts by (overall_risk, confidence) so a thin lead never
    outranks a corroborated finding at the same score. The harness ranked on
    overall_risk alone, which measured an ordering no reviewer is shown. That
    gap is not academic: L0 emits a handful of discrete scores, so 17% of the
    corpus shares one value and the queue inside that block was unordered in
    the measurement and ordered in the product.
    """

    def test_confidence_breaks_ties_the_way_the_queue_does(self):
        risk = np.array([0.5, 0.5, 0.9])
        confidence = np.array([0.2, 0.8, 0.1])
        key = ranking_score(risk, confidence)
        assert key[2] == key.max()          # risk still dominates
        assert key[1] > key[0]              # confidence orders within a tie

    def test_works_identical_on_both_keys_still_tie(self):
        # average_precision breaks ties pessimistically on purpose. Inventing
        # an order for indistinguishable works would hand that protection back.
        key = ranking_score(np.array([0.5, 0.5]), np.array([0.3, 0.3]))
        assert key[0] == key[1]

    def test_without_a_tiebreak_the_score_is_returned_unchanged(self):
        risk = np.array([0.5, 0.1, 0.9])
        assert np.array_equal(ranking_score(risk, None), risk)

    def test_a_missing_confidence_does_not_explode(self):
        key = ranking_score(np.array([0.5, 0.5]), np.array([np.nan, 0.3]))
        assert np.isfinite(key).all()
        assert key[1] > key[0]  # a null confidence sorts below a real one


class TestIndependentCorpusSaysWhyItIsEmpty:
    """An empty `independent` list must never be silent.

    L4's only quotable justification lives in that category (ADR-0010). When
    the encoder is absent the list is empty for a reason that has nothing to
    do with L4's quality, and "measured, found nothing" is the opposite
    conclusion from "never ran".
    """

    def test_empty_results_carry_a_reason(self):
        results, reason = independent_with_reason()
        if results:
            assert reason is None
        else:
            assert reason and "not measured" in reason

    def test_the_reason_reaches_the_rendered_report(self):
        report = EvaluationReport(
            held_out=rank_metrics(np.array([0.9, 0.1]), np.array([1, 0])),
            rule_visible=rank_metrics(np.array([0.9, 0.1]), np.array([1, 0])),
            per_pattern=[],
            calibration=calibration(np.array([0.9, 0.1]), np.array([1, 0])),
            independent=[],
            independent_unavailable="not measured: the encoder is unavailable here",
        )
        assert "not measured" in report.render()
        assert report.to_dict()["independent_unavailable"]
