"""Tests for configuration objects and their guard rails."""

from __future__ import annotations

import dataclasses
import os
from pathlib import Path

import pytest

import drishti.config as config_module
from drishti.config import FusionConfig, GenConfig, GPUConfig, Paths, settings


class TestPaths:
    def test_subdirectories_are_created_on_access(self):
        paths = Paths()
        for directory in (paths.raw, paths.seeds, paths.out, paths.api, paths.fixtures):
            assert directory.is_dir()

    def test_paths_are_absolute(self):
        assert Paths().data.is_absolute()

    def test_a_relative_setting_anchors_to_the_repo_not_the_cwd(self, monkeypatch, tmp_path):
        """`.env` ships `DRISHTI_DATA_DIR=./data`, and cwd must not decide it.

        A plain `.resolve()` read the working directory, so running from
        `backend/` looked for the data tree in `<repo>/backend/data`, found
        nothing, and created an empty one. No error -- just the wrong answer.
        """
        from drishti.config import REPO_ROOT

        monkeypatch.setenv("DRISHTI_DATA_DIR", "./data")
        monkeypatch.chdir(tmp_path)
        assert Paths().data == (REPO_ROOT / "data").resolve()

    def test_an_absolute_setting_is_honoured_exactly(self, monkeypatch, tmp_path):
        """What the containers pass, and it must not be re-anchored."""
        monkeypatch.setenv("DRISHTI_DATA_DIR", str(tmp_path / "elsewhere"))
        assert Paths().data == (tmp_path / "elsewhere").resolve()

    def test_checkpoints_anchor_the_same_way(self, monkeypatch, tmp_path):
        from drishti.config import REPO_ROOT

        monkeypatch.setenv("DRISHTI_CHECKPOINT_DIR", "./checkpoints")
        monkeypatch.chdir(tmp_path)
        assert Paths().checkpoints == (REPO_ROOT / "checkpoints").resolve()


class TestGenConfig:
    def test_defaults_are_sane(self):
        config = GenConfig()
        assert config.n_works > 0
        assert 0.0 < config.inject_rate < 1.0

    def test_held_out_share_is_material(self):
        # R-03: too small a held-out share makes the only honest metric noisy.
        assert GenConfig().held_out_share >= 0.2

    def test_rejects_out_of_range_rate(self):
        with pytest.raises(ValueError, match="inject_rate"):
            GenConfig(inject_rate=1.5)

    def test_rejects_negative_work_count(self):
        with pytest.raises(ValueError, match="n_works"):
            GenConfig(n_works=0)

    def test_is_immutable(self):
        with pytest.raises(dataclasses.FrozenInstanceError):
            GenConfig().n_works = 5  # type: ignore[misc]


class TestFusionConfig:
    def test_band_for_maps_scores_to_bands(self):
        config = FusionConfig()
        assert config.band_for(0.05) == "low"
        assert config.band_for(0.45) == "medium"
        assert config.band_for(0.70) == "high"
        assert config.band_for(0.95) == "critical"

    def test_band_boundaries_are_inclusive_from_below(self):
        config = FusionConfig()
        assert config.band_for(config.bands["high"]) == "high"

    def test_band_for_is_monotone(self):
        config = FusionConfig()
        order = {"low": 0, "medium": 1, "high": 2, "critical": 3}
        previous = -1
        for step in range(0, 101):
            current = order[config.band_for(step / 100)]
            assert current >= previous
            previous = current

    def test_rejects_descending_bands(self):
        with pytest.raises(ValueError, match="ascending"):
            FusionConfig(bands={"low": 0.9, "high": 0.1})

    def test_rejects_negative_weight(self):
        with pytest.raises(ValueError, match="negative"):
            FusionConfig(weights={"rules": -1.0})

    def test_missing_layer_contributes_nothing(self):
        """Fusion must run with only the layers that exist."""
        config = FusionConfig(weights={"rules": 1.0})
        assert "graph" not in config.weights
        assert config.band_for(0.0) == "low"

    def test_critical_rules_are_declared(self):
        assert FusionConfig().critical_rules

    def test_data_quality_floor_guards_critical_band(self):
        # A critical finding computed from mostly-missing inputs must not
        # present as confident (audit finding R-02).
        assert 0.0 < FusionConfig().min_data_quality_for_critical < 1.0


class TestGPUConfig:
    def test_defaults_load(self):
        config = GPUConfig()
        assert config.batch_size > 0
        assert config.mixed_precision in ("off", "fp16", "bf16")

    def test_leaves_vram_headroom(self):
        # The audited machine has one 8 GB GPU shared with any resident model.
        assert GPUConfig().vram_headroom_mb > 0

    def test_rejects_unknown_precision(self):
        with pytest.raises(ValueError, match="mixed_precision"):
            GPUConfig(mixed_precision="int4")

    def test_rejects_bad_batch_size(self):
        with pytest.raises(ValueError, match="batch_size"):
            GPUConfig(batch_size=0)


class TestSettings:
    def test_singleton_is_constructed(self):
        assert settings.seed >= 0
        assert settings.api_port > 0

    def test_database_url_is_well_formed(self):
        assert settings.database_url.startswith("postgresql+psycopg2://")

    def test_redis_url_is_well_formed(self):
        assert settings.redis_url.startswith("redis://")

    def test_no_secret_is_hardcoded_in_the_source_default(self):
        """The code must not carry a credential; .env supplies it.

        This deliberately checks the *code* default rather than the resolved
        URL. Once config loads .env, the resolved URL legitimately contains
        whatever the developer put there -- including the shipped placeholder
        on a fresh clone -- and failing the suite for that would train everyone
        to ignore a red test. `drishti doctor` warns about the placeholder
        instead, which is where a deployment concern belongs.
        """
        source = Path(config_module.__file__).read_text(encoding="utf-8")
        assert "change-me" not in source

    def test_dotenv_does_not_override_real_environment(self, monkeypatch, tmp_path):
        """An explicit env var must win over a stale file."""
        monkeypatch.setenv("DRISHTI_TEST_KEY", "from_environment")
        env_file = tmp_path / ".env"
        env_file.write_text("DRISHTI_TEST_KEY=from_file\n", encoding="utf-8")
        config_module._load_dotenv(env_file)
        assert os.environ["DRISHTI_TEST_KEY"] == "from_environment"

    def test_dotenv_loads_unset_keys(self, monkeypatch, tmp_path):
        monkeypatch.delenv("DRISHTI_UNSET_KEY", raising=False)
        env_file = tmp_path / ".env"
        env_file.write_text('DRISHTI_UNSET_KEY="quoted value"\n# comment\n\n', encoding="utf-8")
        assert config_module._load_dotenv(env_file) == 1
        assert os.environ["DRISHTI_UNSET_KEY"] == "quoted value"
        monkeypatch.delenv("DRISHTI_UNSET_KEY", raising=False)

    def test_dotenv_missing_file_is_not_an_error(self, tmp_path):
        assert config_module._load_dotenv(tmp_path / "absent.env") == 0
