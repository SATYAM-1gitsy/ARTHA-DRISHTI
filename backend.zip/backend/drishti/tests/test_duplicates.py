"""Tests for L4 duplicate detection.

The tests that matter most here are about *not* over-claiming. Text similarity
alone must not decide duplication, the backend actually in use must be visible
in the evidence, and the thresholds must be backend-specific — one threshold
across sparse and dense vectors is meaningless, and running the bi-encoder at
the TF-IDF threshold flagged 2,086 works at 8.7% precision because 0.62 sits
below the dense median of 0.453.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from drishti.config import settings
from drishti.contracts.gold import GOLD_COLUMNS
from drishti.contracts.layer import EvidenceFamily
from drishti.detect.duplicates import (
    DUPLICATE_THRESHOLD,
    LAYER,
    SEMANTIC_GATE,
    WEIGHTS,
    block_candidates,
    embed_descriptions,
    run,
    score_pairs,
)

GOLD = settings.paths.out / "gold.parquet"
LABELS = settings.paths.seeds / "fraud_label.parquet"
READY = GOLD.is_file() and LABELS.is_file()


def frame(rows: list[dict]) -> pd.DataFrame:
    base = {column: 0 for column in GOLD_COLUMNS}
    base.update(
        {
            "description": "",
            "sector": "roads_bridges",
            "work_type": "village_road",
            "state": "Bihar",
            "geo_method": "bbox",
            "status": "in_progress",
            "description_lang": "en",
            "phash": "x",
            "constituency": "C",
            "data_quality": 1.0,
            "sanction_date": pd.Timestamp("2025-01-01"),
            "recommended_on": pd.Timestamp("2024-12-01"),
            "expected_completion_date": pd.Timestamp("2026-01-01"),
            "actual_completion_date": pd.NaT,
            "latitude": 25.0,
            "longitude": 85.0,
            "sanctioned_cost": 1_000_000.0,
            "district_id": 1,
        }
    )
    built = []
    for row in rows:
        merged = dict(base)
        merged.update(row)
        built.append(merged)
    return pd.DataFrame(built)[list(GOLD_COLUMNS)]


# ==========================================================================
# blocking
# ==========================================================================
class TestBlocking:
    def test_groups_by_district(self):
        works = frame(
            [{"work_id": i, "district_id": 1 if i <= 2 else 2} for i in range(1, 7)]
        )
        blocks = block_candidates(works)
        assert len(blocks) == 2
        assert sorted(len(b) for b in blocks) == [2, 4]

    def test_a_lone_work_forms_no_block(self):
        works = frame([{"work_id": 1, "district_id": 1}])
        assert block_candidates(works) == []

    def test_large_districts_are_split_by_work_type(self):
        rows = [
            {
                "work_id": i,
                "district_id": 1,
                "work_type": "village_road" if i % 2 else "culvert",
            }
            for i in range(1, 12)
        ]
        blocks = block_candidates(frame(rows), max_block=5)
        assert len(blocks) == 2

    def test_blocking_cuts_the_quadratic_cost(self):
        rows = [{"work_id": i, "district_id": i % 20} for i in range(1, 401)]
        works = frame(rows)
        in_block = sum(len(b) * (len(b) - 1) // 2 for b in block_candidates(works))
        naive = len(works) * (len(works) - 1) // 2
        assert in_block < naive * 0.10


# ==========================================================================
# configuration honesty
# ==========================================================================
class TestSmallCorpusGuard:
    """TF-IDF over a handful of documents has no usable vocabulary."""

    def test_tiny_corpus_does_not_collapse_to_stopwords(self):
        # With min_df=2 over two documents the vocabulary becomes {"of"} and
        # every pair scores a cosine of 1.0.
        embeddings, backend = embed_descriptions(
            ["Construction of village road", "Purchase of computers"]
        )
        if backend != "tfidf":
            pytest.skip("bi-encoder in use; this guards the fallback")
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        normalised = embeddings / np.maximum(norms, 1e-12)
        assert float(normalised[0] @ normalised[1]) < 0.99


class TestConfiguration:
    def test_thresholds_are_backend_specific(self):
        """One threshold across sparse and dense vectors is meaningless."""
        assert DUPLICATE_THRESHOLD["bi-encoder"] != DUPLICATE_THRESHOLD["tfidf"]
        assert DUPLICATE_THRESHOLD["bi-encoder"] > DUPLICATE_THRESHOLD["tfidf"]

    def test_semantic_gate_is_backend_specific(self):
        assert SEMANTIC_GATE["bi-encoder"] > SEMANTIC_GATE["tfidf"]

    def test_semantic_is_not_a_majority_of_the_score(self):
        """Text alone must not carry a pair over the threshold."""
        assert WEIGHTS["semantic"] < 0.5
        assert sum(WEIGHTS.values()) == pytest.approx(1.0)

    def test_corroborating_signals_are_weighted(self):
        for signal in ("geographic", "financial", "temporal", "lexical"):
            assert WEIGHTS[signal] > 0


# ==========================================================================
# pair scoring
# ==========================================================================
class TestScorePairs:
    def test_identical_works_score_high(self):
        works = frame(
            [
                {"work_id": 1, "description": "Construction of village road at Ward 4"},
                {"work_id": 2, "description": "Construction of village road at Ward 4"},
            ]
        )
        embeddings, backend = embed_descriptions(works["description"].tolist())
        result = score_pairs(works, embeddings, block_candidates(works), backend=backend)
        assert result.n_pairs == 1
        assert result.pairs[0].total > DUPLICATE_THRESHOLD[backend]

    def test_unrelated_works_score_low(self):
        # Padded to a realistic corpus size: TF-IDF over two documents has no
        # usable vocabulary, which is a property of the instrument rather than
        # of the pair, and is guarded separately below.
        works = frame(
            [
                {"work_id": 1, "description": "Construction of village road at Ward 4"},
                {"work_id": 2, "description": "Purchase of computers for the library"},
            ]
            + [
                {"work_id": i, "description": f"Installation of handpump at site {i}"}
                for i in range(3, 60)
            ]
        )
        embeddings, backend = embed_descriptions(works["description"].tolist())
        result = score_pairs(works, embeddings, block_candidates(works), backend=backend)
        flagged = {(p.left, p.right) for p in result.pairs}
        assert (1, 2) not in flagged

    def test_distance_pulls_a_textual_match_down(self):
        """The corroboration principle: same words, far apart, is weaker."""
        text = "Construction of village road at Ward 4"
        near = frame(
            [
                {"work_id": 1, "description": text, "latitude": 25.0},
                {"work_id": 2, "description": text, "latitude": 25.0001},
            ]
        )
        far = frame(
            [
                {"work_id": 1, "description": text, "latitude": 25.0},
                {"work_id": 2, "description": text, "latitude": 28.0},
            ]
        )
        embeddings, backend = embed_descriptions([text, text])
        near_score = score_pairs(near, embeddings, block_candidates(near), 0.0, backend).pairs[0]
        far_score = score_pairs(far, embeddings, block_candidates(far), 0.0, backend).pairs[0]
        assert near_score.total > far_score.total

    def test_clusters_are_transitive(self):
        text = "Construction of village road at Ward 4"
        works = frame([{"work_id": i, "description": text} for i in (1, 2, 3)])
        embeddings, backend = embed_descriptions(works["description"].tolist())
        result = score_pairs(works, embeddings, block_candidates(works), backend=backend)
        assert len(result.clusters) == 1
        assert len(next(iter(result.clusters.values()))) == 3

    def test_pairs_report_their_components(self):
        text = "Construction of village road at Ward 4"
        works = frame([{"work_id": 1, "description": text}, {"work_id": 2, "description": text}])
        embeddings, backend = embed_descriptions([text, text])
        pair = score_pairs(works, embeddings, block_candidates(works), 0.0, backend).pairs[0]
        assert set(pair.components()) == {
            "semantic", "lexical", "geographic", "financial", "temporal"
        }


# ==========================================================================
# Seam B
# ==========================================================================
class TestSeamB:
    def _pair(self) -> pd.DataFrame:
        text = "Construction of village road at Ward 4"
        return frame(
            [
                {"work_id": 1, "description": text},
                {"work_id": 2, "description": text},
                {"work_id": 3, "description": "Purchase of computers for the district library"},
            ]
        )

    def test_emits_the_declared_layer(self):
        assert all(o.layer == LAYER for o in run(self._pair()))

    def test_one_output_per_work(self):
        outputs = run(self._pair())
        assert len(outputs) == 3
        assert {o.work_id for o in outputs} == {1, 2, 3}

    def test_the_unrelated_work_scores_zero(self):
        outputs = {o.work_id: o for o in run(self._pair())}
        assert outputs[3].score == 0.0
        assert outputs[3].reasons == ()

    def test_the_duplicate_pair_both_score(self):
        outputs = {o.work_id: o for o in run(self._pair())}
        assert outputs[1].score > 0
        assert outputs[2].score > 0

    def test_reason_cites_the_twin(self):
        """An investigator cannot act on "this is a duplicate" without the twin."""
        outputs = {o.work_id: o for o in run(self._pair())}
        reason = outputs[1].reasons[0]
        assert "#2" in reason.text
        assert reason.factors["twin_work_id"] == 2

    def test_reason_is_textual_family(self):
        outputs = {o.work_id: o for o in run(self._pair())}
        assert outputs[1].reasons[0].family is EvidenceFamily.TEXTUAL

    def test_reason_defers_to_verification(self):
        outputs = {o.work_id: o for o in run(self._pair())}
        assert "measurement books" in outputs[1].reasons[0].text

    def test_evidence_names_the_backend(self):
        """TF-IDF and a bi-encoder are not the same instrument."""
        outputs = {o.work_id: o for o in run(self._pair())}
        assert outputs[1].reasons[0].factors["embedding_backend"] in ("tfidf", "bi-encoder")
        assert outputs[3].factors["embedding_backend"] in ("tfidf", "bi-encoder")

    def test_tfidf_findings_carry_lower_confidence(self):
        """The fallback cannot see across languages, and says so."""
        outputs = run(self._pair())
        backend = outputs[0].factors["embedding_backend"]
        if backend == "tfidf":
            assert all(o.confidence < 0.7 for o in outputs)

    def test_empty_input(self):
        assert run(pd.DataFrame()) == []

    def test_output_is_json_serialisable(self):
        import json

        for output in run(self._pair()):
            json.dumps(output.to_row())


# ==========================================================================
# against the real data
# ==========================================================================
@pytest.mark.skipif(not READY, reason="run the pipeline first")
class TestAgainstRealData:
    @staticmethod
    def _load():
        return pd.read_parquet(GOLD), pd.read_parquet(LABELS)

    def test_recovers_most_injected_duplicates(self):
        gold, labels = self._load()
        targeted = set(labels.loc[labels["pattern"] == "duplicate_work", "work_id"])
        found = {o.work_id for o in run(gold) if o.score > 0}
        recall = len(found & targeted) / len(targeted)
        assert recall > 0.4, f"only {recall:.1%} of injected duplicates found"

    def test_does_not_flag_most_of_the_population(self):
        gold, _ = self._load()
        rate = sum(1 for o in run(gold) if o.score > 0) / len(gold)
        assert rate < 0.10, f"L4 fires on {rate:.1%} of works"

    def test_blocking_keeps_the_run_tractable(self):
        import time

        gold, _ = self._load()
        start = time.perf_counter()
        run(gold)
        assert time.perf_counter() - start < 180.0


class TestIndependentEvidence:
    """L4's justification is a corpus the generator never produced."""

    def test_independent_corpus_is_committed(self):
        assert (settings.paths.fixtures / "description_pairs.json").is_file()

    def test_independent_evaluation_reports_a_baseline_comparison(self):
        from drishti.evaluate import evaluate_independent

        results = evaluate_independent()
        if not results:
            pytest.skip("sentence-transformers ships in the ml-worker only")
        result = results[0]
        assert result.baseline_roc_auc > 0
        assert "does not beat" in result.describe() or result.justified
