"""Tests for L3 network structure.

The governance test is the one that matters most: `vendor_round_tripping` is a
**held-out** pattern, so nothing here may be designed to detect it. L3 computes
generic structural properties — concentration, degree, neighbourhood closure,
community density — and if a closed payee ring scores high on "closed
neighbourhood" that is generalisation, not targeting.

The graph-structure tests exist because L3's features were briefly measuring
nothing at all: with payees drawn uniformly across the country, the
co-occurrence graph was near-complete, label propagation returned a single
community and clustering ranged 0.415–0.443. Features can be present, finite
and completely uninformative, and only a variance check catches that.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from drishti.config import settings
from drishti.contracts.gold import GOLD_COLUMNS
from drishti.contracts.layer import EvidenceFamily
from drishti.detect import graph as l3
from drishti.detect.graph import (
    FORBIDDEN_TARGETS,
    GRAPH_FEATURES,
    LAYER,
    OUTLIER_QUANTILE,
    build_metrics,
    label_propagation,
    run,
)

GOLD = settings.paths.out / "gold.parquet"
LABELS = settings.paths.seeds / "fraud_label.parquet"
READY = GOLD.is_file() and LABELS.is_file()


def frame(rows: list[dict]) -> pd.DataFrame:
    base = {column: 0 for column in GOLD_COLUMNS}
    base.update(
        {
            "sector": "roads_bridges",
            "work_type": "village_road",
            "state": "Bihar",
            "geo_method": "bbox",
            "status": "in_progress",
            "description": "work",
            "description_lang": "en",
            "phash": "x",
            "constituency": "C",
            "data_quality": 1.0,
            "sanction_date": pd.Timestamp("2025-01-01"),
            "recommended_on": pd.Timestamp("2024-12-01"),
            "expected_completion_date": pd.Timestamp("2026-01-01"),
            "actual_completion_date": pd.NaT,
            "mp_id": 1,
            "district_id": 1,
        }
    )
    built = []
    for row in rows:
        merged = dict(base)
        merged.update(row)
        built.append(merged)
    return pd.DataFrame(built)[list(GOLD_COLUMNS)]


# ==========================================================================
# governance
# ==========================================================================
class TestGovernance:
    def test_held_out_patterns_are_declared_forbidden(self):
        assert "vendor_round_tripping" in FORBIDDEN_TARGETS

    def test_no_feature_names_a_held_out_pattern(self):
        """A feature called `round_tripping_score` would be a targeted detector."""
        for feature in GRAPH_FEATURES:
            for pattern in FORBIDDEN_TARGETS:
                assert pattern not in feature

    def test_module_does_not_reference_ground_truth(self):
        import ast
        from pathlib import Path

        tree = ast.parse(Path(l3.__file__).read_text(encoding="utf-8"))
        imported: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                imported.update(alias.name for alias in node.names)
        assert "fraud_label" not in imported
        assert "FraudLabel" not in imported

    def test_features_are_generic_network_properties(self):
        """Concentration, degree, closure, density -- nothing pattern-specific."""
        assert set(GRAPH_FEATURES) >= {
            "vendor_agency_share",
            "vendor_n_agencies",
            "vendor_clustering",
            "agency_vendor_hhi",
        }


# ==========================================================================
# graph primitives
# ==========================================================================
class TestLabelPropagation:
    def test_two_disconnected_cliques_become_two_communities(self):
        adjacency = np.zeros((6, 6))
        for group in ([0, 1, 2], [3, 4, 5]):
            for i in group:
                for j in group:
                    if i != j:
                        adjacency[i, j] = 1
        assert len(set(label_propagation(adjacency))) == 2

    def test_a_connected_graph_becomes_one_community(self):
        adjacency = np.ones((5, 5))
        np.fill_diagonal(adjacency, 0)
        assert len(set(label_propagation(adjacency))) == 1

    def test_is_deterministic(self):
        rng = np.random.default_rng(0)
        adjacency = (rng.random((30, 30)) > 0.7).astype(float)
        adjacency = np.maximum(adjacency, adjacency.T)
        np.fill_diagonal(adjacency, 0)
        assert list(label_propagation(adjacency)) == list(label_propagation(adjacency))

    def test_empty_graph(self):
        assert len(label_propagation(np.zeros((0, 0)))) == 0


class TestClustering:
    def test_a_closed_triangle_scores_one(self):
        adjacency = np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]], dtype=float)
        assert l3._local_clustering(adjacency)[0] == pytest.approx(1.0)

    def test_a_star_centre_scores_zero(self):
        """Hub with unconnected spokes: no closure at all."""
        adjacency = np.zeros((4, 4))
        adjacency[0, 1:] = 1
        adjacency[1:, 0] = 1
        assert l3._local_clustering(adjacency)[0] == pytest.approx(0.0)

    def test_isolated_node_scores_zero_not_nan(self):
        adjacency = np.zeros((3, 3))
        assert not np.isnan(l3._local_clustering(adjacency)).any()


# ==========================================================================
# metrics
# ==========================================================================
class TestBuildMetrics:
    def test_produces_every_declared_feature(self):
        works = frame([{"work_id": i, "agency_id": 1, "vendor_id": 1.0} for i in range(1, 6)])
        metrics = build_metrics(works)
        assert set(GRAPH_FEATURES) <= set(metrics.frame.columns)

    def test_a_sole_payee_holds_the_whole_agency(self):
        works = frame([{"work_id": i, "agency_id": 1, "vendor_id": 1.0} for i in range(1, 6)])
        metrics = build_metrics(works)
        assert metrics.frame["vendor_agency_share"].iloc[0] == pytest.approx(1.0)
        assert metrics.frame["agency_vendor_hhi"].iloc[0] == pytest.approx(1.0)

    def test_spread_payees_lower_concentration(self):
        works = frame(
            [{"work_id": i, "agency_id": 1, "vendor_id": float(i)} for i in range(1, 6)]
        )
        metrics = build_metrics(works)
        assert metrics.frame["agency_vendor_hhi"].iloc[0] < 0.5

    def test_works_without_a_payee_are_not_scored(self):
        works = frame(
            [
                {"work_id": 1, "agency_id": 1, "vendor_id": 1.0},
                {"work_id": 2, "agency_id": 1, "vendor_id": np.nan},
            ]
        )
        metrics = build_metrics(works)
        assert pd.isna(metrics.frame["vendor_agency_share"].iloc[1])
        assert metrics.notes

    def test_no_payee_information_at_all(self):
        works = frame([{"work_id": i, "vendor_id": np.nan} for i in range(1, 4)])
        metrics = build_metrics(works)
        assert metrics.notes


# ==========================================================================
# the features must actually vary
# ==========================================================================
@pytest.fixture(scope="module")
def metrics():
    if not READY:
        pytest.skip("run the pipeline first")
    return build_metrics(pd.read_parquet(GOLD))


@pytest.mark.skipif(not READY, reason="run the pipeline first")
class TestFeaturesCarryInformation:
    """A feature can be present, finite and completely uninformative.

    Payees drawn uniformly across the country produced a near-complete
    co-occurrence graph: one community, clustering confined to 0.415-0.443.
    Every value was valid and none of it meant anything.
    """

    def test_the_payee_network_has_locality(self, metrics):
        gold = pd.read_parquet(GOLD).dropna(subset=["vendor_id"])
        districts_per_payee = gold.groupby("vendor_id")["district_id"].nunique().median()
        assert districts_per_payee < 10, (
            "a payee operating in every district is a random draw, not a contractor"
        )

    def test_communities_are_plural(self, metrics):
        assert metrics.n_communities > 1, "label propagation collapsed to one community"

    def test_clustering_varies(self, metrics):
        assert metrics.frame["vendor_clustering"].std() > 0.05

    def test_community_density_varies(self, metrics):
        assert metrics.frame["community_density"].std() > 0.01

    def test_every_feature_has_variance(self, metrics):
        flat = [
            column
            for column in GRAPH_FEATURES
            if metrics.frame[column].notna().any()
            and metrics.frame[column].std(skipna=True) < 1e-9
        ]
        assert not flat, f"features carrying no information: {flat}"


# ==========================================================================
# Seam B
# ==========================================================================
class TestSeamB:
    def _population(self) -> pd.DataFrame:
        rows = []
        for i in range(1, 201):
            rows.append(
                {
                    "work_id": i,
                    "agency_id": i % 40,
                    "vendor_id": float(i % 30),
                    "district_id": i % 12,
                    "mp_id": i % 20,
                }
            )
        # One payee that holds an entire agency on its own.
        for i in range(201, 211):
            rows.append(
                {"work_id": i, "agency_id": 99, "vendor_id": 99.0, "district_id": 99, "mp_id": 99}
            )
        return frame(rows)

    def test_emits_the_declared_layer(self):
        assert all(o.layer == LAYER for o in run(self._population()))

    def test_one_output_per_work(self):
        works = self._population()
        assert len(run(works)) == len(works)

    def test_scores_are_bounded(self):
        for output in run(self._population()):
            assert 0.0 <= output.score <= 1.0
            assert 0.0 <= output.confidence <= 1.0

    def test_a_score_always_has_a_reason(self):
        for output in run(self._population()):
            if output.score > 0:
                assert output.reasons

    def test_reasons_are_network_family(self):
        outputs = [o for o in run(self._population()) if o.reasons]
        assert outputs
        assert all(r.family is EvidenceFamily.NETWORK for r in outputs[0].reasons)

    def test_reason_defers_to_verification(self):
        """Concentration is not impropriety, and the card must say so."""
        outputs = [o for o in run(self._population()) if o.reasons]
        assert "not itself improper" in outputs[0].reasons[0].text

    def test_missing_payee_scores_zero_at_low_confidence(self):
        """A gap in evidence is not an absence of risk."""
        works = frame(
            [
                {"work_id": 1, "agency_id": 1, "vendor_id": 1.0},
                {"work_id": 2, "agency_id": 1, "vendor_id": np.nan},
            ]
        )
        outputs = {o.work_id: o for o in run(works)}
        assert outputs[2].score == 0.0
        assert outputs[2].confidence < 0.5

    def test_fire_rate_tracks_the_quantile(self):
        outputs = run(self._population())
        rate = sum(1 for o in outputs if o.score > 0) / len(outputs)
        assert rate <= OUTLIER_QUANTILE * 4

    def test_empty_input(self):
        assert run(pd.DataFrame()) == []

    def test_output_is_json_serialisable(self):
        import json

        for output in run(self._population()):
            json.dumps(output.to_row())


# ==========================================================================
# against the real data
# ==========================================================================
@pytest.mark.skipif(not READY, reason="run the pipeline first")
class TestAgainstRealData:
    def test_generalises_to_a_held_out_pattern(self):
        """The claim L3 exists to make, on a pattern nobody targeted.

        No graph feature is designed for payee rings. If closed-neighbourhood
        and low-degree measures catch them, that is a general measure finding
        a specific pattern -- which is what held-out evaluation is for.
        """
        gold = pd.read_parquet(GOLD)
        labels = pd.read_parquet(LABELS)
        targeted = set(labels.loc[labels["pattern"] == "vendor_round_tripping", "work_id"])
        outputs = run(gold)
        found = {o.work_id for o in outputs if o.score > 0}
        fire_rate = len(found) / len(outputs)
        recall = len(found & targeted) / max(len(targeted), 1)
        assert recall > fire_rate * 3, (
            f"recall {recall:.1%} at a {fire_rate:.1%} fire rate is not generalisation"
        )

    def test_runs_quickly(self):
        import time

        gold = pd.read_parquet(GOLD)
        start = time.perf_counter()
        run(gold)
        assert time.perf_counter() - start < 60.0
