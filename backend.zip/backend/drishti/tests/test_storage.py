"""The storage probe, and why it round-trips instead of importing.

This exists because the whole pipeline stopped and nothing said why. Every
stage from `seed` onward reads and writes parquet, `drishti doctor` reported a
usable environment, and 156 tests then failed on an `ImportError` raised from
inside pandas -- three layers away from the actual cause, which was Windows
Application Control blocking pyarrow's `_parquet` extension module while
leaving the rest of pyarrow importable.
"""

from __future__ import annotations

import pandas as pd
import pytest

from drishti.storage import ENGINES, check_parquet


class TestParquetProbe:
    def test_the_pipeline_can_persist_its_own_artefacts(self):
        """The precondition every stage after `ingest` depends on."""
        support = check_parquet()
        assert support.usable, (
            "no working parquet engine on this machine, so `drishti seed`, "
            f"`features`, `score` and `eval` cannot run. {support.summary()}. "
            f"Engine errors: {support.problems}"
        )

    def test_a_working_engine_is_named(self):
        support = check_parquet()
        assert support.engines
        assert set(support.engines) <= set(ENGINES)

    def test_the_summary_is_actionable_when_it_fails(self):
        """A failure has to say what to install, not just that it failed."""
        from drishti.storage import ParquetSupport

        broken = ParquetSupport(usable=False, problems=("pyarrow: ImportError: blocked",))
        assert "pip install" in broken.summary()

    def test_importing_an_engine_is_not_evidence_it_works(self):
        """Guards the assumption that made the original failure invisible.

        `import pyarrow` succeeds on the reference machine and
        `import pyarrow.parquet` raises. Any future shortcut that checks for
        the top-level package instead of a real round trip reintroduces the
        bug, so the probe's contract is pinned here: it must exercise pandas.
        """
        pytest.importorskip("pyarrow")
        support = check_parquet()
        # Whatever the outcome, it must have been reached by writing and
        # reading a real frame -- a usable report means pandas round-tripped.
        if support.usable:
            frame = pd.DataFrame({"work_id": [1, 2], "value": [0.5, 1.5]})
            import io

            buffer = io.BytesIO()
            frame.to_parquet(buffer, engine=support.engines[0], index=False)
            buffer.seek(0)
            assert len(pd.read_parquet(buffer, engine=support.engines[0])) == 2
