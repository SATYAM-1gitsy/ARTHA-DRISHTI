"""Tests for L5 temporal structure.

The governance tests carry the most weight here. Two of the five held-out
patterns are temporal, so this is the layer most likely to become a targeted
detector by accident, and the checks below are written to catch that rather
than to confirm the arithmetic.

The generality tests are the interesting ones: they assert that each feature
responds to a *general* property and specifically that it does **not** single
out the held-out shape. `progress_roughness` must score a monotone stop-start
series as high as a reversing one, and `sanction_local_density` must score a
July cluster as high as a March one. If either stopped being true, the feature
would have quietly become a pattern detector.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from drishti.config import settings
from drishti.contracts.gold import GOLD_COLUMNS
from drishti.contracts.layer import EvidenceFamily
from drishti.detect import forecast as l5
from drishti.detect.forecast import (
    FORBIDDEN_TARGETS,
    L5_FEATURES,
    LAYER,
    OUTLIER_QUANTILE,
    SURVIVAL_QUANTILE,
    run,
)
from drishti.features.temporal import (
    TEMPORAL_FEATURES,
    kaplan_meier,
    payment_rhythm,
    peer_survival,
    progress_shape,
    sanction_local_density,
)

GOLD = settings.paths.out / "gold.parquet"
LABELS = settings.paths.seeds / "fraud_label.parquet"
READY = GOLD.is_file() and LABELS.is_file()


def frame(rows: list[dict]) -> pd.DataFrame:
    base = {column: 0 for column in GOLD_COLUMNS}
    base.update(
        {
            "sector": "roads_bridges",
            "work_type": "village_road",
            "state": "Bihar",
            "geo_method": "bbox",
            "status": "in_progress",
            "description": "work",
            "description_lang": "en",
            "phash": "x",
            "constituency": "C",
            "data_quality": 1.0,
            "sanction_date": pd.Timestamp("2025-01-01"),
            "recommended_on": pd.Timestamp("2024-12-01"),
            "expected_completion_date": pd.Timestamp("2026-01-01"),
            "actual_completion_date": pd.NaT,
            "mp_id": 1,
            "district_id": 1,
            "progress_roughness": 0.05,
            "progress_increment_cv": 0.2,
            "payment_interval_cv": 0.6,
            "sanction_local_density": 1.0,
            "peer_survival_at_age": 0.9,
        }
    )
    built = []
    for row in rows:
        merged = dict(base)
        merged.update(row)
        built.append(merged)
    return pd.DataFrame(built)[list(GOLD_COLUMNS)]


def progress_series(work_id: int, values: list[float]) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "work_id": work_id,
            "update_date": pd.date_range("2025-01-01", periods=len(values), freq="30D"),
            "progress_pct": values,
        }
    )


# ==========================================================================
# governance -- the reason this module is dangerous
# ==========================================================================
class TestGovernance:
    def test_both_temporal_held_out_patterns_are_forbidden(self):
        assert "year_end_bunching" in FORBIDDEN_TARGETS
        assert "progress_reversal" in FORBIDDEN_TARGETS

    def test_no_feature_names_a_held_out_pattern(self):
        for feature in (*L5_FEATURES, *TEMPORAL_FEATURES):
            for pattern in FORBIDDEN_TARGETS:
                assert pattern not in feature

    def test_the_calendar_feature_is_excluded(self):
        """`is_year_end_sanction` names a calendar position.

        A layer forbidden from detecting year-end bunching has no business
        reading a column that says "this was sanctioned at year end".
        """
        assert "is_year_end_sanction" not in L5_FEATURES

    def test_module_does_not_reference_ground_truth(self):
        import ast
        from pathlib import Path

        for module in (l5, __import__("drishti.features.temporal", fromlist=["x"])):
            tree = ast.parse(Path(module.__file__).read_text(encoding="utf-8"))
            imported: set[str] = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom):
                    imported.update(alias.name for alias in node.names)
            assert "fraud_label" not in imported
            assert "FraudLabel" not in imported


# ==========================================================================
# the features must be general, not pattern-shaped
# ==========================================================================
class TestGenerality:
    def test_roughness_scores_a_monotone_zigzag_as_high_as_a_reversal(self):
        """The check that `progress_roughness` is not `progress_reversal`.

        A strictly increasing but stop-start series is just as rough as one
        that goes backwards. If this ever failed -- if only reversals scored --
        the feature would have become a targeted detector.
        """
        reversing = progress_shape(progress_series(1, [10.0, 60.0, 30.0, 80.0]))
        stop_start = progress_shape(progress_series(2, [10.0, 60.0, 61.0, 80.0]))
        assert stop_start["progress_roughness"].iloc[0] > 0.0
        assert stop_start["progress_roughness"].iloc[0] >= (
            0.4 * reversing["progress_roughness"].iloc[0]
        )

    def test_a_straight_climb_is_perfectly_smooth(self):
        smooth = progress_shape(progress_series(1, [0.0, 25.0, 50.0, 75.0]))
        assert smooth["progress_roughness"].iloc[0] == pytest.approx(0.0, abs=1e-9)

    def test_a_steep_straight_climb_is_still_smooth(self):
        """Roughness measures shape, not speed."""
        steep = progress_shape(progress_series(1, [0.0, 33.0, 66.0, 99.0]))
        assert steep["progress_roughness"].iloc[0] == pytest.approx(0.0, abs=1e-9)

    def test_density_treats_july_exactly_like_march(self):
        """The check that `sanction_local_density` is not year-end detection.

        Two identical clusters, one at fiscal year end and one mid-year, must
        receive the same score. The statistic has no calendar.
        """

        def cluster(month: int, mp_id: int) -> pd.DataFrame:
            # Identical geometry, shifted bodily through the calendar: four
            # sanctions inside a week, then one isolated 150 days later. The
            # span and the spacing are the same in both, so only the month
            # differs.
            start = pd.Timestamp(f"2025-{month:02d}-01")
            dates = [start + pd.Timedelta(days=d) for d in (0, 2, 4, 6)]
            dates.append(start + pd.Timedelta(days=150))
            return pd.DataFrame(
                {
                    "work_id": range(mp_id * 100, mp_id * 100 + len(dates)),
                    "mp_id": mp_id,
                    "sanction_date": dates,
                }
            )

        march = sanction_local_density(cluster(3, 1))
        july = sanction_local_density(cluster(7, 2))
        assert march.to_numpy()[:4] == pytest.approx(july.to_numpy()[:4])

    def test_density_is_near_one_when_sanctions_are_evenly_spread(self):
        works = pd.DataFrame(
            {
                "work_id": range(24),
                "mp_id": 1,
                "sanction_date": pd.date_range("2025-01-01", periods=24, freq="15D"),
            }
        )
        density = sanction_local_density(works).dropna()
        assert 0.5 < density.median() < 2.0

    def test_density_rises_for_a_cluster(self):
        clustered = pd.DataFrame(
            {
                "work_id": range(12),
                "mp_id": 1,
                "sanction_date": list(pd.date_range("2025-06-01", periods=10, freq="D"))
                + [pd.Timestamp("2025-01-01"), pd.Timestamp("2025-12-01")],
            }
        )
        assert sanction_local_density(clustered).max() > 3.0


# ==========================================================================
# survival
# ==========================================================================
class TestKaplanMeier:
    def test_survival_falls_monotonically(self):
        times, survival = kaplan_meier(np.array([1.0, 2, 3, 4, 5]), np.ones(5))
        assert list(survival) == sorted(survival, reverse=True)

    def test_all_censored_never_drops(self):
        """No observed completions means no evidence anything ever ends."""
        times, survival = kaplan_meier(np.array([1.0, 2, 3]), np.zeros(3))
        assert survival.tolist() == [1.0]

    def test_censoring_keeps_survival_higher_than_ignoring_it(self):
        """The reason censoring exists: dropping open works biases short.

        Same five durations. Treating the long ones as completions puts the
        curve on the floor; treating them as still-running leaves survival up.
        """
        durations = np.array([10.0, 20, 30, 40, 50])
        _, all_events = kaplan_meier(durations, np.ones(5))
        _, censored = kaplan_meier(durations, np.array([1.0, 1, 0, 0, 0]))
        assert censored[-1] > all_events[-1]

    def test_empty_input(self):
        times, survival = kaplan_meier(np.array([]), np.array([]))
        assert len(times) == 0 and len(survival) == 0

    def test_negative_durations_are_dropped(self):
        times, survival = kaplan_meier(np.array([-5.0, 10.0]), np.array([1.0, 1.0]))
        assert times.tolist() == [10.0]


class TestPeerSurvival:
    def _population(self, n: int = 60) -> pd.DataFrame:
        rng = np.random.default_rng(0)
        sanction = pd.Timestamp("2024-01-01")
        completed = n // 2
        return pd.DataFrame(
            {
                "work_id": range(n),
                "sector": "roads_bridges",
                "work_type": "village_road",
                "sanction_date": sanction,
                "actual_completion_date": [
                    sanction + pd.Timedelta(days=int(rng.integers(30, 200)))
                    if i < completed
                    else pd.NaT
                    for i in range(n)
                ],
            }
        )

    def test_completed_works_get_null(self):
        """Scoring a work against evidence of its own outcome is circular."""
        works = self._population()
        result = peer_survival(works, pd.Timestamp("2025-01-01"))
        completed = works["actual_completion_date"].notna().to_numpy()
        assert result.to_numpy()[completed].size
        assert np.isnan(result.to_numpy()[completed]).all()

    def test_open_works_get_a_probability(self):
        works = self._population()
        result = peer_survival(works, pd.Timestamp("2025-01-01"))
        open_values = result.to_numpy()[works["actual_completion_date"].isna().to_numpy()]
        assert np.isfinite(open_values).any()
        assert ((open_values >= 0) & (open_values <= 1))[np.isfinite(open_values)].all()

    def test_thin_peer_groups_abstain(self):
        works = self._population(n=5)
        assert peer_survival(works, pd.Timestamp("2025-01-01")).isna().all()

    def test_missing_columns_abstain_rather_than_raise(self):
        works = pd.DataFrame({"work_id": [1, 2, 3]})
        assert peer_survival(works, pd.Timestamp("2025-01-01")).isna().all()


# ==========================================================================
# shape statistics
# ==========================================================================
class TestProgressShape:
    def test_two_updates_have_no_shape(self):
        result = progress_shape(progress_series(1, [10.0, 50.0]))
        assert result["progress_roughness"].isna().all()

    def test_flat_series_does_not_explode(self):
        """A signed-mean CV would divide by zero here and report infinity."""
        result = progress_shape(progress_series(1, [50.0, 50.0, 50.0, 50.0]))
        value = result["progress_increment_cv"].iloc[0]
        assert pd.isna(value) or np.isfinite(value)

    def test_a_series_ending_where_it_started_is_finite(self):
        result = progress_shape(progress_series(1, [50.0, 90.0, 10.0, 50.0]))
        assert np.isfinite(result["progress_roughness"].iloc[0])

    def test_empty_input(self):
        assert progress_shape(pd.DataFrame()).empty


class TestPaymentRhythm:
    def _payments(self, work_id: int, days: list[int]) -> pd.DataFrame:
        base = pd.Timestamp("2025-01-01")
        return pd.DataFrame(
            {
                "work_id": work_id,
                "payment_date": [base + pd.Timedelta(days=d) for d in days],
            }
        )

    def test_regular_schedule_scores_near_zero(self):
        result = payment_rhythm(self._payments(1, [0, 30, 60, 90]))
        assert result["payment_interval_cv"].iloc[0] == pytest.approx(0.0, abs=1e-9)

    def test_bursty_schedule_scores_higher(self):
        regular = payment_rhythm(self._payments(1, [0, 30, 60, 90]))
        bursty = payment_rhythm(self._payments(2, [0, 1, 2, 200]))
        assert (
            bursty["payment_interval_cv"].iloc[0] > regular["payment_interval_cv"].iloc[0]
        )

    def test_two_payments_have_no_dispersion(self):
        assert payment_rhythm(self._payments(1, [0, 30]))["payment_interval_cv"].isna().all()

    def test_empty_input(self):
        assert payment_rhythm(pd.DataFrame()).empty


# ==========================================================================
# Seam B
# ==========================================================================
class TestSeamB:
    def _population(self) -> pd.DataFrame:
        rng = np.random.default_rng(0)
        rows = []
        for i in range(1, 401):
            rows.append(
                {
                    "work_id": i,
                    "mp_id": i % 20,
                    "days_since_sanction": 300.0,
                    "progress_roughness": float(rng.uniform(0, 0.2)),
                    "progress_increment_cv": float(rng.uniform(0, 0.5)),
                    "payment_interval_cv": float(rng.uniform(0, 1.0)),
                    "sanction_local_density": float(rng.uniform(0.5, 1.5)),
                    "peer_survival_at_age": float(rng.uniform(0.3, 1.0)),
                }
            )
        # A handful of unmistakable temporal outliers.
        for i in range(401, 411):
            rows.append(
                {
                    "work_id": i,
                    "mp_id": 99,
                    "days_since_sanction": 1200.0,
                    "progress_roughness": 9.0,
                    "progress_increment_cv": 3.0,
                    "payment_interval_cv": 4.0,
                    "sanction_local_density": 12.0,
                    "peer_survival_at_age": 0.001,
                }
            )
        return frame(rows)

    def test_emits_the_declared_layer(self):
        assert all(o.layer == LAYER for o in run(self._population()))

    def test_one_output_per_work_including_silent_ones(self):
        works = self._population()
        assert len(run(works)) == len(works)

    def test_scores_are_bounded(self):
        for output in run(self._population()):
            assert 0.0 <= output.score <= 1.0
            assert 0.0 <= output.confidence <= 1.0

    def test_a_score_always_has_a_reason(self):
        for output in run(self._population()):
            if output.score > 0:
                assert output.reasons

    def test_reasons_are_temporal_family(self):
        outputs = [o for o in run(self._population()) if o.reasons]
        assert outputs
        for output in outputs:
            assert all(r.family is EvidenceFamily.TEMPORAL for r in output.reasons)

    def test_reason_text_defers_to_verification(self):
        """Lateness and clustering are observations, not findings."""
        texts = [r.text for o in run(self._population()) for r in o.reasons]
        assert texts
        assert any("not itself improper" in t for t in texts)

    def test_fire_rate_tracks_the_quantiles(self):
        outputs = run(self._population())
        rate = sum(1 for o in outputs if o.score > 0) / len(outputs)
        assert rate <= (OUTLIER_QUANTILE + SURVIVAL_QUANTILE) * 4

    def test_the_survival_gate_actually_fires(self):
        """It did not, at first.

        An absolute cut at 0.02 matched nothing, because the Kaplan-Meier curve
        bottoms out around 0.199 on real data -- the Block 8 lesson repeating.
        A rank gate keeps the signal alive whatever the curve looks like.
        """
        codes = {r.code for o in run(self._population()) for r in o.reasons}
        assert "running_beyond_peers" in codes

    def test_empty_input(self):
        assert run(pd.DataFrame()) == []

    def test_missing_features_abstain_rather_than_raise(self):
        works = self._population().drop(columns=list(L5_FEATURES))
        outputs = run(works)
        assert len(outputs) == len(works)

    def test_output_is_json_serialisable(self):
        import json

        for output in run(self._population()):
            json.dumps(output.to_row())


# ==========================================================================
# against the real data
# ==========================================================================
@pytest.mark.skipif(not READY, reason="run the pipeline first")
class TestAgainstRealData:
    def test_every_feature_carries_information(self):
        """ADR-0011's lesson: present, finite and meaningless is a real state."""
        gold = pd.read_parquet(GOLD)
        flat = [
            column
            for column in TEMPORAL_FEATURES
            if column in gold.columns
            and gold[column].notna().any()
            and gold[column].std(skipna=True) < 1e-9
        ]
        assert not flat, f"features carrying no information: {flat}"

    def test_local_density_centres_on_one(self):
        """The normalisation is against an even spread, so chance is 1.0."""
        gold = pd.read_parquet(GOLD)
        assert 0.5 < gold["sanction_local_density"].median() < 1.5

    def test_runs_quickly(self):
        import time

        gold = pd.read_parquet(GOLD)
        start = time.perf_counter()
        run(gold)
        assert time.perf_counter() - start < 60.0
