"""Tests for fusion orchestration, the read layer and the API routers.

The vertical slice's job is to stay connected while six more layers land, so
the tests that matter most here are the ones about *degradation*: fusion must
run with one layer, survive a layer that raises, and keep emitting a row per
work. A slice that only works when everything is present is not a slice.
"""

from __future__ import annotations

import json

import pandas as pd
import pytest

fastapi = pytest.importorskip("fastapi", reason="fastapi not installed")
from fastapi.testclient import TestClient  # noqa: E402

from drishti.api.app import app  # noqa: E402
from drishti.api.store import Store, get_store, reset_store  # noqa: E402
from drishti.config import settings  # noqa: E402
from drishti.contracts.layer import EvidenceFamily, LayerOutput, Reason, Severity  # noqa: E402
from drishti.score.fusion import (  # noqa: E402
    LAYER_MODULES,
    load_layers,
    score_population,
    to_frame,
)

GOLD = settings.paths.out / "gold.parquet"
RISK = settings.paths.out / "risk_score.parquet"
SCORED = GOLD.is_file() and RISK.is_file()

client = TestClient(app)


def _reason(code="r", family=EvidenceFamily.FINANCIAL, severity=Severity.MEDIUM):
    return Reason(
        code=code,
        text=f"{code}: an observation long enough to be evidence",
        family=family,
        severity=severity,
    )


@pytest.fixture(scope="module")
def gold():
    if not SCORED:
        pytest.skip("run the pipeline first")
    return pd.read_parquet(GOLD).head(400)


# ==========================================================================
# fusion orchestration
# ==========================================================================
class TestLoadLayers:
    def test_finds_the_layers_that_exist(self):
        available, absent = load_layers()
        assert "rules" in available
        assert callable(available["rules"])

    def test_reports_layers_not_yet_written(self):
        """Written to survive layers landing rather than needing an edit each block."""
        available, absent = load_layers()
        assert set(available) | set(absent) == set(LAYER_MODULES)
        assert not (set(available) & set(absent))
        assert absent, "every layer has landed -- update this test's premise"

    def test_landed_layers_are_importable_and_runnable(self):
        available, _ = load_layers()
        for name, runner in available.items():
            assert callable(runner), f"{name} exposes a non-callable run"

    def test_every_layer_name_has_a_module_path(self):
        from drishti.contracts.layer import LAYER_NAMES

        assert set(LAYER_MODULES) == set(LAYER_NAMES)


@pytest.mark.skipif(not SCORED, reason="run the pipeline first")
class TestScorePopulation:
    def test_runs_with_a_single_layer(self, gold):
        """Fusion goes live on the day L0 lands, not when L6 does."""
        result = score_population(gold)
        assert result.n_scored == len(gold)
        assert "rules" in result.layers_run

    def test_emits_one_assessment_per_work_including_silent_ones(self, gold):
        result = score_population(gold)
        assert {a.work_id for a in result.assessments} == set(gold["work_id"])

    def test_a_failing_layer_does_not_take_down_the_run(self, gold):
        def explode(features, ctx):
            raise RuntimeError("simulated layer failure")

        result = score_population(gold, layers={"rules": explode})
        assert result.n_scored == len(gold)
        assert "rules" in result.layers_absent

    def test_a_missing_layer_contributes_nothing(self, gold):
        empty = score_population(gold, layers={})
        assert all(a.overall_risk == 0.0 for a in empty.assessments)

    def test_empty_input_is_handled(self):
        result = score_population(pd.DataFrame())
        assert result.n_scored == 0

    def test_records_timings(self, gold):
        result = score_population(gold)
        assert "fusion" in result.timings

    def test_describe_mentions_the_actionable_definition(self, gold):
        assert "confidence" in score_population(gold).describe()


class TestToFrame:
    def test_flattens_the_four_quantities(self):
        from drishti.contracts.risk import assess

        assessment = assess(
            1,
            [LayerOutput(1, "rules", 0.8, reasons=(_reason(),))],
            {"rules": 1.0},
            {"low": 0.0, "high": 0.6},
        )
        frame = to_frame([assessment])
        for column in ("overall_risk", "confidence", "severity", "data_quality"):
            assert column in frame.columns

    def test_reasons_round_trip_as_json(self):
        from drishti.contracts.risk import assess

        assessment = assess(
            1,
            [LayerOutput(1, "rules", 0.8, reasons=(_reason("alpha"),))],
            {"rules": 1.0},
            {"low": 0.0},
        )
        reasons = json.loads(to_frame([assessment])["reasons"].iloc[0])
        assert reasons[0]["code"] == "alpha"

    def test_empty_input(self):
        assert to_frame([]).empty


# ==========================================================================
# the store
# ==========================================================================
@pytest.mark.skipif(not SCORED, reason="run the pipeline first")
class TestStore:
    @staticmethod
    def store() -> Store:
        return get_store()

    def test_loads(self):
        assert not self.store().is_empty

    def test_ranks_by_risk_then_confidence(self):
        page = self.store().list_works(limit=50)
        risks = [w["overall_risk"] for w in page["items"]]
        assert risks == sorted(risks, reverse=True)

    def test_confidence_breaks_ties(self):
        """A thin lead must never outrank a corroborated finding at equal risk."""
        items = self.store().list_works(limit=200)["items"]
        for first, second in zip(items, items[1:], strict=False):
            if first["overall_risk"] == second["overall_risk"]:
                assert first["confidence"] >= second["confidence"]

    def test_actionable_filter_narrows_the_queue(self):
        store = self.store()
        assert store.list_works(actionable_only=True)["total"] < store.list_works()["total"]

    def test_band_filter(self):
        page = self.store().list_works(band="critical", limit=20)
        assert all(w["band"] == "critical" for w in page["items"])

    def test_pagination_does_not_repeat(self):
        store = self.store()
        first = {w["work_id"] for w in store.list_works(limit=10, offset=0)["items"]}
        second = {w["work_id"] for w in store.list_works(limit=10, offset=10)["items"]}
        assert not (first & second)

    def test_unknown_work_returns_none(self):
        assert self.store().work_detail(-1) is None
        assert self.store().work_risk(-1) is None
        assert self.store().evidence_card(-1) is None

    def test_evidence_card_carries_all_four_quantities(self):
        top = self.store().list_works(limit=1)["items"][0]
        card = self.store().evidence_card(top["work_id"])
        for key in ("overall_risk", "confidence", "severity", "data_quality"):
            assert key in card["risk"]

    def test_evidence_card_reports_peer_group_size(self):
        """A percentile over 8 works and one over 800 warrant different trust."""
        top = self.store().list_works(limit=1)["items"][0]
        peers = self.store().evidence_card(top["work_id"])["peer_comparison"]
        assert peers["peer_group_size"] >= 0
        assert isinstance(peers["sufficient_peers"], bool)

    def test_evidence_card_recommends_concrete_checks(self):
        top = self.store().list_works(limit=1)["items"][0]
        checks = self.store().evidence_card(top["work_id"])["recommended_checks"]
        assert checks and all(len(c) > 20 for c in checks)

    def test_evidence_card_carries_the_disclaimer(self):
        top = self.store().list_works(limit=1)["items"][0]
        card = self.store().evidence_card(top["work_id"])
        assert "not a finding of wrongdoing" in card["disclaimer"].lower()

    def test_evidence_card_is_json_serialisable(self):
        top = self.store().list_works(limit=1)["items"][0]
        json.dumps(self.store().evidence_card(top["work_id"]))

    def test_alert_stats_reports_thin_evidence_share(self):
        """The honest headline: most flagged works are leads, not cases."""
        stats = self.store().alert_stats()
        assert 0.0 <= stats["low_confidence_share"] <= 1.0
        assert stats["total"] > 0

    def test_timeline_events_are_dated(self):
        top = self.store().list_works(limit=1)["items"][0]
        for event in self.store().evidence_card(top["work_id"])["timeline"]:
            assert event["at"]


# ==========================================================================
# routers
# ==========================================================================
@pytest.mark.skipif(not SCORED, reason="run the pipeline first")
class TestRouters:
    def test_list_works(self):
        response = client.get("/api/works?limit=5")
        assert response.status_code == 200
        assert len(response.json()["items"]) == 5

    def test_list_works_validates_limit(self):
        assert client.get("/api/works?limit=9999").status_code == 422

    def test_work_risk_returns_four_quantities(self):
        work_id = client.get("/api/works?limit=1").json()["items"][0]["work_id"]
        body = client.get(f"/api/works/{work_id}/risk").json()
        for key in ("overall_risk", "confidence", "severity", "data_quality"):
            assert key in body

    def test_work_risk_matches_the_published_fixture_shape(self):
        """Seam D: the live router and the static JSON must not diverge."""
        from drishti.api.models import RiskOut

        work_id = client.get("/api/works?limit=1").json()["items"][0]["work_id"]
        RiskOut.model_validate(client.get(f"/api/works/{work_id}/risk").json())

        published = json.loads(
            (settings.paths.api / "work_risk.json").read_text(encoding="utf-8")
        )
        assert set(published) == set(client.get(f"/api/works/{work_id}/risk").json())

    def test_evidence_endpoint(self):
        work_id = client.get("/api/works?limit=1").json()["items"][0]["work_id"]
        response = client.get(f"/api/works/{work_id}/evidence")
        assert response.status_code == 200
        assert response.json()["recommended_checks"]

    def test_unknown_work_returns_404(self):
        assert client.get("/api/works/999999999/risk").status_code == 404

    def test_alerts_stats(self):
        assert client.get("/api/alerts/stats").status_code == 200

    def test_alerts_queue(self):
        body = client.get("/api/alerts?limit=5").json()
        assert len(body["items"]) <= 5
        assert all(a["band"] in ("high", "critical") for a in body["items"])

    def test_openapi_includes_the_read_endpoints(self):
        paths = client.get("/openapi.json").json()["paths"]
        for path in ("/api/works", "/api/works/{work_id}/risk", "/api/alerts/stats"):
            assert path in paths


# ==========================================================================
# the acceptance gate itself
# ==========================================================================
@pytest.mark.skipif(not SCORED, reason="run the pipeline first")
class TestAcceptanceGate:
    def test_gate_passes_on_current_artefacts(self):
        from drishti.acceptance import run_acceptance

        report = run_acceptance()
        failed = [c.name for c in report.checks if not c.passed]
        assert not failed, f"acceptance checks failing: {failed}"

    def test_gate_covers_the_four_quantities(self):
        from drishti.acceptance import run_acceptance

        names = " ".join(c.name for c in run_acceptance().checks)
        assert "four separate quantities" in names
        assert "leakage" in names

    def test_a_broken_check_reports_as_failed_not_a_crash(self):
        from drishti.acceptance import AcceptanceReport, _safe

        report = AcceptanceReport()
        _safe(report, "explodes", lambda: (_ for _ in ()).throw(RuntimeError("boom")))
        assert not report.ok
        assert "boom" in report.checks[0].detail


def test_reset_store_clears_the_cache():
    reset_store()
    assert get_store.cache_info().currsize == 0
