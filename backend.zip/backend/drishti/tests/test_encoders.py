"""Tests for GPU text encoding and the L4 evaluation harness.

Split by dependency so the suite is meaningful everywhere:

  * config, corpus building and the evaluation maths need only numpy and run
    on any machine, including CI;
  * anything that loads a transformer is skipped without sentence-transformers,
    since that ships in the ml-worker image only.

The most important test here is the one asserting that require_gpu=True
*raises* on a CPU-only box. Silently encoding on CPU is a 219x slowdown that
looks exactly like success, which is the failure this whole module is built to
prevent.
"""

from __future__ import annotations

import numpy as np
import pytest

from drishti.encoders import EncoderConfig, TextEncoder
from drishti.encoders.corpus import WORK_HI, build_corpus, real_place_names
from drishti.encoders.evaluate import (
    evaluate_similarity,
    lexical_baseline,
    load_corpus,
)
from drishti.gpu import detect as detect_gpu
from drishti.textsim import script_profile

GPU_AVAILABLE = detect_gpu().usable
needs_model = pytest.importorskip


class TestEncoderConfig:
    def test_defaults_are_multilingual(self):
        assert "multilingual" in EncoderConfig().model_name

    def test_requires_gpu_by_default(self):
        # The point of the module: no silent CPU degradation.
        assert EncoderConfig().require_gpu is True

    def test_version_changes_with_model(self):
        a = EncoderConfig(model_name="model-a").version
        b = EncoderConfig(model_name="model-b").version
        assert a != b

    def test_version_changes_with_precision(self):
        assert EncoderConfig(precision="fp16").version != EncoderConfig(precision="fp32").version

    def test_version_is_stable(self):
        assert EncoderConfig().version == EncoderConfig().version

    def test_rejects_unknown_precision(self):
        with pytest.raises(ValueError, match="precision"):
            EncoderConfig(precision="int4")

    def test_rejects_bad_batch_size(self):
        with pytest.raises(ValueError, match="batch_size"):
            EncoderConfig(batch_size=0)

    def test_rejects_tiny_sequence_length(self):
        with pytest.raises(ValueError, match="max_seq_length"):
            EncoderConfig(max_seq_length=2)


class TestDeviceResolution:
    def test_refuses_cpu_when_gpu_required(self):
        encoder = TextEncoder(EncoderConfig(require_gpu=True))
        if GPU_AVAILABLE:
            assert encoder.resolve_device() == "cuda"
        else:
            with pytest.raises(RuntimeError, match="requires a GPU"):
                encoder.resolve_device()

    def test_error_explains_the_cost_of_cpu(self):
        if GPU_AVAILABLE:
            pytest.skip("GPU present, cannot exercise the failure path")
        with pytest.raises(RuntimeError, match="slower"):
            TextEncoder(EncoderConfig(require_gpu=True)).resolve_device()

    def test_cpu_allowed_when_explicitly_opted_in(self):
        encoder = TextEncoder(EncoderConfig(require_gpu=False))
        assert encoder.resolve_device() in ("cpu", "cuda")


class TestCorpus:
    def test_uses_real_place_names(self):
        names = real_place_names()
        assert len(names) > 100, "should load constituencies from the allocation file"

    def test_builds_requested_size(self):
        assert len(build_corpus(n=500, seed=1)) == 500

    def test_is_deterministic(self):
        assert build_corpus(n=200, seed=7) == build_corpus(n=200, seed=7)

    def test_seed_changes_output(self):
        assert build_corpus(n=200, seed=1) != build_corpus(n=200, seed=2)

    def test_contains_devanagari(self):
        texts = build_corpus(n=1000, hindi_share=0.4, seed=3)
        devanagari = [t for t in texts if script_profile(t)["devanagari"] > 0]
        assert len(devanagari) > 100, "corpus must actually be multilingual"

    def test_hindi_share_zero_produces_no_devanagari(self):
        texts = build_corpus(n=300, hindi_share=0.0, seed=4)
        assert all(script_profile(t)["devanagari"] == 0 for t in texts)

    def test_contains_near_duplicates(self):
        texts = build_corpus(n=2000, duplicate_share=0.10, seed=5)
        assert len(texts) > len(set(texts)) or any("Ward No." in t for t in texts)

    def test_rejects_bad_arguments(self):
        with pytest.raises(ValueError, match="n must be"):
            build_corpus(n=0)
        with pytest.raises(ValueError, match="hindi_share"):
            build_corpus(n=10, hindi_share=2.0)

    def test_every_work_type_has_a_hindi_rendering(self):
        from drishti.domain import WORK_TYPES

        missing = [wt for wt in WORK_TYPES if wt not in WORK_HI]
        assert not missing, f"work types without Devanagari text: {missing}"


class TestLabelledCorpus:
    def test_loads(self):
        assert len(load_corpus()) >= 30

    def test_every_item_is_labelled(self):
        for item in load_corpus():
            assert item["group"] and item["lang"] and item["kind"] and item["text"]

    def test_contains_duplicate_groups(self):
        groups = [i["group"] for i in load_corpus()]
        assert any(groups.count(g) > 1 for g in set(groups))

    def test_contains_cross_language_duplicates(self):
        items = load_corpus()
        by_group: dict[str, set[str]] = {}
        for item in items:
            by_group.setdefault(item["group"], set()).add(item["lang"])
        assert any(len(langs) > 1 for langs in by_group.values()), (
            "the corpus must contain the case lexical matching cannot solve"
        )

    def test_contains_hard_negatives(self):
        assert any(i["kind"] == "hard_negative" for i in load_corpus())


class TestEvaluation:
    def test_lexical_baseline_runs(self):
        result = lexical_baseline(load_corpus())
        assert result.n_positive_pairs > 0
        assert result.n_negative_pairs > 0

    def test_lexical_baseline_is_weak_cross_language(self):
        # Documents the gap the encoder exists to close.
        assert lexical_baseline(load_corpus()).cross_language_recall < 0.5

    def test_perfect_similarity_scores_perfectly(self):
        items = load_corpus()
        n = len(items)
        oracle = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                oracle[i, j] = 1.0 if items[i]["group"] == items[j]["group"] else 0.0
        result = evaluate_similarity(items, oracle, "oracle")
        assert result.f1 == pytest.approx(1.0)
        assert result.roc_auc == pytest.approx(1.0)

    def test_random_similarity_scores_near_chance(self):
        items = load_corpus()
        rng = np.random.default_rng(0)
        n = len(items)
        noise = rng.random((n, n))
        noise = (noise + noise.T) / 2
        assert 0.3 < evaluate_similarity(items, noise, "random").roc_auc < 0.7

    def test_rejects_mismatched_matrix(self):
        with pytest.raises(ValueError, match="does not match"):
            evaluate_similarity(load_corpus(), np.zeros((3, 3)), "bad")

    def test_summary_is_readable(self):
        assert "separation" in lexical_baseline(load_corpus()).summary()


@pytest.mark.skipif(not GPU_AVAILABLE, reason="needs a usable CUDA device")
class TestGpuEncoding:
    """Only meaningful in the ml-worker; skipped elsewhere."""

    def test_encodes_on_cuda(self):
        needs_model("sentence_transformers")
        result = TextEncoder().encode(["village road", "ग्रामीण सड़क"])
        assert result.device == "cuda"
        assert result.embeddings.shape[0] == 2

    def test_embeddings_are_unit_norm(self):
        needs_model("sentence_transformers")
        result = TextEncoder().encode(build_corpus(n=32, seed=1))
        norms = np.linalg.norm(result.embeddings, axis=1)
        assert np.allclose(norms, 1.0, atol=1e-3)

    def test_returns_float32_regardless_of_compute_precision(self):
        needs_model("sentence_transformers")
        result = TextEncoder(EncoderConfig(precision="fp16")).encode(["a", "b"])
        assert result.embeddings.dtype == np.float32

    def test_cross_language_pair_is_closer_than_unrelated(self):
        needs_model("sentence_transformers")
        encoder = TextEncoder()
        result = encoder.encode(
            [
                "Construction of village road in Ward 4",
                "वार्ड 4 में ग्रामीण सड़क का निर्माण",
                "Purchase of computers for the district library",
            ]
        )
        sim = encoder.similarity(result.embeddings)
        assert sim[0, 1] > sim[0, 2], "the whole justification for the encoder"

    def test_rejects_empty_input(self):
        needs_model("sentence_transformers")
        with pytest.raises(ValueError, match="at least one text"):
            TextEncoder().encode([])


class TestEncoderCache:
    """The resident-model cache. Reloading per job cost ~28s of GPU idle."""

    def test_returns_the_same_instance_for_one_config(self):
        pytest.importorskip("sentence_transformers")
        if not GPU_AVAILABLE:
            pytest.skip("needs a usable CUDA device")
        from drishti.encoders import get_encoder, release_encoders

        release_encoders()
        first = get_encoder(EncoderConfig())
        second = get_encoder(EncoderConfig())
        assert first is second, "a second call must not reload the model"

    def test_distinct_configs_get_distinct_encoders(self):
        pytest.importorskip("sentence_transformers")
        if not GPU_AVAILABLE:
            pytest.skip("needs a usable CUDA device")
        from drishti.encoders import get_encoder, release_encoders

        release_encoders()
        a = get_encoder(EncoderConfig(precision="fp16"))
        b = get_encoder(EncoderConfig(precision="fp32"))
        assert a is not b, "a config change must not silently reuse the wrong weights"
        release_encoders()

    def test_release_reports_how_many_were_freed(self):
        from drishti.encoders import release_encoders

        release_encoders()
        assert release_encoders() == 0
