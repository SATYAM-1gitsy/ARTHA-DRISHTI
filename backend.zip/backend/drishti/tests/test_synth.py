"""Tests for the synthetic generator and anomaly injection.

The generator is the load-bearing dependency of the whole project: its quality
caps every number measured downstream. So these tests assert on properties
that, if they broke silently, would invalidate results rather than crash a
run -- determinism, the leakage boundary, and whether each injected pattern is
actually *present* in the data it labelled.

That last one matters more than it looks. An injector that quietly no-ops
still writes labels, and every recall computed against those labels would then
be measuring nothing. Each pattern here is checked for a real signal against
the base population's own rate.

A small population is used throughout so the suite stays fast; the separation
figures are stable at this size.
"""

from __future__ import annotations

import hashlib

import numpy as np
import pandas as pd
import pytest

from drishti.config import GenConfig, settings
from drishti.contracts.labels import assert_no_label_leakage
from drishti.domain import (
    INELIGIBLE_KEYWORDS,
    PatternVisibility,
    held_out_patterns,
    rule_visible_patterns,
)
from drishti.synth import INJECTORS, generate, inject
from drishti.synth.generator import load_reference

REFERENCE_READY = (settings.paths.seeds / "silver_mp.parquet").is_file()
pytestmark = pytest.mark.skipif(
    not REFERENCE_READY, reason="run `drishti ingest` first -- the generator is anchored to it"
)

SMALL = GenConfig(n_works=4000, seed=42)


@pytest.fixture(scope="module")
def base():
    return generate(SMALL)


@pytest.fixture(scope="module")
def injected():
    return inject(generate(SMALL), SMALL)


def _digest(dataset) -> str:
    parts = []
    for name, frame in sorted(dataset.tables.items()):
        parts.append(
            f"{name}:{len(frame)}:"
            + hashlib.sha256(
                pd.util.hash_pandas_object(frame.astype(str), index=False).values.tobytes()
            ).hexdigest()
        )
    return hashlib.sha256("|".join(parts).encode()).hexdigest()


# ==========================================================================
# anchoring to the real spine
# ==========================================================================
class TestAnchoring:
    def test_requires_the_reference_tables(self, monkeypatch, tmp_path):
        monkeypatch.setattr(type(settings.paths), "seeds", property(lambda self: tmp_path))
        with pytest.raises(FileNotFoundError, match="drishti ingest"):
            load_reference()

    def test_uses_all_real_states(self, base):
        assert base.districts["state_id"].nunique() == 36

    def test_every_work_belongs_to_a_real_member(self, base):
        _, _, mps = load_reference()
        assert set(base.works["mp_id"]) <= set(mps["mp_id"])

    def test_every_work_belongs_to_a_real_constituency(self, base):
        _, constituencies, _ = load_reference()
        assert set(base.works["constituency_id"]) <= set(constituencies["constituency_id"])

    def test_districts_are_marked_synthetic(self, base):
        """They are stand-ins, and nothing may present them as real."""
        assert base.districts["is_synthetic"].all()

    def test_larger_allocations_fund_more_works(self, base):
        _, _, mps = load_reference()
        counts = base.works.groupby("mp_id").size().rename("n")
        joined = mps.set_index("mp_id").join(counts).dropna(subset=["allocated_limit", "n"])
        correlation = joined["allocated_limit"].corr(joined["n"])
        assert correlation > 0.5, "work volume should follow the real entitlement"

    def test_member_without_an_allocation_still_gets_works(self, base):
        """D-01: excluding them would drop a real member from every table."""
        _, _, mps = load_reference()
        orphan = mps.loc[mps["allocated_limit"].isna(), "mp_id"]
        assert not orphan.empty
        assert base.works["mp_id"].isin(orphan).any()


# ==========================================================================
# the base population
# ==========================================================================
class TestBasePopulation:
    def test_generates_close_to_the_target(self, base):
        assert 0.8 * SMALL.n_works <= len(base.works) <= 1.2 * SMALL.n_works

    def test_all_tables_are_populated(self, base):
        for name, frame in base.tables.items():
            if name == "fraud_label":
                continue
            assert len(frame) > 0, f"{name} is empty"

    def test_work_ids_are_unique(self, base):
        assert not base.works["work_id"].duplicated().any()

    def test_no_anomalies_before_injection(self, base):
        assert base.labels.empty

    def test_costs_are_positive(self, base):
        assert (base.works["sanctioned_cost"] > 0).all()

    def test_progress_is_bounded(self, base):
        assert base.works["progress_pct"].between(0, 100).all()

    def test_status_values_are_valid(self, base):
        assert set(base.works["status"]) <= {
            "sanctioned", "in_progress", "completed", "abandoned",
        }

    def test_payments_reference_real_works(self, base):
        assert set(base.payments["work_id"]) <= set(base.works["work_id"])

    def test_progress_updates_reference_real_works(self, base):
        assert set(base.progress["work_id"]) <= set(base.works["work_id"])

    def test_descriptions_are_multilingual(self, base):
        shares = base.works["description_lang"].value_counts(normalize=True)
        assert shares.get("hi", 0) > 0.2, "L4 needs genuine script mixing to be meaningful"
        assert shares.get("en", 0) > 0.5

    def test_photo_coverage_is_imperfect(self, base):
        """missing_rate is a difficulty knob, not an accident."""
        coverage = base.photos["work_id"].nunique() / len(base.works)
        assert 0.5 < coverage < 0.98

    def test_baseline_has_ordinary_year_end_seasonality(self, base):
        """The held-out bunching pattern must beat a realistic baseline, not a flat one."""
        march = (pd.to_datetime(base.works["sanction_date"]).dt.month == 3).mean()
        assert 0.02 < march < 0.20


# ==========================================================================
# acceptance criteria
# ==========================================================================
class TestDeterminism:
    def test_same_seed_reproduces_identical_data(self):
        """Block 4 acceptance criterion."""
        first = inject(generate(SMALL), SMALL)[0]
        second = inject(generate(SMALL), SMALL)[0]
        assert _digest(first) == _digest(second)

    def test_different_seed_produces_different_data(self):
        other = GenConfig(n_works=SMALL.n_works, seed=7)
        assert _digest(inject(generate(SMALL), SMALL)[0]) != _digest(
            inject(generate(other), other)[0]
        )

    def test_base_population_is_independent_of_injection_rate(self):
        """Changing difficulty must not perturb the normal population."""
        low = GenConfig(n_works=2000, seed=11, inject_rate=0.02)
        high = GenConfig(n_works=2000, seed=11, inject_rate=0.20)
        assert generate(low).works.equals(generate(high).works)


class TestLeakage:
    def test_no_injection_metadata_in_any_data_table(self, injected):
        """Block 4 acceptance criterion. Seam E must never reach Seam A."""
        dataset, _ = injected
        for name, frame in dataset.tables.items():
            if name == "fraud_label":
                continue
            assert_no_label_leakage(list(frame.columns))

    def test_labels_live_only_in_the_label_table(self, injected):
        dataset, _ = injected
        assert "pattern" in dataset.labels.columns
        assert "pattern" not in dataset.works.columns

    def test_injection_parameters_are_not_a_work_column(self, injected):
        dataset, _ = injected
        assert "parameters" not in dataset.works.columns


# ==========================================================================
# injection
# ==========================================================================
class TestInjection:
    def test_every_registered_pattern_has_an_injector(self):
        from drishti.domain import FRAUD_PATTERNS

        missing = [p.name for p in FRAUD_PATTERNS if p.name not in INJECTORS]
        assert not missing, f"patterns without an injector: {missing}"

    def test_no_injector_without_a_registered_pattern(self):
        from drishti.domain import FRAUD_PATTERNS

        known = {p.name for p in FRAUD_PATTERNS}
        assert not set(INJECTORS) - known

    def test_prevalence_tracks_the_configured_rate(self, injected):
        _, report = injected
        # Multi-work patterns and pattern_overlap push it slightly above the
        # nominal rate; an order of magnitude out would mean a runaway injector.
        assert SMALL.inject_rate <= report.prevalence <= SMALL.inject_rate * 2.5

    def test_both_visibility_classes_are_injected(self, injected):
        _, report = injected
        visible = {p.name for p in rule_visible_patterns()}
        held = {p.name for p in held_out_patterns()}
        assert set(report.counts) & visible
        assert set(report.counts) & held

    def test_held_out_share_is_material(self, injected):
        """R-03: too few held-out labels makes the only honest metric noisy."""
        _, report = injected
        assert report.held_out_share >= 0.15

    def test_no_single_pattern_dominates(self, injected):
        """A runaway pattern lets a one-trick model look excellent."""
        _, report = injected
        total = sum(report.counts.values())
        assert max(report.counts.values()) / total < 0.35

    def test_labels_reference_real_works(self, injected):
        dataset, _ = injected
        assert set(dataset.labels["work_id"]) <= set(dataset.works["work_id"])

    def test_labels_carry_visibility_and_severity(self, injected):
        dataset, _ = injected
        assert dataset.labels["visibility"].isin(
            [PatternVisibility.RULE_VISIBLE.value, PatternVisibility.HELD_OUT.value]
        ).all()
        assert dataset.labels["severity"].notna().all()

    def test_report_marks_rule_visible_as_unquotable(self, injected):
        _, report = injected
        assert "never a detection claim" in report.describe()


# ==========================================================================
# does each pattern actually leave a signal?
# ==========================================================================
class TestPatternSignals:
    """An injector that silently no-ops still writes labels, and every recall
    computed against them would then measure nothing."""

    @staticmethod
    def _ids(dataset, pattern: str) -> set[int]:
        labels = dataset.labels
        return set(labels.loc[labels["pattern"] == pattern, "work_id"])

    def test_cost_inflation_raises_unit_cost_above_peers(self, injected):
        dataset, _ = injected
        works = dataset.works.assign(
            unit_cost=dataset.works["sanctioned_cost"] / dataset.works["quantity"]
        )
        ratio = works["unit_cost"] / works.groupby("work_type")["unit_cost"].transform("median")
        targets = works["work_id"].isin(self._ids(dataset, "cost_inflation"))
        assert ratio[targets].median() > 1.5
        assert ratio[~targets].median() < 1.2

    def test_pre_sanction_payment_predates_sanction(self, injected):
        dataset, _ = injected
        sanctions = dict(
            zip(dataset.works["work_id"], pd.to_datetime(dataset.works["sanction_date"]), strict=True)
        )
        payments = dataset.payments
        early = (
            pd.to_datetime(payments["payment_date"]) < payments["work_id"].map(sanctions)
        ).groupby(payments["work_id"]).any()
        targets = list(self._ids(dataset, "pre_sanction_payment"))
        assert early.reindex(targets).fillna(False).mean() > 0.8

    def test_ghost_work_has_no_photo_and_reads_complete(self, injected):
        dataset, _ = injected
        targets = self._ids(dataset, "ghost_work")
        with_photo = set(dataset.photos["work_id"])
        assert not (targets & with_photo)
        progress = dataset.works.set_index("work_id")["progress_pct"]
        assert (progress.reindex(list(targets)) == 100.0).all()

    def test_duplicate_work_is_not_merely_a_verbatim_clone(self, injected):
        """Cloning the text verbatim made the pattern findable by string
        equality, which tested nothing the multilingual encoder exists for.

        Roughly a third of duplicates should be verbatim, a third reworded and
        a third recorded in the other language.
        """
        import json

        dataset, _ = injected
        labels = dataset.labels
        rows = labels.loc[labels["pattern"] == "duplicate_work", "parameters"]
        assert len(rows)
        parameters = rows.iloc[0]
        flavours = (
            parameters if isinstance(parameters, dict) else json.loads(str(parameters))
        ).get("flavours", {})
        assert set(flavours) == {"verbatim", "paraphrase", "translated"}
        assert min(flavours.values()) > 0, f"one flavour never fired: {flavours}"

    def test_duplicate_work_produces_cross_language_pairs(self, injected):
        """The case lexical matching scores at ~0.04 and cannot solve."""
        dataset, _ = injected
        works = dataset.works.set_index("work_id")
        targets = self._ids(dataset, "duplicate_work")
        languages = works["description_lang"]
        mixed = languages.reindex(list(targets)).value_counts()
        assert len(mixed) > 1, "every injected duplicate is in one language"

    def test_advance_without_progress_freezes_progress(self, injected):
        dataset, _ = injected
        progress = dataset.works.set_index("work_id")["progress_pct"]
        targets = list(self._ids(dataset, "advance_without_progress"))
        assert (progress.reindex(targets) < 5).mean() > 0.9

    def test_agency_concentration_raises_district_share(self, injected):
        dataset, _ = injected
        works = dataset.works
        share = works.groupby(["district_id", "agency_id"]).size() / works.groupby(
            "district_id"
        ).size()
        mapped = works.assign(
            share=works.set_index(["district_id", "agency_id"]).index.map(share)
        ).set_index("work_id")["share"]
        targets = list(self._ids(dataset, "agency_concentration"))
        assert mapped.reindex(targets).median() > 0.5

    def test_agency_concentration_stays_within_budget(self, injected):
        """The bug this guards: one district per target labelled 61% of the set."""
        dataset, report = injected
        assert report.counts["agency_concentration"] < len(dataset.works) * 0.05

    def test_ineligible_work_contains_a_banned_keyword(self, injected):
        dataset, _ = injected
        keywords = [k for values in INELIGIBLE_KEYWORDS.values() for k in values]
        descriptions = dataset.works.set_index("work_id")["description"].str.lower()
        targets = list(self._ids(dataset, "ineligible_work"))
        assert descriptions.reindex(targets).str.contains("|".join(keywords)).all()

    def test_split_payment_produces_many_small_payments(self, injected):
        dataset, _ = injected
        counts = dataset.payments.groupby("work_id").size()
        targets = list(self._ids(dataset, "split_payment"))
        assert (counts.reindex(targets).fillna(0) >= 6).mean() > 0.9

    def test_photo_reuse_shares_a_hash(self, injected):
        dataset, _ = injected
        photos = dataset.photos
        duplicated = set(photos.loc[photos["phash"].duplicated(keep=False), "phash"])
        targets = list(self._ids(dataset, "photo_reuse"))
        hit = photos.set_index("work_id")["phash"].reindex(targets).isin(duplicated)
        assert hit.fillna(False).mean() > 0.5

    def test_year_end_bunching_lands_in_march(self, injected):
        dataset, _ = injected
        month = pd.to_datetime(dataset.works.set_index("work_id")["sanction_date"]).dt.month
        targets = list(self._ids(dataset, "year_end_bunching"))
        assert (month.reindex(targets) == 3).all()

    def test_geographic_displacement_moves_the_asset(self, injected):
        dataset, _ = injected
        works = dataset.works.merge(
            dataset.districts[["district_id", "centroid_lat", "centroid_lon"]],
            on="district_id",
            how="left",
        )
        distance = np.hypot(
            works["latitude"] - works["centroid_lat"],
            works["longitude"] - works["centroid_lon"],
        )
        targets = works["work_id"].isin(self._ids(dataset, "geographic_displacement"))
        assert distance[targets].median() > distance[~targets].median() * 3

    def test_vendor_round_tripping_narrows_the_payee_set(self, injected):
        dataset, _ = injected
        payments = dataset.payments
        targets = self._ids(dataset, "vendor_round_tripping")
        ring = payments.loc[payments["work_id"].isin(targets), "vendor_id"]
        assert ring.nunique() <= 6

    def test_progress_reversal_creates_a_dip(self, injected):
        dataset, _ = injected
        updates = dataset.progress.sort_values(["work_id", "update_date"])
        dips = updates.groupby("work_id")["progress_pct"].apply(
            lambda s: bool((s.diff().dropna() < -1).any())
        )
        targets = list(self._ids(dataset, "progress_reversal"))
        assert dips.reindex(targets).fillna(False).mean() > 0.5


class TestDifficultyKnobs:
    def test_higher_inject_rate_produces_more_labels(self):
        low = GenConfig(n_works=2000, seed=3, inject_rate=0.03)
        high = GenConfig(n_works=2000, seed=3, inject_rate=0.15)
        assert inject(generate(low), low)[1].prevalence < inject(generate(high), high)[1].prevalence

    def test_held_out_share_knob_moves_the_split(self):
        few = GenConfig(n_works=2000, seed=3, held_out_share=0.2)
        many = GenConfig(n_works=2000, seed=3, held_out_share=0.5)
        assert (
            inject(generate(few), few)[1].held_out_share
            < inject(generate(many), many)[1].held_out_share
        )

    def test_missing_rate_reduces_photo_coverage(self):
        clean = GenConfig(n_works=2000, seed=3, missing_rate=0.02)
        sparse = GenConfig(n_works=2000, seed=3, missing_rate=0.30)
        clean_data, sparse_data = generate(clean), generate(sparse)
        assert len(sparse_data.photos) < len(clean_data.photos)
