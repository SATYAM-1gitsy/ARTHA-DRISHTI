"""Tests for fusion combiners.

The properties here are the ones the Block 13 measurement demanded, so they are
written as behaviour rather than as arithmetic: a rare layer must outrank a
common one, agreement must beat a single loud layer, and no layer may own the
ranking. If a future combiner change breaks one of these, it has undone the
block rather than improved it.
"""

from __future__ import annotations

import numpy as np
import pytest

from drishti.config import settings
from drishti.score.combine import (
    COMBINERS,
    LayerCalibration,
    calibrated_noisy_or,
    fit_calibration,
    noisy_or,
    resolve,
    weighted_mean,
)

WEIGHTS = {"rules": 0.30, "unsupervised": 0.20, "graph": 0.10, "duplicate": 0.10}


def population(fire_rates: dict[str, float], n: int = 1000) -> LayerCalibration:
    """A synthetic population with the given per-layer fire rates.

    Fired scores are spread over (0, 1] so the tail is not degenerate.
    """
    rng = np.random.default_rng(0)
    rows = []
    for _ in range(n):
        row = {}
        for layer, rate in fire_rates.items():
            row[layer] = float(rng.uniform(0.1, 1.0)) if rng.random() < rate else 0.0
        rows.append(row)
    return fit_calibration(rows)


# ==========================================================================
# registry
# ==========================================================================
class TestRegistry:
    def test_configured_combiner_exists(self):
        """config cannot validate this itself without an import cycle."""
        assert settings.fusion.combiner in COMBINERS

    def test_resolve_returns_the_callable(self):
        assert resolve("weighted_mean") is weighted_mean

    def test_unknown_name_names_the_alternatives(self):
        with pytest.raises(ValueError, match="calibrated_noisy_or"):
            resolve("nope")


# ==========================================================================
# the Block 2 baseline must keep working -- it is the comparison
# ==========================================================================
class TestWeightedMean:
    def test_matches_the_hand_computation(self):
        scores = {"rules": 0.4, "graph": 0.8}
        expected = (0.30 * 0.4 + 0.10 * 0.8) / 0.40
        assert weighted_mean(scores, WEIGHTS) == pytest.approx(expected)

    def test_silent_layers_still_divide(self):
        """Every layer emits a row, so the denominator is layers present."""
        assert weighted_mean({"rules": 1.0, "graph": 0.0}, WEIGHTS) == pytest.approx(
            0.30 / 0.40
        )

    def test_no_layers_scores_zero(self):
        assert weighted_mean({}, WEIGHTS) == 0.0

    def test_unknown_layers_are_ignored(self):
        assert weighted_mean({"martian": 1.0}, WEIGHTS) == 0.0


# ==========================================================================
# bounds -- every combiner, always
# ==========================================================================
@pytest.mark.parametrize("name", sorted(COMBINERS))
class TestBounds:
    def test_stays_in_unit_interval(self, name):
        combiner = resolve(name)
        rng = np.random.default_rng(1)
        for _ in range(200):
            scores = {la: float(rng.random()) for la in WEIGHTS}
            assert 0.0 <= combiner(scores, WEIGHTS) <= 1.0

    def test_all_silent_scores_zero(self, name):
        assert resolve(name)({la: 0.0 for la in WEIGHTS}, WEIGHTS) == 0.0

    def test_empty_input(self, name):
        assert resolve(name)({}, WEIGHTS) == 0.0

    def test_is_monotone_in_a_single_layer(self, name):
        """Raising one layer's score can never lower the fused risk."""
        combiner = resolve(name)
        previous = -1.0
        for score in np.linspace(0.0, 1.0, 21):
            value = combiner({"rules": float(score), "graph": 0.3}, WEIGHTS)
            assert value >= previous - 1e-12
            previous = value


# ==========================================================================
# calibration
# ==========================================================================
class TestCalibration:
    def test_silent_score_has_tail_one(self):
        """P(S >= 0) = 1, so a silent layer contributes nothing to a product."""
        cal = population({"rules": 0.5})
        assert cal.tail("rules", 0.0) == 1.0

    def test_tail_shrinks_as_score_rises(self):
        cal = population({"rules": 0.5})
        assert cal.tail("rules", 0.2) > cal.tail("rules", 0.9)

    def test_tail_is_floored_at_one_over_n(self):
        """The rarest observable event is one-in-n; claiming more is invention."""
        cal = population({"rules": 0.5}, n=500)
        assert cal.tail("rules", 10.0) == pytest.approx(1 / 500)

    def test_tail_tracks_fire_rate_for_the_weakest_hit(self):
        """A hit on a rare layer is rarer than a hit on a common one."""
        cal = population({"common": 0.5, "rare": 0.03})
        assert cal.tail("rare", 0.11) < cal.tail("common", 0.11)

    def test_fire_rate_is_measured_not_assumed(self):
        cal = population({"rules": 0.25}, n=4000)
        assert cal.fire_rate("rules") == pytest.approx(0.25, abs=0.03)

    def test_unknown_layer_is_neutral(self):
        assert population({"rules": 0.5}).tail("martian", 0.9) == 1.0

    def test_accepts_a_column_mapping(self):
        cal = fit_calibration({"rules": [0.0, 0.5, 1.0]})
        assert cal.tail("rules", 1.0) == pytest.approx(1 / 3)

    def test_uses_no_labels(self):
        """Calibration must be fittable with ground truth nowhere in scope."""
        import inspect

        source = inspect.getsource(fit_calibration)
        for forbidden in ("label", "fraud", "y_true", "visibility"):
            assert forbidden not in source


# ==========================================================================
# the properties the block exists to deliver
# ==========================================================================
class TestCalibratedNoisyOr:
    def test_a_rare_layer_outranks_a_common_one_at_equal_score(self):
        """The finding: fire rate must not masquerade as strength.

        `rules` fired on 51.6% of the corpus and took 89% of the fused score
        mass; `graph` fired on 3.0% and took 2.2%, while being the more
        informative layer per work surfaced. Identical raw scores must not
        mean identical evidence.
        """
        cal = population({"rules": 0.52, "graph": 0.03})
        equal_weights = {"rules": 0.10, "graph": 0.10}
        rare = calibrated_noisy_or({"graph": 0.5}, equal_weights, cal)
        common = calibrated_noisy_or({"rules": 0.5}, equal_weights, cal)
        assert rare > common

    def test_agreement_beats_a_single_loud_layer(self):
        """Two layers firing had a 10.9% held-out rate against a 2.1% base.

        A weighted mean cannot express that -- two moderate signals average
        below one loud one. This is the property that fixes it.
        """
        cal = population({"a": 0.05, "b": 0.05})
        weights = {"a": 0.30, "b": 0.30}
        together = calibrated_noisy_or({"a": 0.5, "b": 0.5}, weights, cal)
        alone = calibrated_noisy_or({"a": 1.0, "b": 0.0}, weights, cal)
        assert together > alone

    def test_no_single_layer_can_saturate_the_score(self):
        cal = population({"rules": 0.5, "graph": 0.03})
        loudest = calibrated_noisy_or({"rules": 99.0}, WEIGHTS, cal)
        assert loudest < 1.0

    def test_silent_layers_do_not_dilute(self):
        """Unlike the mean, an absent layer is not evidence of innocence."""
        cal = population({"rules": 0.5, "graph": 0.03, "duplicate": 0.03})
        weights = {"rules": 0.3, "graph": 0.1, "duplicate": 0.1}
        with_silent = calibrated_noisy_or(
            {"rules": 0.9, "graph": 0.0, "duplicate": 0.0}, weights, cal
        )
        alone = calibrated_noisy_or({"rules": 0.9}, weights, cal)
        assert with_silent == pytest.approx(alone)

    def test_degrades_to_noisy_or_without_a_calibration(self):
        scores = {"rules": 0.5, "graph": 0.5}
        assert calibrated_noisy_or(scores, WEIGHTS, None) == pytest.approx(
            noisy_or(scores, WEIGHTS)
        )

    def test_zero_weight_layer_contributes_nothing(self):
        cal = population({"rules": 0.5, "graph": 0.03})
        weights = {"rules": 0.3, "graph": 0.0}
        assert calibrated_noisy_or(
            {"rules": 0.5, "graph": 0.9}, weights, cal
        ) == pytest.approx(calibrated_noisy_or({"rules": 0.5}, weights, cal))


class TestNoisyOr:
    def test_agreement_compounds(self):
        both = noisy_or({"rules": 0.5, "graph": 0.5}, WEIGHTS)
        assert both > noisy_or({"rules": 0.5}, WEIGHTS)
        assert both > noisy_or({"graph": 0.5}, WEIGHTS)

    def test_a_layer_cannot_exceed_its_own_weight(self):
        assert noisy_or({"graph": 1.0}, WEIGHTS) == pytest.approx(0.10)
