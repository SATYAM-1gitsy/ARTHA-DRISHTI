"""Tests for the domain constants and the fraud-pattern registry.

Several of these encode audit findings as executable rules rather than
conventions someone can forget six commits from now:

  R-03  held-out patterns must stay disjoint from rule-visible ones, and both
        sets must be non-empty, or the only honest performance number the
        project produces silently becomes another tautology.
  R-05  every SoR benchmark must carry provenance, so the UI can never render
        an invented number as if it came from a published schedule.
  R-01  every pattern must declare an evidence family, so fusion can count
        corroboration across independent families rather than across layers.
"""

from __future__ import annotations

import dataclasses

import pytest

from drishti.domain import (
    FRAUD_PATTERNS,
    INELIGIBLE_KEYWORDS,
    PER_WORK_CEILING,
    SC_EARMARK_PCT,
    SECTORS,
    SOR_UNIT_COST,
    ST_EARMARK_PCT,
    WORK_TYPES,
    FraudPattern,
    PatternVisibility,
    Provenance,
    Sourced,
    held_out_patterns,
    rule_visible_patterns,
)


class TestSourced:
    def test_verified_provenance(self):
        value = Sourced(1.0, Provenance.GUIDELINE_CLAUSE, "cl. 2.1")
        assert value.is_verified is True

    def test_assumption_is_not_verified(self):
        value = Sourced(1.0, Provenance.ASSUMED, "made up")
        assert value.is_verified is False

    def test_repr_marks_unverified(self):
        assert "unverified" in repr(Sourced(1.0, Provenance.ASSUMED, "x"))

    def test_is_immutable(self):
        value = Sourced(1.0, Provenance.ASSUMED, "x")
        with pytest.raises(dataclasses.FrozenInstanceError):
            value.value = 2.0  # type: ignore[misc]


class TestSchemeParameters:
    def test_earmark_percentages(self):
        assert SC_EARMARK_PCT.value == 15.0
        assert ST_EARMARK_PCT.value == 7.5

    def test_every_parameter_carries_a_citation(self):
        for param in (SC_EARMARK_PCT, ST_EARMARK_PCT, PER_WORK_CEILING):
            assert param.citation.strip(), "a constant without a citation is unusable as evidence"

    def test_unverified_parameters_say_so_loudly(self):
        # The ceiling drives a compliance rule. If it is an assumption, the
        # citation must make that unmissable to whoever renders it.
        assert PER_WORK_CEILING.provenance is Provenance.ASSUMED
        assert "ASSUMPTION" in PER_WORK_CEILING.citation.upper()


class TestWorkTaxonomy:
    def test_sectors_are_non_empty(self):
        assert SECTORS
        for sector, types in SECTORS.items():
            assert types, f"sector {sector} has no work types"

    def test_work_types_are_unique(self):
        assert len(WORK_TYPES) == len(set(WORK_TYPES))

    def test_every_work_type_has_a_benchmark(self):
        missing = [wt for wt in WORK_TYPES if wt not in SOR_UNIT_COST]
        assert not missing, f"work types without a unit-cost benchmark: {missing}"

    def test_no_orphan_benchmarks(self):
        orphans = [wt for wt in SOR_UNIT_COST if wt not in WORK_TYPES]
        assert not orphans, f"benchmarks for unknown work types: {orphans}"

    def test_benchmarks_are_positive(self):
        for work_type, benchmark in SOR_UNIT_COST.items():
            assert benchmark.value > 0, f"{work_type} has a non-positive benchmark"

    def test_every_benchmark_declares_provenance(self):
        """R-05. An unsourced benchmark renders as fabricated evidence."""
        for work_type, benchmark in SOR_UNIT_COST.items():
            assert isinstance(benchmark, Sourced), f"{work_type} is not Sourced"
            assert benchmark.provenance is Provenance.ASSUMED, (
                f"{work_type} claims stronger provenance than the project can "
                "support -- no Schedule of Rates has been digitised yet"
            )


class TestIneligibleKeywords:
    def test_categories_are_populated(self):
        assert INELIGIBLE_KEYWORDS
        for category, words in INELIGIBLE_KEYWORDS.items():
            assert words, f"category {category} has no keywords"

    def test_keywords_are_lowercase(self):
        for words in INELIGIBLE_KEYWORDS.values():
            for word in words:
                assert word == word.lower(), f"{word!r} must be lowercase to match normalized text"


class TestFraudPatterns:
    def test_registry_is_populated(self):
        assert len(FRAUD_PATTERNS) >= 10

    def test_pattern_names_are_unique(self):
        names = [p.name for p in FRAUD_PATTERNS]
        assert len(names) == len(set(names))

    def test_both_visibility_sets_are_non_empty(self):
        """R-03. Without held-out patterns there is no generalisation measure."""
        assert rule_visible_patterns()
        assert held_out_patterns()

    def test_visibility_sets_are_disjoint(self):
        visible = {p.name for p in rule_visible_patterns()}
        held = {p.name for p in held_out_patterns()}
        assert not (visible & held)
        assert visible | held == {p.name for p in FRAUD_PATTERNS}

    def test_held_out_set_is_large_enough_to_measure(self):
        # Fewer than three held-out patterns and a single miss swings the
        # reported recall by more than a third.
        assert len(held_out_patterns()) >= 3

    def test_held_out_patterns_span_multiple_evidence_families(self):
        families = {p.evidence_family for p in held_out_patterns()}
        assert len(families) >= 3, (
            "held-out patterns concentrated in one family would only test one "
            "detector's generalisation"
        )

    def test_every_pattern_declares_an_evidence_family(self):
        """R-01. Fusion counts corroboration across families, not layers."""
        for pattern in FRAUD_PATTERNS:
            assert pattern.evidence_family

    def test_every_pattern_is_grounded(self):
        for pattern in FRAUD_PATTERNS:
            assert len(pattern.grounding) > 20, (
                f"{pattern.name} has no real-world grounding -- an invented "
                "pattern produces invented performance"
            )

    def test_rejects_bad_severity(self):
        with pytest.raises(ValueError, match="severity"):
            FraudPattern("x", "d", PatternVisibility.HELD_OUT, "extreme", "financial", "g" * 25)

    def test_rejects_bad_evidence_family(self):
        with pytest.raises(ValueError, match="evidence_family"):
            FraudPattern("x", "d", PatternVisibility.HELD_OUT, "high", "vibes", "g" * 25)

    def test_critical_patterns_exist(self):
        assert any(p.severity == "critical" for p in FRAUD_PATTERNS)
