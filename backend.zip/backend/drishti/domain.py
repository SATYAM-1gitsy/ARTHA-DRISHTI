"""MPLADS domain constants, every one of them carrying its provenance.

Why provenance is a first-class field here (audit findings R-05 and R-06):
the evidence card's most quotable line is "unit cost 2.4x the Schedule of
Rates benchmark". If that benchmark is a number somebody invented during a
hackathon, the sentence is fabricated evidence -- and it is exactly the line a
domain judge probes first. So no constant enters this module without saying
where it came from, and the UI renders that provenance next to the number.

Three provenance levels, in descending strength:

  GUIDELINE_CLAUSE  quoted from a specific clause of a real published document
  PEER_DERIVED      computed from the data at runtime, not asserted here
  ASSUMED           a project assumption, plausible but unverified

Anything marked ASSUMED must render as an assumption everywhere it appears.
Replace them with GUIDELINE_CLAUSE values once data/guidelines.md exists --
see docs/adr/0001 finding B-03.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Generic, TypeVar

__all__ = [
    "Provenance",
    "Sourced",
    "ANNUAL_ENTITLEMENT",
    "PER_WORK_CEILING",
    "SC_EARMARK_PCT",
    "TRUST_SOCIETY_CEILING",
    "ST_EARMARK_PCT",
    "SANCTION_WINDOW_DAYS",
    "COMPLETION_WINDOW_DAYS",
    "SECTORS",
    "WORK_TYPES",
    "SOR_UNIT_COST",
    "WORK_UNIT",
    "QUANTITY_RANGE",
    "quantity_range",
    "work_unit",
    "AGENCY_TYPES",
    "WORK_STATUSES",
    "PAYMENT_TYPES",
    "INELIGIBLE_KEYWORDS",
    "PatternVisibility",
    "FraudPattern",
    "FRAUD_PATTERNS",
    "rule_visible_patterns",
    "held_out_patterns",
]

T = TypeVar("T")


class Provenance(str, Enum):
    """Where a constant's value came from."""

    GUIDELINE_CLAUSE = "guideline_clause"
    CAG_FINDING = "cag_finding"
    PEER_DERIVED = "peer_derived"
    ASSUMED = "assumed"


@dataclass(frozen=True)
class Sourced(Generic[T]):
    """A value that knows where it came from.

    Carrying the citation alongside the number is what lets an evidence card
    say "ceiling per Guidelines 2023 cl. 3.4" or "ceiling (project
    assumption)" without the rendering code having to guess which it is.
    """

    value: T
    provenance: Provenance
    citation: str

    @property
    def is_verified(self) -> bool:
        return self.provenance in (
            Provenance.GUIDELINE_CLAUSE,
            Provenance.CAG_FINDING,
        )

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        mark = "" if self.is_verified else " (unverified)"
        return f"<{self.value!r} :: {self.provenance.value}{mark}>"


# --------------------------------------------------------------------------
# Scheme parameters
# --------------------------------------------------------------------------
# Widely published and stable since 2011-12. Still flagged unverified against
# a primary source until data/guidelines.md is committed (finding B-03).
ANNUAL_ENTITLEMENT = Sourced(
    value=50_000_000.0,  # rupees, 5 crore per MP per year
    provenance=Provenance.GUIDELINE_CLAUSE,
    citation="MPLADS Guidelines (MoSPI, June 2016) Para 2.5, which states the "
    "entitlement as Rs 5 crore per MP per year in working the SC/ST earmark "
    "arithmetic. Verified; see data/guidelines/SOURCE.md.",
)

PER_WORK_CEILING = Sourced(
    value=2_500_000.0,  # rupees, 25 lakh
    provenance=Provenance.ASSUMED,
    citation="PROJECT ASSUMPTION, and now known to be unsupported rather than "
    "merely unverified. The MPLADS Guidelines (MoSPI, June 2016) contain NO general "
    "per-work ceiling: the ceilings there attach to recipient categories -- Rs 50 "
    "lakh for assets built by trusts and societies (Para 3.21.2), raised 50% to "
    "Rs 75 lakh in tribal areas (Para 2.5.1) -- and aided educational institutions "
    "are explicitly subject to 'no ceiling' (Para 3.37). The Rs 25 lakh in the "
    "document is Para 2.5.1's additional amount for tribal areas only, a different "
    "quantity that this constant appears to have been conflated with. "
    "`ceiling_breach` fires on 12.8% of the corpus against a threshold the "
    "guidelines do not contain; it is an OPEN ITEM, not a verified rule. See "
    "data/guidelines/SOURCE.md.",
)

TRUST_SOCIETY_CEILING = Sourced(
    value=5_000_000.0,  # rupees, 50 lakh
    provenance=Provenance.GUIDELINE_CLAUSE,
    citation="MPLADS Guidelines (MoSPI, June 2016) Para 3.21.2: Rs 50 lakh ceiling "
    "for building assets by trusts and societies, enhanced by 50% to Rs 75 lakh for "
    "community assets primarily benefiting tribal people in tribal areas (Para "
    "2.5.1). No rule consumes this yet -- the Gold view does not record whether an "
    "implementing agency is a trust or society, so the condition that makes the "
    "ceiling apply cannot be evaluated. Recorded so the next person does not "
    "rediscover it. Note the 2023 revision is reported to have raised this figure; "
    "that edition is not the one in data/guidelines/.",
)

SC_EARMARK_PCT = Sourced(
    value=15.0,
    provenance=Provenance.GUIDELINE_CLAUSE,
    citation="MPLADS Guidelines (MoSPI, June 2016) Para 2.5: MPs are to recommend "
    "every year works costing at least 15 per cent of the MPLADS entitlement for "
    "areas inhabited by Scheduled Caste population -- Rs 75 lakh of the Rs 5 crore "
    "annual entitlement. The denominator is the ENTITLEMENT, not sanctioned cost; "
    "any share computed over recorded works is a different quantity and must say so. "
    "Verified; see data/guidelines/SOURCE.md.",
)

ST_EARMARK_PCT = Sourced(
    value=7.5,
    provenance=Provenance.GUIDELINE_CLAUSE,
    citation="MPLADS Guidelines (MoSPI, June 2016) Para 2.5: at least 7.5 per cent "
    "of the annual entitlement for areas inhabited by Scheduled Tribe population -- "
    "Rs 37.5 lakh of Rs 5 crore. Where a constituency has insufficient tribal "
    "population the amount may be spent elsewhere in the State of election, so a "
    "shortfall is a question to ask rather than a breach. Verified; see "
    "data/guidelines/SOURCE.md.",
)

SANCTION_WINDOW_DAYS = Sourced(
    value=75,
    provenance=Provenance.GUIDELINE_CLAUSE,
    citation="MPLADS Guidelines (MoSPI, June 2016) Para 3.12: 'All recommended "
    "eligible works should be sanctioned within 75 days from the date of receipt "
    "of the recommendation, after completing all formalities.' Rejection must be "
    "intimated within 45 days. Periods under the Election Commission's model code "
    "of conduct are excluded from the reckoning, which this project does not yet "
    "model. Verified against the primary document; see data/guidelines/SOURCE.md. "
    "The 75 days was right all along -- ADR-0013 removed the rule because the "
    "constant was unverified and fired on 36% of the corpus, but the fire rate is "
    "the generator's lag distribution being unrealistic, not the clause being wrong.",
)

COMPLETION_WINDOW_DAYS = Sourced(
    value=365,
    provenance=Provenance.ASSUMED,
    citation="PROJECT ASSUMPTION for expected completion. Used only to seed "
    "the generator and as a delay baseline, never as a compliance verdict.",
)


# --------------------------------------------------------------------------
# Work taxonomy
# --------------------------------------------------------------------------
SECTORS: dict[str, tuple[str, ...]] = {
    "roads_bridges": ("village_road", "approach_road", "culvert", "footpath"),
    "drinking_water": ("borewell", "handpump", "water_tank", "pipeline"),
    "education": ("classroom", "school_boundary_wall", "school_toilet", "library"),
    "health": ("phc_building", "ambulance_shelter", "health_sub_centre"),
    "sanitation": ("community_toilet", "drainage", "soak_pit"),
    "electricity": ("street_light", "high_mast_light", "solar_unit"),
    "community": ("community_hall", "crematorium_shed", "bus_shelter"),
    "sports": ("playground", "open_gym", "sports_shed"),
}

WORK_TYPES: tuple[str, ...] = tuple(
    wt for types in SECTORS.values() for wt in types
)


# Unit-cost benchmarks in rupees per unit (metre, unit, sq-m depending on the
# work type). EVERY ONE OF THESE IS ASSUMED.
#
# A real Schedule of Rates is published per state by the PWD and varies by
# year and region. Until a subset is digitised, cost-inflation evidence should
# lead with the PEER_DERIVED percentile ("97th percentile of its sector-state
# peers"), which is computed from the data and defensible, and mention the SoR
# ratio only as a secondary, clearly-labelled assumption.
SOR_UNIT_COST: dict[str, Sourced[float]] = {
    work_type: Sourced(
        value=cost,
        provenance=Provenance.ASSUMED,
        citation="PROJECT ASSUMPTION -- no published Schedule of Rates has "
        "been digitised. Prefer peer-derived percentiles as primary evidence.",
    )
    for work_type, cost in {
        "village_road": 1_400.0,
        "approach_road": 1_650.0,
        "culvert": 185_000.0,
        "footpath": 900.0,
        "borewell": 145_000.0,
        "handpump": 62_000.0,
        "water_tank": 310_000.0,
        "pipeline": 780.0,
        "classroom": 640_000.0,
        "school_boundary_wall": 2_100.0,
        "school_toilet": 215_000.0,
        "library": 890_000.0,
        "phc_building": 2_400_000.0,
        "ambulance_shelter": 340_000.0,
        "health_sub_centre": 1_450_000.0,
        "community_toilet": 265_000.0,
        "drainage": 1_150.0,
        "soak_pit": 48_000.0,
        "street_light": 27_000.0,
        "high_mast_light": 385_000.0,
        "solar_unit": 96_000.0,
        "community_hall": 1_850_000.0,
        "crematorium_shed": 720_000.0,
        "bus_shelter": 195_000.0,
        "playground": 540_000.0,
        "open_gym": 410_000.0,
        "sports_shed": 630_000.0,
    }.items()
}

# What the SoR benchmark is denominated in, and a plausible quantity range for
# a single sanctioned work.
#
# This exists because getting it wrong is not a cosmetic problem. Drawing one
# quantity range for every work type produced "455 primary health centre
# buildings" as a single work costing Rs 106 crore -- against an annual
# entitlement of Rs 5 crore per member. A linear work is measured in metres and
# a building is counted in units, and no single range covers both.
WORK_UNIT: dict[str, str] = {
    "village_road": "metre", "approach_road": "metre", "footpath": "metre",
    "pipeline": "metre", "drainage": "metre",
    "school_boundary_wall": "sq_metre",
    "street_light": "unit", "solar_unit": "unit",
}

QUANTITY_RANGE: dict[str, tuple[float, float]] = {
    # linear works, in metres
    "village_road": (200.0, 2500.0),
    "approach_road": (150.0, 1800.0),
    "footpath": (100.0, 1200.0),
    "pipeline": (300.0, 3000.0),
    "drainage": (150.0, 1500.0),
    # area works, in square metres
    "school_boundary_wall": (80.0, 600.0),
    # multi-unit point works
    "street_light": (10.0, 60.0),
    "solar_unit": (1.0, 10.0),
    "handpump": (1.0, 5.0),
    "soak_pit": (1.0, 6.0),
    "open_gym": (1.0, 3.0),
}

# Everything else is a single structure, occasionally two.
DEFAULT_QUANTITY_RANGE: tuple[float, float] = (1.0, 3.0)


def quantity_range(work_type: str) -> tuple[float, float]:
    """Plausible quantity for one sanctioned work of this type."""
    return QUANTITY_RANGE.get(work_type, DEFAULT_QUANTITY_RANGE)


def work_unit(work_type: str) -> str:
    """The unit its SoR benchmark is denominated in."""
    return WORK_UNIT.get(work_type, "unit")


AGENCY_TYPES: tuple[str, ...] = (
    "PWD",
    "Rural Engineering Service",
    "Municipal Corporation",
    "Zilla Parishad",
    "Gram Panchayat",
    "Public Health Engineering",
    "State Electricity Board",
    "District Rural Development Agency",
)

WORK_STATUSES: tuple[str, ...] = (
    "recommended",
    "sanctioned",
    "in_progress",
    "completed",
    "abandoned",
)

PAYMENT_TYPES: tuple[str, ...] = ("advance", "running", "final")


# Keyword signals for potentially ineligible works. These are SIGNALS, not
# verdicts: MPLADS ineligibility turns on the purpose and beneficiary of a
# work, which a keyword cannot establish. A hit routes a work to
# requires_review, never to ineligible.
INELIGIBLE_KEYWORDS: dict[str, tuple[str, ...]] = {
    "religious": ("temple", "mosque", "church", "gurudwara", "mandir", "masjid"),
    "memorial": ("memorial", "statue", "smarak", "bust", "cenotaph"),
    "private_benefit": ("private", "individual", "residence", "personal", "trust"),
    "government_office": ("office building", "staff quarters", "guest house"),
    "commercial": ("shop", "showroom", "commercial complex", "market stall"),
    "recurring": ("salary", "wages", "maintenance", "fuel", "electricity bill"),
}


# --------------------------------------------------------------------------
# Fraud pattern registry
# --------------------------------------------------------------------------
class PatternVisibility(str, Enum):
    """Whether detectors were written with knowledge of this pattern.

    This is the structural fix for audit finding R-03. If the generator
    injects pre_sanction_payment and L0 has a pre_sanction_payment rule, then
    recall on that pattern is approximately 1.0 by construction -- it measures
    agreement between the rule and the injector, not detection.

    HELD_OUT patterns are injected by the generator but no detector is written
    against them. Only held-out figures may be quoted as detection
    performance; rule-visible figures are a correctness check on the pipeline.
    The evaluation harness reports the two separately and refuses to pool them.
    """

    RULE_VISIBLE = "rule_visible"
    HELD_OUT = "held_out"


@dataclass(frozen=True)
class FraudPattern:
    """One injectable anomaly pattern."""

    name: str
    description: str
    visibility: PatternVisibility
    severity: str  # low | medium | high | critical
    evidence_family: str  # financial | temporal | network | textual | asset | compliance
    grounding: str  # what real-world finding this pattern is modelled on

    def __post_init__(self) -> None:
        if self.severity not in ("low", "medium", "high", "critical"):
            raise ValueError(f"{self.name}: bad severity {self.severity!r}")
        if self.evidence_family not in (
            "financial",
            "temporal",
            "network",
            "textual",
            "asset",
            "compliance",
        ):
            raise ValueError(
                f"{self.name}: bad evidence_family {self.evidence_family!r}"
            )


# evidence_family exists for audit finding R-01: fusion must count
# corroboration across INDEPENDENT families, not across layers. Three layers
# all firing on unit_cost is one piece of financial evidence seen three ways,
# not three independent confirmations.
FRAUD_PATTERNS: tuple[FraudPattern, ...] = (
    # ---- rule-visible: detectors are written against these ----
    FraudPattern(
        "pre_sanction_payment",
        "A payment is dated before the work's sanction date.",
        PatternVisibility.RULE_VISIBLE,
        "critical",
        "compliance",
        "CAG audits repeatedly report expenditure booked ahead of sanction.",
    ),
    FraudPattern(
        "cost_inflation",
        "Unit cost inflated well above comparable works of the same type.",
        PatternVisibility.RULE_VISIBLE,
        "high",
        "financial",
        "Inflated estimates are a recurring CAG finding.",
    ),
    FraudPattern(
        "ghost_work",
        "Paid and reported complete, with no asset or photo evidence.",
        PatternVisibility.RULE_VISIBLE,
        "critical",
        "asset",
        "Works certified complete without a verifiable asset on the ground.",
    ),
    FraudPattern(
        "duplicate_work",
        "Two works with near-identical descriptions and close geography.",
        PatternVisibility.RULE_VISIBLE,
        "high",
        "textual",
        "The same asset funded twice under different recommendations.",
    ),
    FraudPattern(
        "advance_without_progress",
        "Advance released, progress flat for an extended period.",
        PatternVisibility.RULE_VISIBLE,
        "medium",
        "temporal",
        "Funds released against works that never started.",
    ),
    FraudPattern(
        "agency_concentration",
        "One implementing agency takes a disproportionate district share.",
        PatternVisibility.RULE_VISIBLE,
        "medium",
        "network",
        "Agency capture surfaces as concentration in district award shares.",
    ),
    FraudPattern(
        "ineligible_work",
        "Description indicates a category outside the scheme's scope.",
        PatternVisibility.RULE_VISIBLE,
        "high",
        "compliance",
        "Ineligible works are among the most-reported audit irregularities.",
    ),
    FraudPattern(
        "split_payment",
        "One work split into payments that sum just under a threshold.",
        PatternVisibility.RULE_VISIBLE,
        "medium",
        "financial",
        "Splitting to stay below a sanction or scrutiny threshold.",
    ),
    # ---- held out: NO detector may be written against these ----
    # These measure whether the system generalises. If held-out recall is near
    # zero while rule-visible recall is near one, the system has learned the
    # injector and detected nothing.
    FraudPattern(
        "vendor_round_tripping",
        "Payments cycle among a small closed set of related payees.",
        PatternVisibility.HELD_OUT,
        "high",
        "network",
        "Circular flows among related vendors.",
    ),
    FraudPattern(
        "year_end_bunching",
        "Sanctions and spend cluster abnormally into the fiscal year end.",
        PatternVisibility.HELD_OUT,
        "medium",
        "temporal",
        "Year-end rush spending to avoid lapsing funds.",
    ),
    FraudPattern(
        "geographic_displacement",
        "Asset coordinates fall outside the district that sanctioned it.",
        PatternVisibility.HELD_OUT,
        "high",
        "compliance",
        "Works executed outside the permitted area.",
    ),
    FraudPattern(
        "progress_reversal",
        "Reported progress decreases between updates, then recovers.",
        PatternVisibility.HELD_OUT,
        "low",
        "temporal",
        "Reporting manipulation visible only in the update sequence.",
    ),
    FraudPattern(
        "photo_reuse",
        "The same asset photograph appears against unrelated works.",
        PatternVisibility.HELD_OUT,
        "critical",
        "asset",
        "One photograph certifying several works as complete.",
    ),
)


def rule_visible_patterns() -> tuple[FraudPattern, ...]:
    """Patterns detectors are allowed to be written against."""
    return tuple(
        p for p in FRAUD_PATTERNS if p.visibility is PatternVisibility.RULE_VISIBLE
    )


def held_out_patterns() -> tuple[FraudPattern, ...]:
    """Patterns reserved for measuring generalisation. Do not write a rule for
    any of these; doing so silently converts the project's only honest
    performance number into another tautology."""
    return tuple(
        p for p in FRAUD_PATTERNS if p.visibility is PatternVisibility.HELD_OUT
    )
