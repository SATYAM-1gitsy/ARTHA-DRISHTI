"""Ingest orchestration: raw file -> Bronze -> Silver -> report -> storage.

Kept separate from the modules it calls so `ingest`, `transform` and `quality`
stay independently testable, and so the whole chain has one entry point that
Block 4 can call before generating anything.

Writing is idempotent. Re-running replaces the Bronze and Silver parquet files
and upserts the reference tables on their natural keys, so a re-ingest after a
source correction does not accumulate duplicates -- which matters because the
generator anchors to these tables and would otherwise inherit them.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd

from .config import settings
from .ingest.allocation import IngestResult
from .ingest.allocation import ingest as read_and_validate
from .quality import QualityReport, build_report
from .storage import prepare_for_parquet, read_gold
from .transform.reference import ReferenceTables, build_reference_tables

__all__ = ["IngestOutcome", "PostgresWrite", "run_ingest", "write_parquet", "write_postgres"]


@dataclass
class IngestOutcome:
    """Everything one ingest run produced."""

    result: IngestResult
    tables: ReferenceTables
    report: QualityReport
    written: dict[str, str]

    @property
    def ok(self) -> bool:
        return self.report.is_usable


def write_parquet(outcome_result: IngestResult, tables: ReferenceTables) -> dict[str, str]:
    """Persist Bronze and Silver to parquet.

    Bronze is written unchanged and is the immutable record: any later
    question about a value is answerable from it without re-reading the source
    workbook.
    """
    seeds = settings.paths.seeds
    written: dict[str, str] = {}

    targets: list[tuple[str, pd.DataFrame]] = [
        ("bronze_allocation", outcome_result.accepted),
        ("bronze_quarantine", outcome_result.quarantined),
        ("silver_state", tables.states),
        ("silver_constituency", tables.constituencies),
        ("silver_mp", tables.mps),
    ]
    for name, frame in targets:
        path = seeds / f"{name}.parquet"
        prepare_for_parquet(frame).to_parquet(path, index=False)
        written[name] = str(path)
    return written


@dataclass
class PostgresWrite:
    """Result of the optional database write.

    Carries the reason on failure rather than a bare "unavailable". A stage
    that reports only that something did not work, without saying why, costs
    whoever hits it the same debugging twice.
    """

    counts: dict[str, int] = None  # type: ignore[assignment]
    error: str | None = None

    def __post_init__(self) -> None:
        if self.counts is None:
            self.counts = {}

    @property
    def ok(self) -> bool:
        return self.error is None and bool(self.counts)

    def describe(self) -> str:
        if self.ok:
            return ", ".join(f"{k}={v}" for k, v in self.counts.items())
        return f"skipped -- {self.error}"


def write_postgres(tables: ReferenceTables, url: str | None = None) -> PostgresWrite:
    """Upsert the reference tables into Postgres.

    Optional: the whole pipeline runs to parquet without a database, so a
    teammate with no Docker is never blocked. Failure is reported, not hidden.
    """
    try:
        from sqlalchemy import create_engine, text
    except ImportError:
        return PostgresWrite(error="sqlalchemy is not installed")

    engine = create_engine(url or settings.database_url, future=True)
    counts: dict[str, int] = {}

    try:
        with engine.begin() as connection:
            connection.execute(text("SELECT 1"))

            for row in tables.states.itertuples(index=False):
                connection.execute(
                    text(
                        "INSERT INTO state (state_id, name, ls_seats) "
                        "VALUES (:sid, :name, :seats) "
                        "ON CONFLICT (name) DO UPDATE SET ls_seats = EXCLUDED.ls_seats"
                    ),
                    {"sid": int(row.state_id), "name": row.name, "seats": int(row.ls_seats)},
                )

            for row in tables.constituencies.itertuples(index=False):
                connection.execute(
                    text(
                        "INSERT INTO constituency "
                        "(constituency_id, state_id, name, house, reservation) "
                        "VALUES (:cid, :sid, :name, :house, :res) "
                        "ON CONFLICT (state_id, name, house) DO UPDATE "
                        "SET reservation = EXCLUDED.reservation"
                    ),
                    {
                        "cid": int(row.constituency_id),
                        "sid": int(row.state_id),
                        "name": row.name,
                        "house": row.house,
                        "res": row.reservation,
                    },
                )

            for row in tables.mps.itertuples(index=False):
                connection.execute(
                    text(
                        "INSERT INTO mp (mp_id, name, name_canonical, house, constituency_id, "
                        "state_id, term_start, term_end, allocated_limit) "
                        "VALUES (:mid, :name, :canon, :house, :cid, :sid, :start, NULL, :limit) "
                        "ON CONFLICT (mp_id) DO UPDATE SET "
                        "name = EXCLUDED.name, allocated_limit = EXCLUDED.allocated_limit"
                    ),
                    {
                        "mid": int(row.mp_id),
                        "name": row.name,
                        "canon": row.name_canonical,
                        "house": row.house,
                        "cid": None if pd.isna(row.constituency_id) else int(row.constituency_id),
                        "sid": None if pd.isna(row.state_id) else int(row.state_id),
                        "start": row.term_start,
                        "limit": None if pd.isna(row.allocated_limit) else float(row.allocated_limit),
                    },
                )

            # Keep the generated sequences ahead of the ids just inserted, or
            # the next natural insert collides on the primary key.
            for table, column in (("state", "state_id"), ("constituency", "constituency_id"), ("mp", "mp_id")):
                connection.execute(
                    text(
                        f"SELECT setval(pg_get_serial_sequence('{table}', '{column}'), "
                        f"COALESCE((SELECT MAX({column}) FROM {table}), 1))"
                    )
                )

            for table in ("state", "constituency", "mp"):
                counts[table] = int(
                    connection.execute(text(f"SELECT count(*) FROM {table}")).scalar_one()
                )
    except Exception as exc:  # noqa: BLE001 - a database is optional at this stage
        detail = str(exc).splitlines()[0][:160]
        return PostgresWrite(error=f"{type(exc).__name__}: {detail}")

    return PostgresWrite(counts=counts)


def run_ingest(
    path: Path | None = None,
    *,
    to_parquet: bool = True,
    to_postgres: bool = False,
) -> IngestOutcome:
    """Read the allocation file and build everything downstream of it."""
    result = read_and_validate(path)
    tables = build_reference_tables(result.accepted)
    report = build_report(result, tables)

    written: dict[str, Any] = {}
    if to_parquet:
        written.update(write_parquet(result, tables))
        written["quality_report"] = str(
            report.write(settings.paths.out / "data_quality.json")
        )
    if to_postgres:
        written["postgres"] = write_postgres(tables).describe()

    return IngestOutcome(result=result, tables=tables, report=report, written=written)


# --------------------------------------------------------------------------
# synthetic generation
# --------------------------------------------------------------------------
@dataclass
class SeedOutcome:
    """One synthetic generation run."""

    dataset: Any
    report: Any
    written: dict[str, str]

    @property
    def ok(self) -> bool:
        return len(self.dataset.works) > 0 and len(self.dataset.labels) > 0


def run_seed(config: Any = None, *, to_parquet: bool = True) -> SeedOutcome:
    """Generate the synthetic population, inject anomalies, write ground truth.

    Guards the leakage boundary before anything is persisted: if an injection
    parameter has reached a data column, the run fails here rather than
    producing a dataset that silently invalidates every downstream metric.
    """
    from .contracts.labels import assert_no_label_leakage
    from .synth import generate, inject

    cfg = config or settings.gen
    dataset, report = inject(generate(cfg), cfg)

    for name, frame in dataset.tables.items():
        if name == "fraud_label":
            continue
        assert_no_label_leakage(list(frame.columns))

    written: dict[str, str] = {}
    if to_parquet:
        for name, frame in dataset.tables.items():
            path = settings.paths.seeds / f"{name}.parquet"
            prepared = frame.copy()
            if "parameters" in prepared.columns:
                # jsonb-shaped column; parquet needs a scalar type.
                from .util import dumps

                prepared["parameters"] = prepared["parameters"].map(dumps)
            prepare_for_parquet(prepared).to_parquet(path, index=False)
            written[name] = str(path)

        from .util import dumps as _dumps

        manifest = settings.paths.seeds / "generation_manifest.json"
        manifest.write_text(
            _dumps(
                {
                    "config": dataset.config,
                    "row_counts": dataset.summary,
                    "pattern_counts": report.counts,
                    "prevalence": round(report.prevalence, 4),
                    "held_out_share": round(report.held_out_share, 4),
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        written["generation_manifest"] = str(manifest)

    return SeedOutcome(dataset=dataset, report=report, written=written)


# --------------------------------------------------------------------------
# gold features
# --------------------------------------------------------------------------
@dataclass
class FeatureOutcome:
    """One feature-build run."""

    result: Any
    written: dict[str, str]

    @property
    def ok(self) -> bool:
        return self.result.ok


def run_features(*, to_parquet: bool = True) -> FeatureOutcome:
    """Build the Gold view from the seed tables and persist it."""
    from .features import build_from_seeds

    result = build_from_seeds()
    written: dict[str, str] = {}
    if to_parquet and result.ok:
        path = settings.paths.out / "gold.parquet"
        prepare_for_parquet(result.features).to_parquet(path, index=False)
        written["gold"] = str(path)
    return FeatureOutcome(result=result, written=written)


# --------------------------------------------------------------------------
# scoring
# --------------------------------------------------------------------------
@dataclass
class ScoreOutcome:
    """One scoring run."""

    result: Any
    written: dict[str, str]

    @property
    def ok(self) -> bool:
        return self.result.n_scored > 0


def run_score(*, to_parquet: bool = True, to_api: bool = True) -> ScoreOutcome:
    """Score the population and publish what the API serves.

    Writing `data/api/*.json` here is what opens the vertical slice: the
    frontend reads exactly the shapes the live routers return, so swapping
    between them changes a base URL and nothing else.
    """
    from .score import score_population, to_frame

    gold_path = settings.paths.out / "gold.parquet"
    if not gold_path.is_file():
        raise FileNotFoundError(
            f"{gold_path} not found. Run `drishti features` first -- scoring reads Seam A."
        )
    features = read_gold(gold_path)
    result = score_population(features)

    written: dict[str, str] = {}
    if to_parquet:
        frame = to_frame(result.assessments)
        path = settings.paths.out / "risk_score.parquet"
        prepare_for_parquet(frame).to_parquet(path, index=False)
        written["risk_score"] = str(path)

    if to_api:
        from .api.publish import publish_api_payloads

        written.update(publish_api_payloads(features, result.assessments))

    return ScoreOutcome(result=result, written=written)
