"""GPU detection, capability reporting and the CPU-build guard.

Audit finding G-01: on Windows, `pip install torch` resolves to the PyPI
wheel, which has no CUDA. It imports cleanly, torch.cuda.is_available()
returns False, and every model trains on CPU while appearing to work. That
failure is silent, so this module makes it loud -- `drishti gpu --require`
turns it into a non-zero exit, and `drishti test` asserts on it.

The audited machine is an RTX 5070 Laptop GPU: Blackwell, compute capability
12.0 (sm_120), 8 GB VRAM. sm_120 kernels ship only in CUDA 12.8 and newer
builds, so a cu121 or cu124 wheel installs happily and then dies at the first
kernel launch with "no kernel image is available for execution on the device".
MIN_COMPUTE_CAPABILITY encodes that.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

__all__ = [
    "GPUReport",
    "detect",
    "require_cuda",
    "resolve_device",
    "autocast_dtype",
    "INSTALL_HINT",
    "MIN_COMPUTE_CAPABILITY",
]

# Blackwell. Anything below this on this machine means the wrong wheel.
MIN_COMPUTE_CAPABILITY = (12, 0)

INSTALL_HINT = (
    "Install a CUDA build explicitly -- the default PyPI wheel is CPU-only "
    "on Windows:\n"
    "    pip install torch --index-url https://download.pytorch.org/whl/cu130\n"
    "cu128 and cu129 also carry sm_120 kernels; cu121 and cu124 do not."
)


@dataclass(frozen=True)
class GPUReport:
    """What we could learn about the machine's accelerator."""

    torch_installed: bool
    torch_version: str | None = None
    cuda_build: str | None = None
    cuda_available: bool = False
    device_count: int = 0
    device_name: str | None = None
    compute_capability: tuple[int, int] | None = None
    total_memory_mb: int | None = None
    free_memory_mb: int | None = None
    bf16_supported: bool = False
    fp16_supported: bool = False
    problems: list[str] = field(default_factory=list)

    @property
    def usable(self) -> bool:
        """True when real GPU acceleration is available and correctly built."""
        return self.cuda_available and not self.problems

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        if self.compute_capability is not None:
            data["compute_capability"] = "{}.{}".format(*self.compute_capability)
        return data

    def summary(self) -> str:
        if not self.torch_installed:
            return "torch is not installed -- running in the numpy-only fallback."
        if not self.cuda_available:
            return (
                f"torch {self.torch_version} present but CUDA is unavailable "
                f"(build: {self.cuda_build or 'cpu'}). Everything will run on CPU."
            )
        cap = "{}.{}".format(*self.compute_capability) if self.compute_capability else "?"
        mem = f"{self.total_memory_mb} MB" if self.total_memory_mb else "unknown"
        precision = "bf16" if self.bf16_supported else ("fp16" if self.fp16_supported else "fp32 only")
        return (
            f"{self.device_name} | sm_{cap.replace('.', '')} | {mem} VRAM | "
            f"torch {self.torch_version} (cuda {self.cuda_build}) | {precision}"
        )


def detect() -> GPUReport:
    """Inspect the machine. Never raises -- returns a report with `problems`."""
    try:
        import torch
    except ImportError:
        return GPUReport(
            torch_installed=False,
            problems=["torch is not installed"],
        )

    problems: list[str] = []
    cuda_build = getattr(torch.version, "cuda", None)
    available = bool(torch.cuda.is_available())

    if not available:
        problems.append(
            "CUDA is not available to torch. "
            + ("This is a CPU-only build. " if not cuda_build else "")
            + INSTALL_HINT
        )
        return GPUReport(
            torch_installed=True,
            torch_version=torch.__version__,
            cuda_build=cuda_build,
            cuda_available=False,
            problems=problems,
        )

    index = torch.cuda.current_device()
    props = torch.cuda.get_device_properties(index)
    capability = torch.cuda.get_device_capability(index)

    if capability < MIN_COMPUTE_CAPABILITY:
        problems.append(
            f"Device reports compute capability {capability[0]}.{capability[1]}, "
            f"below the expected {MIN_COMPUTE_CAPABILITY[0]}.{MIN_COMPUTE_CAPABILITY[1]}. "
            "If this machine has the audited RTX 5070, the installed wheel is "
            "built for an older architecture and kernels will fail at launch. "
            + INSTALL_HINT
        )

    try:
        free_bytes, total_bytes = torch.cuda.mem_get_info(index)
        free_mb: int | None = free_bytes // (1024 * 1024)
        total_mb: int | None = total_bytes // (1024 * 1024)
    except Exception:  # pragma: no cover - driver dependent
        free_mb = None
        total_mb = props.total_memory // (1024 * 1024)

    try:
        bf16 = bool(torch.cuda.is_bf16_supported())
    except Exception:  # pragma: no cover - driver dependent
        bf16 = capability >= (8, 0)

    return GPUReport(
        torch_installed=True,
        torch_version=torch.__version__,
        cuda_build=cuda_build,
        cuda_available=True,
        device_count=torch.cuda.device_count(),
        device_name=props.name,
        compute_capability=capability,
        total_memory_mb=total_mb,
        free_memory_mb=free_mb,
        bf16_supported=bf16,
        fp16_supported=capability >= (7, 0),
        problems=problems,
    )


def require_cuda(report: GPUReport | None = None) -> GPUReport:
    """Raise unless a correctly-built CUDA device is present.

    Call this at the top of any training entry point that is only worth
    running on a GPU, so a misconfigured environment fails in one second
    rather than after an hour of silent CPU training.
    """
    rep = report if report is not None else detect()
    if not rep.usable:
        raise RuntimeError(
            "GPU required but unavailable.\n  " + "\n  ".join(rep.problems or ["unknown"])
        )
    return rep


def resolve_device(preference: str = "auto") -> str:
    """Turn a device preference into a concrete torch device string.

    "auto" picks cuda when it is genuinely usable and cpu otherwise, so the
    detectors stay runnable on a teammate's laptop with no GPU.
    """
    pref = (preference or "auto").strip().lower()
    if pref == "cpu":
        return "cpu"
    report = detect()
    if pref == "auto":
        return "cuda" if report.usable else "cpu"
    if pref.startswith("cuda"):
        if not report.usable:
            raise RuntimeError(
                f"device {preference!r} requested but CUDA is unusable.\n  "
                + "\n  ".join(report.problems or ["unknown"])
            )
        return pref
    raise ValueError(f"unrecognised device preference {preference!r}")


def autocast_dtype(mixed_precision: str, report: GPUReport | None = None) -> str | None:
    """Resolve the configured precision against what the device supports.

    Returns "bfloat16", "float16" or None. Silently downgrades rather than
    failing: bf16 on a card without it would otherwise crash a training run
    that would have been fine in fp16.
    """
    mode = (mixed_precision or "off").strip().lower()
    if mode == "off":
        return None
    rep = report if report is not None else detect()
    if not rep.usable:
        return None
    if mode == "bf16":
        return "bfloat16" if rep.bf16_supported else ("float16" if rep.fp16_supported else None)
    if mode == "fp16":
        return "float16" if rep.fp16_supported else None
    raise ValueError(f"unsupported mixed_precision {mixed_precision!r}")
