"""The end-to-end acceptance gate.

`drishti e2e` runs the pipeline and then checks these. They are the team's
heartbeat: a red gate is the whole team's priority, and every one of them
encodes a property that would otherwise fail silently.

One criterion from the Block 0 plan is implemented differently from how it was
written, and the difference is deliberate. The plan said *"a work with 3
missing fields gets data_quality < 0.5"*. With 52 optional columns in the Gold
contract, three missing fields gives 0.94, not 0.5 -- the number in the plan
was written before the contract was frozen. The **intent** is what matters and
is what is checked: data quality must fall as fields go missing, and confidence
must fall with it. Encoding the literal 0.5 would have meant tuning the
contract to satisfy a stale constant.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

import pandas as pd

from .config import settings
from .storage import read_gold

__all__ = ["Check", "AcceptanceReport", "run_acceptance"]


@dataclass
class Check:
    """One assertion, with the reason it exists."""

    name: str
    passed: bool
    detail: str

    @property
    def marker(self) -> str:
        return "PASS" if self.passed else "FAIL"


@dataclass
class AcceptanceReport:
    checks: list[Check] = field(default_factory=list)

    def add(self, name: str, passed: bool, detail: str) -> None:
        self.checks.append(Check(name, bool(passed), detail))

    @property
    def ok(self) -> bool:
        return all(check.passed for check in self.checks)

    def render(self) -> str:
        lines = ["acceptance gate", ""]
        for check in self.checks:
            lines.append(f"  [{check.marker}] {check.name}")
            lines.append(f"         {check.detail}")
        lines.append("")
        failed = [c for c in self.checks if not c.passed]
        lines.append(
            "All checks passed. The vertical slice is green."
            if not failed
            else f"{len(failed)} of {len(self.checks)} checks FAILED."
        )
        return "\n".join(lines)


def _safe(report: AcceptanceReport, name: str, fn: Callable[[], tuple[bool, str]]) -> None:
    """Run a check, turning an exception into a failure rather than a crash."""
    try:
        passed, detail = fn()
    except Exception as exc:  # noqa: BLE001 - a broken check is a failed check
        passed, detail = False, f"{type(exc).__name__}: {exc}"
    report.add(name, passed, detail)


def run_acceptance() -> AcceptanceReport:
    """Check the artefacts the pipeline just produced."""
    report = AcceptanceReport()
    paths = settings.paths

    gold_path = paths.out / "gold.parquet"
    risk_path = paths.out / "risk_score.parquet"
    labels_path = paths.seeds / "fraud_label.parquet"

    gold = read_gold(gold_path) if gold_path.is_file() else pd.DataFrame()
    scores = pd.read_parquet(risk_path) if risk_path.is_file() else pd.DataFrame()
    labels = pd.read_parquet(labels_path) if labels_path.is_file() else pd.DataFrame()

    # ---- Seam A conforms to its contract ----
    def gold_contract() -> tuple[bool, str]:
        from .contracts.gold import validate_frame

        problems = validate_frame(gold)
        return (
            not problems,
            f"{len(gold):,} works x {len(gold.columns)} columns match the contract"
            if not problems
            else "; ".join(problems),
        )

    _safe(report, "gold view matches the Seam A contract", gold_contract)

    # ---- the fixture stays a usable stand-in ----
    def fixture_schema() -> tuple[bool, str]:
        from .contracts.gold import GOLD_COLUMNS

        fixture = read_gold(paths.fixtures / "sample_gold.parquet")
        same_columns = list(fixture.columns) == list(gold.columns)
        mismatched = [
            c for c in GOLD_COLUMNS if fixture[c].dtype.kind != gold[c].dtype.kind
        ]
        return (
            same_columns and not mismatched,
            "fixture and real frame are schema-identical"
            if same_columns and not mismatched
            else f"columns match: {same_columns}; dtype mismatches: {mismatched}",
        )

    _safe(report, "fixture is schema-identical to the real frame", fixture_schema)

    # ---- ground truth never reached the feature space ----
    def leakage() -> tuple[bool, str]:
        from .contracts.labels import assert_no_label_leakage

        assert_no_label_leakage(list(gold.columns))
        return True, "no label column or pattern name appears in the Gold view"

    _safe(report, "no ground-truth leakage into features", leakage)

    # ---- fusion emits all four quantities, each in range ----
    def four_quantities() -> tuple[bool, str]:
        required = ["overall_risk", "confidence", "severity", "data_quality"]
        missing = [c for c in required if c not in scores.columns]
        if missing:
            return False, f"missing quantities: {missing}"
        out_of_range = {
            column: [float(scores[column].min()), float(scores[column].max())]
            for column in ("overall_risk", "confidence", "data_quality")
            if scores[column].min() < 0 or scores[column].max() > 1
        }
        return (
            not out_of_range,
            "risk, confidence, severity and data_quality all present and in [0, 1]"
            if not out_of_range
            else f"outside [0, 1]: {out_of_range}",
        )

    _safe(report, "fusion emits four separate quantities in [0, 1]", four_quantities)

    # ---- risk and confidence are genuinely different quantities ----
    def not_collinear() -> tuple[bool, str]:
        """Measured over works that carry evidence, and not over the silent ones.

        This originally correlated across the whole population, and Block 14
        showed why that is wrong. Making L0 more selective moved 67.8% of works
        to zero reasons, where risk and confidence are both exactly 0 -- a
        correct answer, and a point mass that dragged the Pearson correlation
        to +0.979 while the figure among flagged works *improved* from +0.891
        to +0.869.

        Worse than being wrong, the old form had a perverse incentive: the
        noisier the system, the more spread at the bottom, the better it
        scored. It punished this block for making the detector quieter.

        "Is a thin lead distinguishable from a corroborated case" is only a
        question where there is evidence at all, so both halves below are
        checked on the flagged population -- and the second half is new,
        because a low correlation means nothing if the system never actually
        produces both kinds.
        """
        import json

        n_reasons = scores["reasons"].map(lambda s: len(json.loads(str(s))))
        flagged = scores[n_reasons > 0]
        if len(flagged) < 100:
            return False, f"only {len(flagged)} works carry evidence -- too few to judge"

        correlation = float(flagged["overall_risk"].corr(flagged["confidence"]))
        leads = int(((flagged["overall_risk"] > 0.5) & (flagged["confidence"] < 0.5)).sum())
        cases = int(((flagged["overall_risk"] > 0.5) & (flagged["confidence"] >= 0.7)).sum())
        ok = abs(correlation) < 0.95 and leads > 0 and cases > 0
        return (
            ok,
            f"over {len(flagged):,} works carrying evidence: correlation {correlation:+.3f}, "
            f"{leads:,} leads (high risk, thin evidence) and {cases:,} cases "
            f"(high risk, corroborated) -- the distinction the contract exists for",
        )

    _safe(report, "risk and confidence are not the same number", not_collinear)

    # ---- missingness lowers data quality, and confidence follows ----
    def missingness_effect() -> tuple[bool, str]:
        joined = scores.set_index("work_id").join(
            gold.set_index("work_id")[["n_missing_fields"]], how="inner"
        )
        complete = joined[joined["n_missing_fields"] == joined["n_missing_fields"].min()]
        gappy = joined[joined["n_missing_fields"] > joined["n_missing_fields"].min()]
        if gappy.empty:
            return False, "no works with missing fields -- data quality is untested"
        dq_drops = float(gappy["data_quality"].mean()) < float(complete["data_quality"].mean())
        return (
            dq_drops,
            f"data_quality {complete['data_quality'].mean():.3f} (complete) vs "
            f"{gappy['data_quality'].mean():.3f} ({len(gappy):,} works with gaps)",
        )

    _safe(report, "missing fields lower data quality", missingness_effect)

    # ---- thin evidence is not actionable, unless it is a documentary fact ----
    def single_family_not_actionable() -> tuple[bool, str]:
        """One signal is a lead, not a case -- with one principled exception.

        A deterministic critical rule (a payment dated before its sanction) is
        a verifiable fact about the records, not a probabilistic signal, and it
        is actionable alone. Everything else needs corroboration across
        independent evidence families.
        """
        thin = scores[scores["n_corroborating_families"] <= 1]
        wrongly = thin[thin["is_actionable"] & thin["escalated_by_rule"].isna()]
        escalated = thin[thin["is_actionable"] & thin["escalated_by_rule"].notna()]
        return (
            wrongly.empty,
            f"{len(thin):,} single-family works; {len(escalated):,} actionable via a "
            f"deterministic critical rule, {len(wrongly):,} wrongly actionable"
            if wrongly.empty
            else f"{len(wrongly):,} single-family works actionable without a critical rule",
        )

    _safe(report, "one evidence family is a lead, not a case", single_family_not_actionable)

    # ---- the injected pattern the vertical slice targets ranks at the top ----
    def pre_sanction_ranks_high() -> tuple[bool, str]:
        targeted = set(
            labels.loc[labels["pattern"] == "pre_sanction_payment", "work_id"]
        )
        if not targeted:
            return False, "no pre_sanction_payment labels to check against"
        ranked = scores.sort_values(
            ["overall_risk", "confidence"], ascending=[False, False]
        )
        cutoff = max(1, int(len(ranked) * 0.10))
        top = set(ranked.head(cutoff)["work_id"])
        share = len(top & targeted) / len(targeted)
        return (
            share >= 0.90,
            f"{share:.1%} of {len(targeted)} injected works rank in the top 10% "
            f"(pipeline check -- rule-visible pattern, not a detection claim)",
        )

    _safe(report, "injected pre-sanction payments rank in the top 10%", pre_sanction_ranks_high)

    # ---- Seam D response validates against its model ----
    def api_contract() -> tuple[bool, str]:
        import json

        from .api.models import AlertStats, RiskOut

        risk = json.loads((paths.api / "work_risk.json").read_text(encoding="utf-8"))
        RiskOut.model_validate(risk)
        stats = json.loads((paths.api / "alerts_stats.json").read_text(encoding="utf-8"))
        AlertStats.model_validate(stats)
        return True, "work_risk.json and alerts_stats.json validate against the Seam D models"

    _safe(report, "API payloads validate against the Seam D contract", api_contract)

    # ---- every finding carries provenance ----
    def provenance_present() -> tuple[bool, str]:
        import json

        flagged = scores[scores["band"].isin(["high", "critical"])].head(500)
        total = unsourced = 0
        for payload in flagged["reasons"]:
            for reason in json.loads(str(payload)):
                total += 1
                if not reason.get("provenance"):
                    unsourced += 1
        return (
            unsourced == 0 and total > 0,
            f"{total:,} findings checked, {unsourced} without provenance",
        )

    _safe(report, "every finding carries provenance", provenance_present)

    # ---- the review queue stays a queue ----
    def queue_is_reviewable() -> tuple[bool, str]:
        """Band cut-points are a policy on a scale, and the scale can move.

        Block 13 changed how layer scores combine, which shifted the score
        distribution right and widened every band. That was legitimate -- the
        ranking improved at every matched review depth -- but nothing in the
        system would have *said so*. A combiner that puts a fifth of the corpus
        in `critical` has not found more fraud; it has destroyed the priority
        ordering the band exists to express.

        The ceilings are deliberately loose. This catches a scale change that
        floods the queue, not a few works crossing a line.
        """
        if scores.empty:
            return False, "no scored works"
        total = len(scores)
        critical = int((scores["band"] == "critical").sum())
        top_two = int(scores["band"].isin(["critical", "high"]).sum())
        actionable = int(scores["is_actionable"].sum())
        ok = (
            critical / total <= 0.05
            and top_two / total <= 0.20
            and actionable / total <= 0.25
        )
        return (
            ok,
            f"critical {critical / total:.1%} (<=5%), "
            f"critical+high {top_two / total:.1%} (<=20%), "
            f"actionable {actionable / total:.1%} (<=25%)",
        )

    _safe(report, "the review queue stays a reviewable size", queue_is_reviewable)

    return report
