"""How layer scores become one number.

Block 2 shipped a weighted mean to fix the *contract* and keep the pipeline
runnable. Three blocks then produced the same finding by different routes --
L1 helped only in a narrow band (Block 8), L4's marginal value was negative at
every weight (Block 10), and the single best layer beat the four-layer ensemble
(Block 11). This module is the answer, and it is built from the measurement
below rather than from taste.

What the diagnostic found, on 19,875 works with four layers running:

    layer         weight  fire%   mean|fire   share of fused mass   P@500 lift
    rules           0.30  51.60%      0.460                 89.1%         7.05
    unsupervised    0.20   2.62%      0.927                  6.1%         6.29
    duplicate       0.10   3.04%      0.692                  2.6%         1.05
    graph           0.10   3.01%      0.585                  2.2%        10.20

Two things are wrong, and they are separate.

**1. A weight is not an influence.** `rules` holds 43% of the nominal weight
and 89% of the actual score mass, because it fires on half the corpus while
the others fire on 3%. Its Spearman correlation with the fused score is 0.944:
the "ensemble" is the rules layer wearing a hat. Meanwhile `graph`, the most
informative layer per work surfaced (10.2x lift), carries 2.2% of the mass.
Raw layer scores are not on a common scale, so weighting them directly lets
fire rate masquerade as strength.

**2. A mean cannot reward agreement**, and agreement is the strongest signal
in the data:

    layers firing    works    held-out rate
        0            8,940            1.09%
        1            9,973            2.18%
        2              887           10.94%      <- 5.2x base
        3               70            7.14%
        4                5           20.00%

Two independent layers agreeing is worth five times the base rate. A weighted
mean cannot express that -- two moderate signals average to something *lower*
than one loud one -- so the arithmetic actively discards the best evidence in
the system. The layers are near-independent (max pairwise Spearman 0.102,
rules/graph -0.001), so there is no double-counting to fear here: agreement
between them is real corroboration, not an echo.

The fix is therefore two matching pieces:

    calibrate   replace each raw score with how *rare* it is -- the tail
                probability P(S_i >= s) over the whole population -- so a
                weight means the same thing for every layer
    noisy-OR    combine as independent evidence, so agreement compounds and no
                single layer can saturate the ranking

Rarity, specifically, and not rank among the layer's own hits. That was tried
first and moved held-out PR-AUC by -0.003: ranking within hits calls a median
`rules` hit "halfway up what rules flags", but rules flags half the corpus, so
halfway up that is unremarkable. Against the whole population the same hit sits
at q = 0.26 where a median `graph` hit sits at q = 0.015.

Noisy-OR is not an arbitrary pick. `contracts.risk` already models
corroboration as `1 - 0.5^n` over independent evidence families; this is the
same algebra applied to the score instead of the confidence, which makes the
two quantities coherent for the first time.

What it bought, on held-out patterns:

    combiner                PR-AUC   P@500   R@2000   mean pattern lift
    weighted_mean (Block 2) 0.0929   16.8%    28.3%              12.0x
    noisy_or                0.0977   16.4%    27.8%              13.4x
    calibrated_noisy_or     0.1391   17.0%    38.4%              19.7x

The uncalibrated middle row is the load-bearing comparison: noisy-OR *alone*
moves almost nothing. Agreement-awareness is not what fixes this -- putting the
layers on a common scale is, and the two only work together.

Better at every matched review depth, most where capacity is scarcest: at the
top 100 the calibrated ranking surfaces 45 held-out positives against 32.

**On honesty.** The diagnostic above reads held-out labels, so the *design* was
informed by them and any held-out figure for it is optimistically biased.
Nothing here is *fitted* to labels -- calibration uses score distributions
only, and the weights are unchanged from Block 1 -- but "I chose this shape
after looking" is still a form of selection. `evaluate.harness` reports a
leave-one-pattern-out estimate alongside, which is the number that survives
that objection. See ADR-0012.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Protocol

import numpy as np

__all__ = [
    "COMBINERS",
    "Combiner",
    "LayerCalibration",
    "calibrated_noisy_or",
    "fit_calibration",
    "noisy_or",
    "resolve",
    "weighted_mean",
]


class Combiner(Protocol):
    """Fuse one work's layer scores into a single risk in [0, 1]."""

    def __call__(
        self, scores: Mapping[str, float], weights: Mapping[str, float]
    ) -> float: ...


def _clip(value: float) -> float:
    return float(min(1.0, max(0.0, value)))


# ---------------------------------------------------------------------------
# the Block 2 baseline, kept so the comparison is against the real thing
# ---------------------------------------------------------------------------
def weighted_mean(
    scores: Mapping[str, float], weights: Mapping[str, float]
) -> float:
    """Weighted average over the layers that ran.

    The Block 2 arithmetic, preserved exactly. Silent layers are included in
    the denominator -- every layer emits a row per work -- so this is a mean
    over layers present, not over layers that fired.
    """
    present = [layer for layer in scores if layer in weights]
    if not present:
        return 0.0
    total = sum(weights[layer] for layer in present) or 1.0
    return _clip(sum(weights[layer] * scores[layer] for layer in present) / total)


# ---------------------------------------------------------------------------
# independent-evidence combination
# ---------------------------------------------------------------------------
def noisy_or(scores: Mapping[str, float], weights: Mapping[str, float]) -> float:
    """`1 - prod(1 - w_i * s_i)` over the layers that fired.

    Each layer is treated as an independent chance of the work being of
    concern. Agreement compounds: two layers at 0.6 with weight 0.3 give 0.30,
    where the mean gives 0.18. A single layer can never exceed its own weight,
    so no one detector can own the ranking.

    Uncalibrated -- it still trusts raw scores to be comparable. Present so the
    calibration step can be measured on its own.
    """
    survival = 1.0
    for layer, score in scores.items():
        weight = weights.get(layer)
        if weight is None or score <= 0:
            continue
        survival *= 1.0 - _clip(weight * score)
    return _clip(1.0 - survival)


# ---------------------------------------------------------------------------
# calibration: put every layer on the same scale, using no labels
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class LayerCalibration:
    """Per-layer map from a raw score to how *rare* that score is.

    The calibrated quantity is the upper tail probability

        q_i(s) = P(S_i >= s)

    over the **whole scored population**, silent works included. Fitted in one
    pass over the layer outputs, from score distributions only -- it reads no
    ground truth, so it cannot leak labels into the ranking.

    Tail probability rather than rank-among-hits, and the difference decides
    the block. Ranking a score among its own layer's hits says a median `rules`
    hit is "halfway up what rules flags" -- but rules flags 51.6% of the
    corpus, so being halfway up that is being unremarkable in the population.
    Measured against everything, the same hit sits at q = 0.26 while a median
    `graph` hit sits at q = 0.015. Rarity is the thing the layers can be
    compared on; their raw scores are not.

    Two properties fall out for free rather than being special-cased:

    * A silent layer has `q = P(S >= 0) = 1`, which contributes exactly nothing
      to a product. No zero-handling branch.
    * The weakest hit on a rare layer outranks the weakest hit on a common one
      -- firing at all on a 3%-fire-rate layer is itself the evidence.
    """

    # layer -> the layer's scores over the whole population, ascending
    population: dict[str, np.ndarray] = field(default_factory=dict)

    @property
    def layers(self) -> tuple[str, ...]:
        return tuple(sorted(self.population))

    def fire_rate(self, layer: str) -> float:
        values = self.population.get(layer)
        if values is None or len(values) == 0:
            return 0.0
        return float((values > 0).mean())

    def tail(self, layer: str, score: float) -> float:
        """`P(S >= score)` for this layer, in (0, 1].

        Floored at `1/n`: with n observations the rarest thing observable is
        one-in-n, and claiming more resolution than the sample supports is how
        a tail estimate turns into a fabrication.
        """
        if score <= 0:
            return 1.0
        values = self.population.get(layer)
        if values is None or len(values) == 0:
            return 1.0
        n = len(values)
        at_or_above = n - int(np.searchsorted(values, score, side="left"))
        return float(max(at_or_above, 1) / n)

    def __call__(self, layer: str, score: float) -> float:
        """Evidence strength in [0, 1): `1 - q`. Kept for readability."""
        return 1.0 - self.tail(layer, score)


def fit_calibration(
    rows: Sequence[Mapping[str, float]] | Mapping[str, Sequence[float]],
) -> LayerCalibration:
    """Learn each layer's population score distribution.

    Accepts either a sequence of per-work `{layer: score}` mappings or a
    `{layer: [scores]}` mapping, whichever the caller already has. Layers
    missing from a row count as silent, which is what the Seam B contract
    guarantees anyway: every layer emits a row per work.
    """
    collected: dict[str, list[float]] = {}
    if isinstance(rows, Mapping):
        for layer, values in rows.items():
            collected[layer] = [float(v) for v in values]
    else:
        seen: set[str] = set()
        for row in rows:
            seen.update(row)
        for row in rows:
            for layer in seen:
                collected.setdefault(layer, []).append(float(row.get(layer, 0.0)))
    return LayerCalibration(
        population={
            layer: np.sort(np.asarray(v, dtype=float)) for layer, v in collected.items()
        }
    )


def calibrated_noisy_or(
    scores: Mapping[str, float],
    weights: Mapping[str, float],
    calibration: LayerCalibration | None = None,
) -> float:
    """Combine layers as independent evidence about how unusual a work is.

        risk = 1 - prod_i q_i ** w_i

    where `q_i` is the tail probability of the work's score on layer i. This is
    the standard combination of independent tail probabilities -- equivalently
    `1 - exp(-sum_i w_i * surprisal_i)` -- and it is noisy-OR written in the
    coordinates where the layers are actually comparable.

    What it buys, all of it structural rather than tuned:

    * **Rarity, not magnitude.** A layer firing on 3% of works contributes more
      per hit than one firing on 52%, without anyone setting a weight to say so.
    * **Agreement compounds.** Two independent layers multiply their tails, so
      corroboration raises the score the way `contracts.risk` already models
      corroboration for confidence. The two quantities finally use the same
      algebra.
    * **No layer can own the ranking.** A single layer's contribution is capped
      by its own weight, where a weighted mean let one loud layer take 89% of
      the score mass.

    Without a calibration it degrades to plain `noisy_or` rather than failing,
    so a caller that has not fitted one still gets a sane number.
    """
    if calibration is None:
        return noisy_or(scores, weights)
    survival = 1.0
    for layer, score in scores.items():
        weight = weights.get(layer)
        if weight is None or weight <= 0 or score <= 0:
            continue
        survival *= calibration.tail(layer, score) ** weight
    return _clip(1.0 - survival)


COMBINERS: dict[str, Callable[..., float]] = {
    "weighted_mean": weighted_mean,
    "noisy_or": noisy_or,
    "calibrated_noisy_or": calibrated_noisy_or,
}


def resolve(name: str) -> Callable[..., float]:
    """Look up a combiner by configured name, with a legible failure."""
    try:
        return COMBINERS[name]
    except KeyError:
        raise ValueError(
            f"unknown combiner {name!r}; available: {', '.join(sorted(COMBINERS))}"
        ) from None
