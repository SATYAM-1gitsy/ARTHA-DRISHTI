"""Seam C producer: run the available layers and fuse them.

The integration keystone. It is written to work with **whatever layers
currently exist** — a layer absent from `config.fusion.weights` contributes
nothing, and a layer module that fails to import is skipped with a warning
rather than taking the pipeline down. That is what lets fusion go live on the
day L0 lands and silently improve as L1 through L6 arrive, with each new layer
costing one line of config rather than a change here.

The arithmetic lives in `score.combine` and is selected by
`FusionConfig.combiner`. Block 13 replaced the Block 2 weighted mean with
calibrated noisy-OR, which is why scoring is two-pass: the calibration is
fitted across the whole population before any single work can be assessed. It
reads score distributions only, never labels.

What has not changed, and will not, is the *shape*: four separate quantities,
corroboration counted over independent evidence families rather than over
layers, and deterministic escalation kept apart from the model score.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from functools import partial
from importlib import import_module
from typing import Any

import pandas as pd

from ..config import settings
from ..contracts.layer import LAYER_NAMES, LayerOutput
from ..contracts.risk import RiskAssessment, assess
from ..util import dumps
from .combine import (
    LayerCalibration,
    calibrated_noisy_or,
    fit_calibration,
    resolve,
)

__all__ = ["LAYER_MODULES", "ScoreResult", "load_layers", "score_population", "to_frame"]

log = logging.getLogger(__name__)

# Layer name -> module path. A layer listed here but not yet written is
# skipped; nothing needs editing when one lands.
LAYER_MODULES: dict[str, str] = {
    "rules": "drishti.detect.rules",
    "unsupervised": "drishti.detect.unsupervised",
    "supervised": "drishti.detect.supervised",
    "graph": "drishti.detect.graph",
    "duplicate": "drishti.detect.duplicates",
    "forecast": "drishti.detect.forecast",
    "vision": "drishti.detect.vision",
}


@dataclass
class ScoreResult:
    """Assessments plus what actually ran."""

    assessments: list[RiskAssessment]
    layers_run: list[str]
    layers_absent: list[str]
    timings: dict[str, float] = field(default_factory=dict)
    combiner: str = "weighted_mean"
    calibration: LayerCalibration | None = None

    @property
    def n_scored(self) -> int:
        return len(self.assessments)

    def band_counts(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for assessment in self.assessments:
            counts[assessment.band.value] = counts.get(assessment.band.value, 0) + 1
        return counts

    def describe(self) -> str:
        bands = self.band_counts()
        actionable = sum(1 for a in self.assessments if a.is_actionable)
        lines = [
            f"scored {self.n_scored:,} works",
            f"  layers run       {', '.join(self.layers_run) or 'none'}",
            f"  layers absent    {', '.join(self.layers_absent) or 'none'}",
            f"  combiner         {self.combiner}",
            "",
            "  band          count     share",
        ]
        for band in ("critical", "high", "medium", "low"):
            count = bands.get(band, 0)
            lines.append(f"  {band:<12} {count:>7,}  {count / max(self.n_scored, 1):>7.2%}")
        lines.append("")
        lines.append(
            f"  actionable    {actionable:>7,}  (band >= high AND confidence >= 0.6)"
        )
        if self.timings:
            lines.append("")
            for layer, seconds in self.timings.items():
                lines.append(f"  {layer:<14} {seconds:>7.2f}s")
        return "\n".join(lines)


def load_layers() -> tuple[dict[str, Callable], list[str]]:
    """Import the layer modules that exist.

    A missing module is an expected state, not an error: L1 through L6 arrive
    over several blocks and fusion must run throughout.
    """
    available: dict[str, Callable] = {}
    absent: list[str] = []

    for name in LAYER_NAMES:
        path = LAYER_MODULES.get(name)
        if path is None:
            absent.append(name)
            continue
        try:
            module = import_module(path)
        except ImportError:
            absent.append(name)
            continue
        runner = getattr(module, "run", None)
        if runner is None:
            log.warning("%s has no run() -- skipping", path)
            absent.append(name)
            continue
        available[name] = runner
    return available, absent


def score_population(
    features: pd.DataFrame,
    layers: dict[str, Callable] | None = None,
    ctx: Any = None,
) -> ScoreResult:
    """Run every available layer over the Gold view and fuse the outputs."""
    if features.empty:
        return ScoreResult(assessments=[], layers_run=[], layers_absent=list(LAYER_NAMES))

    runners, absent = (layers, []) if layers is not None else load_layers()
    if layers is not None:
        absent = [name for name in LAYER_NAMES if name not in runners]

    by_work: dict[int, list[LayerOutput]] = {
        int(work_id): [] for work_id in features["work_id"]
    }
    timings: dict[str, float] = {}
    ran: list[str] = []

    for name, runner in runners.items():
        started = time.perf_counter()
        try:
            outputs: Sequence[LayerOutput] = runner(features, ctx)
        except Exception as exc:  # noqa: BLE001 - one bad layer must not lose the run
            log.error("layer %s failed (%s) -- continuing without it", name, exc)
            absent.append(name)
            continue
        timings[name] = time.perf_counter() - started
        ran.append(name)
        for output in outputs:
            bucket = by_work.get(output.work_id)
            if bucket is not None:
                bucket.append(output)

    fusion = settings.fusion
    started = time.perf_counter()

    # Calibration is fitted across the whole population before any work is
    # assessed, which is why fusion is two-pass. It reads score distributions
    # only -- no labels -- so it cannot leak ground truth into the ranking.
    combiner = resolve(fusion.combiner)
    calibration: LayerCalibration | None = None
    if fusion.combiner == "calibrated_noisy_or":
        calibration = fit_calibration(
            [{o.layer: o.score for o in outputs} for outputs in by_work.values()]
        )
        combine = partial(calibrated_noisy_or, calibration=calibration)
    else:
        combine = combiner

    assessments = [
        assess(
            work_id=work_id,
            outputs=outputs,
            weights=fusion.weights,
            bands=fusion.bands,
            critical_rules=fusion.critical_rules,
            min_data_quality_for_critical=fusion.min_data_quality_for_critical,
            combine=combine,
        )
        for work_id, outputs in by_work.items()
    ]
    timings["fusion"] = time.perf_counter() - started

    return ScoreResult(
        assessments=assessments,
        layers_run=ran,
        layers_absent=sorted(set(absent)),
        timings=timings,
        combiner=fusion.combiner,
        calibration=calibration,
    )


def to_frame(assessments: Sequence[RiskAssessment]) -> pd.DataFrame:
    """Flatten assessments for persistence.

    `reasons` and `layer_scores` are stored as JSON text rather than nested
    columns: parquet handles them, and the API round-trips them straight into
    the evidence card without a schema migration every time a layer lands.
    """
    rows = []
    for assessment in assessments:
        rows.append(
            {
                "work_id": assessment.work_id,
                "overall_risk": assessment.overall_risk,
                "confidence": assessment.confidence,
                "severity": assessment.severity.value,
                "data_quality": assessment.data_quality,
                "band": assessment.band.value,
                "n_corroborating_families": assessment.n_corroborating_families,
                "corroborating_families": ",".join(assessment.corroborating_families),
                "escalated_by_rule": assessment.escalated_by_rule,
                "is_actionable": assessment.is_actionable,
                "narrative": assessment.narrative,
                "layer_scores": dumps(assessment.layer_scores),
                "reasons": dumps([r.to_dict() for r in assessment.reasons]),
            }
        )
    return pd.DataFrame(rows)
