"""Whether this machine can actually read and write the project's storage format.

Every stage between `seed` and `eval` persists to parquet, so a missing or
broken parquet engine does not degrade the pipeline -- it stops it. That makes
it exactly the kind of thing `drishti doctor` exists to catch, and it was not
being caught: `doctor` imported numpy and pandas, reported a usable
environment, and the next command failed on the first `read_parquet`.

**Importing the engine is not the check.** On the reference Windows machine
`import pyarrow` succeeds and `import pyarrow.parquet` raises, because
Windows Application Control blocks that one extension module:

    The pyarrow installation is not built with support for the Parquet file
    format (DLL load failed while importing _parquet: An Application Control
    policy has blocked this file.)

pandas then falls through to fastparquet and raises `ImportError` if that is
absent too. Nothing about the failure names the real cause, and it surfaces
156 test failures away from it. So the probe below does a real round trip
through pandas -- the same call path the pipeline uses -- rather than trusting
an import.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover - typing only
    import pandas as pd

__all__ = [
    "ParquetSupport",
    "check_parquet",
    "prepare_for_parquet",
    "restore_dtypes",
    "read_gold",
]

# Engines pandas will try, in its own order of preference.
ENGINES: tuple[str, ...] = ("pyarrow", "fastparquet")

INSTALL_HINT = (
    "install a parquet engine: `pip install pyarrow` (or `pip install fastparquet`, "
    "which is the fallback when a security policy blocks pyarrow's _parquet module)"
)


@dataclass(frozen=True)
class ParquetSupport:
    """The outcome of a real read/write round trip."""

    usable: bool
    engines: tuple[str, ...] = ()
    problems: tuple[str, ...] = ()

    def summary(self) -> str:
        if self.usable:
            return f"{', '.join(self.engines)} (round trip verified)"
        return "no working engine -- " + INSTALL_HINT


def check_parquet() -> ParquetSupport:
    """Round-trip a one-row frame through parquet and report what worked.

    Deliberately exercises `to_parquet`/`read_parquet` rather than importing
    an engine: an engine that imports and then fails to load its extension
    module is the failure this function exists to name.
    """
    import io

    import pandas as pd

    frame = pd.DataFrame({"work_id": [1], "value": [1.5]})
    working: list[str] = []
    problems: list[str] = []

    for engine in ENGINES:
        buffer = io.BytesIO()
        try:
            frame.to_parquet(buffer, engine=engine, index=False)
            buffer.seek(0)
            pd.read_parquet(buffer, engine=engine)
        except Exception as exc:  # noqa: BLE001 - any failure means unusable
            problems.append(f"{engine}: {type(exc).__name__}: {exc}")
            continue
        working.append(engine)

    return ParquetSupport(
        usable=bool(working), engines=tuple(working), problems=tuple(problems)
    )


def restore_dtypes(frame: pd.DataFrame, dtypes: dict[str, str]) -> pd.DataFrame:  # noqa: F821
    """Put declared dtypes back after a parquet round trip.

    A nullable integer does not survive every write/read engine pairing. A
    column declared `int8` and nullable is held as pandas `Int8`; write it with
    fastparquet, read it back with pyarrow, and the nulls return as `float64`.
    The values are intact and the dtype is not, which is enough to fail a
    schema-identity check and enough to change how a downstream comparison
    behaves.

    Both engines are self-consistent. The mismatch appears only when the engine
    that wrote a file is not the engine that reads it -- exactly what happens
    when one machine's pyarrow is unavailable and another's is not, which is
    the situation this project has now been in twice in one session. Rather
    than pin an engine and hope, the declared dtype is restored from the
    contract, so the Gold view presents one schema wherever it is read.

    Only columns present in both the frame and the mapping are touched, and a
    column that will not coerce is left alone: a dtype repair must never be the
    thing that loses data.
    """
    restored = frame
    for column, dtype in dtypes.items():
        if column not in restored.columns:
            continue
        target = dtype
        # A nullable integer needs pandas' capitalised extension dtype; the
        # plain numpy one cannot hold NA.
        if dtype.startswith("int") and restored[column].isna().any():
            target = dtype.capitalize()
        if str(restored[column].dtype) == target:
            continue
        try:
            converted = restored[column].astype(target)
        except (TypeError, ValueError):
            continue
        if restored is frame:
            restored = frame.copy()
        restored[column] = converted
    return restored


def prepare_for_parquet(frame: pd.DataFrame) -> pd.DataFrame:  # noqa: F821
    """Coerce the two column shapes parquet cannot infer a type for.

    Both were previously handled inline at each write site, against pyarrow's
    behaviour alone, which made them engine-specific by accident:

    **All-null object columns.** Parquet needs a declared type and an empty
    object column has none. `term_end` is legitimately empty until a
    by-election date exists.

    **Object columns of `datetime.date`.** `term_start` is a `date`, which
    pandas keeps in an object column of boxed Python values. pyarrow guesses
    `date32` from the first element; fastparquet refuses outright with
    "Can't infer object conversion type", so the whole ingest stage died on a
    machine where pyarrow's parquet module was unavailable.

    The guess was not reliable either. Round-tripping the pyarrow-written
    `silver_mp.parquet` returned `term_start` as **1717459200000000000** -- raw
    nanoseconds in an object column, not a date -- so the value did not survive
    persistence under either engine. Converting to `datetime64` before writing
    makes the round trip type-stable and engine-independent.

    The in-memory frame is left alone: `date` is the right domain type for a
    term start, `ReferenceTables` is a frozen seam, and a test pins it. This
    is a persistence concern and it stays at the persistence boundary.
    """
    import datetime as _dt

    import pandas as pd

    prepared = frame.copy()
    for column in prepared.columns:
        if prepared[column].dtype != object:
            continue
        if prepared[column].isna().all():
            prepared[column] = prepared[column].astype("string")
            continue
        sample = prepared[column].dropna().iloc[0]
        if isinstance(sample, (_dt.date, _dt.datetime)):
            # Pinned to nanoseconds on purpose. pandas 3 infers `datetime64[s]`
            # from a column of `date`, and a second-resolution column does not
            # survive the round trip: fastparquet writes it as milliseconds and
            # then refuses to read it back -- "Cannot losslessly cast
            # '1717459 ms' to s" -- so the file written by `ingest` could not be
            # opened by `seed`. Nanoseconds is the unit every engine agrees on.
            prepared[column] = pd.to_datetime(
                prepared[column], errors="coerce"
            ).astype("datetime64[ns]")
    return prepared


def read_gold(path) -> pd.DataFrame:  # noqa: F821
    """Read a Gold-view parquet file with its Seam A dtypes intact.

    The single read boundary for the Gold view, mirroring
    `prepare_for_parquet` on the write side. Importing the contract lazily
    keeps `storage` free of a package-level cycle -- `contracts.gold` has no
    reason to know about persistence.
    """
    import pandas as pd

    from .contracts.gold import GOLD_FEATURES

    return restore_dtypes(
        pd.read_parquet(path), {spec.name: spec.dtype for spec in GOLD_FEATURES}
    )
