"""The Celery application.

Long stages -- generation, feature building, scoring, training -- run here
rather than inside an HTTP request. The worker also owns the GPU: the API
container has no accelerator, by design, so anything needing CUDA is enqueued
onto the gpu queue and executed by ml-worker.

Celery is an optional dependency. Importing this module without it gives a
clear error rather than an AttributeError halfway through a task definition,
and the API degrades to reporting jobs as unavailable instead of crashing.
"""

from __future__ import annotations

from typing import Any

from ..config import settings

__all__ = ["app", "celery_available", "CELERY_IMPORT_ERROR"]

try:
    from celery import Celery

    CELERY_IMPORT_ERROR: str | None = None
except ImportError as exc:  # pragma: no cover - depends on optional install
    Celery = None  # type: ignore[assignment,misc]
    CELERY_IMPORT_ERROR = str(exc)


def celery_available() -> bool:
    """Whether the broker client library is installed.

    Says nothing about whether Redis is actually reachable -- that is only
    knowable by trying, which is why the API reports enqueue failures rather
    than pre-flighting them.
    """
    return Celery is not None


def _build() -> Any:
    if Celery is None:  # pragma: no cover - depends on optional install
        return None

    instance = Celery(
        "drishti",
        broker=settings.redis_url,
        backend=settings.redis_url,
        include=["drishti.tasks.jobs"],
    )
    config = settings.celery
    instance.conf.update(
        task_serializer="json",
        result_serializer="json",
        accept_content=["json"],
        timezone="Asia/Kolkata",
        enable_utc=True,
        task_track_started=True,
        task_time_limit=config.task_time_limit,
        task_soft_time_limit=config.task_soft_time_limit,
        result_expires=config.result_expires,
        worker_concurrency=config.worker_concurrency,
        # Long ML jobs vary hugely in duration. Prefetching would let one
        # worker sit on a queued job while another idles.
        worker_prefetch_multiplier=1,
        task_acks_late=True,
        task_default_queue=config.default_queue,
        task_routes={
            "drishti.gpu_probe": {"queue": config.gpu_queue},
            "drishti.gpu_benchmark": {"queue": config.gpu_queue},
            "drishti.encode_corpus": {"queue": config.gpu_queue},
            "drishti.evaluate_l4": {"queue": config.gpu_queue},
            "drishti.train_*": {"queue": config.gpu_queue},
        },
    )
    return instance


app = _build()
