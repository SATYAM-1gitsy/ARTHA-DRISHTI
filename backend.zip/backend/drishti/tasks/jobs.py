"""Task definitions.

The GPU probe and benchmark answer a question that cannot be answered from
the host: whether the accelerator is reachable from the process that will do
the training. The API container has no GPU, so asking it proves nothing.

encode_corpus is the project's actual GPU workload -- multilingual transformer
inference over a production-scale description corpus. evaluate_l4 measures
whether that transformer earns its place against the lexical baseline, on a
hand-labelled corpus that is independent of the synthetic generator.

Pipeline stages land here from Block 4 onward and follow the same shape:
pure functions in their own module, thin task wrappers here.
"""

from __future__ import annotations

import platform
import time
from typing import Any

from ..config import settings
from ..gpu import detect as detect_gpu
from ..util import to_jsonable
from .app import app

__all__ = [
    "ping",
    "gpu_probe",
    "gpu_benchmark",
    "encode_corpus",
    "evaluate_l4",
    "TASK_NAMES",
]

# Names the API is allowed to enqueue. An allowlist rather than free-form task
# names, so an HTTP caller can never dispatch an arbitrary task.
TASK_NAMES: dict[str, str] = {
    "ping": "drishti.ping",
    "gpu_probe": "drishti.gpu_probe",
    "gpu_benchmark": "drishti.gpu_benchmark",
    "encode_corpus": "drishti.encode_corpus",
    "evaluate_l4": "drishti.evaluate_l4",
}


def _task(name: str, **kwargs: Any):
    """Register a Celery task, or leave the function plain if Celery is absent.

    Keeps this module importable -- and unit-testable -- on a machine with no
    broker installed.
    """

    def decorator(func):
        if app is None:  # pragma: no cover - depends on optional install
            return func
        return app.task(name=name, bind=False, **kwargs)(func)

    return decorator


@_task("drishti.ping")
def ping() -> dict[str, Any]:
    """Broker round-trip check. Proves the queue works end to end."""
    return {
        "pong": True,
        "worker_host": platform.node(),
        "python": platform.python_version(),
    }


@_task("drishti.gpu_probe")
def gpu_probe() -> dict[str, Any]:
    """Report the accelerator as seen from inside the worker process.

    The API image ships no torch and requests no device, so its /health
    endpoint always reports a CPU fallback. This is the only place that
    answers whether CUDA is genuinely available where training will happen.
    """
    report = detect_gpu()
    return to_jsonable(
        {
            "worker_host": platform.node(),
            "summary": report.summary(),
            "usable": report.usable,
            **report.to_dict(),
        }
    )


@_task("drishti.gpu_benchmark")
def gpu_benchmark(size: int = 4096, iterations: int = 20) -> dict[str, Any]:
    """Time a matrix multiply on the GPU and on the CPU.

    A concrete measurement rather than an assumption. The audit's claim -- that
    this project's bottleneck is dataset size, not the accelerator -- deserves
    a number attached to it before deep models are chosen over classical ones.

    Returns speedup=None when CUDA is unusable rather than raising, so calling
    it on a CPU-only box still yields a useful CPU baseline.
    """
    try:
        import torch
    except ImportError:
        return {"error": "torch is not installed in this worker"}

    if size < 2 or iterations < 1:
        raise ValueError("size must be >= 2 and iterations >= 1")

    report = detect_gpu()
    result: dict[str, Any] = {
        "size": size,
        "iterations": iterations,
        "device": report.device_name,
        "dtype": "float32",
    }

    def _time_matmul(device: str) -> float:
        a = torch.randn(size, size, device=device)
        b = torch.randn(size, size, device=device)
        if device == "cuda":
            torch.cuda.synchronize()
        start = time.perf_counter()
        for _ in range(iterations):
            a @ b
        if device == "cuda":
            torch.cuda.synchronize()
        return time.perf_counter() - start

    # Warm up before timing: the first CUDA call pays kernel-compilation and
    # context-creation costs that would otherwise dominate a short benchmark.
    if report.usable:
        _time_matmul("cuda")
        cuda_seconds = _time_matmul("cuda")
        result["cuda_seconds"] = round(cuda_seconds, 4)
        flops = 2 * (size**3) * iterations
        result["cuda_tflops"] = round(flops / cuda_seconds / 1e12, 2)
        result["peak_memory_mb"] = round(torch.cuda.max_memory_allocated() / 1024**2, 1)
    else:
        result["cuda_seconds"] = None
        result["note"] = "CUDA unusable in this worker: " + "; ".join(report.problems)

    cpu_seconds = _time_matmul("cpu")
    result["cpu_seconds"] = round(cpu_seconds, 4)
    result["speedup"] = (
        round(cpu_seconds / result["cuda_seconds"], 1)
        if result.get("cuda_seconds")
        else None
    )
    result["vram_headroom_mb"] = settings.gpu.vram_headroom_mb
    return to_jsonable(result)


@_task("drishti.encode_corpus")
def encode_corpus(
    n: int = 50_000, precision: str = "fp16", require_gpu: bool = True
) -> dict[str, Any]:
    """Encode a production-scale description corpus and record the cost.

    This is the project's real GPU workload. Every run is tracked, so the
    throughput claim behind keeping a transformer in the stack stays
    reproducible rather than becoming folklore.
    """
    from ..encoders import EncoderConfig, get_encoder
    from ..encoders.corpus import build_corpus
    from ..tracking import run as tracked_run

    texts = build_corpus(n=n, seed=settings.seed)
    config = EncoderConfig(precision=precision, require_gpu=require_gpu)
    # Resident model: reloading it per job wasted ~28s of GPU idle time.
    encoder = get_encoder(config)

    with tracked_run(
        "encode_corpus",
        n_texts=n,
        model=config.model_name,
        precision=precision,
        max_seq_length=config.max_seq_length,
    ) as context:
        result = encoder.encode(texts)
        context.log_metrics(
            texts_per_second=result.texts_per_second,
            seconds=result.seconds,
            peak_memory_mb=result.peak_memory_mb or 0.0,
            batch_size=result.batch_size,
            dimension=result.dimension,
        )
        context.set_tags(device=result.device, model_version=result.model_version)

    return to_jsonable(
        {
            "summary": result.summary(),
            "n_texts": result.n_texts,
            "device": result.device,
            "texts_per_second": round(result.texts_per_second, 1),
            "seconds": round(result.seconds, 2),
            "batch_size": result.batch_size,
            "peak_memory_mb": result.peak_memory_mb,
            "dimension": result.dimension,
            "model_version": result.model_version,
            "tracked": context.tracked,
        }
    )


@_task("drishti.evaluate_l4")
def evaluate_l4() -> dict[str, Any]:
    """Measure semantic duplicate detection against the lexical baseline.

    Runs on the committed labelled corpus, which is independent of the
    synthetic generator -- so unlike every metric that will come out of
    Block 15, this number is not circular.
    """
    from ..encoders import EncoderConfig, get_encoder
    from ..encoders.evaluate import evaluate_similarity, lexical_baseline, load_corpus
    from ..tracking import run as tracked_run

    items = load_corpus()
    texts = [item["text"] for item in items]
    encoder = get_encoder(EncoderConfig(require_gpu=True))

    with tracked_run("evaluate_l4", n_texts=len(items)) as context:
        encoded = encoder.encode(texts)
        semantic = evaluate_similarity(
            items, encoder.similarity(encoded.embeddings), "semantic"
        )
        lexical = lexical_baseline(items)
        context.log_metrics(
            semantic_f1=semantic.f1,
            semantic_roc_auc=semantic.roc_auc,
            semantic_cross_language_recall=semantic.cross_language_recall,
            semantic_hard_negative_rate=semantic.hard_negative_rate,
            lexical_f1=lexical.f1,
            lexical_roc_auc=lexical.roc_auc,
            lexical_cross_language_recall=lexical.cross_language_recall,
            roc_auc_gain=semantic.roc_auc - lexical.roc_auc,
        )

    return to_jsonable(
        {
            "semantic": semantic.summary(),
            "lexical": lexical.summary(),
            "roc_auc_gain": round(semantic.roc_auc - lexical.roc_auc, 3),
            "verdict": (
                "semantic encoder justified"
                if semantic.roc_auc - lexical.roc_auc > 0.10
                else "lexical baseline is sufficient"
            ),
            "tracked": context.tracked,
        }
    )
