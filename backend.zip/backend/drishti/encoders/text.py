"""GPU-resident multilingual text encoding.

This is the workload the accelerator exists for. Per ADR-0002, semantic
duplicate detection is the strongest deep-learning case in the project:
MPLADS descriptions mix English, Hindi and regional languages, two records of
the same physical work are routinely written differently, and lexical
similarity scores cross-language pairs at roughly 0.04 -- so no amount of
string matching can find them. A multilingual bi-encoder can.

**No silent CPU fallback.** `require_gpu` defaults to True and raises when CUDA
is unusable, because the failure this guards against is not a crash: it is a
run that quietly takes forty times longer and looks like it worked. A teammate
without a GPU sets require_gpu=False deliberately and sees it in the logs.

Encoding a corpus is embarrassingly parallel, so throughput is a batch-size
and precision question. `autotune_batch_size` finds the largest batch that
fits the card's free VRAM minus the configured headroom, rather than hardcoding
a number that is wrong on every other machine.
"""

from __future__ import annotations

import hashlib
import logging
import time
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..config import settings
from ..gpu import GPUReport
from ..gpu import detect as detect_gpu

__all__ = [
    "EncoderConfig",
    "EncodeResult",
    "TextEncoder",
    "get_encoder",
    "release_encoders",
    "SENTENCE_TRANSFORMERS_ERROR",
]

log = logging.getLogger(__name__)

try:
    from sentence_transformers import SentenceTransformer

    SENTENCE_TRANSFORMERS_ERROR: str | None = None
except ImportError as exc:  # pragma: no cover - depends on optional install
    SentenceTransformer = None  # type: ignore[assignment,misc]
    SENTENCE_TRANSFORMERS_ERROR = str(exc)


@dataclass(frozen=True)
class EncoderConfig:
    """How to encode.

    The default model is 118M parameters and about 470 MB on disk -- small
    enough to leave the 8 GB card almost entirely free for batching, which is
    where the throughput actually comes from.
    """

    model_name: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
    batch_size: int = 128
    max_seq_length: int = 128
    precision: str = "fp16"  # fp16 | bf16 | fp32
    normalize: bool = True  # unit vectors, so a dot product is a cosine
    require_gpu: bool = True
    autotune: bool = True

    def __post_init__(self) -> None:
        if self.precision not in ("fp16", "bf16", "fp32"):
            raise ValueError(f"unsupported precision {self.precision!r}")
        if self.batch_size < 1:
            raise ValueError("batch_size must be positive")
        if self.max_seq_length < 8:
            raise ValueError("max_seq_length must be at least 8")

    @property
    def version(self) -> str:
        """Identity of everything that changes the output vectors.

        Embeddings are cached and persisted; a cache keyed only on text would
        silently serve vectors from a different model after a config change.
        """
        payload = f"{self.model_name}|{self.max_seq_length}|{self.precision}|{self.normalize}"
        return hashlib.sha256(payload.encode()).hexdigest()[:12]


@dataclass
class EncodeResult:
    """Vectors plus the measurements needed to justify the hardware."""

    embeddings: np.ndarray
    n_texts: int
    seconds: float
    device: str
    batch_size: int
    precision: str
    model_version: str
    peak_memory_mb: float | None = None
    metrics: dict[str, Any] = field(default_factory=dict)

    @property
    def texts_per_second(self) -> float:
        return self.n_texts / self.seconds if self.seconds > 0 else 0.0

    @property
    def dimension(self) -> int:
        return int(self.embeddings.shape[1]) if self.embeddings.ndim == 2 else 0

    def summary(self) -> str:
        peak = f" | peak {self.peak_memory_mb:.0f} MB" if self.peak_memory_mb else ""
        return (
            f"{self.n_texts} texts -> {self.dimension}d in {self.seconds:.2f}s "
            f"({self.texts_per_second:.0f}/s) on {self.device} "
            f"@ batch {self.batch_size} {self.precision}{peak}"
        )


class TextEncoder:
    """A multilingual sentence encoder pinned to the GPU.

    Loading is lazy so constructing the object is cheap and testable; the
    model is materialised on first use and then reused, because reloading a
    transformer per call would dominate every measurement.
    """

    def __init__(self, config: EncoderConfig | None = None) -> None:
        self.config = config or EncoderConfig()
        self._model: Any = None
        self._device: str | None = None
        self._report: GPUReport | None = None

    # ------------------------------------------------------------------
    # device
    # ------------------------------------------------------------------
    def resolve_device(self) -> str:
        """Pick the device, refusing to silently degrade to CPU."""
        report = self._report or detect_gpu()
        self._report = report

        if report.usable:
            return "cuda"
        if self.config.require_gpu:
            raise RuntimeError(
                "TextEncoder requires a GPU and CUDA is unusable.\n  "
                + "\n  ".join(report.problems or ["unknown reason"])
                + "\n  Encoding on CPU is roughly an order of magnitude slower. "
                "Set require_gpu=False to accept that deliberately."
            )
        log.warning(
            "CUDA unusable, encoding on CPU by explicit configuration: %s",
            "; ".join(report.problems) or "unknown",
        )
        return "cpu"

    @property
    def device(self) -> str:
        if self._device is None:
            self._device = self.resolve_device()
        return self._device

    def _torch_dtype(self) -> Any:
        import torch

        report = self._report or detect_gpu()
        if self.device != "cuda" or self.config.precision == "fp32":
            return torch.float32
        if self.config.precision == "bf16":
            return torch.bfloat16 if report.bf16_supported else torch.float16
        return torch.float16 if report.fp16_supported else torch.float32

    # ------------------------------------------------------------------
    # model
    # ------------------------------------------------------------------
    def load(self) -> Any:
        """Materialise the model on the resolved device."""
        if self._model is not None:
            return self._model
        if SentenceTransformer is None:
            raise RuntimeError(
                "sentence-transformers is not installed. It ships in the "
                "ml-worker image only: pip install -r backend/requirements-ml.txt"
            )

        started = time.perf_counter()
        model = SentenceTransformer(self.config.model_name, device=self.device)
        model.max_seq_length = self.config.max_seq_length

        if self.device == "cuda":
            dtype = self._torch_dtype()
            import torch

            if dtype is not torch.float32:
                model = model.half() if dtype is torch.float16 else model.to(dtype)

        log.info(
            "loaded %s on %s in %.1fs",
            self.config.model_name,
            self.device,
            time.perf_counter() - started,
        )
        self._model = model
        return model

    @property
    def dimension(self) -> int:
        return int(self.load().get_sentence_embedding_dimension())

    # ------------------------------------------------------------------
    # batching
    # ------------------------------------------------------------------
    def autotune_batch_size(self, probe_text: str = "sample work description") -> int:
        """Find the largest batch that fits in free VRAM minus headroom.

        Doubling from the configured size and measuring actual allocation is
        more reliable than estimating from parameter counts, because
        activation memory dominates and scales with sequence length. Headroom
        is left unallocated so a resident copilot model and an encoding run
        can share one card.
        """
        if self.device != "cuda":
            return self.config.batch_size

        import torch

        model = self.load()
        headroom = settings.gpu.vram_headroom_mb * 1024 * 1024
        free, _total = torch.cuda.mem_get_info()
        budget = max(0, free - headroom)

        best = self.config.batch_size
        candidate = self.config.batch_size
        while candidate <= 4096:
            torch.cuda.reset_peak_memory_stats()
            try:
                model.encode(
                    [probe_text] * candidate,
                    batch_size=candidate,
                    show_progress_bar=False,
                    convert_to_numpy=True,
                )
            except RuntimeError as exc:  # out of memory
                if "out of memory" not in str(exc).lower():
                    raise
                torch.cuda.empty_cache()
                break
            if torch.cuda.max_memory_allocated() > budget:
                break
            best = candidate
            candidate *= 2

        torch.cuda.empty_cache()
        log.info("autotuned batch size to %d (free %d MB)", best, free // 1024**2)
        return best

    # ------------------------------------------------------------------
    # encoding
    # ------------------------------------------------------------------
    def encode(self, texts: Sequence[str], batch_size: int | None = None) -> EncodeResult:
        """Encode a corpus, returning vectors and throughput measurements."""
        if not texts:
            raise ValueError("encode() needs at least one text")

        model = self.load()
        size = batch_size or (
            self.autotune_batch_size() if self.config.autotune else self.config.batch_size
        )

        peak_mb: float | None = None
        if self.device == "cuda":
            import torch

            torch.cuda.reset_peak_memory_stats()
            torch.cuda.synchronize()

        started = time.perf_counter()
        embeddings = model.encode(
            list(texts),
            batch_size=size,
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=self.config.normalize,
        )
        if self.device == "cuda":
            import torch

            torch.cuda.synchronize()
            peak_mb = torch.cuda.max_memory_allocated() / 1024**2
        elapsed = time.perf_counter() - started

        # float32 downstream regardless of compute precision: fp16 vectors
        # accumulate visible error in cosine similarity over a large corpus.
        embeddings = np.asarray(embeddings, dtype=np.float32)

        return EncodeResult(
            embeddings=embeddings,
            n_texts=len(texts),
            seconds=elapsed,
            device=self.device,
            batch_size=size,
            precision=self.config.precision if self.device == "cuda" else "fp32",
            model_version=self.config.version,
            peak_memory_mb=peak_mb,
        )

    def similarity(self, embeddings: np.ndarray) -> np.ndarray:
        """Pairwise cosine over encoded rows.

        O(n^2). Fine for validation and for a blocked candidate set; a full
        corpus needs an ANN index instead.
        """
        matrix = np.asarray(embeddings, dtype=np.float32)
        if matrix.ndim != 2:
            raise ValueError(f"expected a 2-D matrix, got shape {matrix.shape}")
        if not self.config.normalize:
            norms = np.linalg.norm(matrix, axis=1, keepdims=True)
            matrix = matrix / np.maximum(norms, 1e-12)
        return np.clip(matrix @ matrix.T, -1.0, 1.0)


# --------------------------------------------------------------------------
# process-wide encoder cache
# --------------------------------------------------------------------------
_ENCODERS: dict[str, TextEncoder] = {}


def get_encoder(config: EncoderConfig | None = None) -> TextEncoder:
    """Return a process-wide encoder, loading the model at most once.

    Measured on the reference machine, constructing a fresh encoder per job
    costs **27.8 seconds** of model loading against 30.3 seconds of actual
    encoding -- so nearly half of every job's wall clock was spent with the
    GPU sitting idle at 0% while weights came off disk.

    A Celery worker is a long-lived process, so the model should be resident
    between tasks. Keyed on EncoderConfig.version, which covers every setting
    that changes the output vectors, so a config change gets a new instance
    rather than silently reusing the wrong weights.

    Trade-off worth stating: each cached encoder holds roughly 500 MB of VRAM
    for the lifetime of the process. On an 8 GB card that is affordable for
    one or two configurations, not for many, which is why release_encoders()
    exists.
    """
    cfg = config or EncoderConfig()
    key = cfg.version
    encoder = _ENCODERS.get(key)
    if encoder is None:
        encoder = TextEncoder(cfg)
        encoder.load()
        _ENCODERS[key] = encoder
        log.info("cached encoder %s (%d resident)", key, len(_ENCODERS))
    return encoder


def release_encoders() -> int:
    """Drop cached encoders and free their VRAM.

    Call before a training job that needs the whole card.
    """
    count = len(_ENCODERS)
    _ENCODERS.clear()
    try:
        import torch

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except ImportError:
        pass
    return count
