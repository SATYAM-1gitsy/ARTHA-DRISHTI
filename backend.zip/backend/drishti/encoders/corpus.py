"""Build a production-scale description corpus for encoder benchmarking.

Not synthetic fraud data and not training data -- this exists to answer one
engineering question honestly: what does encoding a real-sized MPLADS corpus
cost, and does the GPU earn its place doing it?

Scale is taken from the scheme itself. 543 Lok Sabha MPs generating dozens of
works a year reaches the order of 50,000 live works, which is the number the
throughput measurement has to be made at. Measuring on 36 rows tells you
nothing except that the card is idle.

Place names come from the real allocation file, so string length, script mix
and token distribution resemble production rather than a lorem-ipsum
stand-in -- all three drive tokenizer output length, which is what actually
determines encoding cost.
"""

from __future__ import annotations

import random
from collections.abc import Sequence
from pathlib import Path

from ..config import settings
from ..domain import SECTORS

__all__ = ["real_place_names", "build_corpus", "TEMPLATES_EN", "TEMPLATES_HI"]

TEMPLATES_EN: tuple[str, ...] = (
    "Construction of {work} at {place}, Ward {ward}",
    "Installation of {work} in {place} village, Ward {ward}",
    "Repair and renovation of {work} at {place}",
    "Development of {work} near the panchayat office, {place}",
    "Supply and installation of {work} for {place} Gram Panchayat",
    "Construction of {work} from main road to {place}, Ward {ward}",
    "Providing and laying {work} in {place} municipal area",
)

TEMPLATES_HI: tuple[str, ...] = (
    "{place} में {work} का निर्माण कार्य, वार्ड {ward}",
    "ग्राम पंचायत {place} में {work} की स्थापना",
    "{place} में {work} की मरम्मत एवं जीर्णोद्धार",
    "{place} वार्ड {ward} में {work} निर्माण",
)

# Devanagari renderings of the work types in domain.SECTORS, so the corpus
# carries genuine script mixing rather than Latin text in a Hindi frame.
WORK_HI: dict[str, str] = {
    "village_road": "ग्रामीण सड़क",
    "approach_road": "संपर्क मार्ग",
    "culvert": "पुलिया",
    "footpath": "पैदल पथ",
    "borewell": "नलकूप",
    "handpump": "हैंडपंप",
    "water_tank": "पेयजल टंकी",
    "pipeline": "पाइपलाइन",
    "classroom": "कक्षा कक्ष",
    "school_boundary_wall": "विद्यालय चारदीवारी",
    "school_toilet": "विद्यालय शौचालय",
    "library": "पुस्तकालय",
    "phc_building": "प्राथमिक स्वास्थ्य केंद्र भवन",
    "ambulance_shelter": "एम्बुलेंस शेड",
    "health_sub_centre": "स्वास्थ्य उप केंद्र",
    "community_toilet": "सामुदायिक शौचालय",
    "drainage": "नाली",
    "soak_pit": "सोख्ता गड्ढा",
    "street_light": "स्ट्रीट लाइट",
    "high_mast_light": "हाई मास्ट लाइट",
    "solar_unit": "सोलर यूनिट",
    "community_hall": "सामुदायिक भवन",
    "crematorium_shed": "श्मशान शेड",
    "bus_shelter": "बस शेड",
    "playground": "खेल मैदान",
    "open_gym": "खुला जिम",
    "sports_shed": "खेल शेड",
}


def real_place_names(path: Path | None = None) -> list[str]:
    """Constituency names from the allocation file.

    Falls back to a small canned list when pandas or the file is unavailable,
    so a benchmark never fails for want of an optional dependency -- but the
    real names are strongly preferred, since they carry the length and
    tokenisation profile that determines encoding cost.
    """
    target = path or (settings.paths.raw / "Allocated Limit for Honble MPs.xlsx")
    try:
        import pandas as pd

        frame = pd.read_excel(target, header=None).iloc[2:545]
        names = [
            str(value).strip().title().replace("_", " ")
            for value in frame.iloc[:, 3].dropna().tolist()
        ]
        if names:
            return names
    except Exception:  # noqa: BLE001 - benchmarking must not depend on this
        pass
    return ["Rampur", "Sultanpur", "Nandgaon", "Rajpur", "Bhiwandi", "Kadapa"]


def build_corpus(
    n: int = 50_000,
    hindi_share: float = 0.35,
    duplicate_share: float = 0.04,
    seed: int = 42,
    places: Sequence[str] | None = None,
) -> list[str]:
    """Generate `n` realistic work descriptions.

    hindi_share controls script mixing; duplicate_share re-emits an earlier
    description with light edits so the corpus contains near-duplicates at a
    plausible rate rather than being uniformly distinct.
    """
    if n < 1:
        raise ValueError("n must be positive")
    if not 0.0 <= hindi_share <= 1.0:
        raise ValueError("hindi_share must be in [0, 1]")
    if not 0.0 <= duplicate_share <= 1.0:
        raise ValueError("duplicate_share must be in [0, 1]")

    rng = random.Random(seed)
    names = list(places) if places else real_place_names()
    work_types = [wt for types in SECTORS.values() for wt in types]

    corpus: list[str] = []
    for _ in range(n):
        if corpus and rng.random() < duplicate_share:
            source = rng.choice(corpus)
            corpus.append(source.replace("Ward", "Ward No.").replace("वार्ड", "वार्ड सं."))
            continue

        place = rng.choice(names)
        work = rng.choice(work_types)
        ward = rng.randint(1, 30)
        if rng.random() < hindi_share:
            template = rng.choice(TEMPLATES_HI)
            rendered = template.format(place=place, work=WORK_HI.get(work, work), ward=ward)
        else:
            template = rng.choice(TEMPLATES_EN)
            rendered = template.format(place=place, work=work.replace("_", " "), ward=ward)
        corpus.append(rendered)

    return corpus
