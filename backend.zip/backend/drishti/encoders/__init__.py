"""Representation learning: encoders that turn records into vectors."""

from .text import EncoderConfig, EncodeResult, TextEncoder, get_encoder, release_encoders

__all__ = [
    "EncoderConfig",
    "EncodeResult",
    "TextEncoder",
    "get_encoder",
    "release_encoders",
]
