"""Does the encoder actually beat lexical matching?

The claim that justifies putting a transformer on the GPU is specific: a
multilingual bi-encoder finds duplicate works that string matching cannot,
because the same work is routinely recorded in different languages. That claim
is testable now, before the generator exists, against a hand-written corpus of
known duplicate groups (data/fixtures/description_pairs.json).

The measurement that matters is not raw similarity -- it is *separation*: do
same-work pairs score above different-work pairs, and is there a threshold that
splits them. A model with high similarity everywhere is useless.

Hard negatives are the real test. "Boundary wall for the primary school" and
"boundary wall for the crematorium" share almost every word and are different
works; a duplicate detector that flags them will bury an investigator in false
positives.
"""

from __future__ import annotations

import json
from collections.abc import Sequence
from dataclasses import dataclass, field
from itertools import combinations
from pathlib import Path
from typing import Any

import numpy as np

from ..config import settings
from ..textsim import token_set_ratio

__all__ = ["PairEvaluation", "load_corpus", "evaluate_similarity", "lexical_baseline"]


def load_corpus(path: Path | None = None) -> list[dict[str, Any]]:
    """Load the labelled description corpus."""
    target = path or (settings.paths.fixtures / "description_pairs.json")
    payload = json.loads(Path(target).read_text(encoding="utf-8"))
    items = payload["items"]
    if not items:
        raise ValueError(f"{target} contains no items")
    return items


@dataclass
class PairEvaluation:
    """Separation between same-work and different-work pairs."""

    method: str
    n_texts: int
    n_positive_pairs: int
    n_negative_pairs: int
    mean_positive: float
    mean_negative: float
    best_threshold: float
    precision: float
    recall: float
    f1: float
    roc_auc: float
    cross_language_recall: float
    hard_negative_rate: float
    per_pair: list[dict[str, Any]] = field(default_factory=list)

    @property
    def separation(self) -> float:
        """Gap between the class means. Negative means the method is inverted."""
        return self.mean_positive - self.mean_negative

    def summary(self) -> str:
        return (
            f"{self.method}: separation {self.separation:+.3f} "
            f"(pos {self.mean_positive:.3f} / neg {self.mean_negative:.3f}) | "
            f"F1 {self.f1:.3f} @ t={self.best_threshold:.2f} | "
            f"ROC-AUC {self.roc_auc:.3f} | "
            f"cross-language recall {self.cross_language_recall:.3f} | "
            f"hard negatives flagged {self.hard_negative_rate:.3f}"
        )


def _roc_auc(scores: np.ndarray, labels: np.ndarray) -> float:
    """Probability a random positive outscores a random negative.

    Computed from rank sums (the Mann-Whitney identity) so this stays a numpy
    dependency rather than pulling in scikit-learn for one number.
    """
    positives = int(labels.sum())
    negatives = int(len(labels) - positives)
    if positives == 0 or negatives == 0:
        return float("nan")
    order = np.argsort(scores, kind="mergesort")
    ranks = np.empty(len(scores), dtype=float)
    ranks[order] = np.arange(1, len(scores) + 1, dtype=float)
    # Average ranks within ties, or tied scores would inflate the result.
    unique, inverse, counts = np.unique(scores, return_inverse=True, return_counts=True)
    sums = np.zeros(unique.size, dtype=float)
    np.add.at(sums, inverse, ranks)
    ranks = (sums / counts)[inverse]
    rank_sum = ranks[labels == 1].sum()
    return float((rank_sum - positives * (positives + 1) / 2) / (positives * negatives))


def _score_pairs(
    items: Sequence[dict[str, Any]],
    score_fn,
    method: str,
) -> PairEvaluation:
    indices = list(range(len(items)))
    scores: list[float] = []
    labels: list[int] = []
    records: list[dict[str, Any]] = []

    for i, j in combinations(indices, 2):
        a, b = items[i], items[j]
        score = float(score_fn(i, j))
        same_work = int(a["group"] == b["group"])
        cross_language = a["lang"] != b["lang"]
        # Lexically similar but different work -- the false positives that
        # actually damage an investigator's trust.
        hard_negative = (
            not same_work
            and "hard_negative" in (a["kind"], b["kind"])
            and a["group"][:4] == b["group"][:4]
        )
        scores.append(score)
        labels.append(same_work)
        records.append(
            {
                "a": a["id"],
                "b": b["id"],
                "score": round(score, 4),
                "same_work": bool(same_work),
                "cross_language": cross_language,
                "hard_negative": hard_negative,
            }
        )

    score_array = np.asarray(scores, dtype=float)
    label_array = np.asarray(labels, dtype=int)

    best = {"f1": -1.0, "threshold": 0.5, "precision": 0.0, "recall": 0.0}
    for threshold in np.unique(np.round(score_array, 3)):
        predicted = score_array >= threshold
        true_positive = int((predicted & (label_array == 1)).sum())
        if true_positive == 0:
            continue
        precision = true_positive / int(predicted.sum())
        recall = true_positive / int(label_array.sum())
        f1 = 2 * precision * recall / (precision + recall)
        if f1 > best["f1"]:
            best = {
                "f1": f1,
                "threshold": float(threshold),
                "precision": precision,
                "recall": recall,
            }

    at_threshold = score_array >= best["threshold"]
    cross_mask = np.asarray([r["cross_language"] and r["same_work"] for r in records])
    hard_mask = np.asarray([r["hard_negative"] for r in records])

    return PairEvaluation(
        method=method,
        n_texts=len(items),
        n_positive_pairs=int(label_array.sum()),
        n_negative_pairs=int((label_array == 0).sum()),
        mean_positive=float(score_array[label_array == 1].mean()),
        mean_negative=float(score_array[label_array == 0].mean()),
        best_threshold=best["threshold"],
        precision=best["precision"],
        recall=best["recall"],
        f1=best["f1"],
        roc_auc=_roc_auc(score_array, label_array),
        cross_language_recall=(
            float(at_threshold[cross_mask].mean()) if cross_mask.any() else float("nan")
        ),
        hard_negative_rate=(
            float(at_threshold[hard_mask].mean()) if hard_mask.any() else 0.0
        ),
        per_pair=records,
    )


def lexical_baseline(items: Sequence[dict[str, Any]]) -> PairEvaluation:
    """The baseline the transformer has to beat: token_set_ratio."""
    return _score_pairs(
        items,
        lambda i, j: token_set_ratio(items[i]["text"], items[j]["text"]),
        method="lexical (token_set_ratio)",
    )


def evaluate_similarity(
    items: Sequence[dict[str, Any]], similarity: np.ndarray, method: str
) -> PairEvaluation:
    """Evaluate a precomputed similarity matrix over the same corpus."""
    matrix = np.asarray(similarity, dtype=float)
    if matrix.shape != (len(items), len(items)):
        raise ValueError(
            f"similarity matrix shape {matrix.shape} does not match {len(items)} items"
        )
    return _score_pairs(items, lambda i, j: matrix[i, j], method=method)
