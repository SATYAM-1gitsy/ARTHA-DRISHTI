"""Configuration: paths, seeds, fusion weights, band thresholds, GPU settings.

Everything tunable lives here or in .env, never inline in a detector. Changing
a fusion weight or a band threshold must not require touching logic -- that is
what lets one person retune scoring while another edits a detector, without a
merge conflict (Manual 2.3, "data not code for rules and weights").
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

__all__ = [
    "Paths",
    "GenConfig",
    "FusionConfig",
    "GPUConfig",
    "CeleryConfig",
    "TrackingConfig",
    "Settings",
    "settings",
]


def _env(key: str, default: str) -> str:
    value = os.environ.get(key)
    return default if value is None or value == "" else value


def _env_int(key: str, default: int) -> int:
    try:
        return int(_env(key, str(default)))
    except ValueError:
        return default


def _env_float(key: str, default: float) -> float:
    try:
        return float(_env(key, str(default)))
    except ValueError:
        return default


def _env_bool(key: str, default: bool) -> bool:
    return _env(key, "true" if default else "false").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )


REPO_ROOT = Path(__file__).resolve().parents[2]


def _load_dotenv(path: Path | None = None) -> int:
    """Load `.env` into the process environment.

    Docker Compose reads `.env` on its own, but Python does not -- so without
    this the container and a natively-run command disagree about every
    credential in it, and the mismatch surfaces as an authentication failure
    that looks like a server problem rather than a configuration one.

    Real environment variables win: an explicit `POSTGRES_PASSWORD=... drishti
    ingest` must not be silently overridden by a stale file.
    """
    target = path or (REPO_ROOT / ".env")
    if not target.is_file():
        return 0
    loaded = 0
    for line in target.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, _, value = stripped.partition("=")
        key = key.strip()
        if key in os.environ:
            continue
        os.environ[key] = value.strip().strip('"').strip("'")
        loaded += 1
    return loaded


_load_dotenv()


def _anchor(value: str) -> Path:
    """Resolve a configured path against the repo, never against the cwd.

    `.env` ships `DRISHTI_DATA_DIR=./data`, and a plain `.resolve()` on that
    reads the *current working directory* -- so `python -m drishti doctor` run
    from `backend/` silently looked for the data tree in
    `<repo>/backend/data`, found nothing, and created an empty one beside the
    source. The wrong answer arrived without an error, which is the failure
    mode this project keeps paying for.

    An absolute value is honoured exactly as given, which is what the
    containers pass.
    """

    target = Path(value).expanduser()
    return target.resolve() if target.is_absolute() else (REPO_ROOT / target).resolve()


@dataclass(frozen=True)
class Paths:
    """Filesystem layout. Every directory is created on access, not at import."""

    data: Path = field(default_factory=lambda: _anchor(_env("DRISHTI_DATA_DIR", "data")))

    @property
    def raw(self) -> Path:
        return self._sub("raw")

    @property
    def seeds(self) -> Path:
        return self._sub("seeds")

    @property
    def out(self) -> Path:
        return self._sub("out")

    @property
    def api(self) -> Path:
        return self._sub("api")

    @property
    def fixtures(self) -> Path:
        return self._sub("fixtures")

    @property
    def checkpoints(self) -> Path:
        target = _anchor(_env("DRISHTI_CHECKPOINT_DIR", "checkpoints"))
        target.mkdir(parents=True, exist_ok=True)
        return target

    def _sub(self, name: str) -> Path:
        target = self.data / name
        target.mkdir(parents=True, exist_ok=True)
        return target


@dataclass(frozen=True)
class GenConfig:
    """Synthetic generator knobs.

    inject_rate, noise_level and pattern_overlap are the difficulty dials: the
    evaluation harness sweeps them to produce a performance curve rather than
    a single flattering number.
    """

    seed: int = field(default_factory=lambda: _env_int("DRISHTI_SEED", 42))
    n_works: int = 20_000
    inject_rate: float = 0.06
    noise_level: float = 0.10
    pattern_overlap: float = 0.15
    missing_rate: float = 0.08
    # Fraction of injected works drawn from held-out patterns. These carry the
    # only honest detection numbers the project produces (domain.R-03), so the
    # split must be large enough to measure.
    held_out_share: float = 0.35

    def __post_init__(self) -> None:
        for name in ("inject_rate", "noise_level", "pattern_overlap", "missing_rate", "held_out_share"):
            value = getattr(self, name)
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"GenConfig.{name} must be in [0, 1], got {value}")
        if self.n_works < 1:
            raise ValueError("GenConfig.n_works must be positive")


@dataclass(frozen=True)
class FusionConfig:
    """Layer weights, band cut-points and escalation policy.

    A layer absent from `weights` contributes nothing, so fusion runs on day
    one with only L0 and silently improves as layers land -- adding a detector
    is a one-line change here, not a change to fusion logic.

    The weights are still the Block 1 values. Block 13 changed the
    *arithmetic*, not them: measurement showed the weighted mean gave `rules`
    89% of the score mass on 43% of the nominal weight, purely because it fires
    on half the corpus. Re-tuning weights against held-out PR-AUC would fit the
    only honest metric this project has, so the fix went into how scores
    combine. See `score.combine` and ADR-0012.
    """

    weights: dict[str, float] = field(
        default_factory=lambda: {
            "rules": 0.30,
            "unsupervised": 0.20,
            "supervised": 0.15,
            "graph": 0.10,
            "duplicate": 0.10,
            # L5 temporal is built, tested and correct, and its weight is 0.
            #
            # Measured in one ablation run, so the comparison is clean: the
            # full stack scores held-out PR-AUC 0.149, and the same stack
            # without forecast scores 0.155. Marginal value -0.0058. ADR-0010's
            # rule is that a layer must either improve held-out generalisation
            # or carry independent-corpus evidence, and L5 has neither.
            #
            # At zero weight it still runs and still emits reasons, which is
            # deliberate rather than an oversight: "still incomplete 1,200 days
            # after sanction, where only 2% of comparable works were still
            # running" is useful to a reviewer looking at a work another layer
            # flagged, even though it does not improve the ranking. Evidence
            # and ranking are different jobs.
            #
            # What would turn it on: an independent corpus measuring the
            # survival estimate against hand-checked delays, the way ADR-0010
            # justified L4. Building one now, after seeing this result and in
            # order to rescue the layer, would be motivated reasoning.
            "forecast": 0.00,
            "vision": 0.05,
        }
    )
    # composite_score cut-points, ascending. A score at or above a cut-point
    # takes that band.
    bands: dict[str, float] = field(
        default_factory=lambda: {"low": 0.0, "medium": 0.35, "high": 0.60, "critical": 0.80}
    )
    # How layer scores become one number. `weighted_mean` is the Block 2
    # arithmetic, kept runnable so the harness compares against the real
    # baseline rather than a reconstruction of it.
    combiner: str = "calibrated_noisy_or"
    # A confirmed hard violation escalates regardless of model score: due
    # process does not depend on a model being confident.
    #
    # Only rules that are both deterministic and precise belong here. This
    # previously listed "ghost_no_asset", which no rule implements -- dead
    # config that could never fire. Its real counterpart,
    # completed_without_asset_photo, is deliberately NOT here: measured
    # precision against ground truth is 6.8%, because ~31% of works legitimately
    # have no photograph on record. Escalating on it would bury an investigator
    # in false criticals. It screens; corroboration decides.
    critical_rules: tuple[str, ...] = ("pre_sanction_payment",)
    # Below this data_quality, the band is capped -- a high score computed
    # from mostly-missing inputs must not present as a confident finding.
    min_data_quality_for_critical: float = 0.40

    def __post_init__(self) -> None:
        for layer, weight in self.weights.items():
            if weight < 0:
                raise ValueError(f"fusion weight for {layer!r} is negative")
        ordered = sorted(self.bands.values())
        if list(self.bands.values()) != ordered:
            raise ValueError("FusionConfig.bands must be in ascending order")
        # The combiner name is NOT validated here: `score` imports `config`, so
        # reaching the other way makes a cycle. `score.combine.resolve` raises
        # on an unknown name, and a test pins the configured default against
        # the registry so a typo cannot ship.

    def band_for(self, score: float) -> str:
        """Map a composite score to its band name."""
        chosen = "low"
        for name, cut in self.bands.items():
            if score >= cut:
                chosen = name
        return chosen


@dataclass(frozen=True)
class GPUConfig:
    """Training and inference settings.

    Defaults are tuned for the audited machine: an RTX 5070 Laptop GPU with
    8 GB of VRAM (docs/adr/0001 section 9). vram_headroom_mb is left
    unallocated so a resident copilot model and a training run can coexist.
    """

    device: str = field(default_factory=lambda: _env("DRISHTI_GPU_DEVICE", "auto"))
    mixed_precision: str = field(default_factory=lambda: _env("DRISHTI_MIXED_PRECISION", "bf16"))
    batch_size: int = field(default_factory=lambda: _env_int("DRISHTI_BATCH_SIZE", 256))
    gradient_accumulation: int = field(default_factory=lambda: _env_int("DRISHTI_GRADIENT_ACCUMULATION", 1))
    num_workers: int = field(default_factory=lambda: _env_int("DRISHTI_NUM_WORKERS", 4))
    pin_memory: bool = field(default_factory=lambda: _env_bool("DRISHTI_PIN_MEMORY", True))
    prefetch_factor: int = field(default_factory=lambda: _env_int("DRISHTI_PREFETCH_FACTOR", 2))
    max_sequence_length: int = field(default_factory=lambda: _env_int("DRISHTI_MAX_SEQUENCE_LENGTH", 64))
    image_size: int = field(default_factory=lambda: _env_int("DRISHTI_IMAGE_SIZE", 224))
    model_dtype: str = field(default_factory=lambda: _env("DRISHTI_MODEL_DTYPE", "float32"))
    vram_headroom_mb: int = field(default_factory=lambda: _env_int("DRISHTI_VRAM_HEADROOM_MB", 1024))

    def __post_init__(self) -> None:
        if self.mixed_precision not in ("off", "fp16", "bf16"):
            raise ValueError(f"unsupported mixed_precision {self.mixed_precision!r}")
        if self.batch_size < 1:
            raise ValueError("batch_size must be positive")
        if self.gradient_accumulation < 1:
            raise ValueError("gradient_accumulation must be positive")


@dataclass(frozen=True)
class CeleryConfig:
    """Async job execution.

    Long pipeline stages -- generation, scoring, training -- must not run
    inside an HTTP request. `POST /api/jobs/...` enqueues and returns
    immediately; the worker owns the GPU.
    """

    task_time_limit: int = field(default_factory=lambda: _env_int("CELERY_TASK_TIME_LIMIT", 3600))
    task_soft_time_limit: int = field(
        default_factory=lambda: _env_int("CELERY_TASK_SOFT_TIME_LIMIT", 3300)
    )
    worker_concurrency: int = field(default_factory=lambda: _env_int("CELERY_CONCURRENCY", 2))
    # A GPU job that lands on a second worker process while the first still
    # holds VRAM will OOM on an 8 GB card, so GPU tasks are serialised onto
    # their own queue rather than sharing the default one.
    gpu_queue: str = "gpu"
    default_queue: str = "default"
    result_expires: int = field(default_factory=lambda: _env_int("CELERY_RESULT_EXPIRES", 86400))

    def __post_init__(self) -> None:
        if self.task_soft_time_limit >= self.task_time_limit:
            raise ValueError("soft time limit must be below the hard limit")
        if self.worker_concurrency < 1:
            raise ValueError("worker_concurrency must be positive")


@dataclass(frozen=True)
class TrackingConfig:
    """Experiment tracking.

    enabled=False and an unreachable server behave identically: tracking
    degrades to no-ops rather than failing a training run. Losing a metric log
    is an inconvenience; losing an hour of training to a down sidecar is not.
    """

    enabled: bool = field(default_factory=lambda: _env_bool("MLFLOW_ENABLED", True))
    tracking_uri: str = field(
        default_factory=lambda: _env("MLFLOW_TRACKING_URI", "http://localhost:5000")
    )
    experiment: str = field(default_factory=lambda: _env("MLFLOW_EXPERIMENT", "drishti"))
    # Seconds to wait on the tracking server before giving up and continuing.
    timeout: int = field(default_factory=lambda: _env_int("MLFLOW_TIMEOUT", 5))


@dataclass(frozen=True)
class Settings:
    """The single settings object the rest of the codebase imports."""

    paths: Paths = field(default_factory=Paths)
    gen: GenConfig = field(default_factory=GenConfig)
    fusion: FusionConfig = field(default_factory=FusionConfig)
    gpu: GPUConfig = field(default_factory=GPUConfig)
    celery: CeleryConfig = field(default_factory=CeleryConfig)
    tracking: TrackingConfig = field(default_factory=TrackingConfig)
    seed: int = field(default_factory=lambda: _env_int("DRISHTI_SEED", 42))
    log_level: str = field(default_factory=lambda: _env("DRISHTI_LOG_LEVEL", "INFO").upper())
    api_host: str = field(default_factory=lambda: _env("API_HOST", "0.0.0.0"))
    api_port: int = field(default_factory=lambda: _env_int("API_PORT", 8000))

    @property
    def database_url(self) -> str:
        user = _env("POSTGRES_USER", "drishti")
        password = _env("POSTGRES_PASSWORD", "drishti")
        host = _env("POSTGRES_HOST", "localhost")
        port = _env_int("POSTGRES_PORT", 5432)
        name = _env("POSTGRES_DB", "drishti")
        return f"postgresql+psycopg2://{user}:{password}@{host}:{port}/{name}"

    @property
    def redis_url(self) -> str:
        return _env("REDIS_URL", "redis://localhost:6379/0")


settings = Settings()
