"""The review workflow and the audit log — Blueprint §11, §12, §16.5.

The engine has always produced a queue; nothing could act on it. `AlertAction`
and the `alert_review` / `audit_log` tables existed as contract and schema with
no writer, so the human-in-the-loop story the Blueprint names as a
differentiator (§16.5) had no implementation and there was no feedback label to
retrain anything on.

**Append-only, never update-in-place.** A review is an event, not a field. The
sequence "opened → under_review → dismissed → reopened" is exactly what an
audit needs to see, and collapsing it to a current status destroys the only
record of who decided what and when. Current status is derived by replaying the
log, which also makes the store trivially correct under concurrent writers:
appends never conflict.

**JSONL on disk, Postgres later.** `db/ddl.sql` already declares both tables and
the columns here mirror them one-for-one, so moving to Postgres is a change of
backend inside this module. A file keeps the native path working — the project
runs without a database by design, and a review workflow that requires
`docker compose up` is a review workflow nobody uses during development.

**A reviewer's outcome is a weak label, never ground truth.** `contracts.labels`
is explicit that a human review and a synthetic injection are different kinds of
evidence and must never be averaged. A dismissal may be correct, or may be a
missed case. `LabelSource.HUMAN_REVIEW` exists precisely so a future L2 can use
these without pretending they are certain.
"""

from __future__ import annotations

import json
import os
import threading
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ..config import settings
from ..util import to_jsonable

__all__ = [
    "AuditLog",
    "OUTCOMES",
    "ReviewEvent",
    "ReviewStore",
    "STATUSES",
    "TERMINAL_STATUSES",
    "get_audit_log",
    "get_review_store",
    "reset_review_store",
]

# Mirrors the CHECK constraint on alert.status in db/ddl.sql.
STATUSES: tuple[str, ...] = ("open", "under_review", "resolved", "dismissed")
# Mirrors the CHECK constraint on alert_review.outcome.
OUTCOMES: tuple[str, ...] = (
    "confirmed_issue",
    "false_positive",
    "insufficient_evidence",
    "duplicate_alert",
    "requires_field_inspection",
)
TERMINAL_STATUSES: frozenset[str] = frozenset({"resolved", "dismissed"})

DEFAULT_STATUS = "open"


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


@dataclass(frozen=True)
class ReviewEvent:
    """One reviewer decision, as stored. Mirrors `alert_review`."""

    alert_id: int
    reviewer: str
    from_status: str
    to_status: str
    outcome: str | None = None
    note: str = ""
    reviewed_at: str = field(default_factory=_now)

    def to_dict(self) -> dict[str, Any]:
        return {
            "alert_id": int(self.alert_id),
            "reviewed_at": self.reviewed_at,
            "reviewer": self.reviewer,
            "from_status": self.from_status,
            "to_status": self.to_status,
            "outcome": self.outcome,
            "note": self.note,
        }


class _JsonlLog:
    """An append-only JSONL file with a process-local write lock.

    The lock serialises this process's own writers. Across processes the append
    itself is the ordering primitive: each record is written as one line in one
    `write` call, which is what keeps a concurrent reader from seeing a torn
    record.
    """

    def __init__(self, path: Path) -> None:
        self._path = path
        self._lock = threading.Lock()

    @property
    def path(self) -> Path:
        return self._path

    def append(self, record: dict[str, Any]) -> None:
        line = json.dumps(to_jsonable(record), separators=(",", ":")) + "\n"
        with self._lock:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with self._path.open("a", encoding="utf-8") as handle:
                handle.write(line)
                handle.flush()
                os.fsync(handle.fileno())

    def read(self) -> list[dict[str, Any]]:
        """Every record, oldest first. A truncated final line is skipped.

        A partial last line means a crash mid-append. Dropping it loses one
        event; refusing to read loses the whole history, so the log stays
        readable.
        """
        if not self._path.is_file():
            return []
        records: list[dict[str, Any]] = []
        for line in self._path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            try:
                records.append(json.loads(stripped))
            except json.JSONDecodeError:
                continue
        return records


class AuditLog:
    """Who did what, when. Blueprint §12 — the accountability tool is accountable.

    Written for every state-changing request, including ones that are refused:
    a rejected action by an out-of-jurisdiction reviewer is exactly the event an
    audit wants to see.
    """

    def __init__(self, path: Path | None = None) -> None:
        self._log = _JsonlLog(path or (settings.paths.out / "audit_log.jsonl"))

    @property
    def path(self) -> Path:
        return self._log.path

    def write(
        self,
        *,
        actor: str,
        action: str,
        entity: str,
        entity_id: str | None = None,
        detail: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        record = {
            "at": _now(),
            "actor": actor,
            "action": action,
            "entity": entity,
            "entity_id": entity_id,
            "detail": detail or {},
        }
        self._log.append(record)
        return record

    def entries(self, *, entity_id: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        rows = self._log.read()
        if entity_id is not None:
            rows = [r for r in rows if str(r.get("entity_id")) == str(entity_id)]
        return rows[-limit:][::-1]


class ReviewStore:
    """Alert review state, derived by replaying an append-only event log."""

    def __init__(self, path: Path | None = None, audit: AuditLog | None = None) -> None:
        self._log = _JsonlLog(path or (settings.paths.out / "alert_reviews.jsonl"))
        self._audit = audit or AuditLog()

    @property
    def path(self) -> Path:
        return self._log.path

    @property
    def audit(self) -> AuditLog:
        """The audit log this store writes to.

        Public because a refused action is also an auditable event, and the
        router needs to record one without reaching into a private attribute.
        """
        return self._audit

    # -- reads ---------------------------------------------------------
    def history(self, alert_id: int | None = None) -> list[dict[str, Any]]:
        rows = self._log.read()
        if alert_id is not None:
            rows = [r for r in rows if int(r.get("alert_id", -1)) == int(alert_id)]
        return rows

    def statuses(self) -> dict[int, str]:
        """alert_id -> current status. Absent means `open`, the default."""
        current: dict[int, str] = {}
        for row in self._log.read():
            try:
                current[int(row["alert_id"])] = str(row["to_status"])
            except (KeyError, TypeError, ValueError):
                continue
        return current

    def status_of(self, alert_id: int) -> str:
        return self.statuses().get(int(alert_id), DEFAULT_STATUS)

    def outcomes(self) -> dict[int, str]:
        """alert_id -> latest recorded outcome, for alerts that have one.

        The weak-label feed for a future supervised layer. Deliberately separate
        from `statuses`: a status is workflow state, an outcome is a judgement,
        and only the second one carries any signal about whether the flag was
        right.
        """
        current: dict[int, str] = {}
        for row in self._log.read():
            outcome = row.get("outcome")
            if outcome:
                try:
                    current[int(row["alert_id"])] = str(outcome)
                except (KeyError, TypeError, ValueError):
                    continue
        return current

    def counts(self) -> dict[str, int]:
        """How many alerts sit in each status, `open` included by omission."""
        tally = dict.fromkeys(STATUSES, 0)
        for status in self.statuses().values():
            if status in tally:
                tally[status] += 1
        return tally

    # -- writes --------------------------------------------------------
    def record(
        self,
        alert_id: int,
        *,
        to_status: str,
        reviewer: str,
        outcome: str | None = None,
        note: str = "",
    ) -> ReviewEvent:
        """Append one decision and return it.

        Raises `ValueError` on an unknown status or outcome rather than storing
        a value the database's CHECK constraint would later reject — the file
        backend has to enforce what Postgres would.
        """
        if to_status not in STATUSES:
            raise ValueError(
                f"unknown status {to_status!r}; expected one of {', '.join(STATUSES)}"
            )
        if outcome is not None and outcome not in OUTCOMES:
            raise ValueError(
                f"unknown outcome {outcome!r}; expected one of {', '.join(OUTCOMES)}"
            )

        event = ReviewEvent(
            alert_id=int(alert_id),
            reviewer=reviewer,
            from_status=self.status_of(alert_id),
            to_status=to_status,
            outcome=outcome,
            note=note,
        )
        self._log.append(event.to_dict())
        self._audit.write(
            actor=reviewer,
            action=f"alert.{to_status}",
            entity="alert",
            entity_id=str(alert_id),
            detail={"from": event.from_status, "to": to_status, "outcome": outcome},
        )
        return event


_review_store: ReviewStore | None = None
_audit_log: AuditLog | None = None


def get_review_store() -> ReviewStore:
    global _review_store
    if _review_store is None:
        _review_store = ReviewStore(audit=get_audit_log())
    return _review_store


def get_audit_log() -> AuditLog:
    global _audit_log
    if _audit_log is None:
        _audit_log = AuditLog()
    return _audit_log


def reset_review_store() -> None:
    """Drop the singletons. Tests point them at a temporary directory."""
    global _review_store, _audit_log
    _review_store = None
    _audit_log = None
