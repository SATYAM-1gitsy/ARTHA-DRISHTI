"""Seam D -- REST response shapes.

Pydantic models are the contract in executable form: the frontend generates
its TypeScript from these, and a producer cannot silently change a shape the
UI depends on without the model rejecting it first.

Every risk-bearing response carries all four quantities from Seam C. That is
not verbosity -- a UI given only a score will render a thinly-evidenced lead
and a four-way-corroborated finding identically, and an officer will act on
both the same way.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "Page",
    "ReasonOut",
    "RiskOut",
    "WorkSummary",
    "WorkDetail",
    "EvidenceCard",
    "TimelineEvent",
    "AlertOut",
    "AlertAction",
    "AlertStats",
    "AlertActionResult",
    "ReviewEventOut",
    "DataQualityNote",
    "Kpis",
    "GroupRow",
    "NationalAnalytics",
    "StateAnalytics",
    "DistrictAnalytics",
    "MPAnalytics",
    "GraphEdge",
    "AgencyGraph",
    "DuplicatePair",
    "DuplicatePage",
    "EarmarkRow",
    "EarmarkReport",
    "CopilotQuery",
    "CopilotSource",
    "CopilotAnswerOut",
    "CopilotStatusOut",
]

T = TypeVar("T")


class Page(BaseModel, Generic[T]):
    """A page of results."""

    items: list[T]
    total: int = Field(description="total matching rows, not the page size")
    limit: int = 50
    offset: int = 0


class ReasonOut(BaseModel):
    """One finding on the evidence card."""

    model_config = ConfigDict(extra="forbid")

    code: str
    text: str = Field(description="plain language; states an observation, never a verdict")
    family: str = Field(description="financial | temporal | network | textual | asset | compliance")
    severity: str
    provenance: str = Field(
        description="guideline_clause | cag_finding | peer_derived | assumed. "
        "Rendered next to the finding so an assumed benchmark is never shown as official."
    )
    factors: dict[str, Any] = Field(default_factory=dict)


class DataQualityNote(BaseModel):
    """Why a work's data quality is what it is."""

    score: float = Field(ge=0.0, le=1.0)
    missing_fields: list[str] = Field(default_factory=list)
    geo_method: str = Field(default="unknown", description="postgis | bbox | unknown")


class RiskOut(BaseModel):
    """The four quantities, kept separate. Seam C over the wire."""

    model_config = ConfigDict(extra="forbid")

    work_id: int
    overall_risk: float = Field(ge=0.0, le=1.0, description="how concerning this looks")
    confidence: float = Field(ge=0.0, le=1.0, description="how much the evidence supports it")
    severity: str = Field(description="consequence if true: low | medium | high | critical")
    data_quality: float = Field(ge=0.0, le=1.0, description="completeness of the inputs")
    band: str = Field(description="investigation priority, not a finding of wrongdoing")
    corroborating_families: list[str] = Field(
        default_factory=list,
        description="independent evidence types supporting this, not the layer count",
    )
    layer_scores: dict[str, float] = Field(default_factory=dict)
    reasons: list[ReasonOut] = Field(default_factory=list)
    narrative: str
    escalated_by_rule: str | None = Field(
        default=None, description="set when a deterministic rule forced the band up"
    )
    factors: dict[str, Any] = Field(
        default_factory=dict, description="machine-readable evidence values"
    )


class WorkSummary(BaseModel):
    """A row in the works list or the alert queue."""

    work_id: int
    description: str
    sector: str
    work_type: str
    state: str
    district_id: int
    status: str
    sanctioned_cost: float
    progress_pct: float
    sanction_date: date | None = None
    band: str
    overall_risk: float
    confidence: float
    data_quality: float


class TimelineEvent(BaseModel):
    """One dated event in a work's life."""

    at: date
    kind: str = Field(description="recommendation | sanction | payment | progress | completion")
    label: str
    amount: float | None = None
    progress_pct: float | None = None


class WorkDetail(BaseModel):
    """Full record behind the summary."""

    work_id: int
    description: str
    sector: str
    work_type: str
    state: str
    constituency: str | None = None
    district_id: int
    mp_id: int
    agency_id: int
    status: str
    estimated_cost: float | None = None
    sanctioned_cost: float
    expenditure_to_date: float
    progress_pct: float
    sanction_date: date | None = None
    expected_completion_date: date | None = None
    actual_completion_date: date | None = None
    latitude: float | None = None
    longitude: float | None = None
    photo_present: bool = False
    timeline: list[TimelineEvent] = Field(default_factory=list)


class EvidenceCard(BaseModel):
    """Everything an investigator needs to decide whether to act.

    Deliberately includes `recommended_checks` and `data_quality`: the product
    of this system is a prioritised, verifiable lead, not a score.
    """

    work: WorkSummary
    risk: RiskOut
    data_quality: DataQualityNote
    peer_comparison: dict[str, Any] = Field(
        default_factory=dict,
        description="how this work compares to its sector-state peers, with the group size",
    )
    duplicate_candidates: list[dict[str, Any]] = Field(default_factory=list)
    graph_evidence: dict[str, Any] = Field(default_factory=dict)
    timeline: list[TimelineEvent] = Field(default_factory=list)
    recommended_checks: list[str] = Field(
        default_factory=list,
        description="concrete verification steps, e.g. 'request the utilisation certificate'",
    )
    disclaimer: str = (
        "Flagged for review based on statistical and rule-based signals. "
        "This is not a finding of wrongdoing."
    )


class AlertOut(BaseModel):
    """An item in a reviewer's queue."""

    alert_id: int
    work_id: int
    category: str
    severity: str
    band: str
    overall_risk: float
    confidence: float
    status: str = Field(description="open | under_review | resolved | dismissed")
    created_at: datetime
    assigned_to: str | None = None
    summary: str


class AlertAction(BaseModel):
    """A reviewer's decision. Feeds the learning loop as a weak label, never
    as ground truth -- a dismissal may be correct or may be a missed case."""

    model_config = ConfigDict(extra="forbid")

    status: str = Field(description="under_review | resolved | dismissed")
    outcome: str | None = Field(
        default=None,
        description="confirmed_issue | false_positive | insufficient_evidence "
        "| duplicate_alert | requires_field_inspection",
    )
    note: str = Field(default="", max_length=4000)


class ReviewEventOut(BaseModel):
    """One recorded reviewer decision. Mirrors the `alert_review` table."""

    alert_id: int
    reviewed_at: str
    reviewer: str
    from_status: str
    to_status: str
    outcome: str | None = None
    note: str = ""


class AlertActionResult(BaseModel):
    """What changed, returned so a client never has to guess.

    Carries the recorded event rather than just the new status: the workflow is
    an append-only history, and a client that renders "who moved this, when"
    should not need a second request to do it.
    """

    alert: AlertOut
    event: ReviewEventOut
    history: list[ReviewEventOut] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# analytics -- Blueprint §10
#
# Every aggregate carries `disclaimer` for the same reason every evidence card
# does. A district ranked worst in a table is the easiest thing in the product
# to mistake for an accusation, and an aggregate has no reasons attached for a
# reader to argue with.
# ---------------------------------------------------------------------------
class Kpis(BaseModel):
    """The headline figures a role view opens with."""

    n_works: int
    sanctioned_total: float
    expenditure_total: float
    utilisation_pct: float
    completed_pct: float
    flagged: int = Field(description="works in band high or critical")
    flagged_pct: float
    critical: int
    actionable: int = Field(description="band >= high AND confidence >= 0.6")
    median_data_quality: float
    value_flagged: float = Field(
        description="rupee value of works flagged for review -- value under "
        "review, never value established as misused"
    )


class GroupRow(BaseModel):
    """One state, district, agency or sector in a comparison table."""

    key: Any
    n_works: int
    flagged: int
    flagged_pct: float
    critical: int
    sanctioned_total: float
    utilisation_pct: float
    completed_pct: float
    mean_risk: float


class NationalAnalytics(BaseModel):
    """Ministry view. Blueprint §11 -- where are the systemic problems?"""

    scope: str
    kpis: Kpis
    by_state: list[GroupRow] = Field(default_factory=list)
    worst_districts: list[GroupRow] = Field(default_factory=list)
    worst_agencies: list[GroupRow] = Field(default_factory=list)
    by_sector: list[GroupRow] = Field(default_factory=list)
    pattern_mix: dict[str, int] = Field(default_factory=dict)
    disclaimer: str


class StateAnalytics(BaseModel):
    """State Nodal view -- which of my districts are lagging or risky?"""

    state: str
    kpis: Kpis
    by_district: list[GroupRow] = Field(default_factory=list)
    by_sector: list[GroupRow] = Field(default_factory=list)
    worst_agencies: list[GroupRow] = Field(default_factory=list)
    pattern_mix: dict[str, int] = Field(default_factory=dict)
    disclaimer: str


class DistrictAnalytics(BaseModel):
    """District view -- which works do I act on today?"""

    district_id: int
    state: str
    kpis: Kpis
    by_agency: list[GroupRow] = Field(default_factory=list)
    by_sector: list[GroupRow] = Field(default_factory=list)
    agency_hhi: float = Field(description="Herfindahl index of agency share, Blueprint §4.4")
    top_agency_share_pct: float
    pattern_mix: dict[str, int] = Field(default_factory=dict)
    disclaimer: str


class MPAnalytics(BaseModel):
    """A member's portfolio: the health of works they recommended."""

    mp_id: int
    state: str
    constituency: str | None = None
    kpis: Kpis
    by_status: dict[str, int] = Field(default_factory=dict)
    by_sector: list[GroupRow] = Field(default_factory=list)
    sc_share_pct: float
    st_share_pct: float
    flagged_works: list[WorkSummary] = Field(default_factory=list)
    note: str = Field(
        description="separates recommending a work from sanctioning and "
        "executing it, so the view cannot read as an accusation"
    )
    disclaimer: str


class GraphEdge(BaseModel):
    """One counterparty in an agency's subgraph."""

    id: Any
    n_works: int
    share_pct: float


class AgencyGraph(BaseModel):
    """The subgraph behind a concentration finding, as inspectable evidence."""

    agency_id: int
    districts: list[int] = Field(default_factory=list)
    n_works: int
    district_share_pct: float
    agency_hhi: float
    centrality: float
    flagged: int
    flagged_pct: float
    members: list[GraphEdge] = Field(default_factory=list)
    payees: list[GraphEdge] = Field(default_factory=list)
    sectors: list[GraphEdge] = Field(default_factory=list)
    note: str
    disclaimer: str


class DuplicatePair(BaseModel):
    """Two works L4 considers the same work recorded twice."""

    work_id: int
    match_work_id: int | None = None
    similarity: float | None = Field(default=None, description="fused pair score")
    semantic: float | None = None
    lexical: float | None = None
    distance_km: float | None = None
    method: str | None = Field(
        default=None,
        description="embedding backend -- sparse tfidf and dense scores are not "
        "on the same scale, so a reader comparing two pairs needs to know which",
    )
    text: str
    district_id: int


class DuplicatePage(Page[DuplicatePair]):
    """Duplicate pairs, with the standing caveat attached."""

    disclaimer: str


class EarmarkRow(BaseModel):
    """One member's SC/ST earmark position."""

    mp_id: int
    state: str
    constituency: str | None = None
    n_works: int
    sanctioned_total: float
    sc_share_pct: float
    st_share_pct: float
    sc_shortfall_pct: float = Field(description="points below the SC floor, 0 when compliant")
    st_shortfall_pct: float
    sc_compliant: bool
    st_compliant: bool


class EarmarkReport(BaseModel):
    """SC/ST earmark compliance. Blueprint §4.3, §18.2.

    An aggregate check by design — the Blueprint's §6.1 says the earmark is
    "checked at MP/entitlement aggregate level, not per-work", and measurement
    agrees: as a per-work rule it fires on 87% of the corpus.

    `basis` and `citation` ship with the numbers because the denominator here
    is not the one the Guidelines specify, and the reader has to be told.
    """

    items: list[EarmarkRow] = Field(default_factory=list)
    total: int
    limit: int = 100
    offset: int = 0
    sc_threshold_pct: float
    st_threshold_pct: float
    basis: str
    provenance: str
    citation: str
    disclaimer: str


class CopilotQuery(BaseModel):
    """A question for the analyst copilot."""

    model_config = ConfigDict(extra="forbid")

    question: str = Field(min_length=3, max_length=1000)


class CopilotSource(BaseModel):
    """One guideline clause an answer rests on."""

    clause: str
    page: int
    source: str
    citation: str
    text: str
    relevance: float | None = None


class CopilotAnswerOut(BaseModel):
    """An answer, what it rests on, and how it was produced.

    `generated_by` is part of the contract, not debug output. A reader is
    entitled to know whether a sentence was phrased by a model or handed to
    them verbatim from the guidelines, and `sources` lets them check it either
    way.
    """

    question: str
    answer: str
    sources: list[CopilotSource] = Field(default_factory=list)
    generated_by: str = Field(description="gemini | retrieval | unavailable")
    corpus: str = ""
    warning: str | None = None
    disclaimer: str


class CopilotStatusOut(BaseModel):
    """Whether the copilot can retrieve, and whether it can phrase.

    Two independent capabilities, reported separately on purpose. Retrieval is
    what the copilot promises and it works offline; generation is a phrasing
    layer that is allowed to be absent. Collapsing them to one "healthy" flag
    would either call a fully usable copilot broken, or hide a dead API key
    behind an answer that still arrives.
    """

    corpus_available: bool
    corpus_source: str = ""
    n_chunks: int = 0
    corpus_problem: str | None = None
    key_configured: bool = False
    model: str = ""
    generation_ok: bool = False
    generation_problem: str | None = Field(
        default=None,
        description="what to fix, derived from the provider's reason code. Never the key.",
    )


class AlertStats(BaseModel):
    """Queue counts for the dashboards."""

    total: int
    by_band: dict[str, int] = Field(default_factory=dict)
    by_status: dict[str, int] = Field(default_factory=dict)
    by_family: dict[str, int] = Field(default_factory=dict)
    median_confidence: float = 0.0
    low_confidence_share: float = Field(
        default=0.0,
        description="share of open alerts below the actionable confidence threshold",
    )
