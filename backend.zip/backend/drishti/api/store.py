"""The read layer behind Seam D.

One module builds every API payload, and both the live routers and the static
`data/api/*.json` fixtures go through it. That is deliberate: the fixture seam
only works while the fixtures are *exactly* what the routers return, and the
cheapest way to guarantee that is to give them one implementation rather than
two that agree today.

Parquet-backed and loaded into memory. At 20,000 works that is a few hundred
milliseconds and simpler than a database round trip; the interface is what
matters, and swapping the backing store to Postgres in a later block changes
this file only.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import date
from functools import lru_cache
from typing import Any

import pandas as pd

from ..config import settings
from ..contracts.risk import Band
from ..domain import SC_EARMARK_PCT, ST_EARMARK_PCT
from ..storage import read_gold
from ..util import to_jsonable

__all__ = ["Store", "get_store", "reset_store"]

_ACTIONABLE_CONFIDENCE = 0.6

# A "worst offenders" list needs a denominator worth ranking on. Below this
# many works a flagged share is one or two works wearing a percentage.
_MIN_RANKED_WORKS = 10

# What the earmark share is actually computed over. The Guidelines earmark a
# share of the *annual entitlement*; this is a share of sanctioned cost
# present in the dataset, which is a different denominator and must be said
# out loud wherever the number is shown.
_EARMARK_BASIS = (
    "Share of sanctioned cost recorded in this dataset, not of the annual "
    "entitlement the Guidelines earmark. Area flags are generator-assigned "
    "and the generator does not model earmark compliance, so the shortfall "
    "rate here describes synthetic data only."
)

# Repeated on every aggregate payload for the same reason it sits on the
# evidence card: an aggregate is easier to misread as a verdict than a single
# work is, because it has no reasons attached to argue with.
_DISCLAIMER = (
    "Risk bands prioritise review. They are not findings of wrongdoing, and "
    "every figure here is measured on synthetically generated data."
)


def _as_date(value: Any) -> str | None:
    if value is None or pd.isna(value):
        return None
    stamp = pd.to_datetime(value)
    return stamp.date().isoformat() if isinstance(stamp, pd.Timestamp) else str(value)


@dataclass
class Store:
    """Gold features joined to their risk assessments."""

    features: pd.DataFrame
    scores: pd.DataFrame

    @classmethod
    def from_parquet(cls) -> Store:
        gold = settings.paths.out / "gold.parquet"
        risk = settings.paths.out / "risk_score.parquet"
        missing = [str(p) for p in (gold, risk) if not p.is_file()]
        if missing:
            raise FileNotFoundError(
                f"missing {missing}. Run `drishti features` then `drishti score`."
            )
        return cls(
            features=read_gold(gold).set_index("work_id", drop=False),
            scores=pd.read_parquet(risk).set_index("work_id", drop=False),
        )

    @property
    def is_empty(self) -> bool:
        return self.features.empty

    # ------------------------------------------------------------------
    # works
    # ------------------------------------------------------------------
    def _summary_row(self, work_id: int) -> dict[str, Any]:
        work = self.features.loc[work_id]
        score = self.scores.loc[work_id] if work_id in self.scores.index else None
        return {
            "work_id": int(work_id),
            "description": str(work["description"]),
            "sector": str(work["sector"]),
            "work_type": str(work["work_type"]),
            "state": str(work["state"]),
            "district_id": int(work["district_id"]),
            "status": str(work["status"]),
            "sanctioned_cost": float(work["sanctioned_cost"]),
            "progress_pct": float(work["progress_pct"]),
            "sanction_date": _as_date(work["sanction_date"]),
            "band": str(score["band"]) if score is not None else "low",
            "overall_risk": float(score["overall_risk"]) if score is not None else 0.0,
            "confidence": float(score["confidence"]) if score is not None else 0.0,
            "data_quality": float(work["data_quality"]),
        }

    def joined(self, scope: Any = None) -> pd.DataFrame:
        """Scores joined to features, narrowed to what the caller may see.

        Jurisdiction scoping happens here rather than at the router, so every
        endpoint is scoped by construction. A district officer asking for
        national analytics gets their district's numbers, not a 403 arriving
        after the whole country has already been aggregated (Blueprint §12).
        """
        frame = self.scores.join(
            self.features.drop(columns=["work_id"]), how="inner", rsuffix="_f"
        )
        if scope is None:
            return frame
        if getattr(scope, "state", None) is not None:
            frame = frame[frame["state"] == scope.state]
        if getattr(scope, "district_id", None) is not None:
            frame = frame[frame["district_id"] == scope.district_id]
        if getattr(scope, "mp_id", None) is not None:
            frame = frame[frame["mp_id"] == scope.mp_id]
        return frame

    def list_works(
        self,
        *,
        band: str | None = None,
        state: str | None = None,
        district_id: int | None = None,
        sector: str | None = None,
        min_risk: float = 0.0,
        actionable_only: bool = False,
        limit: int = 50,
        offset: int = 0,
        scope: Any = None,
    ) -> dict[str, Any]:
        """The alert queue. Ranked by risk, because that is its whole job."""
        joined = self.joined(scope)

        if band:
            joined = joined[joined["band"] == band]
        if state:
            joined = joined[joined["state"] == state]
        if district_id is not None:
            joined = joined[joined["district_id"] == district_id]
        if sector:
            joined = joined[joined["sector"] == sector]
        if min_risk > 0:
            joined = joined[joined["overall_risk"] >= min_risk]
        if actionable_only:
            joined = joined[joined["is_actionable"]]

        # Confidence breaks ties, so a thinly-evidenced work never outranks a
        # corroborated one at the same score.
        joined = joined.sort_values(
            ["overall_risk", "confidence"], ascending=[False, False]
        )
        total = len(joined)
        page = joined.iloc[offset : offset + limit]
        return {
            "items": [self._summary_row(int(w)) for w in page.index],
            "total": int(total),
            "limit": limit,
            "offset": offset,
        }

    def work_detail(self, work_id: int) -> dict[str, Any] | None:
        if work_id not in self.features.index:
            return None
        work = self.features.loc[work_id]
        return {
            "work_id": int(work_id),
            "description": str(work["description"]),
            "sector": str(work["sector"]),
            "work_type": str(work["work_type"]),
            "state": str(work["state"]),
            "constituency": None if pd.isna(work["constituency"]) else str(work["constituency"]),
            "district_id": int(work["district_id"]),
            "mp_id": int(work["mp_id"]),
            "agency_id": int(work["agency_id"]),
            "status": str(work["status"]),
            "estimated_cost": None if pd.isna(work["estimated_cost"]) else float(work["estimated_cost"]),
            "sanctioned_cost": float(work["sanctioned_cost"]),
            "expenditure_to_date": float(work["expenditure_to_date"]),
            "progress_pct": float(work["progress_pct"]),
            "sanction_date": _as_date(work["sanction_date"]),
            "expected_completion_date": _as_date(work["expected_completion_date"]),
            "actual_completion_date": _as_date(work["actual_completion_date"]),
            "latitude": None if pd.isna(work["latitude"]) else float(work["latitude"]),
            "longitude": None if pd.isna(work["longitude"]) else float(work["longitude"]),
            "photo_present": bool(work["photo_present"]),
            "timeline": self._timeline(work),
        }

    def work_risk(self, work_id: int) -> dict[str, Any] | None:
        if work_id not in self.scores.index:
            return None
        score = self.scores.loc[work_id]
        families = str(score["corroborating_families"] or "")
        return {
            "work_id": int(work_id),
            "overall_risk": round(float(score["overall_risk"]), 4),
            "confidence": round(float(score["confidence"]), 4),
            "severity": str(score["severity"]),
            "data_quality": round(float(score["data_quality"]), 4),
            "band": str(score["band"]),
            "corroborating_families": [f for f in families.split(",") if f],
            "layer_scores": json.loads(str(score["layer_scores"])),
            "reasons": json.loads(str(score["reasons"])),
            "narrative": str(score["narrative"]),
            "escalated_by_rule": None
            if pd.isna(score["escalated_by_rule"])
            else str(score["escalated_by_rule"]),
            "factors": {},
        }

    # ------------------------------------------------------------------
    # evidence
    # ------------------------------------------------------------------
    def _timeline(self, work: pd.Series) -> list[dict[str, Any]]:
        """Dated events reconstructed from the Gold view.

        Enough to orient an investigator without a second query. Payment-level
        detail arrives when the API reads the transactional tables directly.
        """
        events: list[dict[str, Any]] = []
        if pd.notna(work["recommended_on"]):
            events.append(
                {"at": _as_date(work["recommended_on"]), "kind": "recommendation",
                 "label": "Recommended by the Member of Parliament"}
            )
        if pd.notna(work["sanction_date"]):
            events.append(
                {"at": _as_date(work["sanction_date"]), "kind": "sanction",
                 "label": "Sanctioned by the district authority",
                 "amount": float(work["sanctioned_cost"])}
            )
        if pd.notna(work["time_to_first_payment"]) and pd.notna(work["sanction_date"]):
            first = pd.to_datetime(work["sanction_date"]) + pd.Timedelta(
                days=float(work["time_to_first_payment"])
            )
            events.append(
                {"at": _as_date(first), "kind": "payment",
                 "label": f"First of {int(work['n_payments'])} payment(s)"}
            )
        if float(work["progress_pct"]) > 0:
            events.append(
                {"at": _as_date(work["sanction_date"]), "kind": "progress",
                 "label": "Latest reported progress",
                 "progress_pct": float(work["progress_pct"])}
            )
        if pd.notna(work["actual_completion_date"]):
            events.append(
                {"at": _as_date(work["actual_completion_date"]), "kind": "completion",
                 "label": "Reported complete"}
            )
        return [e for e in events if e["at"]]

    def _peer_comparison(self, work: pd.Series) -> dict[str, Any]:
        """How this work sits against its peers, with the group size shown.

        The size is not decoration: a percentile over 8 works and one over 800
        justify very different levels of confidence, and hiding it would let
        the card overstate its own evidence.
        """
        peers = self.features[
            (self.features["sector"] == work["sector"])
            & (self.features["work_type"] == work["work_type"])
            & (self.features["state"] == work["state"])
        ]
        unit_costs = peers["unit_cost"].dropna()
        return {
            "peer_group": "sector x work_type x state",
            "peer_group_size": int(len(peers)),
            "unit_cost": None if pd.isna(work["unit_cost"]) else float(work["unit_cost"]),
            "unit_cost_percentile": None
            if pd.isna(work["unit_cost_peer_percentile"])
            else float(work["unit_cost_peer_percentile"]),
            "median_peer_unit_cost": float(unit_costs.median()) if len(unit_costs) else None,
            "sufficient_peers": bool(len(peers) >= 5),
        }

    def _recommended_checks(self, reasons: list[dict[str, Any]]) -> list[str]:
        """Concrete next steps, derived from what actually fired.

        The product of this system is a verifiable lead, not a score, so the
        card has to say what verifying it would involve.
        """
        by_code = {
            "pre_sanction_payment": "Obtain the sanction order and the payment voucher, and "
            "confirm which was issued first.",
            "unit_cost_above_peers": "Compare the measurement book and rate analysis against "
            "the state Schedule of Rates for this work type.",
            "completed_without_asset_photo": "Request a geo-tagged photograph, or schedule a "
            "field inspection to confirm the asset exists.",
            "advance_without_progress": "Ask the implementing agency for a status report and "
            "the utilisation certificate for the advance.",
            "split_payment_near_ceiling": "Review whether the payments relate to one work that "
            "should have been sanctioned as a single item.",
            "potentially_ineligible_description": "Confirm the purpose and beneficiary against "
            "the eligible-works list before treating this as a finding.",
            "agency_concentration": "Review how works were allotted to this agency across the "
            "district over the period.",
            "ceiling_breach": "Confirm the applicable per-work ceiling for this category.",
            "spend_ahead_of_progress": "Reconcile recorded expenditure against the last "
            "measured progress.",
            "sanction_delay_above_peers": "Check whether the delay between recommendation and "
            "sanction was recorded with a reason. Comparable works in this sector and state "
            "were sanctioned faster; that is context, not a breach of any stated window.",
        }
        checks = [by_code[r["code"]] for r in reasons if r.get("code") in by_code]
        return checks or [
            "No specific check indicated. Review the work record before taking action."
        ]

    def evidence_card(self, work_id: int) -> dict[str, Any] | None:
        if work_id not in self.features.index:
            return None
        work = self.features.loc[work_id]
        risk = self.work_risk(work_id) or {}
        reasons = risk.get("reasons", [])

        missing = [
            column
            for column in ("latitude", "longitude", "quantity", "unit_cost", "phash",
                           "estimated_cost", "unit_cost_peer_percentile")
            if pd.isna(work.get(column))
        ]

        return to_jsonable(
            {
                "work": self._summary_row(work_id),
                "risk": risk,
                "data_quality": {
                    "score": float(work["data_quality"]),
                    "missing_fields": missing,
                    "geo_method": str(work["geo_method"]),
                },
                "peer_comparison": self._peer_comparison(work),
                "duplicate_candidates": [],
                "graph_evidence": {
                    "agency_district_share": None
                    if pd.isna(work["agency_district_share"])
                    else float(work["agency_district_share"]),
                    "agency_hhi": None if pd.isna(work["agency_hhi"]) else float(work["agency_hhi"]),
                    "n_works_same_agency": int(work["n_works_same_agency"]),
                },
                "timeline": self._timeline(work),
                "recommended_checks": self._recommended_checks(reasons),
                "disclaimer": "Flagged for review based on statistical and rule-based signals. "
                "This is not a finding of wrongdoing.",
            }
        )

    # ------------------------------------------------------------------
    # aggregates
    # ------------------------------------------------------------------
    def alert_stats(
        self, *, scope: Any = None, statuses: dict[int, str] | None = None
    ) -> dict[str, Any]:
        scores = self.joined(scope)
        if scores.empty:
            return {"total": 0, "by_band": {}, "by_status": {}, "by_family": {},
                    "median_confidence": 0.0, "low_confidence_share": 0.0}

        flagged = scores[scores["band"].isin([Band.HIGH.value, Band.CRITICAL.value])]
        families: dict[str, int] = {}
        for value in flagged["corroborating_families"].fillna(""):
            for family in str(value).split(","):
                if family:
                    families[family] = families.get(family, 0) + 1

        # Real workflow counts, replayed from the review log. This used to
        # report every alert as `open` with the other three hard-coded to zero,
        # which made a reviewed queue indistinguishable from an untouched one.
        current = statuses or {}
        by_status = dict.fromkeys(("open", "under_review", "resolved", "dismissed"), 0)
        for work_id in flagged.index:
            state = current.get(int(work_id), "open")
            if state in by_status:
                by_status[state] += 1

        confidence = flagged["confidence"]
        return {
            "total": int(len(flagged)),
            "by_band": {k: int(v) for k, v in scores["band"].value_counts().items()},
            "by_status": by_status,
            "by_family": families,
            "median_confidence": round(float(confidence.median()), 4) if len(confidence) else 0.0,
            "low_confidence_share": round(
                float((confidence < _ACTIONABLE_CONFIDENCE).mean()), 4
            )
            if len(confidence)
            else 0.0,
        }

    def flagged(self, scope: Any = None) -> pd.DataFrame:
        """The works that constitute the review queue: band high or critical."""
        frame = self.joined(scope)
        return frame[frame["band"].isin([Band.HIGH.value, Band.CRITICAL.value])].sort_values(
            ["overall_risk", "confidence"], ascending=[False, False]
        )

    def alert_row(self, alert_id: int, statuses: dict[int, str] | None = None) -> dict[str, Any] | None:
        """One alert, or None when that work is not in the queue."""
        work_id = int(alert_id)
        if work_id not in self.scores.index:
            return None
        row = self.scores.loc[work_id]
        if str(row["band"]) not in (Band.HIGH.value, Band.CRITICAL.value):
            return None
        reasons = json.loads(str(row["reasons"]))
        current = (statuses or {}).get(work_id, "open")
        return {
            # The alert id IS the work id, and that is load-bearing rather than
            # lazy. It used to be the row's position in the queue, which changes
            # under pagination and again on every re-score -- so a review
            # recorded against alert 42 would later refer to a different work.
            # An action has to be keyed on something stable, and one flagged
            # work is one alert.
            "alert_id": work_id,
            "work_id": work_id,
            "category": reasons[0]["family"] if reasons else "unclassified",
            "severity": str(row["severity"]),
            "band": str(row["band"]),
            "overall_risk": round(float(row["overall_risk"]), 4),
            "confidence": round(float(row["confidence"]), 4),
            "status": current,
            "created_at": f"{date.today().isoformat()}T00:00:00",
            "assigned_to": None,
            "summary": str(row["narrative"]),
        }

    def alert_row_visible(self, alert_id: int, scope: Any = None) -> bool:
        """Whether this alert falls inside a principal's jurisdiction.

        Separate from `alert_row` on purpose. Reading outside your scope is a
        narrowed query; *actioning* outside it is refused, and the two need
        different answers from the same data.
        """
        work_id = int(alert_id)
        frame = self.joined(scope)
        return work_id in frame.index

    def alerts(
        self,
        limit: int = 50,
        offset: int = 0,
        *,
        status: str | None = None,
        scope: Any = None,
        statuses: dict[int, str] | None = None,
    ) -> dict[str, Any]:
        """High and critical works, as a reviewer queue.

        `statuses` is the replayed review log, passed in rather than read here
        so the store stays a pure function of the scored artefacts and the
        router owns the workflow state.
        """
        frame = self.flagged(scope)
        current = statuses or {}

        if status:
            keep = [w for w in frame.index if current.get(int(w), "open") == status]
            frame = frame.loc[keep]

        page = frame.iloc[offset : offset + limit]
        items = []
        for work_id in page.index:
            row = self.alert_row(int(work_id), current)
            if row is not None:
                items.append(row)
        return {"items": items, "total": int(len(frame)), "limit": limit, "offset": offset}


    # ------------------------------------------------------------------
    # analytics -- Blueprint §10 and §11
    #
    # One set of helpers feeds all four role views. The Blueprint frames them as
    # four dashboards, but they are four groupings of one risk engine: the
    # Ministry groups by state, a State Nodal by district, a District by agency,
    # an MP by their own works. Writing them once keeps the definition of "risky
    # district" identical everywhere it is displayed, which is the whole reason
    # a State and the Ministry can have a conversation about the same number.
    # ------------------------------------------------------------------
    def _kpis(self, frame: pd.DataFrame) -> dict[str, Any]:
        """The headline figures every role view opens with."""
        if frame.empty:
            return {
                "n_works": 0, "sanctioned_total": 0.0, "expenditure_total": 0.0,
                "utilisation_pct": 0.0, "completed_pct": 0.0, "flagged": 0,
                "flagged_pct": 0.0, "critical": 0, "actionable": 0,
                "median_data_quality": 0.0, "value_flagged": 0.0,
            }
        sanctioned = float(frame["sanctioned_cost"].sum())
        spent = float(frame["expenditure_to_date"].sum())
        flagged = frame[frame["band"].isin([Band.HIGH.value, Band.CRITICAL.value])]
        return {
            "n_works": int(len(frame)),
            "sanctioned_total": round(sanctioned, 2),
            "expenditure_total": round(spent, 2),
            "utilisation_pct": round(100.0 * spent / sanctioned, 2) if sanctioned else 0.0,
            "completed_pct": round(100.0 * float((frame["status"] == "completed").mean()), 2),
            "flagged": int(len(flagged)),
            "flagged_pct": round(100.0 * len(flagged) / len(frame), 2),
            "critical": int((frame["band"] == Band.CRITICAL.value).sum()),
            "actionable": int(frame["is_actionable"].sum()),
            "median_data_quality": round(float(frame["data_quality"].median()), 4),
            # Blueprint §15's governance-impact metric: the rupee value of works
            # flagged for review. Value under review, never value misused.
            "value_flagged": round(float(flagged["sanctioned_cost"].sum()), 2),
        }

    def _group_table(
        self, frame: pd.DataFrame, by: str, *, limit: int = 0, min_works: int = 1
    ) -> list[dict[str, Any]]:
        """Risk and utilisation per group, worst first.

        Ordered by flagged *share*, not flagged count, so a small district with
        a bad rate is not buried beneath a large one with an ordinary rate. The
        count travels alongside so a reader can always see the denominator --
        "60% flagged" over five works is a different claim from the same figure
        over five hundred.

        `min_works` guards the *ranked* tables. Without it the worst-agency list
        was entirely agencies holding a single work that happened to be flagged,
        every one of them at 100%: arithmetically correct, and useless as a
        list of who to look at. Full tables pass `min_works=1` because there the
        reader is scanning a complete population, not a top ten.
        """
        if frame.empty or by not in frame.columns:
            return []
        rows: list[dict[str, Any]] = []
        for key, group in frame.groupby(by, sort=False):
            if len(group) < min_works:
                continue
            flagged = group[group["band"].isin([Band.HIGH.value, Band.CRITICAL.value])]
            sanctioned = float(group["sanctioned_cost"].sum())
            spent = float(group["expenditure_to_date"].sum())
            rows.append({
                "key": to_jsonable(key),
                "n_works": int(len(group)),
                "flagged": int(len(flagged)),
                "flagged_pct": round(100.0 * len(flagged) / len(group), 2),
                "critical": int((group["band"] == Band.CRITICAL.value).sum()),
                "sanctioned_total": round(sanctioned, 2),
                "utilisation_pct": round(100.0 * spent / sanctioned, 2) if sanctioned else 0.0,
                "completed_pct": round(100.0 * float((group["status"] == "completed").mean()), 2),
                "mean_risk": round(float(group["overall_risk"].mean()), 4),
            })
        rows.sort(key=lambda r: (-r["flagged_pct"], -r["n_works"]))
        return rows[:limit] if limit else rows

    def _pattern_mix(self, frame: pd.DataFrame) -> dict[str, int]:
        """Which findings are driving the flags in this slice.

        Read from the persisted reasons, so it describes the run that produced
        these scores rather than whatever detectors happen to be importable now.
        """
        mix: dict[str, int] = {}
        flagged = frame[frame["band"].isin([Band.HIGH.value, Band.CRITICAL.value])]
        for payload in flagged["reasons"].head(5000):
            for reason in json.loads(str(payload)):
                code = str(reason.get("code", "")).split(":")[0]
                if code:
                    mix[code] = mix.get(code, 0) + 1
        return dict(sorted(mix.items(), key=lambda kv: -kv[1])[:12])

    def national_analytics(self, scope: Any = None) -> dict[str, Any]:
        """Ministry view. Blueprint §11 -- where are the systemic problems?"""
        frame = self.joined(scope)
        return {
            "scope": scope.describe() if scope is not None else "national",
            "kpis": self._kpis(frame),
            "by_state": self._group_table(frame, "state"),
            "worst_districts": self._group_table(frame, "district_id", limit=10, min_works=_MIN_RANKED_WORKS),
            "worst_agencies": self._group_table(frame, "agency_id", limit=10, min_works=_MIN_RANKED_WORKS),
            "by_sector": self._group_table(frame, "sector"),
            "pattern_mix": self._pattern_mix(frame),
            "disclaimer": _DISCLAIMER,
        }

    def state_analytics(self, state: str, scope: Any = None) -> dict[str, Any] | None:
        """State Nodal view -- which of my districts are lagging or risky?"""
        frame = self.joined(scope)
        frame = frame[frame["state"] == state]
        if frame.empty:
            return None
        return {
            "state": state,
            "kpis": self._kpis(frame),
            "by_district": self._group_table(frame, "district_id"),
            "by_sector": self._group_table(frame, "sector"),
            "worst_agencies": self._group_table(frame, "agency_id", limit=10, min_works=_MIN_RANKED_WORKS),
            "pattern_mix": self._pattern_mix(frame),
            "disclaimer": _DISCLAIMER,
        }

    def district_analytics(self, district_id: int, scope: Any = None) -> dict[str, Any] | None:
        """District view -- which works do I act on today?"""
        frame = self.joined(scope)
        frame = frame[frame["district_id"] == district_id]
        if frame.empty:
            return None
        # Concentration is the district officer's own signal rather than a
        # per-work one: Blueprint §4.4's Herfindahl index over agency share.
        shares = frame["agency_id"].value_counts(normalize=True)
        return {
            "district_id": int(district_id),
            "state": str(frame["state"].iloc[0]),
            "kpis": self._kpis(frame),
            "by_agency": self._group_table(frame, "agency_id", limit=15, min_works=_MIN_RANKED_WORKS),
            "by_sector": self._group_table(frame, "sector"),
            "agency_hhi": round(float((shares**2).sum()), 4),
            "top_agency_share_pct": round(100.0 * float(shares.iloc[0]), 2) if len(shares) else 0.0,
            "pattern_mix": self._pattern_mix(frame),
            "disclaimer": _DISCLAIMER,
        }

    def mp_analytics(self, mp_id: int, scope: Any = None) -> dict[str, Any] | None:
        """MP portfolio -- the health of works this member recommended.

        The member recommends; the District Authority sanctions, pays and
        reports. This view says what became of those recommendations. It must
        not read as attributing an execution failure to the member, which is
        why the framing note ships inside the payload rather than living in
        frontend copy that a second client could omit.
        """
        frame = self.joined(scope)
        frame = frame[frame["mp_id"] == mp_id]
        if frame.empty:
            return None
        first = frame.iloc[0]
        constituency = str(first.get("constituency", "") or "") or None
        flagged = frame[frame["band"].isin([Band.HIGH.value, Band.CRITICAL.value])]
        return {
            "mp_id": int(mp_id),
            "state": str(first["state"]),
            "constituency": constituency,
            "kpis": self._kpis(frame),
            "by_status": {k: int(v) for k, v in frame["status"].value_counts().items()},
            "by_sector": self._group_table(frame, "sector"),
            "sc_share_pct": round(float(first.get("mp_sc_share_pct", 0.0) or 0.0), 2),
            "st_share_pct": round(float(first.get("mp_st_share_pct", 0.0) or 0.0), 2),
            "flagged_works": [
                self._summary_row(int(w))
                for w in flagged.sort_values(
                    ["overall_risk", "confidence"], ascending=[False, False]
                ).index[:25]
            ],
            "note": (
                "The Member recommends works; the District Authority sanctions, "
                "pays for and reports on them. Flags describe execution, not the "
                "recommendation."
            ),
            "disclaimer": _DISCLAIMER,
        }

    def earmark_compliance(
        self, *, shortfall_only: bool = True, limit: int = 100, scope: Any = None
    ) -> dict[str, Any]:
        """SC/ST earmark shortfall per member. Blueprint §4.3 and §18.2.

        **Deliberately not an L0 rule**, and the Blueprint says so itself in
        §6.1: "SC/ST earmark checked at MP/entitlement aggregate level, not
        per-work". Measurement backs that up hard — as a per-work predicate it
        fires on **87.1% of the corpus**, 17,321 flags carrying 475 distinct
        findings, because every one of a member's works inherits their
        portfolio's shortfall. That would bury the queue and trip the
        acceptance gate's queue-size check, and it is the same failure ADR-0013
        already paid for once. A portfolio-level fact belongs in a
        portfolio-level view.

        Two caveats travel in the payload rather than in a comment, because
        this figure is the one most likely to be quoted at a member:

        * The share is of **sanctioned cost recorded here**, not of the annual
          entitlement the Guidelines actually earmark. Works absent from the
          dataset are absent from the denominator.
        * `is_sc_area` / `is_st_area` come from the generator, which does not
          model earmark compliance at all. The shortfall rate below describes
          synthetic data and says nothing about real members.
        """
        frame = self.joined(scope)
        if frame.empty:
            return {"items": [], "total": 0, "limit": limit, "offset": 0,
                    "sc_threshold_pct": float(SC_EARMARK_PCT.value),
                    "st_threshold_pct": float(ST_EARMARK_PCT.value),
                    "basis": _EARMARK_BASIS, "provenance": SC_EARMARK_PCT.provenance.value,
                    "citation": SC_EARMARK_PCT.citation, "disclaimer": _DISCLAIMER}

        sc_floor = float(SC_EARMARK_PCT.value)
        st_floor = float(ST_EARMARK_PCT.value)
        rows: list[dict[str, Any]] = []
        for mp_id, group in frame.groupby("mp_id", sort=False):
            first = group.iloc[0]
            sc = float(first.get("mp_sc_share_pct", 0.0) or 0.0)
            st = float(first.get("mp_st_share_pct", 0.0) or 0.0)
            sc_short = sc < sc_floor
            st_short = st < st_floor
            if shortfall_only and not (sc_short or st_short):
                continue
            rows.append({
                "mp_id": int(mp_id),
                "state": str(first["state"]),
                "constituency": str(first.get("constituency", "") or "") or None,
                "n_works": int(len(group)),
                "sanctioned_total": round(float(group["sanctioned_cost"].sum()), 2),
                "sc_share_pct": round(sc, 2),
                "st_share_pct": round(st, 2),
                "sc_shortfall_pct": round(max(sc_floor - sc, 0.0), 2),
                "st_shortfall_pct": round(max(st_floor - st, 0.0), 2),
                "sc_compliant": not sc_short,
                "st_compliant": not st_short,
            })
        # Largest combined shortfall first: that is the order in which a nodal
        # officer would work the list.
        rows.sort(key=lambda r: -(r["sc_shortfall_pct"] + r["st_shortfall_pct"]))
        return {
            "items": rows[:limit],
            "total": len(rows),
            "limit": limit,
            "offset": 0,
            "sc_threshold_pct": sc_floor,
            "st_threshold_pct": st_floor,
            "basis": _EARMARK_BASIS,
            "provenance": SC_EARMARK_PCT.provenance.value,
            "citation": SC_EARMARK_PCT.citation,
            "disclaimer": _DISCLAIMER,
        }

    # ------------------------------------------------------------------
    # graph and duplicates -- Blueprint §10
    # ------------------------------------------------------------------
    def agency_graph(self, agency_id: int, scope: Any = None) -> dict[str, Any] | None:
        """The subgraph behind a concentration finding.

        Returns the agency's district footprint, the members whose works it
        executes and the payees it pays. That is what turns "71% of this
        district routed to one agency" from an assertion into something an
        officer can open and check.
        """
        frame = self.joined(scope)
        works = frame[frame["agency_id"] == agency_id]
        if works.empty:
            return None
        districts = sorted({int(d) for d in works["district_id"].dropna().unique()})
        peers = frame[frame["district_id"].isin(districts)]
        flagged = works[works["band"].isin([Band.HIGH.value, Band.CRITICAL.value])]

        def edges(column: str, limit: int = 12) -> list[dict[str, Any]]:
            if column not in works.columns:
                return []
            counts = works[column].dropna().value_counts()
            return [
                {
                    "id": to_jsonable(key),
                    "n_works": int(value),
                    "share_pct": round(100.0 * value / len(works), 2),
                }
                for key, value in counts.head(limit).items()
            ]

        def mean_of(column: str) -> float:
            if column not in works.columns:
                return 0.0
            series = works[column].dropna()
            return round(float(series.mean()), 4) if len(series) else 0.0

        return {
            "agency_id": int(agency_id),
            "districts": districts,
            "n_works": int(len(works)),
            "district_share_pct": round(100.0 * len(works) / max(len(peers), 1), 2),
            "agency_hhi": mean_of("agency_hhi"),
            "centrality": mean_of("agency_centrality"),
            "flagged": int(len(flagged)),
            "flagged_pct": round(100.0 * len(flagged) / len(works), 2),
            "members": edges("mp_id"),
            "payees": edges("vendor_id"),
            "sectors": edges("sector"),
            "note": (
                "Concentration is a structural observation. An agency may hold a "
                "large share for legitimate reasons -- it may be the only PWD "
                "division serving the district."
            ),
            "disclaimer": _DISCLAIMER,
        }

    def duplicate_clusters(
        self, *, district_id: int | None = None, limit: int = 50, scope: Any = None
    ) -> dict[str, Any]:
        """Duplicate-work pairs, read from L4's persisted findings.

        Built from the stored reasons rather than by re-running the detector, so
        the list here can never disagree with the evidence card for the same
        work.
        """
        frame = self.joined(scope)
        if district_id is not None:
            frame = frame[frame["district_id"] == district_id]

        clusters: list[dict[str, Any]] = []
        for work_id, payload in frame["reasons"].items():
            for reason in json.loads(str(payload)):
                if not str(reason.get("code", "")).startswith("duplicate"):
                    continue
                # Key names come from L4's own Reason.factors, not from a guess:
                # `twin_work_id`, `pair_score`, `embedding_backend`. Reading the
                # detector's actual keys is what keeps this endpoint and the
                # evidence card describing the same pair.
                factors = reason.get("factors", {}) or {}
                twin = factors.get("twin_work_id")
                components = factors.get("components", {}) or {}
                clusters.append({
                    "work_id": int(work_id),
                    "match_work_id": int(twin) if twin is not None else None,
                    "similarity": factors.get("pair_score"),
                    "semantic": components.get("semantic"),
                    "lexical": components.get("lexical"),
                    "distance_km": factors.get("distance_km"),
                    # Sparse TF-IDF and dense embeddings are not on the same
                    # scale, so a reader comparing two similarities needs to know
                    # which backend produced them.
                    "method": factors.get("embedding_backend"),
                    "text": str(reason.get("text", "")),
                    "district_id": int(frame.loc[work_id, "district_id"]),
                })
                break
        clusters.sort(key=lambda c: -(c["similarity"] or 0.0))
        return {
            "items": clusters[:limit],
            "total": len(clusters),
            "limit": limit,
            "offset": 0,
            "disclaimer": _DISCLAIMER,
        }


@lru_cache(maxsize=1)
def get_store() -> Store:
    """Process-wide store. Cached because parsing parquet per request is waste."""
    return Store.from_parquet()


def reset_store() -> None:
    """Drop the cache so a re-score is picked up without a restart."""
    get_store.cache_clear()
