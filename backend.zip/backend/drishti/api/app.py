"""FastAPI application.

Block 1 scope is the walking skeleton: a health endpoint the frontend can
reach, plus the fixture seam. Real routers arrive in Block 7 (/works,
/works/{id}/risk) once fusion emits scores.

The fixture seam matters more than it looks. Serving data/api/*.json under
the same paths the real routers will use lets the frontend build complete
screens against correctly-shaped data before any detector exists, then switch
to live data without touching a component (Manual 3.6).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .. import __version__
from ..config import settings
from ..gpu import detect as detect_gpu
from .routers import router as read_router

app = FastAPI(
    title="ARTHA DRISHTI",
    version=__version__,
    description="MPLADS anomaly, fraud and compliance risk intelligence. "
    "Flags works for human review; never issues a verdict.",
)

# The Vite dev server runs on a different origin during development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class HealthResponse(BaseModel):
    """What the frontend renders to prove the stack is wired together."""

    status: str = Field(description="ok when the service is serving requests")
    service: str
    version: str
    accelerator: str = Field(description="human-readable GPU summary")
    gpu_usable: bool = Field(description="whether CUDA is available and correctly built")
    fixtures_available: list[str] = Field(
        default_factory=list,
        description="fixture endpoints currently backed by static JSON",
    )


def _fixture_path(name: str) -> Path:
    return settings.paths.api / f"{name}.json"


app.include_router(read_router)


@app.get("/health", response_model=HealthResponse, tags=["system"])
def health() -> HealthResponse:
    """Liveness plus enough environment detail to diagnose a bad setup.

    Reporting gpu_usable here means a teammate who accidentally installed the
    CPU-only torch wheel sees it on the dashboard rather than discovering it
    after an hour of slow training (finding G-01).
    """
    report = detect_gpu()
    fixtures = sorted(p.stem for p in settings.paths.api.glob("*.json"))
    return HealthResponse(
        status="ok",
        service="artha-drishti",
        version=__version__,
        accelerator=report.summary(),
        gpu_usable=report.usable,
        fixtures_available=fixtures,
    )


@app.get("/api/fixtures/{name}", tags=["system"])
def fixture(name: str) -> Any:
    """Serve a committed fixture by name.

    Temporary scaffolding: each real router replaces its fixture as it lands.
    """
    if not name.replace("_", "").replace("-", "").isalnum():
        raise HTTPException(status_code=400, detail="invalid fixture name")
    path = _fixture_path(name)
    if not path.is_file():
        raise HTTPException(status_code=404, detail=f"no fixture named {name!r}")
    return json.loads(path.read_text(encoding="utf-8"))


# --------------------------------------------------------------------------
# async jobs
# --------------------------------------------------------------------------
class JobAccepted(BaseModel):
    """Returned on enqueue. The caller polls the status endpoint."""

    job_id: str
    task: str
    queue: str = Field(description="gpu jobs are serialised onto their own queue")
    status_url: str


class JobStatus(BaseModel):
    """Current state of an enqueued job."""

    job_id: str
    state: str = Field(description="PENDING | STARTED | SUCCESS | FAILURE | REVOKED")
    ready: bool
    successful: bool | None = None
    result: Any = None
    error: str | None = None


@app.post("/api/jobs/{task}", response_model=JobAccepted, status_code=202, tags=["jobs"])
def enqueue(task: str, size: int | None = None, iterations: int | None = None) -> JobAccepted:
    """Enqueue an allowlisted background task.

    Only names in TASK_NAMES can be dispatched. Accepting a free-form task name
    from an HTTP caller would let anyone reachable run any registered task.
    """
    from ..tasks.jobs import TASK_NAMES

    if task not in TASK_NAMES:
        raise HTTPException(
            status_code=404,
            detail=f"unknown task {task!r}. Available: {sorted(TASK_NAMES)}",
        )

    from ..tasks.app import app as celery_app

    if celery_app is None:
        raise HTTPException(
            status_code=503,
            detail="celery is not installed in this image; jobs run in the ml-worker",
        )

    kwargs: dict[str, Any] = {}
    if size is not None:
        kwargs["size"] = size
    if iterations is not None:
        kwargs["iterations"] = iterations

    try:
        async_result = celery_app.send_task(TASK_NAMES[task], kwargs=kwargs)
    except Exception as exc:  # noqa: BLE001 - broker down is an expected state
        raise HTTPException(
            status_code=503,
            detail=f"cannot reach the broker at {settings.redis_url}: {exc}",
        ) from exc

    # Read the queue from Celery's own routing table rather than guessing from
    # the task name -- a prefix heuristic reported `encode_corpus` as running
    # on the default queue while it was actually routed to the GPU queue.
    routes = celery_app.conf.task_routes or {}
    queue = routes.get(TASK_NAMES[task], {}).get("queue", settings.celery.default_queue)
    return JobAccepted(
        job_id=async_result.id,
        task=TASK_NAMES[task],
        queue=queue,
        status_url=f"/api/jobs/{async_result.id}/status",
    )


@app.get("/api/jobs/{job_id}/status", response_model=JobStatus, tags=["jobs"])
def job_status(job_id: str) -> JobStatus:
    """Poll a job.

    A failed task reports its error as data rather than as a 500: the request
    to inspect the job succeeded, and the caller needs the message to act on.
    """
    from ..tasks.app import app as celery_app

    if celery_app is None:
        raise HTTPException(status_code=503, detail="celery is not installed in this image")

    try:
        async_result = celery_app.AsyncResult(job_id)
        state = async_result.state
        ready = async_result.ready()
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=503, detail=f"cannot reach the broker: {exc}") from exc

    status = JobStatus(job_id=job_id, state=state, ready=ready)
    if ready:
        status.successful = async_result.successful()
        if status.successful:
            status.result = async_result.result
        else:
            status.error = str(async_result.result)
    return status
