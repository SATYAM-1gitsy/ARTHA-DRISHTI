"""Seam D: the read endpoints.

Thin by design. Every payload is built by `Store`, which also writes the static
fixtures, so a router cannot drift from the JSON the frontend developed
against.

A missing scored dataset returns 503 with the command that fixes it, not a
500. "Run `drishti score`" is a far more useful response than a stack trace,
and the API legitimately has nothing to serve until the pipeline has run.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query

from .models import (
    AgencyGraph,
    AlertAction,
    AlertActionResult,
    AlertOut,
    AlertStats,
    CopilotAnswerOut,
    CopilotQuery,
    CopilotStatusOut,
    DistrictAnalytics,
    DuplicatePage,
    EarmarkReport,
    EvidenceCard,
    MPAnalytics,
    NationalAnalytics,
    Page,
    RiskOut,
    StateAnalytics,
    WorkDetail,
    WorkSummary,
)
from .rbac import Principal, principal_from_headers, require_write
from .review import get_review_store
from .store import Store, get_store

__all__ = ["router"]

router = APIRouter(prefix="/api", tags=["works"])

# Every endpoint takes the caller, and `Store` applies `principal.scope` to the
# frame before aggregating. Scoping a query is not the same as refusing one:
# a district officer asking for national analytics gets their district's
# numbers rather than a 403 after the country has already been read.
Caller = Annotated[Principal, Depends(principal_from_headers)]


def _store() -> Store:
    try:
        return get_store()
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail=(
                "No scored data available. Run the pipeline first: "
                "`drishti ingest && drishti seed && drishti features && drishti score`."
            ),
        ) from exc


def _in_scope(store: Store, work_id: int, caller: Principal) -> None:
    """404 a work outside the caller's jurisdiction.

    Not 403: telling an out-of-jurisdiction caller that a work exists and is
    merely forbidden leaks the fact of it. To a district officer, a work in
    another district is simply not there.
    """
    if not store.alert_row_visible(work_id, scope=caller.scope):
        raise HTTPException(status_code=404, detail=f"no work {work_id}")


@router.get("/works", response_model=Page[WorkSummary])
def list_works(
    caller: Caller,
    band: str | None = Query(None, description="low | medium | high | critical"),
    state: str | None = None,
    district_id: int | None = None,
    sector: str | None = None,
    min_risk: float = Query(0.0, ge=0.0, le=1.0),
    actionable_only: bool = Query(
        False, description="band >= high AND confidence >= 0.6"
    ),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
) -> Any:
    """Works ranked by risk, then by confidence.

    Confidence breaks ties so a thinly-evidenced work never outranks a
    corroborated one at the same score.
    """
    return _store().list_works(
        band=band,
        state=state,
        district_id=district_id,
        sector=sector,
        min_risk=min_risk,
        actionable_only=actionable_only,
        limit=limit,
        offset=offset,
        scope=caller.scope,
    )


@router.get("/works/{work_id}", response_model=WorkDetail)
def get_work(work_id: int, caller: Caller) -> Any:
    store = _store()
    detail = store.work_detail(work_id)
    if detail is None:
        raise HTTPException(status_code=404, detail=f"no work {work_id}")
    _in_scope(store, work_id, caller)
    return detail


@router.get("/works/{work_id}/risk", response_model=RiskOut)
def get_work_risk(work_id: int, caller: Caller) -> Any:
    """The four quantities, kept separate. Seam C over the wire."""
    store = _store()
    risk = store.work_risk(work_id)
    if risk is None:
        raise HTTPException(status_code=404, detail=f"work {work_id} has not been scored")
    _in_scope(store, work_id, caller)
    return risk


@router.get("/works/{work_id}/evidence", response_model=EvidenceCard)
def get_work_evidence(work_id: int, caller: Caller) -> Any:
    """Everything an investigator needs to decide whether to act."""
    store = _store()
    card = store.evidence_card(work_id)
    if card is None:
        raise HTTPException(status_code=404, detail=f"no work {work_id}")
    _in_scope(store, work_id, caller)
    return card


@router.get("/alerts", response_model=Page[AlertOut])
def list_alerts(
    caller: Caller,
    status: str | None = Query(
        None, description="open | under_review | resolved | dismissed"
    ),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
) -> Any:
    return _store().alerts(
        limit=limit,
        offset=offset,
        status=status,
        scope=caller.scope,
        statuses=get_review_store().statuses(),
    )


@router.get("/alerts/stats", response_model=AlertStats)
def alert_stats(caller: Caller) -> Any:
    return _store().alert_stats(
        scope=caller.scope, statuses=get_review_store().statuses()
    )


@router.post("/alerts/{alert_id}/action", response_model=AlertActionResult, tags=["review"])
def action_alert(alert_id: int, action: AlertAction, caller: Caller) -> Any:
    """Record a reviewer's decision. Blueprint §10, §11 and §16.5.

    The alert id is the work id -- one flagged work is one alert -- because a
    decision has to be keyed on something that survives the next re-score.

    The decision is appended, never written in place. "opened → under_review →
    dismissed → reopened" is the sequence an audit needs, and collapsing it to a
    current status destroys the only record of who decided what.
    """
    reviewer = require_write(caller)
    store = _store()

    review = get_review_store()
    alert = store.alert_row(alert_id, review.statuses())
    if alert is None:
        raise HTTPException(
            status_code=404,
            detail=(
                f"no alert {alert_id}. Alert ids are work ids, and only works in "
                "band high or critical are in the queue."
            ),
        )

    # Jurisdiction is enforced on the write path too. Reading a work outside
    # your district is a scoped query; actioning one is not something to scope
    # silently, so it is refused and the refusal is audited.
    if not store.alert_row_visible(alert_id, scope=reviewer.scope):
        review.audit.write(
            actor=reviewer.subject,
            action="alert.action.refused",
            entity="alert",
            entity_id=str(alert_id),
            detail={"reason": "out_of_jurisdiction", "scope": reviewer.scope.describe()},
        )
        raise HTTPException(
            status_code=403,
            detail=f"alert {alert_id} is outside your jurisdiction ({reviewer.scope.describe()})",
        )

    try:
        event = review.record(
            alert_id,
            to_status=action.status,
            reviewer=reviewer.subject,
            outcome=action.outcome,
            note=action.note,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    return {
        "alert": store.alert_row(alert_id, review.statuses()),
        "event": event.to_dict(),
        "history": review.history(alert_id)[::-1],
    }


# ---------------------------------------------------------------------------
# analytics -- Blueprint §10, one per stakeholder in §3
# ---------------------------------------------------------------------------
@router.get("/analytics/national", response_model=NationalAnalytics, tags=["analytics"])
def national_analytics(caller: Caller) -> Any:
    """Ministry view. Scoped callers get their own slice, not a refusal."""
    return _store().national_analytics(scope=caller.scope)


@router.get("/analytics/state/{state}", response_model=StateAnalytics, tags=["analytics"])
def state_analytics(state: str, caller: Caller) -> Any:
    payload = _store().state_analytics(state, scope=caller.scope)
    if payload is None:
        raise HTTPException(
            status_code=404, detail=f"no works in {state!r} within your jurisdiction"
        )
    return payload


@router.get(
    "/analytics/district/{district_id}", response_model=DistrictAnalytics, tags=["analytics"]
)
def district_analytics(district_id: int, caller: Caller) -> Any:
    payload = _store().district_analytics(district_id, scope=caller.scope)
    if payload is None:
        raise HTTPException(
            status_code=404,
            detail=f"no works in district {district_id} within your jurisdiction",
        )
    return payload


@router.get("/analytics/mp/{mp_id}", response_model=MPAnalytics, tags=["analytics"])
def mp_analytics(mp_id: int, caller: Caller) -> Any:
    payload = _store().mp_analytics(mp_id, scope=caller.scope)
    if payload is None:
        raise HTTPException(
            status_code=404, detail=f"no works for MP {mp_id} within your jurisdiction"
        )
    return payload


# ---------------------------------------------------------------------------
# graph and duplicates -- Blueprint §10
# ---------------------------------------------------------------------------
@router.get("/graph/agency/{agency_id}", response_model=AgencyGraph, tags=["graph"])
def agency_graph(agency_id: int, caller: Caller) -> Any:
    """The subgraph behind a concentration finding, so it can be checked."""
    payload = _store().agency_graph(agency_id, scope=caller.scope)
    if payload is None:
        raise HTTPException(
            status_code=404,
            detail=f"no works for agency {agency_id} within your jurisdiction",
        )
    return payload


@router.get("/analytics/earmark", response_model=EarmarkReport, tags=["analytics"])
def earmark(
    caller: Caller,
    shortfall_only: bool = Query(True, description="only members below a floor"),
    limit: int = Query(100, ge=1, le=1000),
) -> Any:
    """SC/ST earmark compliance per member. Blueprint §4.3 and §18.2.

    Deliberately not an L0 rule: the Blueprint's own §6.1 puts this at
    "MP/entitlement aggregate level, not per-work", and as a per-work predicate
    it fires on 87% of the corpus.
    """
    return _store().earmark_compliance(
        shortfall_only=shortfall_only, limit=limit, scope=caller.scope
    )


@router.get("/copilot/status", response_model=CopilotStatusOut, tags=["copilot"])
def copilot_status(caller: Caller) -> Any:
    """Whether the copilot can retrieve, and whether it can phrase.

    Read-only and cheap: `probe=False` reports configuration without calling
    the provider, because a status endpoint a dashboard polls must not spend
    free-tier quota. `drishti copilot` does the live probe.
    """
    from ..copilot import diagnose

    status = diagnose(probe=False)
    return {
        "corpus_available": status.corpus_available,
        "corpus_source": status.corpus_source,
        "n_chunks": status.n_chunks,
        "corpus_problem": status.corpus_problem,
        "key_configured": status.key_configured,
        "model": status.model,
        "generation_ok": status.generation_ok,
        "generation_problem": status.generation_problem,
    }


@router.post("/copilot/query", response_model=CopilotAnswerOut, tags=["copilot"])
def copilot_query(query: CopilotQuery, caller: Caller) -> Any:
    """Ask the scheme guidelines a question. Blueprint §10, §16.6.

    Retrieval runs locally and always; Gemini phrases the result when
    `GEMINI_API_KEY` is set. The model is never asked what the guidelines say,
    only to phrase clauses retrieval already found, because a copilot that
    invents a guideline is worse than no copilot.
    """
    from ..copilot import answer_question

    return answer_question(query.question).to_dict()


@router.post("/copilot/explain/{work_id}", response_model=CopilotAnswerOut, tags=["copilot"])
def copilot_explain(work_id: int, caller: Caller) -> Any:
    """Plain-language brief for one work, from findings the detectors produced.

    The copilot phrases the evidence card; it does not re-judge the work.
    """
    from ..copilot import explain_work

    store = _store()
    risk = store.work_risk(work_id)
    if risk is None:
        raise HTTPException(status_code=404, detail=f"work {work_id} has not been scored")
    _in_scope(store, work_id, caller)
    return explain_work(risk).to_dict()


@router.get("/duplicates", response_model=DuplicatePage, tags=["graph"])
def duplicates(
    caller: Caller,
    district_id: int | None = None,
    limit: int = Query(50, ge=1, le=500),
) -> Any:
    """Duplicate-work pairs L4 found, ordered by pair score."""
    return _store().duplicate_clusters(
        district_id=district_id, limit=limit, scope=caller.scope
    )
