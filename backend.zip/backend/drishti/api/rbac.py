"""Roles and jurisdiction scoping — Blueprint §3, §12.

Until now the API was open: any caller could read every work in the country and,
once the review workflow landed, action any alert. The Blueprint is explicit
that a District Authority sees only its district and a State Nodal officer only
its state (§12), and §3 makes the four roles the organising idea of the whole
product.

**Scoping is a filter on data, not a check at the door.** A role does not merely
gate an endpoint — it changes what every endpoint *returns*. `Principal.scope`
is applied inside `Store`, so a district officer calling the national analytics
endpoint gets their district's numbers rather than a 403 arriving after the
query has already read the country. That is also what makes the same dashboard
code work for all four roles.

**Header-based, and honest about it.** A real deployment authenticates against
the government's identity provider and carries these claims in a signed JWT
(§8, §12). This reads them from request headers instead, which is a development
stand-in and *not* a security boundary: anyone can set a header. It is wired as
a FastAPI dependency with the same shape a JWT decoder would have, so replacing
it is one function, and `require_write` already refuses the anonymous default so
the write path is not open by construction. The API advertises the limitation on
`/health` rather than implying an authentication it does not perform.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

from fastapi import Header, HTTPException

__all__ = [
    "ANONYMOUS",
    "Principal",
    "Role",
    "Scope",
    "principal_from_headers",
    "require_write",
]


class Role(str, Enum):
    """The four stakeholders in Blueprint §3, plus an unauthenticated default."""

    MINISTRY = "ministry"
    STATE_NODAL = "state_nodal"
    DISTRICT = "district"
    MP = "mp"
    ANONYMOUS = "anonymous"

    @property
    def label(self) -> str:
        return {
            Role.MINISTRY: "Ministry (MoSPI)",
            Role.STATE_NODAL: "State Nodal Authority",
            Role.DISTRICT: "District Authority",
            Role.MP: "Member of Parliament",
            Role.ANONYMOUS: "Unauthenticated",
        }[self]

    @property
    def can_review(self) -> bool:
        """Who may action an alert.

        District Authorities own the review queue (§11: "the workhorse
        screen"), and State Nodal and Ministry officers oversee it. An MP is
        shown their own portfolio and does not adjudicate it — the scheme
        separates recommending a work from sanctioning and reviewing it, and
        the product must not collapse that separation.
        """
        return self in (Role.DISTRICT, Role.STATE_NODAL, Role.MINISTRY)


@dataclass(frozen=True)
class Scope:
    """The rows a principal may see. `None` on every field means unrestricted."""

    state: str | None = None
    district_id: int | None = None
    mp_id: int | None = None

    @property
    def is_national(self) -> bool:
        return self.state is None and self.district_id is None and self.mp_id is None

    def describe(self) -> str:
        if self.district_id is not None:
            return f"district {self.district_id}"
        if self.mp_id is not None:
            return f"constituency of MP {self.mp_id}"
        if self.state is not None:
            return self.state
        return "national"


@dataclass(frozen=True)
class Principal:
    """Who is calling, and what they may see."""

    role: Role = Role.ANONYMOUS
    scope: Scope = Scope()
    subject: str = "anonymous"

    @property
    def can_review(self) -> bool:
        return self.role.can_review

    def to_dict(self) -> dict[str, Any]:
        return {
            "role": self.role.value,
            "label": self.role.label,
            "subject": self.subject,
            "scope": self.scope.describe(),
            "can_review": self.can_review,
        }


ANONYMOUS = Principal()


def _scope_for(role: Role, state: str | None, district_id: int | None, mp_id: int | None) -> Scope:
    """Keep only the claim the role is actually scoped by.

    A district officer's state claim is redundant once the district is known,
    and honouring both would let a malformed pair widen the scope rather than
    narrow it.
    """
    if role is Role.MINISTRY:
        return Scope()
    if role is Role.STATE_NODAL:
        return Scope(state=state)
    if role is Role.DISTRICT:
        return Scope(state=state, district_id=district_id)
    if role is Role.MP:
        return Scope(mp_id=mp_id)
    return Scope()


def principal_from_headers(
    x_drishti_role: str | None = Header(
        default=None,
        description="ministry | state_nodal | district | mp. "
        "Development stand-in for a signed JWT claim -- not a security boundary.",
    ),
    x_drishti_state: str | None = Header(default=None),
    x_drishti_district: int | None = Header(default=None),
    x_drishti_mp: int | None = Header(default=None),
    x_drishti_subject: str | None = Header(default=None),
) -> Principal:
    """FastAPI dependency yielding the calling principal.

    An unknown role is refused rather than quietly downgraded to anonymous: a
    typo in a role claim must not silently widen or narrow what a caller sees.
    """
    if x_drishti_role is None:
        return ANONYMOUS
    try:
        role = Role(x_drishti_role.strip().lower())
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=(
                f"unknown role {x_drishti_role!r}; expected one of "
                + ", ".join(r.value for r in Role if r is not Role.ANONYMOUS)
            ),
        ) from None

    scope = _scope_for(role, x_drishti_state, x_drishti_district, x_drishti_mp)

    # A scoped role without its scope would read as national. Refuse instead.
    if role is Role.STATE_NODAL and scope.state is None:
        raise HTTPException(status_code=400, detail="state_nodal requires X-Drishti-State")
    if role is Role.DISTRICT and scope.district_id is None:
        raise HTTPException(status_code=400, detail="district requires X-Drishti-District")
    if role is Role.MP and scope.mp_id is None:
        raise HTTPException(status_code=400, detail="mp requires X-Drishti-MP")

    return Principal(role=role, scope=scope, subject=x_drishti_subject or role.value)


def require_write(principal: Principal) -> Principal:
    """Refuse a principal that may not action an alert.

    Anonymous is refused too, so the write path is closed by default even though
    the read path is open in development.
    """
    if not principal.can_review:
        raise HTTPException(
            status_code=403,
            detail=(
                f"role {principal.role.value!r} may not action alerts. "
                "Reviewing is for district, state_nodal and ministry roles; an MP "
                "is shown their portfolio and does not adjudicate it."
            ),
        )
    return principal
