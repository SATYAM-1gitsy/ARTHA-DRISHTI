"""Write the static API payloads.

Same code path as the live routers, via `Store` -- which is the point. The
fixture seam only works while the static JSON is exactly what the routers
return, and two implementations that agree today will not agree next week.

Written to `data/api/` after every scoring run, so the frontend can develop
against real shapes with the API down, then flip a base URL.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import pandas as pd

from ..config import settings
from ..contracts.risk import RiskAssessment
from ..util import dumps
from .store import Store

__all__ = ["publish_api_payloads"]


def publish_api_payloads(
    features: pd.DataFrame, assessments: Sequence[RiskAssessment]
) -> dict[str, str]:
    """Build and write one JSON per endpoint."""
    from ..score.fusion import to_frame

    store = Store(
        features=features.set_index("work_id", drop=False),
        scores=to_frame(assessments).set_index("work_id", drop=False),
    )

    # The exemplar is the highest-risk work that is genuinely actionable --
    # corroborated, not just loud. A demo that opens on a thinly-evidenced
    # work teaches the wrong lesson about what the system produces.
    actionable = [a for a in assessments if a.is_actionable]
    pool = actionable or list(assessments)
    exemplar = max(
        pool,
        key=lambda a: (a.n_corroborating_families, a.overall_risk, a.confidence),
        default=None,
    )

    payloads: dict[str, Any] = {
        "works": store.list_works(limit=50),
        "alerts": store.alerts(limit=50),
        "alerts_stats": store.alert_stats(),
    }
    if exemplar is not None:
        payloads["work_risk"] = store.work_risk(exemplar.work_id)
        payloads["work_evidence"] = store.evidence_card(exemplar.work_id)
        payloads["work_detail"] = store.work_detail(exemplar.work_id)

    written: dict[str, str] = {}
    for name, payload in payloads.items():
        path = settings.paths.api / f"{name}.json"
        path.write_text(dumps(payload, indent=2), encoding="utf-8")
        written[f"api/{name}"] = str(path)
    return written
