"""Seam E -- ground truth, and the rules governing where it may flow.

`fraud_label` records what the generator injected. It exists to measure the
system, and it is the single most dangerous table in the project: routed into
a feature column it produces a model that scores 1.0 and knows nothing.

Three guarantees are enforced here rather than left to discipline:

1. **Never into L1.** The unsupervised layer must not see labels, or its
   "no labels required" claim is false.
2. **Rule-visible and held-out figures are never pooled** (finding R-03). If
   the generator injects `pre_sanction_payment` and L0 has a
   `pre_sanction_payment` rule, recall on it is ~1.0 by construction; it
   measures agreement between a rule and its own injector. Only held-out
   patterns -- injected but never written against -- carry a detection claim.
3. **Label provenance is recorded.** A synthetic injection, a rule-derived
   weak label and a human review outcome are different kinds of evidence and
   must never be averaged together.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from ..domain import FRAUD_PATTERNS, PatternVisibility

__all__ = [
    "LabelSource",
    "FraudLabel",
    "LABEL_COLUMNS",
    "LAYERS_DENIED_LABELS",
    "assert_no_label_leakage",
    "split_by_visibility",
    "PatternRecall",
]

LABEL_COLUMNS: tuple[str, ...] = (
    "work_id",
    "pattern",
    "injected",
    "visibility",
    "severity",
    "source",
    "parameters",
)

# Layers that must never receive ground truth, for reasons that would
# invalidate their output rather than merely bias it.
LAYERS_DENIED_LABELS: frozenset[str] = frozenset({"rules", "unsupervised"})


class LabelSource(str, Enum):
    """How a label came to exist. Never mix these in one training target."""

    SYNTHETIC_INJECTION = "synthetic_injection"
    RULE_DERIVED = "rule_derived"  # weak supervision; noisy by construction
    HUMAN_REVIEW = "human_review"  # a reviewer's outcome, not proven fact
    CONFIRMED_FINDING = "confirmed_finding"  # an upheld audit finding

    @property
    def is_ground_truth(self) -> bool:
        """Only synthetic injection is certain -- and only about synthetic data."""
        return self is LabelSource.SYNTHETIC_INJECTION


@dataclass(frozen=True)
class FraudLabel:
    """One injected or observed pattern on one work."""

    work_id: int
    pattern: str
    injected: bool
    visibility: PatternVisibility
    severity: str
    source: LabelSource = LabelSource.SYNTHETIC_INJECTION
    parameters: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        known = {p.name for p in FRAUD_PATTERNS}
        if self.pattern not in known:
            raise ValueError(
                f"unknown pattern {self.pattern!r}. Register it in domain.FRAUD_PATTERNS "
                "so its visibility and evidence family are declared."
            )

    @property
    def is_held_out(self) -> bool:
        """True when no detector was written against this pattern."""
        return self.visibility is PatternVisibility.HELD_OUT

    def to_dict(self) -> dict[str, Any]:
        return {
            "work_id": self.work_id,
            "pattern": self.pattern,
            "injected": self.injected,
            "visibility": self.visibility.value,
            "severity": self.severity,
            "source": self.source.value,
            "parameters": self.parameters,
        }


def assert_no_label_leakage(feature_columns: Iterable[str]) -> None:
    """Raise if anything label-shaped reached the feature space.

    Called by the feature builder and by every training entry point. Cheap,
    and it catches the failure mode that silently invalidates every number
    the project would otherwise report.
    """
    # work_id is the join key both seams legitimately share -- it is how a
    # score is matched to its label at evaluation time, not a leak. Excluding
    # it matters: without this, the guard rejects every valid feature frame
    # and gets disabled, which is worse than not having it.
    forbidden = (set(LABEL_COLUMNS) - {"work_id"}) | {p.name for p in FRAUD_PATTERNS}
    forbidden |= {"is_fraud", "fraud", "label", "target", "y"}
    found = sorted(set(feature_columns) & forbidden)
    if found:
        raise ValueError(
            "ground truth leaked into the feature space: "
            f"{found}. Seam E must never reach Seam A."
        )


def split_by_visibility(
    labels: Sequence[FraudLabel],
) -> tuple[list[FraudLabel], list[FraudLabel]]:
    """Separate rule-visible labels from held-out ones.

    Returns (rule_visible, held_out). Evaluation reports these separately and
    must refuse to pool them.
    """
    visible = [x for x in labels if x.visibility is PatternVisibility.RULE_VISIBLE]
    held = [x for x in labels if x.visibility is PatternVisibility.HELD_OUT]
    return visible, held


@dataclass(frozen=True)
class PatternRecall:
    """Recall on one pattern, carrying whether it may be quoted."""

    pattern: str
    visibility: PatternVisibility
    n_injected: int
    n_detected: int

    @property
    def recall(self) -> float:
        return self.n_detected / self.n_injected if self.n_injected else float("nan")

    @property
    def quotable(self) -> bool:
        """Whether this figure is a detection claim or a pipeline check.

        Rule-visible recall says the rule and the injector agree. Useful as a
        correctness test, worthless as evidence the system detects fraud.
        """
        return self.visibility is PatternVisibility.HELD_OUT

    def describe(self) -> str:
        caveat = "" if self.quotable else "  [pipeline check only -- not a detection claim]"
        return (
            f"{self.pattern:<28} {self.n_detected:>4}/{self.n_injected:<4} "
            f"recall {self.recall:.3f}{caveat}"
        )
