"""Seam B -- the Layer Output Contract.

Every detector, L0 through L6, returns the same shape. That uniformity is what
lets seven different techniques fuse identically and lets two people build
detectors in parallel without touching each other's files.

Two deliberate extensions to the shape in Build Manual 3.3, both from the
Block 0 audit:

**`confidence` and `data_quality` are separate from `score`** (finding R-02).
A rule that fired on complete records and an anomaly model that fired on a row
missing half its inputs must not present identically. The manual's contract
carried only a score, and retrofitting confidence into seven detectors after
they exist is a seven-file breaking change across two people -- so it lands
here, before any detector is written.

**`reasons` carries an evidence family** (finding R-01). Fusion must count
corroboration across *independent families* -- financial, temporal, network,
textual, asset, compliance -- not across layers. Three layers all firing on
`unit_cost` is one financial signal seen three ways, and a weighted sum that
treats it as three confirmations inflates the score. `reason_texts` still
yields the plain list of strings the manual specified.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

__all__ = [
    "EvidenceFamily",
    "Severity",
    "Reason",
    "LayerOutput",
    "LAYER_NAMES",
    "LAYER_OUTPUT_COLUMNS",
    "validate_layer_frame",
    "empty_output",
]


class EvidenceFamily(str, Enum):
    """Independent kinds of evidence.

    Independence is the point. Two signals in the same family corroborate each
    other weakly, because they are usually two views of one underlying fact.
    Two signals in different families corroborate strongly.
    """

    FINANCIAL = "financial"
    TEMPORAL = "temporal"
    NETWORK = "network"
    TEXTUAL = "textual"
    ASSET = "asset"
    COMPLIANCE = "compliance"


class Severity(str, Enum):
    """Consequence if the finding is true. Distinct from how likely it is."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @property
    def rank(self) -> int:
        return {"low": 0, "medium": 1, "high": 2, "critical": 3}[self.value]


# The seven detection layers, plus the names fusion knows them by.
LAYER_NAMES: tuple[str, ...] = (
    "rules",  # L0
    "unsupervised",  # L1
    "supervised",  # L2
    "graph",  # L3
    "duplicate",  # L4
    "forecast",  # L5
    "vision",  # L6
)

LAYER_OUTPUT_COLUMNS: tuple[str, ...] = (
    "work_id",
    "layer",
    "score",
    "confidence",
    "data_quality",
    "reasons",
    "factors",
)


@dataclass(frozen=True)
class Reason:
    """One human-readable finding, with the machine-readable evidence behind it.

    `text` is what a District officer reads on the evidence card, so it states
    the observation and its comparison -- "unit cost is 2.4x the median of 340
    comparable works" -- not a verdict.

    `provenance` records where the threshold or benchmark came from. An
    assumed Schedule-of-Rates figure must render differently from a quoted
    guideline clause (finding R-05).
    """

    code: str
    text: str
    family: EvidenceFamily
    severity: Severity = Severity.MEDIUM
    provenance: str = "peer_derived"
    factors: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.code or not self.text:
            raise ValueError("a Reason needs both a code and human-readable text")
        if len(self.text) < 8:
            raise ValueError(f"{self.code}: reason text is too short to be evidence")

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "text": self.text,
            "family": self.family.value,
            "severity": self.severity.value,
            "provenance": self.provenance,
            "factors": self.factors,
        }


def _unit(value: float, name: str) -> float:
    number = float(value)
    if not 0.0 <= number <= 1.0:
        raise ValueError(f"{name} must be in [0, 1], got {number}")
    return number


@dataclass(frozen=True)
class LayerOutput:
    """What one detector says about one work.

    A layer with nothing to say emits score=0.0 with empty reasons -- never a
    null, and never a row omitted, because fusion joins on the full population
    and a missing row is indistinguishable from a missing layer.
    """

    work_id: int
    layer: str
    score: float
    confidence: float = 1.0
    data_quality: float = 1.0
    reasons: tuple[Reason, ...] = ()
    factors: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.layer not in LAYER_NAMES:
            raise ValueError(f"unknown layer {self.layer!r}; expected one of {LAYER_NAMES}")
        object.__setattr__(self, "score", _unit(self.score, "score"))
        object.__setattr__(self, "confidence", _unit(self.confidence, "confidence"))
        object.__setattr__(self, "data_quality", _unit(self.data_quality, "data_quality"))
        if self.score > 0 and not self.reasons:
            raise ValueError(
                f"{self.layer} scored work {self.work_id} at {self.score} with no reason. "
                "An unexplained score cannot be shown to an investigator."
            )

    @property
    def reason_texts(self) -> list[str]:
        """The plain string list from Build Manual 3.3."""
        return [r.text for r in self.reasons]

    @property
    def families(self) -> frozenset[EvidenceFamily]:
        """Independent evidence families this layer touched for this work."""
        return frozenset(r.family for r in self.reasons)

    @property
    def max_severity(self) -> Severity | None:
        return max((r.severity for r in self.reasons), key=lambda s: s.rank, default=None)

    def to_row(self) -> dict[str, Any]:
        """Flat dict, for building a DataFrame of layer outputs."""
        return {
            "work_id": self.work_id,
            "layer": self.layer,
            "score": self.score,
            "confidence": self.confidence,
            "data_quality": self.data_quality,
            "reasons": [r.to_dict() for r in self.reasons],
            "factors": self.factors,
        }


def empty_output(work_id: int, layer: str, data_quality: float = 1.0) -> LayerOutput:
    """A no-finding row. Layers must emit these, not skip works."""
    return LayerOutput(
        work_id=work_id,
        layer=layer,
        score=0.0,
        confidence=1.0,
        data_quality=data_quality,
    )


def validate_layer_frame(frame: Any, layer: str | None = None) -> list[str]:
    """Check a DataFrame of layer outputs against the contract."""
    problems: list[str] = []
    columns = set(getattr(frame, "columns", []))

    missing = [c for c in LAYER_OUTPUT_COLUMNS if c not in columns]
    if missing:
        problems.append(f"missing columns: {sorted(missing)}")
        return problems

    for column in ("score", "confidence", "data_quality"):
        try:
            series = frame[column]
            if bool(series.isna().any()):
                problems.append(f"{column} contains nulls; emit 0.0 or 1.0 explicitly")
            elif len(series) and (float(series.min()) < 0.0 or float(series.max()) > 1.0):
                problems.append(
                    f"{column} outside [0, 1] -- normalise inside the layer, not in fusion"
                )
        except Exception:  # noqa: BLE001 - not a pandas frame
            continue

    try:
        if int(frame["work_id"].duplicated().sum()):
            problems.append("duplicate work_id rows; a layer emits exactly one row per work")
    except Exception:  # noqa: BLE001
        pass

    if layer is not None:
        try:
            wrong = sorted(set(frame["layer"].unique()) - {layer})
            if wrong:
                problems.append(f"expected layer {layer!r}, also found {wrong}")
        except Exception:  # noqa: BLE001
            pass

    return problems


def independent_families(outputs: Sequence[LayerOutput] | Iterable[LayerOutput]) -> frozenset[EvidenceFamily]:
    """Union of evidence families across layers, for corroboration counting.

    This is the R-01 fix in one line: corroboration is the size of this set,
    not the number of layers that fired.
    """
    families: set[EvidenceFamily] = set()
    for output in outputs:
        families |= output.families
    return frozenset(families)
