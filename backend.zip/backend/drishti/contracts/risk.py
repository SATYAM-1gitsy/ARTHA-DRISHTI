"""Seam C -- the risk assessment and evidence card.

What fusion produces and the API serves. Four quantities are kept separate,
because collapsing them is how a monitoring system starts lying:

  overall_risk   how concerning this work looks,      [0, 1]
  confidence     how much the evidence supports that, [0, 1]
  severity       the consequence if it is true,       low..critical
  data_quality   how complete the inputs were,        [0, 1]

A work with risk 0.9 and confidence 0.3 is a lead worth a phone call. A work
with risk 0.9 and confidence 0.9 corroborated across four evidence families is
worth an inspection. A single number cannot say which is which, and a District
officer given only the number will treat them the same.

Confidence is computed from *independent evidence families*, not from the
number of layers that fired (finding R-01). Three layers keying off the same
cost column is one financial observation seen three times.

Nothing here produces a verdict. `band` sets investigation priority.
"""

from __future__ import annotations

import math
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from .layer import LayerOutput, Reason, Severity

__all__ = [
    "Band",
    "BANDS",
    "RiskAssessment",
    "corroboration_confidence",
    "assess",
    "build_narrative",
    "entropy_of_agreement",
]


class Band(str, Enum):
    """Investigation priority. Not a finding of wrongdoing."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @property
    def rank(self) -> int:
        return {"low": 0, "medium": 1, "high": 2, "critical": 3}[self.value]


BANDS: tuple[Band, ...] = (Band.LOW, Band.MEDIUM, Band.HIGH, Band.CRITICAL)

# Confidence from independent corroboration: 1 - 0.5^n.
# One family 0.50, two 0.75, three 0.875, four 0.9375. Saturating rather than
# linear, because the second independent signal is worth far more than the
# fifth -- and no amount of corroboration should reach certainty.
_MAX_CORROBORATION_CONFIDENCE = 0.95

# Deterministic compliance evidence quoted from a real guideline clause is not
# a probabilistic guess, so it gets a floor even when it stands alone.
_DETERMINISTIC_CONFIDENCE_FLOOR = 0.80


def corroboration_confidence(n_families: int) -> float:
    """Confidence contributed by n independent evidence families."""
    if n_families <= 0:
        return 0.0
    return min(_MAX_CORROBORATION_CONFIDENCE, 1.0 - 0.5**n_families)


@dataclass(frozen=True)
class RiskAssessment:
    """One work's assessment. Persisted to risk_score, served as the evidence card."""

    work_id: int
    overall_risk: float
    confidence: float
    severity: Severity
    data_quality: float
    band: Band
    corroborating_families: tuple[str, ...]
    layer_scores: dict[str, float]
    reasons: tuple[Reason, ...]
    narrative: str
    escalated_by_rule: str | None = None
    factors: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for name in ("overall_risk", "confidence", "data_quality"):
            value = float(getattr(self, name))
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be in [0, 1], got {value}")

    @property
    def n_corroborating_families(self) -> int:
        return len(self.corroborating_families)

    @property
    def is_actionable(self) -> bool:
        """High priority *and* enough evidence to act on.

        The distinction the whole contract exists for: a high band on thin,
        uncorroborated evidence is a lead to verify, not a case to open.
        """
        return self.band.rank >= Band.HIGH.rank and self.confidence >= 0.6

    def to_dict(self) -> dict[str, Any]:
        return {
            "work_id": self.work_id,
            "overall_risk": round(self.overall_risk, 4),
            "confidence": round(self.confidence, 4),
            "severity": self.severity.value,
            "data_quality": round(self.data_quality, 4),
            "band": self.band.value,
            "corroborating_families": list(self.corroborating_families),
            "layer_scores": {k: round(v, 4) for k, v in self.layer_scores.items()},
            "reasons": [r.to_dict() for r in self.reasons],
            "narrative": self.narrative,
            "escalated_by_rule": self.escalated_by_rule,
            "factors": self.factors,
        }


def _band_for(risk: float, cuts: dict[str, float]) -> Band:
    chosen = Band.LOW
    for name, cut in cuts.items():
        if risk >= cut:
            chosen = Band(name)
    return chosen


def assess(
    work_id: int,
    outputs: Sequence[LayerOutput],
    weights: dict[str, float],
    bands: dict[str, float],
    critical_rules: Sequence[str] = (),
    min_data_quality_for_critical: float = 0.40,
    combine: Callable[[dict[str, float], dict[str, float]], float] | None = None,
) -> RiskAssessment:
    """Fuse layer outputs into one assessment.

    The *shape* was settled in Block 2 and has not changed: four separate
    quantities, corroboration counted over evidence families, and escalation
    kept distinct from the model score. The arithmetic that turns layer scores
    into `overall_risk` is now injected -- Block 13 replaced the weighted mean
    with calibrated noisy-OR, and `score.combine` holds both along with the
    measurements that motivated the change.

    `combine` is a callable rather than an import so this module stays a
    contract: `score` depends on `contracts`, never the reverse. Passing None
    keeps the Block 2 weighted mean, which is what the contract's own tests
    exercise.

    Rules that matter:

    * A layer absent from `weights` contributes nothing, so fusion runs on day
      one with only L0 and improves silently as layers land.
    * A confirmed critical rule escalates the band regardless of model score.
      Due process does not wait for a model to feel confident.
    * A critical band is capped when `data_quality` is too low. A confident
      presentation built on mostly-missing inputs is the most damaging output
      this system could produce.
    """
    scoring = [o for o in outputs if o.layer in weights]
    layer_scores = {o.layer: o.score for o in outputs}

    if combine is None:
        total_weight = sum(weights[o.layer] for o in scoring) or 1.0
        overall_risk = sum(weights[o.layer] * o.score for o in scoring) / total_weight
    else:
        overall_risk = combine({o.layer: o.score for o in scoring}, weights)
    overall_risk = min(1.0, max(0.0, overall_risk))

    contributing = [o for o in outputs if o.score > 0 and o.reasons]
    reasons: list[Reason] = []
    for output in sorted(contributing, key=lambda o: -o.score):
        reasons.extend(output.reasons)

    families = sorted({r.family.value for r in reasons})
    severity = max(
        (r.severity for r in reasons), key=lambda s: s.rank, default=Severity.LOW
    )

    # Data quality is the weakest link across contributing layers: one layer
    # scoring on complete data does not repair another that scored on gaps.
    data_quality = min((o.data_quality for o in contributing), default=1.0)

    confidence = corroboration_confidence(len(families)) * (0.5 + 0.5 * data_quality)

    # The deterministic floor applies to the curated `critical_rules` set, not
    # to anything merely citing a guideline.
    #
    # It originally keyed on provenance == "guideline_clause", which conflated
    # two different things: provenance says where a *threshold* came from, not
    # how certain a *finding* is. That gave 76 works a lone keyword match at
    # 0.80 confidence -- from a rule whose own text says "eligibility turns on
    # the purpose and beneficiary, which this check cannot establish". A
    # payment predating its sanction is a documentary fact; a keyword match is
    # a screen. Only the former earns a floor.
    if any(r.code in critical_rules for r in reasons):
        confidence = max(confidence, _DETERMINISTIC_CONFIDENCE_FLOOR * data_quality)
    confidence = min(1.0, max(0.0, confidence))

    band = _band_for(overall_risk, bands)

    escalated_by: str | None = None
    for reason in reasons:
        if reason.code in critical_rules and reason.severity is Severity.CRITICAL:
            band = Band.CRITICAL
            escalated_by = reason.code
            break

    if band is Band.CRITICAL and data_quality < min_data_quality_for_critical:
        band = Band.HIGH
        escalated_by = None

    return RiskAssessment(
        work_id=work_id,
        overall_risk=overall_risk,
        confidence=confidence,
        severity=severity,
        data_quality=data_quality,
        band=band,
        corroborating_families=tuple(families),
        layer_scores=layer_scores,
        reasons=tuple(reasons),
        narrative=build_narrative(reasons, len(families), confidence),
        escalated_by_rule=escalated_by,
    )


def build_narrative(
    reasons: Sequence[Reason], n_families: int, confidence: float
) -> str:
    """Plain-language summary for the evidence card.

    Template-generated, not model-generated. The copilot may rephrase this
    later, but the system must be able to explain itself with no LLM present,
    and the sentence must never assert wrongdoing.
    """
    if not reasons:
        return "No risk signals detected for this work."

    leading = "; ".join(r.text for r in reasons[:3])
    if n_families >= 2:
        support = (
            f"Corroborated across {n_families} independent evidence types "
            f"(confidence {confidence:.0%})."
        )
    else:
        support = (
            f"Based on a single type of evidence (confidence {confidence:.0%}); "
            "verification is needed before any conclusion."
        )
    return f"{leading}. {support} Flagged for review, not a finding of wrongdoing."


def entropy_of_agreement(outputs: Sequence[LayerOutput]) -> float:
    """How evenly the risk is spread across layers, 0-1.

    Near 0 means one layer drove everything; near 1 means many agreed. Fed to
    Block 13's fusion as a reliability signal, and exposed here so the
    contract does not change when that lands.
    """
    scores = [o.score for o in outputs if o.score > 0]
    total = sum(scores)
    if not scores or total <= 0 or len(scores) == 1:
        return 0.0
    shares = [s / total for s in scores]
    entropy = -sum(p * math.log(p) for p in shares if p > 0)
    return float(entropy / math.log(len(scores)))
