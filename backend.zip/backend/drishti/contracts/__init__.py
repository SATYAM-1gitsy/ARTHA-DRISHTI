"""The five seams. Freeze these before writing code against them.

    Seam A  gold      one row per work_id, consumed by every detector
    Seam B  layer     what a detector returns, identical across L0-L6
    Seam C  risk      fused assessment + evidence card, served by the API
    Seam D  api       REST response shapes (drishti.api.models)
    Seam E  labels    ground truth, and where it may not flow

Changing any of these is a three-part commit: the contract, the fixture, and
every producer and consumer -- landed together so main never goes red.
"""

from .gold import GOLD_COLUMNS, GOLD_FEATURES, REQUIRED_COLUMNS, validate_frame
from .labels import FraudLabel, LabelSource, assert_no_label_leakage
from .layer import EvidenceFamily, LayerOutput, Reason, Severity, validate_layer_frame
from .risk import Band, RiskAssessment, assess

__all__ = [
    "GOLD_COLUMNS",
    "GOLD_FEATURES",
    "REQUIRED_COLUMNS",
    "validate_frame",
    "EvidenceFamily",
    "LayerOutput",
    "Reason",
    "Severity",
    "validate_layer_frame",
    "Band",
    "RiskAssessment",
    "assess",
    "FraudLabel",
    "LabelSource",
    "assert_no_label_leakage",
]
