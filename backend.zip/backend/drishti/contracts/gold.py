"""Seam A -- the Gold feature-view contract.

One row per `work_id`. Every detector consumes this and nothing else, which is
what lets seven detection layers be written by two people in parallel without
touching each other's files.

Each column is declared with its dtype, its source, how it behaves when the
underlying data is missing, and whether it carries leakage risk. That last
field is not documentation for its own sake: `actual_completion_date` is
perfectly legitimate for an evaluation join and catastrophic as an input to a
delay model, and the only way to keep that straight across six people is to
make the model declare it.

Changing this contract is a three-part change -- the spec here, the fixture in
data/fixtures, and every producer or consumer -- landed in one commit so `main`
never goes red. See docs/adr/0003.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from enum import Enum
from typing import Any

__all__ = [
    "Leakage",
    "FeatureSpec",
    "GOLD_FEATURES",
    "GOLD_COLUMNS",
    "REQUIRED_COLUMNS",
    "PEER_GROUP_KEYS",
    "NUMERIC_FEATURES",
    "feature",
    "validate_frame",
    "missingness",
]


class Leakage(str, Enum):
    """Whether a column may be used as a model input, and when."""

    SAFE = "safe"
    # Known only after the outcome. Fine for evaluation joins, never an input
    # to a model predicting that outcome.
    POST_OUTCOME = "post_outcome"
    # Derived from another detector's output. Must not feed a model whose
    # prediction that detector also informs, or the two correlate by
    # construction rather than by evidence.
    DERIVED_FROM_DETECTOR = "derived_from_detector"
    # Ground truth. Never an input to anything except supervised training on
    # an explicit, documented split.
    GROUND_TRUTH = "ground_truth"


@dataclass(frozen=True)
class FeatureSpec:
    """One column of the Gold view."""

    name: str
    dtype: str
    description: str
    source: str
    missing_behavior: str
    leakage: Leakage = Leakage.SAFE
    nullable: bool = False
    required: bool = False
    peer_relative: bool = False
    numeric: bool = True

    def __post_init__(self) -> None:
        if not self.description or not self.source or not self.missing_behavior:
            raise ValueError(f"{self.name}: description, source and missing_behavior are mandatory")
        if self.required and self.nullable:
            raise ValueError(f"{self.name}: a required column cannot be nullable")

    @property
    def model_safe(self) -> bool:
        return self.leakage is Leakage.SAFE


def feature(
    name: str,
    dtype: str,
    description: str,
    source: str,
    missing_behavior: str,
    **kwargs: Any,
) -> FeatureSpec:
    """Terser constructor, so the registry below stays readable."""
    return FeatureSpec(
        name=name,
        dtype=dtype,
        description=description,
        source=source,
        missing_behavior=missing_behavior,
        **kwargs,
    )


# --------------------------------------------------------------------------
# The registry
# --------------------------------------------------------------------------
_ID = "identity"
_TX = "transactional records"
_DER = "derived at feature-build time"
_REF = "reference data"

GOLD_FEATURES: tuple[FeatureSpec, ...] = (
    # ---- identity and grouping keys ----
    feature("work_id", "int64", "Primary key. The scoring entity.", _ID, "row is rejected at ingest", required=True, numeric=False),
    feature("mp_id", "int64", "Recommending Member of Parliament.", _ID, "row quarantined", required=True, numeric=False),
    feature("agency_id", "int64", "Implementing agency executing the work.", _ID, "row quarantined", required=True, numeric=False),
    feature("district_id", "int64", "District authority that sanctioned the work.", _ID, "row quarantined", required=True, numeric=False),
    feature("vendor_id", "int64", "Payee on the largest payment, where identifiable.", _TX, "null; L3 vendor edges omitted for this work", nullable=True, numeric=False),
    feature("state", "string", "State or UT name, canonicalised.", _REF, "row quarantined", required=True, numeric=False),
    feature("constituency", "string", "Constituency name, canonicalised.", _REF, "null; MP-scope rules skip this work", nullable=True, numeric=False),

    # ---- peer-group keys: anomaly is relative to these, never global ----
    feature("sector", "string", "Sector, e.g. roads_bridges.", _REF, "falls back to 'unknown' peer group", required=True, numeric=False),
    feature("work_type", "string", "Work type within the sector.", _REF, "falls back to sector-level peers", required=True, numeric=False),
    feature("financial_year", "int64", "Fiscal year of sanction.", _TX, "row quarantined", required=True, numeric=False),

    # ---- financial ----
    feature("estimated_cost", "float64", "Cost estimated at recommendation, rupees.", _TX, "null; cost-ratio features become null", nullable=True),
    feature("sanctioned_cost", "float64", "Amount sanctioned by the district authority, rupees.", _TX, "row quarantined -- nothing is scorable without it", required=True),
    feature("expenditure_to_date", "float64", "Sum of payments made, rupees.", _DER, "0.0 when no payments exist", ),
    feature("quantity", "float64", "Physical quantity (metres, units, sq-m).", _TX, "null; unit_cost becomes null", nullable=True),
    feature("unit_cost", "float64", "sanctioned_cost / quantity.", _DER, "null when quantity is missing or zero", nullable=True),
    feature("unit_cost_vs_sor", "float64", "unit_cost / Schedule-of-Rates benchmark. NOTE: the benchmark is an ASSUMPTION (finding R-05) -- lead evidence with the percentile below.", _DER, "null when unit_cost or benchmark is missing", nullable=True),
    feature("unit_cost_peer_percentile", "float64", "Percentile of unit_cost within (sector, work_type, state) peers. The defensible cost signal.", _DER, "null when the peer group has fewer than 5 members", nullable=True, peer_relative=True),
    feature("cost_deviation_ratio", "float64", "expenditure_to_date / sanctioned_cost.", _DER, "0.0 when no expenditure"),
    feature("estimated_to_sanctioned_ratio", "float64", "sanctioned_cost / estimated_cost.", _DER, "null when estimated_cost is missing", nullable=True),

    # ---- execution ----
    feature("status", "string", "recommended | sanctioned | in_progress | completed | abandoned.", _TX, "defaults to 'sanctioned'", numeric=False),
    feature("progress_pct", "float64", "Latest reported physical progress, 0-100.", _TX, "0.0 when no progress update exists"),
    feature("spend_progress_gap", "float64", "expenditure percentage minus progress percentage. Positive = money ahead of work.", _DER, "computed from defaults; flagged in missingness"),
    feature("progress_velocity", "float64", "Progress percentage points per 30 days.", _DER, "0.0 with fewer than 2 updates"),
    feature("progress_acceleration", "float64", "Change in progress_velocity between the last two intervals.", _DER, "0.0 with fewer than 3 updates"),

    # ---- temporal ----
    feature("recommended_on", "datetime64[ns]", "Date the MP recommended the work.", _TX, "null; recommendation-window rule skipped", nullable=True, numeric=False),
    feature("sanction_date", "datetime64[ns]", "Date of sanction. Anchors every temporal feature.", _TX, "row quarantined", required=True, numeric=False),
    feature("expected_completion_date", "datetime64[ns]", "Target completion.", _TX, "derived from COMPLETION_WINDOW_DAYS (an assumption)", nullable=True, numeric=False),
    feature("actual_completion_date", "datetime64[ns]", "Actual completion, where reported.", _TX, "null for incomplete works", nullable=True, numeric=False, leakage=Leakage.POST_OUTCOME),
    feature("days_since_sanction", "float64", "Days from sanction to the scoring date.", _DER, "computed from sanction_date, always present"),
    feature("days_recommendation_to_sanction", "float64", "Recommendation-to-sanction lag.", _DER, "null when recommended_on is missing", nullable=True),
    feature("sanction_delay_peer_percentile", "float64", "Recommendation-to-sanction lag ranked within (sector, work_type, state) peers.", _DER, "null when the peer group is thinner than MIN_PEER_GROUP", nullable=True),
    feature("time_to_first_payment", "float64", "Days from sanction to first payment.", _DER, "null when no payment exists", nullable=True),
    feature("is_year_end_sanction", "int8", "1 when sanctioned in March, the closing month of the fiscal year.", _DER, "0"),
    feature("progress_roughness", "float64", "Mean absolute second difference of the progress series, span-normalised.", _DER, "null below three updates -- a two-point series has no shape", nullable=True),
    feature("progress_increment_cv", "float64", "Dispersion of progress increments, scaled by mean absolute increment.", _DER, "null below three updates, or when increments are all zero", nullable=True),
    feature("payment_interval_cv", "float64", "Coefficient of variation of gaps between payments.", _DER, "null below three payments -- one interval has no dispersion", nullable=True),
    feature("sanction_local_density", "float64", "Same-MP sanctions within 30 days, over the count expected if evenly spread.", _DER, "null when the MP has fewer than three works", nullable=True),
    feature("peer_survival_at_age", "float64", "Kaplan-Meier probability a comparable work is still incomplete at this age.", _DER, "null for completed works and thin peer groups", nullable=True),

    # ---- payment behaviour ----
    feature("n_payments", "int64", "Count of payments against the work.", _DER, "0"),
    feature("advance_ratio", "float64", "Advance payments / total payments.", _DER, "0.0 when no payments"),
    feature("payment_velocity", "float64", "Rupees disbursed per 30 days since sanction.", _DER, "0.0 when no payments"),
    feature("max_payment_gap_days", "float64", "Longest interval between consecutive payments.", _DER, "null with fewer than 2 payments", nullable=True),
    feature("has_pre_sanction_payment", "int8", "1 when any payment predates sanction_date.", _DER, "0"),

    # ---- network ----
    feature("agency_district_share", "float64", "Share of the district's works held by this agency.", _DER, "null when the district has fewer than 10 works", nullable=True, peer_relative=True),
    feature("agency_hhi", "float64", "Herfindahl-Hirschman index of agency concentration in the district.", _DER, "null when the district has fewer than 10 works", nullable=True, peer_relative=True),
    feature("agency_centrality", "float64", "Eigenvector centrality of the agency in the MP-agency-work graph.", _DER, "0.0 for isolated nodes"),
    feature("mp_agency_affinity", "float64", "Share of this MP's works routed to this agency.", _DER, "null when the MP has fewer than 5 works", nullable=True, peer_relative=True),
    feature("n_works_same_agency", "int64", "Works executed by this agency in this district and year.", _DER, "1"),

    # ---- geography ----
    feature("latitude", "float64", "Asset latitude.", _TX, "null; geo rules skipped and data_quality reduced", nullable=True),
    feature("longitude", "float64", "Asset longitude.", _TX, "null; geo rules skipped and data_quality reduced", nullable=True),
    feature("geo_in_district", "int8", "1 when the asset point lies inside the sanctioning district.", _DER, "null when coordinates are missing", nullable=True),
    feature("geo_method", "string", "postgis | bbox | unknown. bbox is an approximation and evidence must say so.", _DER, "'unknown'", numeric=False),
    feature("distance_to_district_centroid_km", "float64", "Haversine distance from the district centroid.", _DER, "null when coordinates are missing", nullable=True),

    # ---- text ----
    feature("description", "string", "Work description as recorded. Multilingual.", _TX, "empty string; L4 skips this work", numeric=False),
    feature("description_lang", "string", "Dominant script: en | hi | mixed | unknown.", _DER, "'unknown'", numeric=False),
    feature("description_length", "int64", "Character count after normalisation.", _DER, "0"),

    # ---- asset and photo evidence ----
    feature("photo_present", "int8", "1 when at least one asset photograph is recorded.", _TX, "0"),
    feature("phash", "string", "Perceptual hash of the primary photograph.", _TX, "null when no photo", nullable=True, numeric=False),
    feature("phash_duplicate_count", "int64", "Other works sharing this photograph's hash.", _DER, "0"),
    feature("exif_latitude", "float64", "Latitude from photograph EXIF.", _TX, "null", nullable=True),
    feature("exif_longitude", "float64", "Longitude from photograph EXIF.", _TX, "null", nullable=True),
    feature("exif_consistent", "int8", "1 when EXIF coordinates agree with the work location.", _DER, "null when either is missing", nullable=True),

    # ---- compliance context ----
    feature("is_sc_area", "int8", "Work located in a Scheduled Caste area.", _REF, "0, and flagged as unknown in missingness"),
    feature("is_st_area", "int8", "Work located in a Scheduled Tribe area.", _REF, "0, and flagged as unknown in missingness"),
    feature("mp_sc_share_pct", "float64", "Share of this MP's sanctioned value in SC areas.", _DER, "null when the MP has no sanctioned works", nullable=True),
    feature("mp_st_share_pct", "float64", "Share of this MP's sanctioned value in ST areas.", _DER, "null when the MP has no sanctioned works", nullable=True),

    # ---- data quality ----
    feature("n_missing_fields", "int64", "Count of null values across the optional columns.", _DER, "computed, always present"),
    feature("data_quality", "float64", "Completeness and reliability of this row's inputs, 0-1. Consumed by fusion; see contracts.risk.", _DER, "computed, always present"),
)

GOLD_COLUMNS: tuple[str, ...] = tuple(spec.name for spec in GOLD_FEATURES)
REQUIRED_COLUMNS: tuple[str, ...] = tuple(s.name for s in GOLD_FEATURES if s.required)
PEER_GROUP_KEYS: tuple[str, ...] = ("sector", "work_type", "state")
NUMERIC_FEATURES: tuple[str, ...] = tuple(
    s.name for s in GOLD_FEATURES if s.numeric and s.model_safe
)

_BY_NAME: dict[str, FeatureSpec] = {s.name: s for s in GOLD_FEATURES}


def spec_for(name: str) -> FeatureSpec:
    """Look up one column's contract."""
    try:
        return _BY_NAME[name]
    except KeyError:
        raise KeyError(
            f"{name!r} is not in the Gold contract. Add it to GOLD_FEATURES first "
            "-- inventing a column in one module hides it from everyone else."
        ) from None


def validate_frame(frame: Any, *, strict: bool = True) -> list[str]:
    """Check a DataFrame against the contract. Returns a list of problems.

    strict=True also rejects extra columns, which catches the failure this
    contract exists to prevent: a producer quietly adding a field that
    consumers cannot see and the fixture does not carry.
    """
    problems: list[str] = []
    columns = set(getattr(frame, "columns", []))

    missing = [c for c in GOLD_COLUMNS if c not in columns]
    if missing:
        problems.append(f"missing columns: {sorted(missing)}")

    if strict:
        extra = sorted(columns - set(GOLD_COLUMNS))
        if extra:
            problems.append(f"undeclared columns: {extra}")

    for name in REQUIRED_COLUMNS:
        if name in columns:
            try:
                nulls = int(frame[name].isna().sum())
            except Exception:  # noqa: BLE001 - not a pandas frame
                continue
            if nulls:
                problems.append(f"{name} is required but has {nulls} null values")

    return problems


def missingness(frame: Any) -> dict[str, float]:
    """Null fraction per optional column, for the data-quality score."""
    out: dict[str, float] = {}
    total = len(frame) if len(frame) else 1
    for spec in GOLD_FEATURES:
        if spec.required or spec.name not in getattr(frame, "columns", []):
            continue
        try:
            out[spec.name] = float(frame[spec.name].isna().sum()) / total
        except Exception:  # noqa: BLE001
            continue
    return out


def leakage_report() -> dict[str, list[str]]:
    """Columns grouped by leakage class, for the training-split guard."""
    report: dict[str, list[str]] = {}
    for spec in GOLD_FEATURES:
        report.setdefault(spec.leakage.value, []).append(spec.name)
    return report


def model_input_columns(exclude: Iterable[str] = ()) -> tuple[str, ...]:
    """Numeric columns a model may legitimately train on."""
    blocked = set(exclude)
    return tuple(n for n in NUMERIC_FEATURES if n not in blocked)
