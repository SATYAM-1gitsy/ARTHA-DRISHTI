"""Bronze: read the allocation file exactly as it is, and judge nothing.

The medallion rule is that Bronze never repairs anything. Every row lands with
its source row number and its original strings, so any later question about a
value can be traced back to the cell it came from. Repair belongs in Silver,
where it is recorded.

The one real dataset is `Allocated Limit for Honble MPs.xlsx`: a two-row
banner, 543 member rows, and a Grand Total footer. Its total reconciles to the
stated Rs 83,062,104,294.53 exactly, so the extract is internally consistent
even though four defects sit inside it (audit findings D-01 to D-05).

Validation separates two very different failures:

  *reject*  the row cannot be identified at all -- no member, no state, no
            constituency. Nothing downstream could use it.
  *accept with a flag*  the row identifies a real member but is missing an
            optional value. Rejecting these loses a genuine MP, which is worse
            than carrying a null. This is what happens to the Nanded row whose
            allocation is blank (D-01).

Silently imputing the missing value is not an option in either case.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pandas as pd

from ..config import settings

__all__ = [
    "BRONZE_COLUMNS",
    "RowIssue",
    "IngestResult",
    "read_allocation_file",
    "validate_rows",
]

BRONZE_COLUMNS: tuple[str, ...] = (
    "source_row",
    "sr_no",
    "state_raw",
    "mp_name_raw",
    "constituency_raw",
    "allocated_amount_raw",
    "row_hash",
)

# Column order in the source sheet. Positional because the header row carries
# a merged title rather than usable names.
_SOURCE_COLUMNS = ("sr_no", "state_raw", "mp_name_raw", "constituency_raw", "allocated_amount_raw")

# Row 0 is the merged title, row 1 the header. Data starts at row 2.
_HEADER_ROWS = 2
_GRAND_TOTAL = "grand total"


@dataclass(frozen=True)
class RowIssue:
    """One problem with one row."""

    source_row: int
    field: str
    code: str
    detail: str
    rejected: bool

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_row": self.source_row,
            "field": self.field,
            "code": self.code,
            "detail": self.detail,
            "rejected": self.rejected,
        }


@dataclass
class IngestResult:
    """What came out of Bronze, and what did not."""

    accepted: pd.DataFrame
    quarantined: pd.DataFrame
    issues: list[RowIssue] = field(default_factory=list)
    source_path: str = ""
    declared_total: float | None = None

    @property
    def n_accepted(self) -> int:
        return len(self.accepted)

    @property
    def n_quarantined(self) -> int:
        return len(self.quarantined)

    @property
    def flagged_issues(self) -> list[RowIssue]:
        """Problems on rows that were kept -- the ones easy to forget about."""
        return [i for i in self.issues if not i.rejected]

    def reconciles(self, tolerance: float = 0.01) -> bool | None:
        """Whether the accepted rows sum to the file's own Grand Total.

        A cheap, powerful check: if the sum disagrees, the extract is partial
        or the parse is wrong, and nothing downstream should be trusted.
        """
        if self.declared_total is None:
            return None
        total = float(self.accepted["allocated_amount_raw"].dropna().sum())
        return abs(total - self.declared_total) <= tolerance


def _row_hash(values: tuple[Any, ...]) -> str:
    """Stable identity for a source row, so re-ingesting is idempotent."""
    payload = "|".join("" if v is None else str(v) for v in values)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def read_allocation_file(path: Path | None = None) -> tuple[pd.DataFrame, float | None]:
    """Read the sheet into a Bronze frame. No cleaning, no coercion beyond
    parsing the amount, which is needed to find the Grand Total footer."""
    target = Path(path or (settings.paths.raw / "Allocated Limit for Honble MPs.xlsx"))
    if not target.is_file():
        raise FileNotFoundError(
            f"{target} not found. The allocation file is the project's only real data; "
            "it belongs in data/raw/."
        )

    sheet = pd.read_excel(target, header=None)
    if sheet.shape[1] < len(_SOURCE_COLUMNS):
        raise ValueError(
            f"{target.name} has {sheet.shape[1]} columns, expected at least "
            f"{len(_SOURCE_COLUMNS)}. The layout has changed."
        )

    body = sheet.iloc[_HEADER_ROWS :, : len(_SOURCE_COLUMNS)].copy()
    body.columns = list(_SOURCE_COLUMNS)
    body.insert(0, "source_row", body.index.to_numpy() + 1)

    # The footer carries the file's own total. Pull it out before it becomes
    # a member row, and keep it as an independent reconciliation check.
    is_total = body["sr_no"].astype(str).str.strip().str.lower() == _GRAND_TOTAL
    declared_total: float | None = None
    if is_total.any():
        raw_total = pd.to_numeric(body.loc[is_total, "allocated_amount_raw"], errors="coerce")
        if raw_total.notna().any():
            declared_total = float(raw_total.dropna().iloc[0])
        body = body.loc[~is_total]

    body["allocated_amount_raw"] = pd.to_numeric(body["allocated_amount_raw"], errors="coerce")
    for column in ("state_raw", "mp_name_raw", "constituency_raw"):
        body[column] = body[column].astype("string").str.strip()

    body["row_hash"] = [
        _row_hash(tuple(row))
        for row in body[list(_SOURCE_COLUMNS)].itertuples(index=False, name=None)
    ]
    return body[list(BRONZE_COLUMNS)].reset_index(drop=True), declared_total


def validate_rows(bronze: pd.DataFrame) -> IngestResult:
    """Split Bronze into accepted and quarantined, recording every issue."""
    issues: list[RowIssue] = []
    reject_rows: set[int] = set()

    def record(row: int, field_name: str, code: str, detail: str, rejected: bool) -> None:
        issues.append(RowIssue(int(row), field_name, code, detail, rejected))
        if rejected:
            reject_rows.add(int(row))

    for record_row in bronze.itertuples(index=False):
        source_row = int(record_row.source_row)

        # --- identity: without these the row is unusable ---
        for column, value in (
            ("mp_name_raw", record_row.mp_name_raw),
            ("state_raw", record_row.state_raw),
            ("constituency_raw", record_row.constituency_raw),
        ):
            if pd.isna(value) or not str(value).strip():
                record(source_row, column, "missing_identifier", f"{column} is empty", True)

        # --- allocation: missing is a real gap, not a reason to drop an MP ---
        amount = record_row.allocated_amount_raw
        if pd.isna(amount):
            record(
                source_row,
                "allocated_amount_raw",
                "missing_allocation",
                "no allocated amount recorded; kept with a null rather than imputed",
                False,
            )
        elif float(amount) < 0:
            record(
                source_row,
                "allocated_amount_raw",
                "negative_allocation",
                f"negative allocation {amount}",
                True,
            )

        if pd.isna(record_row.sr_no):
            record(source_row, "sr_no", "missing_serial", "no serial number", False)

    rejected_mask = bronze["source_row"].astype(int).isin(reject_rows)
    return IngestResult(
        accepted=bronze.loc[~rejected_mask].reset_index(drop=True),
        quarantined=bronze.loc[rejected_mask].reset_index(drop=True),
        issues=issues,
    )


def ingest(path: Path | None = None) -> IngestResult:
    """Read and validate in one step."""
    bronze, declared_total = read_allocation_file(path)
    result = validate_rows(bronze)
    result.source_path = str(path or (settings.paths.raw / "Allocated Limit for Honble MPs.xlsx"))
    result.declared_total = declared_total
    return result
