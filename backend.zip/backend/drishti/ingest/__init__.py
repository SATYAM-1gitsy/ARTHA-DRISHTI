"""Bronze: read sources as they are, judge nothing, repair nothing."""

from .allocation import IngestResult, RowIssue, ingest, read_allocation_file, validate_rows

__all__ = ["IngestResult", "RowIssue", "ingest", "read_allocation_file", "validate_rows"]
