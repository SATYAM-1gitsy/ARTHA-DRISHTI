"""L3 -- network structure, in numpy.

Fraud is relational. A work is not only a row: it sits in a network of the
member who recommended it, the agency that executed it and the payee that
received the money, and some failure modes exist *only* in that structure.

## Written as general structural analysis, deliberately

`vendor_round_tripping` is a **held-out** pattern, and this module must not be
a round-tripping detector. Writing one would make recall on it ~1.0 by
construction and destroy one of the five figures in this project that carry a
detection claim (finding R-03) -- exactly the reason L0 omits three rules the
Blueprint asked for.

So the features here are generic properties of a network: concentration,
degree, how closed a neighbourhood is, community density. If a closed payee
ring happens to score high on "closed neighbourhood", that is **generalisation**
-- a general measure catching a pattern nobody aimed at -- and it is precisely
what the held-out set exists to reveal. `FORBIDDEN_TARGETS` is asserted by a
test so the discipline survives contact with a deadline.

## Classical first, and possibly last

ADR-0002: a GNN must beat explainable classical analytics to earn a place.
These are the analytics it has to beat -- HHI, degree, local clustering,
label-propagation communities -- computed in numpy, with no networkx, because
the detection core runs on numpy and pandas alone (ADR-0001).

## Reading only Seam A

The graph is built from `mp_id`, `agency_id`, `vendor_id` and `district_id` in
the Gold view. `vendor_id` is the payee on a work's largest payment, so the
edge is a proxy for the full payment graph rather than the whole of it. That
is a real limitation and it is stated rather than papered over: a ring that
moves money through a work's *smaller* payments is invisible here.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from ..contracts.layer import EvidenceFamily, LayerOutput, Reason, Severity
from ..domain import held_out_patterns
from ..util import ecdf_tail, minmax

__all__ = [
    "LAYER",
    "FORBIDDEN_TARGETS",
    "GRAPH_FEATURES",
    "OUTLIER_QUANTILE",
    "GraphMetrics",
    "build_metrics",
    "label_propagation",
    "run",
]

log = logging.getLogger(__name__)

LAYER = "graph"

# No graph feature may be designed to detect one of these.
FORBIDDEN_TARGETS: frozenset[str] = frozenset(p.name for p in held_out_patterns())

# Structural quantities, each a generic property of a network.
GRAPH_FEATURES: tuple[str, ...] = (
    "vendor_agency_share",
    "vendor_n_agencies",
    "vendor_n_districts",
    "vendor_clustering",
    "agency_vendor_hhi",
    "community_density",
    "mp_agency_vendor_triangle",
)

FEATURE_LABEL: dict[str, str] = {
    "vendor_agency_share": "this payee's share of the agency's works",
    "vendor_n_agencies": "number of agencies this payee works with",
    "vendor_n_districts": "number of districts this payee operates in",
    "vendor_clustering": "how closed this payee's network neighbourhood is",
    "agency_vendor_hhi": "concentration of the agency's payees",
    "community_density": "density of the community this work sits in",
    "mp_agency_vendor_triangle": "repeat member-agency-payee combination",
}

# A work is a finding when its structural score is in the top slice of the
# population. Rank-based for the same reason as L1: an absolute threshold on a
# structural score means different things in a sparse and a dense graph.
OUTLIER_QUANTILE = 0.03
MAX_REASONS = 3


@dataclass
class GraphMetrics:
    """Per-work structural features, plus what the graph looked like."""

    frame: pd.DataFrame
    n_vendors: int = 0
    n_agencies: int = 0
    n_communities: int = 0
    notes: list[str] = field(default_factory=list)

    def describe(self) -> str:
        return (
            f"{self.n_agencies:,} agencies, {self.n_vendors:,} payees, "
            f"{self.n_communities:,} communities"
        )


# --------------------------------------------------------------------------
# graph construction
# --------------------------------------------------------------------------
def _vendor_vendor_projection(
    vendor_codes: np.ndarray, agency_codes: np.ndarray, n_vendors: int, n_agencies: int
) -> np.ndarray:
    """Payees connected when they share an agency.

    Returns a dense vendor-by-vendor co-occurrence count. Dense is affordable
    at the current 2,279 payees -- a 20 MB matrix, and every consumer of it is
    a BLAS call. A national deployment with tens of thousands would need a
    sparse representation, which is a scaling concern rather than a
    correctness one.
    """
    incidence = np.zeros((n_vendors, n_agencies), dtype=np.float32)
    np.add.at(incidence, (vendor_codes, agency_codes), 1.0)
    projection = incidence @ incidence.T
    np.fill_diagonal(projection, 0.0)
    return projection


def _local_clustering(adjacency: np.ndarray) -> np.ndarray:
    """Local clustering coefficient per node.

    The fraction of a node's neighbours that are themselves connected. A payee
    embedded in a tightly closed group scores near 1; one serving many
    unrelated agencies scores near 0.

    This is a generic structural measure. It is not a ring detector, and it
    fires on any closed neighbourhood whatever produced it.
    """
    binary = (adjacency > 0).astype(np.float32)
    degree = binary.sum(axis=1)
    # Triangles through each node: the diagonal of A^3, halved.
    #
    # Written as a matmul rather than `np.einsum("ij,jk,ki->i", A, A, A)`.
    # einsum without `optimize` contracts three operands in one naive pass and
    # never reaches BLAS, and this is the project's single hottest line:
    # measured on the real payee graph (2,279 nodes) it costs 28.2s against
    # 0.065s here, bit-for-bit identical output -- 436x, and roughly two thirds
    # of the whole L3 layer. `diag(A @ A @ A)` is `sum(A * (A @ A), axis=1)`,
    # which is one BLAS call plus a row sum.
    triangles = np.sum(binary * (binary @ binary), axis=1) / 2.0
    possible = degree * (degree - 1) / 2.0
    with np.errstate(divide="ignore", invalid="ignore"):
        coefficient = np.where(possible > 0, triangles / possible, 0.0)
    return np.nan_to_num(coefficient, nan=0.0)


def label_propagation(
    adjacency: np.ndarray, iterations: int = 20, seed: int = 42
) -> np.ndarray:
    """Community labels by label propagation.

    Chosen over Louvain because it needs no external dependency and no
    resolution parameter to tune. Each node repeatedly takes the most common
    label among its neighbours; ties break by lowest label so the result is
    deterministic, which matters more here than modularity quality.
    """
    n = adjacency.shape[0]
    if n == 0:
        return np.zeros(0, dtype=int)
    labels = np.arange(n)
    neighbours = [np.flatnonzero(adjacency[i]) for i in range(n)]
    rng = np.random.default_rng(seed)

    for _ in range(iterations):
        changed = False
        for node in rng.permutation(n):
            near = neighbours[node]
            if not len(near):
                continue
            counts = np.bincount(labels[near])
            best = int(np.argmax(counts))
            if labels[node] != best:
                labels[node] = best
                changed = True
        if not changed:
            break
    return labels


def build_metrics(features: pd.DataFrame) -> GraphMetrics:
    """Compute every structural feature from the Seam A columns."""
    frame = features[["work_id", "mp_id", "agency_id", "vendor_id", "district_id"]].copy()
    known = frame["vendor_id"].notna()

    out = pd.DataFrame(index=frame.index)
    for column in GRAPH_FEATURES:
        out[column] = np.nan

    if not known.any():
        return GraphMetrics(frame=out, notes=["no payee information in the Gold view"])

    linked = frame.loc[known].copy()
    vendor_codes, vendor_index = pd.factorize(linked["vendor_id"])
    agency_codes, agency_index = pd.factorize(linked["agency_id"])

    # ---- agency-level concentration ----
    pair_counts = linked.groupby(["agency_id", "vendor_id"]).size().rename("n")
    agency_totals = linked.groupby("agency_id").size().rename("total")
    pairs = pair_counts.reset_index().merge(agency_totals.reset_index(), on="agency_id")
    pairs["share"] = pairs["n"] / pairs["total"]

    hhi = (
        pairs.assign(sq=lambda f: f["share"] ** 2)
        .groupby("agency_id")["sq"]
        .sum()
        .rename("agency_vendor_hhi")
    )

    # ---- payee reach ----
    vendor_agencies = linked.groupby("vendor_id")["agency_id"].nunique()
    vendor_districts = linked.groupby("vendor_id")["district_id"].nunique()

    # ---- payee neighbourhood closure ----
    projection = _vendor_vendor_projection(
        vendor_codes, agency_codes, len(vendor_index), len(agency_index)
    )
    clustering = _local_clustering(projection)
    communities = label_propagation(projection)

    sizes = pd.Series(communities).value_counts()
    # Density here is a share of the payee population, so "this payee sits in a
    # community holding 3% of all payees" is directly readable.
    density = pd.Series(communities).map(sizes) / max(len(vendor_index), 1)
    clustering_by_vendor = pd.Series(clustering, index=vendor_index)
    density_by_vendor = pd.Series(density.to_numpy(), index=vendor_index)

    # ---- repeat member-agency-payee combination ----
    triangle = (
        linked.groupby(["mp_id", "agency_id", "vendor_id"]).size().rename("triangle")
    )

    joined = linked.merge(
        pairs[["agency_id", "vendor_id", "share"]], on=["agency_id", "vendor_id"], how="left"
    ).merge(hhi.reset_index(), on="agency_id", how="left").merge(
        triangle.reset_index(), on=["mp_id", "agency_id", "vendor_id"], how="left"
    )
    joined.index = linked.index

    out.loc[known, "vendor_agency_share"] = joined["share"].to_numpy()
    out.loc[known, "agency_vendor_hhi"] = joined["agency_vendor_hhi"].to_numpy()
    out.loc[known, "mp_agency_vendor_triangle"] = joined["triangle"].to_numpy()
    out.loc[known, "vendor_n_agencies"] = (
        linked["vendor_id"].map(vendor_agencies).to_numpy()
    )
    out.loc[known, "vendor_n_districts"] = (
        linked["vendor_id"].map(vendor_districts).to_numpy()
    )
    out.loc[known, "vendor_clustering"] = (
        linked["vendor_id"].map(clustering_by_vendor).to_numpy()
    )
    out.loc[known, "community_density"] = (
        linked["vendor_id"].map(density_by_vendor).to_numpy()
    )

    metrics = GraphMetrics(
        frame=out,
        n_vendors=len(vendor_index),
        n_agencies=len(agency_index),
        n_communities=int(pd.Series(communities).nunique()),
    )
    if not known.all():
        metrics.notes.append(
            f"{int((~known).sum()):,} works have no recorded payee and are not scored"
        )
    return metrics


# --------------------------------------------------------------------------
# scoring
# --------------------------------------------------------------------------
# Structural features where the *low* tail is the interesting one. A payee
# serving very few agencies is unusual in a way that serving many is not.
_LOW_TAIL_IS_ANOMALOUS = {"vendor_n_agencies", "vendor_n_districts"}


def _score(metrics: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    """ECOD-style score over the structural features."""
    columns = [c for c in GRAPH_FEATURES if c in metrics.columns]
    values = np.zeros((len(metrics), len(columns)), dtype=float)
    tails = np.ones_like(values)

    for index, column in enumerate(columns):
        series = metrics[column].astype(float)
        filled = series.fillna(series.median() if series.notna().any() else 0.0)
        values[:, index] = filled.to_numpy()
        tails[:, index] = ecdf_tail(values[:, index])

    contributions = -np.log(tails)
    return minmax(contributions.sum(axis=1)), tails


def _reason(
    column: str, value: float, tail: float, median: float, n_vendors: int
) -> Reason:
    label = FEATURE_LABEL.get(column, column.replace("_", " "))
    direction = "unusually low" if column in _LOW_TAIL_IS_ANOMALOUS else "unusually high"

    if column == "vendor_agency_share":
        detail = f"{value * 100:.0f}% of the agency's works go to this payee"
    elif column == "vendor_clustering":
        detail = (
            f"every other payee in its neighbourhood also transacts with the same "
            f"agencies (closure {value:.2f})"
            if value > 0.8
            else f"neighbourhood closure {value:.2f} against a median of {median:.2f}"
        )
    elif column in ("vendor_n_agencies", "vendor_n_districts"):
        detail = f"{value:.0f} against a median of {median:.0f} across {n_vendors:,} payees"
    else:
        detail = f"{value:.3f} against a median of {median:.3f}"

    return Reason(
        code=f"network_outlier:{column}",
        text=(
            f"The {label} is {direction}: {detail}. "
            f"In the top {tail * 100:.1f}% of the payee network. "
            "A concentrated relationship is not itself improper -- confirm how "
            "the work was allotted before drawing any conclusion."
        ),
        family=EvidenceFamily.NETWORK,
        severity=Severity.MEDIUM if tail > 0.005 else Severity.HIGH,
        provenance="peer_derived",
        factors={
            "feature": column,
            "value": round(float(value), 4),
            "network_median": round(float(median), 4),
            "tail_probability": round(float(tail), 5),
            "n_payees_in_network": int(n_vendors),
        },
    )


def run(features: pd.DataFrame, ctx: Any = None) -> list[LayerOutput]:
    """Seam B: one LayerOutput per work."""
    if features.empty:
        return []

    required = {"mp_id", "agency_id", "vendor_id", "district_id"}
    if not required.issubset(features.columns):
        log.warning("Gold view lacks %s -- L3 emits zeros", required - set(features.columns))
        return [
            LayerOutput(work_id=int(w), layer=LAYER, score=0.0, confidence=0.0)
            for w in features["work_id"]
        ]

    metrics = build_metrics(features)
    scores, tails = _score(metrics.frame)
    cutoff = float(np.quantile(scores, 1.0 - OUTLIER_QUANTILE)) if len(scores) else 1.0

    columns = [c for c in GRAPH_FEATURES if c in metrics.frame.columns]
    medians = metrics.frame[columns].astype(float).median()
    # Read the structural features once as an array. The reason loop below
    # used `metrics.frame.iloc[pos][col]`, which materialises a whole row as a
    # Series for a single cell -- twice per reason, on every flagged work.
    metric_values = metrics.frame[columns].to_numpy(dtype=float, na_value=np.nan)
    median_by_column = [float(medians[column]) for column in columns]
    has_payee = features["vendor_id"].notna().to_numpy()
    quality = features["data_quality"].to_numpy(dtype=float)
    work_ids = features["work_id"].to_numpy()

    outputs: list[LayerOutput] = []
    for position in range(len(features)):
        work_id = int(work_ids[position])

        # A work with no recorded payee has no network position. That is a
        # gap in the evidence, not an absence of risk, so it scores zero at
        # low confidence rather than zero at high confidence.
        if not has_payee[position]:
            outputs.append(
                LayerOutput(
                    work_id=work_id,
                    layer=LAYER,
                    score=0.0,
                    confidence=0.2,
                    data_quality=float(quality[position]),
                    factors={"reason": "no payee recorded for this work"},
                )
            )
            continue

        score = float(scores[position])
        if score < cutoff:
            outputs.append(
                LayerOutput(
                    work_id=work_id,
                    layer=LAYER,
                    score=0.0,
                    confidence=0.75,
                    data_quality=float(quality[position]),
                    factors={"n_payees_in_network": metrics.n_vendors},
                )
            )
            continue

        ranked = sorted(
            ((j, float(tails[position, j])) for j in range(len(columns))),
            key=lambda pair: pair[1],
        )
        reasons = [
            _reason(
                columns[j],
                float(metric_values[position, j]),
                tail,
                median_by_column[j],
                metrics.n_vendors,
            )
            for j, tail in ranked[:MAX_REASONS]
            if not np.isnan(metric_values[position, j])
        ]
        outputs.append(
            LayerOutput(
                work_id=work_id,
                layer=LAYER,
                score=score if reasons else 0.0,
                confidence=0.75,
                data_quality=float(quality[position]),
                reasons=tuple(reasons),
                factors={
                    "n_payees_in_network": metrics.n_vendors,
                    "n_communities": metrics.n_communities,
                },
            )
        )
    return outputs
