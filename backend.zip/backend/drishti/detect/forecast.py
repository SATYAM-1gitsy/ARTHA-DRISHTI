"""L5 -- temporal structure: survival and rhythm.

Two of the five held-out patterns are temporal, `year_end_bunching` and
`progress_reversal`, which makes this the layer most at risk of quietly
becoming a targeted detector. Nothing here is written against either. The
features are general time-series and point-process statistics -- second
differences, coefficients of variation, a Ripley-style local density and a
Kaplan-Meier curve -- chosen because they are standard, and `features.temporal`
records the specific temptations declined.

If a work whose progress goes backwards scores high on *roughness*, or a work
sanctioned in a fiscal-year rush scores high on *local density*, that is a
general measure catching a specific pattern. It is what held-out evaluation
exists to reveal, and the same argument L3 made for networks (ADR-0011).

Two signals, deliberately different in kind:

  survival    Kaplan-Meier probability that a comparable work is still
              incomplete at this age. Directly interpretable -- a value of 0.20
              means only a fifth of peers ran this long -- and it needs no
              outlier machinery, only a rank gate.
  rhythm      ECOD over the shape statistics within peer groups. Catches works
              whose *pattern* of activity is unlike their peers, whatever the
              absolute values.

ADR-0002 rejected recurrent models here: a work carries 6-12 events, measured
as a median of 4 progress updates and 3 payments. Nothing in this module would
be improved by a sequence model, and a sequence model over four points would be
presentation rather than engineering.
"""

from __future__ import annotations

import logging
import math
from typing import Any

import numpy as np
import pandas as pd

from ..contracts.layer import EvidenceFamily, LayerOutput, Reason, Severity
from ..domain import held_out_patterns
from ..util import ecod_scores, to_jsonable

__all__ = [
    "FORBIDDEN_TARGETS",
    "L5_FEATURES",
    "LAYER",
    "OUTLIER_QUANTILE",
    "SURVIVAL_QUANTILE",
    "run",
]

log = logging.getLogger(__name__)

# `forecast` is the Seam B slot name, fixed in Block 2. Survival analysis is
# time-to-event forecasting, so the name is honest for the load-bearing half of
# this layer even though the rhythm half is anomaly detection.
LAYER = "forecast"

# Patterns no feature or threshold here may be designed around. Asserted by a
# test rather than left to memory.
FORBIDDEN_TARGETS: frozenset[str] = frozenset(p.name for p in held_out_patterns())

# The shape statistics, minus survival which is handled on its own terms.
# `is_year_end_sanction` exists in the Gold view and is deliberately excluded:
# it names a calendar position, and a layer that must not detect year-end
# bunching has no business reading one.
L5_FEATURES: tuple[str, ...] = (
    "progress_roughness",
    "progress_increment_cv",
    "payment_interval_cv",
    "sanction_local_density",
)

# Rank-based, like L1 and L3. An absolute tail threshold silently disables the
# layer for narrow peer groups, because `ecdf_tail` floors at 1/group_size.
OUTLIER_QUANTILE = 0.03

# The share of works with the *lowest* peer survival that count as running
# beyond their peers. Rank-based, not an absolute survival probability, and
# this was a bug before it was a decision: an absolute cut at 0.02 fired on
# nothing at all, because the Kaplan-Meier curve bottoms out at 0.199 on this
# population. That is the Block 8 lesson repeating -- an absolute tail
# threshold silently disables a layer when the estimator cannot reach it.
# Gate on rank and the layer keeps working whatever the curve looks like.
SURVIVAL_QUANTILE = 0.02

MIN_GROUP_SIZE = 30
PEER_KEYS = ("sector", "work_type")


def _survival_reason(survival: float, age_days: float) -> Reason:
    return Reason(
        code="running_beyond_peers",
        text=(
            f"Still incomplete {age_days:.0f} days after sanction, where only "
            f"{survival:.1%} of comparable works were still running. A long "
            "run is not itself improper -- it may reflect scope, terrain or "
            "seasonal access -- but it is the point at which the record should "
            "explain itself."
        ),
        family=EvidenceFamily.TEMPORAL,
        severity=Severity.MEDIUM,
        provenance="peer_derived",
        factors={"peer_survival_at_age": round(survival, 4), "age_days": round(age_days, 1)},
    )


_RHYTHM_TEXT = {
    "progress_roughness": (
        "Reported progress moves unevenly compared with similar works "
        "(roughness {value:.2f} against a peer median of {median:.2f}). "
        "Irregular reporting is not itself irregular work."
    ),
    "progress_increment_cv": (
        "Progress arrives in uneven steps compared with similar works "
        "({value:.2f} against a peer median of {median:.2f})."
    ),
    "payment_interval_cv": (
        "Payments are spaced unevenly compared with similar works "
        "({value:.2f} against a peer median of {median:.2f}); the gaps cluster "
        "rather than following a schedule."
    ),
    "sanction_local_density": (
        "This sanction sits in a cluster of the same member's sanctions -- "
        "{value:.1f} times as many within a month as an even spread would give. "
        "Clustering is not itself improper and may reflect a funding release."
    ),
}


def _rhythm_reason(column: str, value: float, median: float) -> Reason:
    return Reason(
        code=f"temporal_{column}",
        text=_RHYTHM_TEXT[column].format(value=value, median=median),
        family=EvidenceFamily.TEMPORAL,
        severity=Severity.LOW,
        provenance="peer_derived",
        factors={column: round(float(value), 4), "peer_median": round(float(median), 4)},
    )


def run(features: pd.DataFrame, ctx: Any = None) -> list[LayerOutput]:
    """Seam B: one LayerOutput per work, including the silent ones.

    Reads only the Gold view and never touches ground truth.
    """
    if features.empty:
        return []

    available = [column for column in L5_FEATURES if column in features.columns]
    has_survival = "peer_survival_at_age" in features.columns
    if not available and not has_survival:
        log.warning("no L5 features in the Gold view -- layer emits zeros")
        return [
            LayerOutput(work_id=int(w), layer=LAYER, score=0.0, confidence=0.0)
            for w in features["work_id"]
        ]

    indexed = features.set_index("work_id", drop=False)
    scores = pd.Series(0.0, index=indexed.index)
    confidences = pd.Series(0.2, index=indexed.index)
    reasons: dict[int, list[Reason]] = {}
    factors: dict[int, dict[str, Any]] = {}

    # ---- survival ----
    if has_survival:
        survival = pd.to_numeric(indexed["peer_survival_at_age"], errors="coerce")
        age = pd.to_numeric(indexed.get("days_since_sanction"), errors="coerce")
        observed = survival.dropna()
        cutoff = (
            float(np.quantile(observed, SURVIVAL_QUANTILE)) if len(observed) else 0.0
        )
        flagged = survival.notna() & (survival <= cutoff)
        for work_id in indexed.index[flagged]:
            work_id = int(work_id)
            value = float(survival.loc[work_id])
            # Deeper into the tail scores higher, scaled against the cutoff so
            # the strongest survival evidence available still reads as strong.
            scores.loc[work_id] = float(
                min(1.0, 1.0 - 0.5 * value / cutoff) if cutoff > 0 else 1.0
            )
            confidences.loc[work_id] = 0.75
            reasons.setdefault(work_id, []).append(
                _survival_reason(value, float(age.loc[work_id]) if age is not None else 0.0)
            )
            factors.setdefault(work_id, {})["peer_survival_at_age"] = round(value, 4)

    # ---- rhythm ----
    if available:
        keys = [k for k in PEER_KEYS if k in indexed.columns]
        grouping = indexed.groupby(keys, sort=False) if keys else [((), indexed)]
        for _, members in grouping:
            if len(members) < MIN_GROUP_SIZE:
                continue
            matrix = members[available].astype(float)
            # Impute to the column median so a work with one missing statistic
            # is still scored on the rest, and record how much was invented.
            medians = matrix.median()
            imputed = matrix.isna()
            filled = matrix.fillna(medians)
            if filled.isna().all().all():
                continue

            filled_values = filled.to_numpy(dtype=float)
            imputed_mask = imputed.to_numpy(dtype=bool)
            median_by_column = [float(medians[column]) for column in available]

            ensemble = ecod_scores(filled_values)
            if not len(ensemble):
                continue
            cutoff = float(np.quantile(ensemble, 1.0 - OUTLIER_QUANTILE))
            completeness = 1.0 - imputed_mask.mean(axis=1)
            size_confidence = min(1.0, math.log10(max(len(members), 2)) / math.log10(200))

            for position, work_id in enumerate(members.index):
                work_id = int(work_id)
                if ensemble[position] < cutoff:
                    continue
                # Explain with the statistic furthest from its peer median.
                # Read from the array, not `filled.iloc[pos][col]`, which built
                # a Series per cell -- three times per candidate column.
                deviations = [
                    (
                        column,
                        float(filled_values[position, j]),
                        median_by_column[j],
                        abs(float(filled_values[position, j]) - median_by_column[j]),
                    )
                    for j, column in enumerate(available)
                    if not imputed_mask[position, j]
                ]
                if not deviations:
                    continue
                deviations.sort(key=lambda row: -row[3])
                column, value, median, _ = deviations[0]

                rhythm_score = float(ensemble[position])
                scores.loc[work_id] = max(float(scores.loc[work_id]), rhythm_score)
                confidences.loc[work_id] = max(
                    float(confidences.loc[work_id]),
                    float(size_confidence * completeness[position]),
                )
                reasons.setdefault(work_id, []).append(
                    _rhythm_reason(column, value, median)
                )
                factors.setdefault(work_id, {})[column] = round(value, 4)

    data_quality = pd.to_numeric(
        indexed.get("data_quality", pd.Series(1.0, index=indexed.index)), errors="coerce"
    ).fillna(1.0)

    # Resolve the three per-work lookups once. Indexing a Series by label
    # inside the output loop repeated the same index resolution 3x per work.
    score_by_work = scores.to_dict()
    confidence_by_work = confidences.to_dict()
    quality_by_work = data_quality.to_dict()

    outputs: list[LayerOutput] = []
    for work_id in indexed.index:
        work_id = int(work_id)
        outputs.append(
            LayerOutput(
                work_id=work_id,
                layer=LAYER,
                score=float(min(1.0, max(0.0, score_by_work[work_id]))),
                confidence=float(min(1.0, max(0.0, confidence_by_work[work_id]))),
                data_quality=float(quality_by_work[work_id]),
                reasons=tuple(reasons.get(work_id, ())),
                factors=to_jsonable(factors.get(work_id, {})),
            )
        )
    return outputs
