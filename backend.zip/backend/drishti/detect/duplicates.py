"""L4 -- duplicate-work detection across languages.

The strongest deep-learning case in the project (ADR-0002), for a specific
reason: the same physical work is routinely recorded twice in different
languages, and lexical matching scores those pairs at roughly 0.04. No amount
of string comparison finds them. A multilingual bi-encoder does.

Measured in Block 1c on a hand-written labelled corpus that is **independent
of the generator**: semantic ROC-AUC 0.939 against a lexical baseline of 0.486
-- worse than chance. That corpus is the honest measurement of this
capability; the pipeline's own `duplicate_work` recall is a rule-visible
figure and only a pipeline check.

## Three signals, not one

Text similarity alone must never decide duplication. "Boundary wall for the
primary school" and "boundary wall for the crematorium" share almost every
word and are different works. A pair is scored on semantic similarity,
lexical overlap, geographic proximity, cost similarity and timing -- and the
evidence card cites the twin so a reviewer can judge for themselves.

## Blocking

Comparing 19,817 works pairwise is 196 million comparisons. Candidates are
blocked by district first, which is where a duplicated work almost always
sits, reducing that to a few hundred thousand. The cost is real and stated:
**a duplicate split across two districts will be missed.** Widening the block
is a later trade against runtime, not an oversight.
"""

from __future__ import annotations

import logging
from collections.abc import Sequence
from dataclasses import dataclass, field
from itertools import combinations
from typing import Any

import numpy as np
import pandas as pd

from ..contracts.layer import EvidenceFamily, LayerOutput, Reason, Severity
from ..textsim import TfidfLite, token_set_ratio
from ..util import DisjointSet, haversine_km

__all__ = [
    "LAYER",
    "PairScore",
    "WEIGHTS",
    "DUPLICATE_THRESHOLD",
    "MAX_BLOCK_SIZE",
    "block_candidates",
    "embed_descriptions",
    "score_pairs",
    "run",
]

log = logging.getLogger(__name__)

LAYER = "duplicate"

# Weights over the five signals. Semantic leads, but it is deliberately less
# than half: a pair that agrees on text and nothing else should not reach the
# threshold on its own.
WEIGHTS: dict[str, float] = {
    "semantic": 0.40,
    "lexical": 0.15,
    "geographic": 0.20,
    "financial": 0.15,
    "temporal": 0.10,
}

# Above this a pair is reported. **Backend-specific, and it has to be.**
#
# Sparse TF-IDF puts unrelated descriptions near 0; dense embeddings put them
# near 0.45 (measured median in-block similarity: 0.453). One threshold across
# both is meaningless -- running the bi-encoder at the TF-IDF threshold flagged
# 2,086 works at 8.7% precision, because 0.62 sits below the median.
#
# Measured on 210 injected duplicates, one third of them cross-language:
#
#   backend      threshold   recall   precision      F1
#   TF-IDF            0.62    69.0%       25.3%   0.370
#   bi-encoder        0.70    67.6%       30.0%   0.415
#   bi-encoder        0.75    51.4%       53.7%   0.526   <- best balanced
#   bi-encoder        0.80    37.1%       79.6%   0.506
#
# At matched recall the bi-encoder is the better instrument (30.0% vs 25.3%),
# and it reaches recall TF-IDF cannot: 86.2% at a permissive threshold against
# a TF-IDF ceiling of 69.0%, because it is the only one that sees across
# languages.
DUPLICATE_THRESHOLD: dict[str, float] = {
    "bi-encoder": 0.75,
    "tfidf": 0.62,
}

# A pair below this in semantic similarity is not scored further. Also
# backend-specific: on dense vectors 0.35 is below the median and gates
# nothing, which is why the two backends were producing candidate sets of
# 24k and 173k pairs and could not be compared directly.
SEMANTIC_GATE: dict[str, float] = {
    "bi-encoder": 0.55,
    "tfidf": 0.30,
}

# A district with more works than this is split into sub-blocks by work type,
# to keep the pairwise cost bounded.
MAX_BLOCK_SIZE = 400

# Distance at which two works are certainly not the same asset.
GEO_FAR_KM = 25.0


@dataclass
class PairScore:
    """One candidate pair and why it scored as it did."""

    left: int
    right: int
    total: float
    semantic: float
    lexical: float
    geographic: float
    financial: float
    temporal: float
    distance_km: float | None = None

    def components(self) -> dict[str, float]:
        return {
            "semantic": round(self.semantic, 4),
            "lexical": round(self.lexical, 4),
            "geographic": round(self.geographic, 4),
            "financial": round(self.financial, 4),
            "temporal": round(self.temporal, 4),
        }


@dataclass
class DuplicateResult:
    """Pairs, clusters, and how the embeddings were produced."""

    pairs: list[PairScore] = field(default_factory=list)
    clusters: dict[int, list[int]] = field(default_factory=dict)
    backend: str = "tfidf"
    n_candidates: int = 0

    @property
    def n_pairs(self) -> int:
        return len(self.pairs)


# --------------------------------------------------------------------------
# blocking
# --------------------------------------------------------------------------
def block_candidates(
    features: pd.DataFrame, max_block: int = MAX_BLOCK_SIZE
) -> list[tuple[int, ...]]:
    """Group works into blocks within which pairs will be compared.

    District first. A district larger than `max_block` is split by work type,
    because the quadratic term is what makes this expensive and a 900-work
    district would dominate the run on its own.
    """
    blocks: list[tuple[int, ...]] = []
    for _, district in features.groupby("district_id", sort=False):
        if len(district) <= max_block:
            if len(district) > 1:
                blocks.append(tuple(district.index))
            continue
        for _, chunk in district.groupby("work_type", sort=False):
            if len(chunk) > 1:
                blocks.append(tuple(chunk.index))
    return blocks


# --------------------------------------------------------------------------
# embeddings
# --------------------------------------------------------------------------
def embed_descriptions(descriptions: Sequence[str]) -> tuple[np.ndarray, str]:
    """Encode descriptions, preferring the multilingual bi-encoder.

    Falls back to TF-IDF when sentence-transformers is unavailable -- it ships
    in the ml-worker image only. The fallback is *not* equivalent and the
    backend name is carried into the evidence so nobody mistakes one for the
    other: TF-IDF scores a cross-language twin at roughly 0.04.
    """
    try:
        from ..encoders import EncoderConfig, get_encoder

        encoder = get_encoder(EncoderConfig(require_gpu=False))
        result = encoder.encode(list(descriptions))
        return result.embeddings.astype(np.float32), "bi-encoder"
    except Exception as exc:  # noqa: BLE001 - fallback is an expected path
        log.info("bi-encoder unavailable (%s) -- falling back to TF-IDF", exc)

    # min_df must scale with the corpus. On a handful of documents min_df=2
    # filters every content word and leaves only stopwords -- two unrelated
    # descriptions sharing the word "of" then score a cosine of 1.0, because
    # "of" is the entire vocabulary. Real risk in a small district block, not
    # just in tests.
    texts = list(descriptions)
    min_df = 2 if len(texts) >= 50 else 1
    model = TfidfLite(min_df=min_df, max_features=2000)
    matrix = model.fit_transform(texts).astype(np.float32)

    if len(model.vocabulary_) < 5 and len(texts) > 1:
        log.warning(
            "TF-IDF vocabulary collapsed to %d terms over %d descriptions -- "
            "similarity from this backend is not meaningful",
            len(model.vocabulary_),
            len(texts),
        )
    return matrix, "tfidf"


# --------------------------------------------------------------------------
# pair scoring
# --------------------------------------------------------------------------
def _geo_similarity(distance_km: float | None) -> float:
    """1.0 for the same spot, decaying to 0 by GEO_FAR_KM."""
    if distance_km is None:
        return 0.0
    return float(max(0.0, 1.0 - distance_km / GEO_FAR_KM))


def _ratio_similarity(a: float, b: float) -> float:
    """Symmetric closeness of two positive quantities, in [0, 1]."""
    if a <= 0 or b <= 0:
        return 0.0
    return float(min(a, b) / max(a, b))


def score_pairs(
    features: pd.DataFrame,
    embeddings: np.ndarray,
    blocks: Sequence[tuple[int, ...]],
    threshold: float | None = None,
    backend: str = "tfidf",
) -> DuplicateResult:
    """Score every in-block pair and keep those above the threshold."""
    if threshold is None:
        threshold = DUPLICATE_THRESHOLD.get(backend, 0.62)
    gate = SEMANTIC_GATE.get(backend, 0.30)

    result = DuplicateResult(backend=backend)
    positions = {index: position for position, index in enumerate(features.index)}

    descriptions = features["description"].fillna("").to_numpy()
    latitudes = features["latitude"].to_numpy(dtype=float)
    longitudes = features["longitude"].to_numpy(dtype=float)
    costs = features["sanctioned_cost"].to_numpy(dtype=float)
    dates = pd.to_datetime(features["sanction_date"]).to_numpy()
    work_ids = features["work_id"].to_numpy()

    for block in blocks:
        rows = [positions[index] for index in block]
        result.n_candidates += len(rows) * (len(rows) - 1) // 2

        vectors = embeddings[rows]
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        normalised = vectors / np.maximum(norms, 1e-12)
        similarity = np.clip(normalised @ normalised.T, -1.0, 1.0)

        for a, b in combinations(range(len(rows)), 2):
            semantic = float(similarity[a, b])
            # Cheap gate: a pair with no textual resemblance cannot reach the
            # threshold, and skipping it avoids the geo and date work.
            if semantic < gate:
                continue

            left, right = rows[a], rows[b]
            lexical = token_set_ratio(str(descriptions[left]), str(descriptions[right]))

            distance = None
            if np.isfinite(latitudes[left]) and np.isfinite(latitudes[right]):
                distance = haversine_km(
                    latitudes[left], longitudes[left], latitudes[right], longitudes[right]
                )
            geographic = _geo_similarity(distance)
            financial = _ratio_similarity(costs[left], costs[right])

            days = abs((dates[left] - dates[right]) / np.timedelta64(1, "D"))
            temporal = float(max(0.0, 1.0 - days / 365.0))

            total = (
                WEIGHTS["semantic"] * semantic
                + WEIGHTS["lexical"] * lexical
                + WEIGHTS["geographic"] * geographic
                + WEIGHTS["financial"] * financial
                + WEIGHTS["temporal"] * temporal
            )
            if total >= threshold:
                result.pairs.append(
                    PairScore(
                        left=int(work_ids[left]),
                        right=int(work_ids[right]),
                        total=float(total),
                        semantic=semantic,
                        lexical=lexical,
                        geographic=geographic,
                        financial=financial,
                        temporal=temporal,
                        distance_km=distance,
                    )
                )

    # Connected components: A~B and B~C makes one cluster of three, which is
    # what a reviewer needs to see rather than two disconnected pairs.
    union = DisjointSet()
    for pair in result.pairs:
        union.union(pair.left, pair.right)
    result.clusters = {
        root: members for root, members in union.clusters().items() if len(members) > 1
    }
    return result


# --------------------------------------------------------------------------
# Seam B
# --------------------------------------------------------------------------
def _reason(pair: PairScore, other: int, backend: str) -> Reason:
    detail = []
    if pair.distance_km is not None:
        detail.append(
            "at the same location" if pair.distance_km < 0.5
            else f"{pair.distance_km:.1f} km apart"
        )
    if pair.financial > 0.9:
        detail.append("with near-identical sanctioned cost")
    location = ", ".join(detail) if detail else "in the same district"

    return Reason(
        code="duplicate_candidate",
        text=(
            f"The description closely matches work #{other} ({location}). "
            f"Semantic similarity {pair.semantic:.2f}, lexical {pair.lexical:.2f}. "
            "Two records may describe one physical work -- compare the measurement "
            "books before treating this as duplication."
        ),
        family=EvidenceFamily.TEXTUAL,
        severity=Severity.HIGH if pair.total > 0.80 else Severity.MEDIUM,
        provenance="peer_derived",
        factors={
            "twin_work_id": other,
            "pair_score": round(pair.total, 4),
            "components": pair.components(),
            "distance_km": None if pair.distance_km is None else round(pair.distance_km, 2),
            "embedding_backend": backend,
        },
    )


def run(features: pd.DataFrame, ctx: Any = None) -> list[LayerOutput]:
    """Seam B: one LayerOutput per work."""
    if features.empty:
        return []
    if "description" not in features.columns:
        log.warning("no description column -- L4 emits zeros")
        return [
            LayerOutput(work_id=int(w), layer=LAYER, score=0.0, confidence=0.0)
            for w in features["work_id"]
        ]

    indexed = features.reset_index(drop=True)
    blocks = block_candidates(indexed)
    embeddings, backend = embed_descriptions(indexed["description"].fillna("").tolist())
    result = score_pairs(indexed, embeddings, blocks, backend=backend)

    # Strongest pair each work participates in, and which twin it was.
    best: dict[int, PairScore] = {}
    twin: dict[int, int] = {}
    for pair in result.pairs:
        for work_id, other in ((pair.left, pair.right), (pair.right, pair.left)):
            if work_id not in best or pair.total > best[work_id].total:
                best[work_id] = pair
                twin[work_id] = other

    cluster_of: dict[int, int] = {}
    for members in result.clusters.values():
        for work_id in members:
            cluster_of[work_id] = len(members)

    # TF-IDF cannot see across languages, so a finding it produces rests on a
    # weaker instrument. The confidence says so.
    backend_confidence = 0.85 if backend == "bi-encoder" else 0.55

    outputs: list[LayerOutput] = []
    quality = indexed.set_index("work_id")["data_quality"]
    for work_id in indexed["work_id"]:
        work_id = int(work_id)
        pair = best.get(work_id)
        if pair is None:
            outputs.append(
                LayerOutput(
                    work_id=work_id,
                    layer=LAYER,
                    score=0.0,
                    confidence=backend_confidence,
                    data_quality=float(quality.loc[work_id]),
                    factors={"embedding_backend": backend},
                )
            )
            continue

        outputs.append(
            LayerOutput(
                work_id=work_id,
                layer=LAYER,
                # The pair score is already in [0, 1] and is the strength of
                # the evidence, so it is the score.
                score=float(min(1.0, pair.total)),
                confidence=backend_confidence,
                data_quality=float(quality.loc[work_id]),
                reasons=(_reason(pair, twin[work_id], backend),),
                factors={
                    "twin_work_id": twin[work_id],
                    "cluster_size": cluster_of.get(work_id, 2),
                    "embedding_backend": backend,
                    "candidate_pairs_considered": result.n_candidates,
                },
            )
        )
    return outputs
