"""The detection layers. Each obeys the Seam B Layer Output Contract.

    L0  rules          deterministic compliance, no training data needed
    L1  unsupervised   peer-relative anomaly detection
    L2  supervised     calibrated risk model
    L3  graph          network structure
    L4  duplicate      multilingual semantic duplicates
    L5  forecast       delay and utilisation
    L6  vision         asset and photo metadata

Every layer exposes `run(features, ctx) -> list[LayerOutput]` and reads only
the Gold view. No layer may read another layer's output -- fusion is the only
place they combine.
"""

from . import duplicates, graph, rules, unsupervised

__all__ = ["duplicates", "graph", "rules", "unsupervised"]
