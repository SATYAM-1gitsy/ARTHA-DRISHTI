"""L1 -- peer-relative anomaly detection.

The "AI" that needs no labels, and the layer where one modelling choice
dominates everything else: **a work is scored against its peers, not against
the population.** An expensive metro flyover and an expensive rural culvert
are both expensive; only one of them is anomalous. Scoring globally finds the
sector, not the outlier.

Three detectors, deliberately different in kind so their agreement means
something:

  ECOD          per-feature empirical tail probability. Parameter-free, and
                its per-feature contributions read directly as evidence.
  robust MAD    median/MAD z-score. Catches a single extreme value that ECOD
                dilutes across twenty columns.
  IsolationForest  captures feature *interactions* the other two cannot see.
                Optional -- sklearn ships in the ml-worker image only.

**No labels, ever.** `contracts.labels.LAYERS_DENIED_LABELS` names this layer
explicitly: the moment L1 sees ground truth, its "requires no labels" claim
is false and every unsupervised number it produces is worthless.

**Features are curated, not swept in.** Feeding all 43 numeric columns would
count `unit_cost`, `unit_cost_vs_sor` and `unit_cost_peer_percentile` as three
independent signals when they are one quantity viewed three ways -- the same
double-counting that finding R-01 addresses at the fusion layer, applied here
at the feature layer. Raw values are used rather than pre-computed
percentiles, because L1 does its own peer-relative work.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

from ..contracts.gold import PEER_GROUP_KEYS
from ..contracts.layer import EvidenceFamily, LayerOutput, Reason, Severity
from ..util import ecdf_tail, minmax, percentile_rank, robust_z

__all__ = [
    "LAYER",
    "L1_FEATURES",
    "FEATURE_FAMILY",
    "MIN_GROUP_SIZE",
    "OUTLIER_QUANTILE",
    "PeerGrouping",
    "assign_peer_groups",
    "score_group",
    "run",
    "sklearn_available",
    "USE_ISOLATION_FOREST",
]

log = logging.getLogger(__name__)

LAYER = "unsupervised"

try:
    from sklearn.ensemble import IsolationForest

    _SKLEARN = True
except ImportError:  # pragma: no cover - depends on optional install
    IsolationForest = None  # type: ignore[assignment,misc]
    _SKLEARN = False


def sklearn_available() -> bool:
    return _SKLEARN


# One column per distinct aspect. Where several columns describe the same
# underlying quantity, only the rawest is kept.
L1_FEATURES: tuple[str, ...] = (
    # financial
    "unit_cost",
    "cost_deviation_ratio",
    "estimated_to_sanctioned_ratio",
    # execution
    "progress_pct",
    "spend_progress_gap",
    "progress_velocity",
    "progress_acceleration",
    # temporal
    "days_since_sanction",
    "days_recommendation_to_sanction",
    "time_to_first_payment",
    "max_payment_gap_days",
    # payment behaviour
    "n_payments",
    "advance_ratio",
    "payment_velocity",
    # network
    "agency_district_share",
    "agency_hhi",
    "mp_agency_affinity",
    "agency_centrality",
    # asset and geography
    "phash_duplicate_count",
    "distance_to_district_centroid_km",
)

# Which evidence family a feature belongs to, so a reason lands in the right
# bucket for corroboration counting (finding R-01).
FEATURE_FAMILY: dict[str, EvidenceFamily] = {
    "unit_cost": EvidenceFamily.FINANCIAL,
    "cost_deviation_ratio": EvidenceFamily.FINANCIAL,
    "estimated_to_sanctioned_ratio": EvidenceFamily.FINANCIAL,
    "spend_progress_gap": EvidenceFamily.FINANCIAL,
    "advance_ratio": EvidenceFamily.FINANCIAL,
    "payment_velocity": EvidenceFamily.FINANCIAL,
    "n_payments": EvidenceFamily.FINANCIAL,
    "progress_pct": EvidenceFamily.TEMPORAL,
    "progress_velocity": EvidenceFamily.TEMPORAL,
    "progress_acceleration": EvidenceFamily.TEMPORAL,
    "days_since_sanction": EvidenceFamily.TEMPORAL,
    "days_recommendation_to_sanction": EvidenceFamily.TEMPORAL,
    "time_to_first_payment": EvidenceFamily.TEMPORAL,
    "max_payment_gap_days": EvidenceFamily.TEMPORAL,
    "agency_district_share": EvidenceFamily.NETWORK,
    "agency_hhi": EvidenceFamily.NETWORK,
    "mp_agency_affinity": EvidenceFamily.NETWORK,
    "agency_centrality": EvidenceFamily.NETWORK,
    "phash_duplicate_count": EvidenceFamily.ASSET,
    "distance_to_district_centroid_km": EvidenceFamily.COMPLIANCE,
}

# Readable names for the evidence card.
FEATURE_LABEL: dict[str, str] = {
    "unit_cost": "unit cost",
    "cost_deviation_ratio": "expenditure against sanction",
    "estimated_to_sanctioned_ratio": "sanctioned against estimate",
    "progress_pct": "reported progress",
    "spend_progress_gap": "spending ahead of progress",
    "progress_velocity": "rate of progress",
    "progress_acceleration": "change in the rate of progress",
    "days_since_sanction": "time since sanction",
    "days_recommendation_to_sanction": "recommendation-to-sanction delay",
    "time_to_first_payment": "time to the first payment",
    "max_payment_gap_days": "longest gap between payments",
    "n_payments": "number of payments",
    "advance_ratio": "share paid as advance",
    "payment_velocity": "rate of disbursement",
    "agency_district_share": "agency's share of the district",
    "agency_hhi": "agency concentration in the district",
    "mp_agency_affinity": "share of this member's works with one agency",
    "agency_centrality": "agency's centrality in the award network",
    "phash_duplicate_count": "works sharing this photograph",
    "distance_to_district_centroid_km": "distance from the district centre",
}

# Below this a group's empirical distribution is not a distribution. The
# fallback chain widens the peer definition rather than scoring on six works.
MIN_GROUP_SIZE = 30

# A work is a finding when its *ensemble* score sits in the top slice of its
# own peer group. Rank-based, not an absolute tail probability.
#
# The absolute version was a bug worth recording. `ecdf_tail` floors at
# 1/group_size, so a 52-member group can never produce a tail below 0.019 --
# any threshold under that silently disabled L1 for every narrow peer group
# while appearing to work on wide ones. Gating on rank makes the criterion
# mean the same thing in a group of 40 and a group of 900.
#
# Per-feature tails are still computed, but they now *explain* the score
# rather than gate it, which is how ECOD is meant to be read.
OUTLIER_QUANTILE = 0.02
MAX_REASONS = 3

# Ensemble weights. ECOD leads because its contributions are explainable.
WEIGHT_ECOD = 0.60
WEIGHT_MAD = 0.40
WEIGHT_IFOREST = 0.30

# Isolation Forest is OFF by default, and that is a measured decision rather
# than an accident of sklearn being absent.
#
# Measured on 19,817 works against held-out patterns:
#
#   variant                        secs   L1 P@500  L1 R@2k   fused P@500  fused R@2k
#   ECOD + MAD                      2.9      10.2%    18.8%         15.0%      28.6%
#   ECOD + MAD + IsolationForest   17.1      13.0%    21.4%         15.0%      27.9%
#
# It genuinely improves L1 *in isolation*, and contributes nothing once fused
# with L0 -- same precision, slightly worse recall, at 5.9x the compute. The
# interactions it captures are apparently ones the rules already cover.
#
# ADR-0002 set the rule: a model must beat a named baseline to stay. This one
# does not, so it is available and not enabled. Re-measure before turning it
# on; do not turn it on because it sounds better.
USE_ISOLATION_FOREST = False


@dataclass
class PeerGrouping:
    """Which peer definition each work was scored against, and why."""

    keys: pd.Series  # work_id -> group key string
    level: pd.Series  # work_id -> how wide the fallback had to go
    sizes: dict[str, int]

    @property
    def level_counts(self) -> dict[str, int]:
        return {str(k): int(v) for k, v in self.level.value_counts().items()}


def assign_peer_groups(
    features: pd.DataFrame, min_size: int = MIN_GROUP_SIZE
) -> PeerGrouping:
    """Assign each work the narrowest peer group that is large enough.

    Falls back sector x work_type x state -> sector x work_type -> sector ->
    all works. The level is recorded and surfaced in the reason text, because
    "the 99th percentile of comparable works in this state" and "the 99th
    percentile of all works" are different claims and an investigator is
    entitled to know which one they are being shown.
    """
    chains: list[tuple[str, list[str]]] = [
        ("sector x work_type x state", list(PEER_GROUP_KEYS)),
        ("sector x work_type", ["sector", "work_type"]),
        ("sector", ["sector"]),
    ]

    assigned = pd.Series(index=features.index, dtype="object")
    level = pd.Series(index=features.index, dtype="object")

    remaining = pd.Series(True, index=features.index)
    for label, columns in chains:
        if not remaining.any():
            break
        subset = features.loc[remaining]
        key = subset[columns].astype(str).agg("|".join, axis=1)
        counts = key.value_counts()
        big_enough = key.map(counts) >= min_size
        chosen = key[big_enough]
        assigned.loc[chosen.index] = label + "::" + chosen
        level.loc[chosen.index] = label
        remaining.loc[chosen.index] = False

    assigned.loc[remaining] = "all works::global"
    level.loc[remaining] = "all works"

    return PeerGrouping(
        keys=assigned,
        level=level,
        sizes={str(k): int(v) for k, v in assigned.value_counts().items()},
    )


def _prepare(matrix: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    """Impute with the group median and report what was imputed.

    Imputation is unavoidable -- a row with one null must still be scored --
    but it invents a value, so the fraction imputed is tracked and lowers the
    work's confidence rather than passing silently.

    **Deliberately does not winsorize.** An earlier version clipped to the 1st
    and 99th percentiles, which is standard practice and exactly wrong here:
    in an anomaly detector the extreme value *is* the signal, and clipping made
    the top 1% of every column indistinguishable from each other. A planted
    50x outlier stopped ranking first. Both detectors downstream are already
    robust to scale -- ECOD is rank-based and MAD uses the median -- so
    nothing needed the clipping in the first place.
    """
    values = np.zeros(matrix.shape, dtype=float)
    imputed = np.zeros(matrix.shape, dtype=bool)

    for index, column in enumerate(matrix.columns):
        series = matrix[column].astype(float)
        imputed[:, index] = series.isna().to_numpy()
        filled = series.fillna(series.median() if series.notna().any() else 0.0)
        values[:, index] = filled.to_numpy()
    return values, imputed


def _isolation_forest(values: np.ndarray, seed: int) -> np.ndarray | None:
    """Isolation Forest scores, or None when sklearn is unavailable."""
    if not (USE_ISOLATION_FOREST and _SKLEARN) or values.shape[0] < MIN_GROUP_SIZE:
        return None
    try:
        model = IsolationForest(
            n_estimators=100,
            contamination="auto",
            random_state=seed,
            n_jobs=1,
        ).fit(values)
        # decision_function: higher is more normal. Invert so higher is riskier.
        return minmax(-model.decision_function(values))
    except Exception as exc:  # noqa: BLE001 - never lose a group to a model
        log.warning("IsolationForest failed on a peer group (%s) -- skipping", exc)
        return None


def score_group(
    matrix: pd.DataFrame, seed: int = 42
) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    """Score one peer group.

    Returns (ensemble score, per-feature tail probabilities, imputed mask,
    diagnostics). Scores are min-max normalized *within* the group so a work
    in a 40-member group and one in a 900-member group are comparable.
    """
    values, imputed = _prepare(matrix)
    n_rows, n_features = values.shape

    tails = np.ones((n_rows, n_features), dtype=float)
    # Where in its peer group the value actually sits, in [0, 1]. `ecdf_tail`
    # is two-sided and so cannot answer this: a value in the bottom 1% and one
    # in the top 1% get the same tail, and reconstructing a percentile from it
    # puts every low-side outlier at the top of its group. See `_reason_for`.
    percentiles = np.ones((n_rows, n_features), dtype=float)
    contributions = np.zeros((n_rows, n_features), dtype=float)
    for index in range(n_features):
        tails[:, index] = ecdf_tail(values[:, index])
        percentiles[:, index] = percentile_rank(values[:, index])
        contributions[:, index] = -np.log(tails[:, index])

    ecod = minmax(contributions.sum(axis=1))

    mad = np.zeros(n_rows, dtype=float)
    for index in range(n_features):
        mad = np.maximum(mad, np.abs(robust_z(values[:, index])))
    mad = minmax(mad)

    forest = _isolation_forest(values, seed)

    components = {"ecod": (ecod, WEIGHT_ECOD), "mad": (mad, WEIGHT_MAD)}
    if forest is not None:
        components["iforest"] = (forest, WEIGHT_IFOREST)

    total_weight = sum(weight for _, weight in components.values())
    ensemble = sum(score * weight for score, weight in components.values()) / total_weight

    return (
        minmax(ensemble),
        tails,
        imputed,
        {
            "n_rows": int(n_rows),
            "detectors": sorted(components),
            "component_scores": {name: score for name, (score, _) in components.items()},
            # Carried in the diagnostics rather than the tuple so the return
            # arity stays what every caller and test already unpacks.
            "percentiles": percentiles,
        },
    )


def _reason_for(
    column: str,
    value: float,
    tail: float,
    median: float,
    group_size: int,
    level: str,
    percentile: float,
) -> Reason:
    """A finding phrased as a comparison, not a score.

    "unit cost is 2.4x the median of 340 comparable works" is actionable;
    "anomaly score 0.87" is not.

    `percentile` is passed in rather than derived from `tail`, and the
    difference is not cosmetic. `ecdf_tail` is deliberately two-sided -- a
    value in the bottom 1% and one in the top 1% both score 0.01, because both
    are equally extreme and that is what the ECOD contribution needs. It
    therefore carries no direction, and the old `(1 - tail / 2) * 100` put
    *every* outlier near the 99th percentile. A stalled work at the 1st
    percentile of reported progress was described to a reviewer as the 99.5th
    -- the exact inverse of the finding, on the layer whose entire purpose is
    peer comparison.
    """
    label = FEATURE_LABEL.get(column, column.replace("_", " "))
    percentile = float(np.clip(percentile, 0.0, 1.0)) * 100.0
    # Which side of its peers the work sits on. An investigator reading
    # "in the most extreme 1.1%" is entitled to know whether that means
    # unusually high or unusually low.
    direction = "above" if percentile >= 50.0 else "below"
    extreme = "highest" if direction == "above" else "lowest"

    # A multiple only reads as a multiple when both numbers point the same way.
    # `time_to_first_payment` is negative on a pre-sanction payment, and against
    # a positive peer median that rendered as "-1.68x the median" -- arithmetic
    # that no investigator can act on. The real finding there is that the work
    # was paid 101 days *before* sanction where its peers are first paid 60 days
    # after, which the absolute form states plainly.
    ratio = value / median if median and abs(median) > 1e-9 else None
    if ratio is not None and ratio > 1.15:
        comparison = f"{ratio:.1f}x the median of {group_size:,} comparable works"
    elif ratio is not None and 0.0 < ratio < 0.85:
        comparison = f"{ratio:.2f}x the median of {group_size:,} comparable works"
    else:
        # Each form carries its own connector. Sharing one produced "a median
        # of 60.00 of 62 comparable works", which reads as a nested quantity.
        comparison = (
            f"{value:,.2f}, against a median of {median:,.2f} "
            f"across {group_size:,} comparable works"
        )

    severity = Severity.HIGH if tail <= 0.005 else Severity.MEDIUM
    return Reason(
        code=f"peer_outlier:{column}",
        text=(
            f"The {label} is {comparison} "
            f"({level}), in the {extreme} {tail * 100:.1f}% of that group."
        ),
        family=FEATURE_FAMILY.get(column, EvidenceFamily.FINANCIAL),
        severity=severity,
        provenance="peer_derived",
        factors={
            "feature": column,
            "value": round(float(value), 4),
            "peer_median": round(float(median), 4),
            "tail_probability": round(float(tail), 5),
            "percentile": round(float(percentile), 2),
            "direction": direction,
            "peer_group_size": int(group_size),
            "peer_group_level": level,
        },
    )


def run(features: pd.DataFrame, ctx: Any = None) -> list[LayerOutput]:
    """Seam B: one LayerOutput per work.

    Deliberately reads only the Gold view. It never touches `fraud_label` --
    see the module docstring.
    """
    if features.empty:
        return []

    available = [column for column in L1_FEATURES if column in features.columns]
    if not available:
        log.warning("no L1 features present in the Gold view -- layer emits zeros")
        return [
            LayerOutput(work_id=int(w), layer=LAYER, score=0.0, confidence=0.0)
            for w in features["work_id"]
        ]

    indexed = features.set_index("work_id", drop=False)
    grouping = assign_peer_groups(indexed)

    scores = pd.Series(0.0, index=indexed.index)
    confidences = pd.Series(0.0, index=indexed.index)
    reasons: dict[int, list[Reason]] = {}
    factors: dict[int, dict[str, Any]] = {}

    for group_key, members in indexed.groupby(grouping.keys, sort=False):
        matrix = members[available]
        ensemble, tails, imputed, diagnostics = score_group(matrix)
        level = str(grouping.level.loc[members.index[0]])
        group_size = len(members)
        medians = matrix.astype(float).median()
        # Read the group's values once as a plain array. The loop below
        # previously reached back into the frame with `matrix.iloc[pos][col]`,
        # which builds a fresh Series per cell -- two of them per reason, on
        # every flagged work.
        raw = matrix.to_numpy(dtype=float, na_value=np.nan)
        median_by_column = [float(medians[column]) for column in available]
        percentiles = diagnostics["percentiles"]

        # A small group and a heavily imputed row both mean the same thing:
        # this score rests on less than it appears to.
        size_confidence = min(1.0, math.log10(max(group_size, 2)) / math.log10(200))
        completeness = 1.0 - imputed.mean(axis=1)

        # The score a work must reach to be called an outlier *within its own
        # group*. Rank-based, so group size does not change what it means.
        cutoff = float(np.quantile(ensemble, 1.0 - OUTLIER_QUANTILE)) if len(ensemble) else 1.0

        member_ids = members.index.to_numpy()
        group_scores = np.asarray(ensemble, dtype=float)
        group_confidences = size_confidence * np.asarray(completeness, dtype=float)

        for position, work_id in enumerate(member_ids):
            work_id = int(work_id)

            # Explain with the features that contributed most, whatever their
            # absolute tail: in a narrow peer group the most extreme value is
            # still the most extreme value.
            extreme = [
                (j, float(tails[position, j]))
                for j in range(len(available))
                if not imputed[position, j] and tails[position, j] < 0.5
            ]
            extreme.sort(key=lambda pair: pair[1])

            if extreme and ensemble[position] >= cutoff:
                reasons[work_id] = [
                    _reason_for(
                        available[j],
                        float(raw[position, j]),
                        tail,
                        median_by_column[j],
                        group_size,
                        level,
                        float(percentiles[position, j]),
                    )
                    for j, tail in extreme[:MAX_REASONS]
                    if not np.isnan(raw[position, j])
                ]
            factors[work_id] = {
                "peer_group": str(group_key),
                "peer_group_size": group_size,
                "peer_group_level": level,
                "detectors": diagnostics["detectors"],
                "features_imputed": int(imputed[position].sum()),
            }

        # One aligned write per group rather than a scalar `.loc` set per work.
        # Both forms produce the same Series; the scalar one re-resolved the
        # index on all 19,875 works, twice each.
        scores.loc[members.index] = group_scores
        confidences.loc[members.index] = group_confidences

    score_by_work = scores.to_dict()
    confidence_by_work = confidences.to_dict()
    quality_by_work = pd.to_numeric(
        indexed["data_quality"], errors="coerce"
    ).fillna(1.0).to_dict()

    outputs: list[LayerOutput] = []
    for work_id in indexed.index:
        work_id = int(work_id)
        found = reasons.get(work_id, [])
        # A score with nothing to say about it cannot be shown to an
        # investigator, so it is not emitted as a finding.
        score = float(score_by_work[work_id]) if found else 0.0
        outputs.append(
            LayerOutput(
                work_id=work_id,
                layer=LAYER,
                score=score,
                confidence=float(confidence_by_work[work_id]),
                data_quality=float(quality_by_work[work_id]),
                reasons=tuple(found),
                factors=factors.get(work_id, {}),
            )
        )
    return outputs
