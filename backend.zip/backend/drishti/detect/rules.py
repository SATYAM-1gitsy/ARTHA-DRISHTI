"""L0 -- the deterministic compliance engine.

Roughly 40% of the value of this system, 100% explainable, and it needs no
training data. A rule hit is a fact about the records with a citation attached,
which is what makes it usable by an auditor in a way a model probability is
not.

**Rules are data, not code.** Each is a `Rule` value carrying its predicate,
severity, evidence columns and provenance. Tuning a threshold or retiring a
rule is a change to this table, not to logic, so scoring can be retuned
without touching the engine.

**Provenance is mandatory** (findings R-05, R-06). Every rule states whether
its threshold came from a published guideline clause, a documented CAG
finding, the data itself, or a project assumption. `data/guidelines.md` does
not exist yet, so several rules ship as assumptions — and they render as
assumptions rather than quietly borrowing the authority of a real clause.

**A rule abstains rather than guessing.** If the columns it needs are null for
a work, it does not fire *and* it does not count as evidence of compliance.
Abstention lowers that work's confidence, which is the whole reason Seam B
carries confidence separately from score.

## Three rules deliberately not implemented

The Blueprint's starter set (§18.2) includes `geo_outside_district`, a
year-end sanction rule, and a duplicate-photo rule. Each targets a **held-out**
pattern (`geographic_displacement`, `year_end_bunching`, `photo_reuse`).

Writing them would make recall on those patterns ~1.0 by construction and
destroy the only figures in this project that carry a detection claim
(finding R-03). They are omitted on purpose, not overlooked, and
`FORBIDDEN_TARGETS` makes the omission enforceable rather than a convention.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from ..contracts.layer import EvidenceFamily, LayerOutput, Reason, Severity
from ..domain import (
    INELIGIBLE_KEYWORDS,
    PER_WORK_CEILING,
    SANCTION_WINDOW_DAYS,
    Provenance,
    held_out_patterns,
)
from ..textsim import normalize_text
from ..util import to_jsonable

__all__ = [
    "LAYER",
    "Rule",
    "RULES",
    "FORBIDDEN_TARGETS",
    "SEVERITY_WEIGHT",
    "RuleHit",
    "run",
    "evaluate_rules",
]

LAYER = "rules"

# Patterns no rule may target. Enforced by a test, not left to memory.
FORBIDDEN_TARGETS: frozenset[str] = frozenset(p.name for p in held_out_patterns())

# How much a single hit contributes before saturation.
SEVERITY_WEIGHT: dict[Severity, float] = {
    Severity.LOW: 0.20,
    Severity.MEDIUM: 0.45,
    Severity.HIGH: 0.70,
    Severity.CRITICAL: 0.95,
}

# A cost this far above its peers is worth a look. Peer-derived, so it needs
# no external benchmark -- unlike the SoR ratio, which rests on an assumption.
PEER_COST_PERCENTILE = 0.98
# The same cut-point for sanction delay, deliberately: reusing the number the
# project already committed to introduces no new free parameter, and a second
# tunable dial is exactly where fitting to the evaluation set would begin.
PEER_DELAY_PERCENTILE = PEER_COST_PERCENTILE
# Below this the work is effectively not started.
STALLED_PROGRESS_PCT = 5.0
ADVANCE_DOMINANT_RATIO = 0.60
ADVANCE_STALE_DAYS = 120.0
SPLIT_PAYMENT_MIN_COUNT = 6
SPLIT_PAYMENT_CEILING_BAND = (0.85, 1.02)
CONCENTRATION_SHARE = 0.60
COMPLETE_PROGRESS_PCT = 95.0


@dataclass(frozen=True)
class Rule:
    """One deterministic check.

    `requires` is what makes abstention possible: a rule that cannot see its
    inputs returns no opinion instead of a false negative dressed as a pass.
    """

    code: str
    description: str
    family: EvidenceFamily
    severity: Severity
    provenance: Provenance
    citation: str
    requires: tuple[str, ...]
    predicate: Callable[[pd.DataFrame], pd.Series]
    reason: Callable[[pd.Series], str]
    factors: tuple[str, ...] = ()
    targets: str | None = None  # the fraud pattern this rule is aimed at

    def __post_init__(self) -> None:
        if not self.citation.strip():
            raise ValueError(f"{self.code}: a rule without a citation is not evidence")
        if self.targets and self.targets in FORBIDDEN_TARGETS:
            raise ValueError(
                f"{self.code} targets held-out pattern {self.targets!r}. Writing a rule "
                "against a held-out pattern converts the only quotable recall figure in "
                "this project into a tautology (finding R-03)."
            )

    @property
    def is_verified(self) -> bool:
        return self.provenance in (Provenance.GUIDELINE_CLAUSE, Provenance.CAG_FINDING)

    @property
    def provenance_note(self) -> str:
        """What the UI renders beside the finding."""
        if self.provenance is Provenance.ASSUMED:
            return "project assumption -- not verified against a published source"
        if self.provenance is Provenance.PEER_DERIVED:
            return "derived from comparable works in this dataset"
        return self.citation


@dataclass
class RuleHit:
    """One rule firing on one work."""

    work_id: int
    rule: Rule
    values: dict[str, Any] = field(default_factory=dict)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _money(value: float) -> str:
    """Rupees in the units an Indian officer reads."""
    if value >= 1e7:
        return f"Rs {value / 1e7:.2f} crore"
    if value >= 1e5:
        return f"Rs {value / 1e5:.2f} lakh"
    return f"Rs {value:,.0f}"


_INELIGIBLE_BY_KEYWORD: dict[str, str] = {
    keyword: category
    for category, keywords in INELIGIBLE_KEYWORDS.items()
    for keyword in keywords
}


def _matched_keyword(text: str) -> str | None:
    normalised = normalize_text(text)
    if not normalised:
        return None
    for keyword in _INELIGIBLE_BY_KEYWORD:
        if keyword in normalised:
            return keyword
    return None


def _ineligible_mask(frame: pd.DataFrame) -> pd.Series:
    return frame["description"].fillna("").map(lambda t: _matched_keyword(t) is not None)


# --------------------------------------------------------------------------
# the rule table
# --------------------------------------------------------------------------
RULES: tuple[Rule, ...] = (
    Rule(
        code="pre_sanction_payment",
        description="A payment is dated before the work was sanctioned.",
        family=EvidenceFamily.COMPLIANCE,
        severity=Severity.CRITICAL,
        provenance=Provenance.CAG_FINDING,
        citation="CAG performance audits repeatedly report expenditure booked ahead of sanction.",
        requires=("has_pre_sanction_payment",),
        predicate=lambda f: f["has_pre_sanction_payment"] == 1,
        reason=lambda r: (
            f"A payment is recorded {abs(float(r['time_to_first_payment'])):.0f} days before "
            f"the sanction date of {pd.to_datetime(r['sanction_date']).date()}."
            if pd.notna(r.get("time_to_first_payment"))
            else "A payment is recorded before the work's sanction date."
        ),
        factors=("has_pre_sanction_payment", "time_to_first_payment", "sanction_date"),
        targets="pre_sanction_payment",
    ),
    Rule(
        code="ceiling_breach",
        description="Sanctioned cost exceeds the per-work ceiling.",
        family=EvidenceFamily.COMPLIANCE,
        severity=Severity.HIGH,
        provenance=Provenance.ASSUMED,
        citation=PER_WORK_CEILING.citation,
        requires=("sanctioned_cost",),
        predicate=lambda f: f["sanctioned_cost"] > PER_WORK_CEILING.value,
        reason=lambda r: (
            f"Sanctioned at {_money(float(r['sanctioned_cost']))}, above the assumed "
            f"per-work ceiling of {_money(PER_WORK_CEILING.value)}."
        ),
        factors=("sanctioned_cost",),
    ),
    Rule(
        code="unit_cost_above_peers",
        description="Unit cost sits in the extreme tail of comparable works.",
        family=EvidenceFamily.FINANCIAL,
        severity=Severity.HIGH,
        provenance=Provenance.PEER_DERIVED,
        citation="Percentile within (sector, work_type, state) peers computed from this dataset.",
        requires=("unit_cost_peer_percentile",),
        predicate=lambda f: f["unit_cost_peer_percentile"] >= PEER_COST_PERCENTILE,
        reason=lambda r: (
            f"Unit cost of {_money(float(r['unit_cost']))} sits at the "
            f"{float(r['unit_cost_peer_percentile']) * 100:.1f}th percentile of comparable "
            f"works in this sector and state."
        ),
        factors=("unit_cost", "unit_cost_peer_percentile", "unit_cost_vs_sor"),
        targets="cost_inflation",
    ),
    Rule(
        code="advance_without_progress",
        description="An advance dominates spending but progress has not followed.",
        family=EvidenceFamily.TEMPORAL,
        severity=Severity.MEDIUM,
        provenance=Provenance.CAG_FINDING,
        citation="Funds released against works that never started is a recurring audit finding.",
        requires=("advance_ratio", "progress_pct", "days_since_sanction"),
        predicate=lambda f: (
            (f["advance_ratio"] >= ADVANCE_DOMINANT_RATIO)
            & (f["progress_pct"] < STALLED_PROGRESS_PCT)
            & (f["days_since_sanction"] > ADVANCE_STALE_DAYS)
        ),
        reason=lambda r: (
            f"{float(r['advance_ratio']) * 100:.0f}% of spending is advance, yet progress is "
            f"{float(r['progress_pct']):.1f}% after {float(r['days_since_sanction']):.0f} days."
        ),
        factors=("advance_ratio", "progress_pct", "days_since_sanction", "spend_progress_gap"),
        targets="advance_without_progress",
    ),
    Rule(
        code="spend_ahead_of_progress",
        description="Expenditure has run well ahead of reported physical progress.",
        family=EvidenceFamily.FINANCIAL,
        severity=Severity.MEDIUM,
        provenance=Provenance.CAG_FINDING,
        citation="Expenditure outpacing physical progress is a documented irregularity.",
        requires=("spend_progress_gap", "progress_pct"),
        predicate=lambda f: (f["spend_progress_gap"] > 40.0) & (f["progress_pct"] < 90.0),
        reason=lambda r: (
            f"Expenditure is {float(r['spend_progress_gap']):.0f} percentage points ahead of "
            f"physical progress ({float(r['progress_pct']):.1f}% complete)."
        ),
        factors=("spend_progress_gap", "progress_pct", "cost_deviation_ratio"),
    ),
    Rule(
        code="completed_without_asset_photo",
        description="Reported complete and paid, with no photographic evidence of an asset.",
        family=EvidenceFamily.ASSET,
        # HIGH, not CRITICAL, and deliberately absent from
        # config.fusion.critical_rules. Measured precision against ground truth
        # is 6.8%: roughly 31% of works legitimately have no photograph on
        # record, so absence screens rather than proves. It earns its place by
        # corroborating other families, not by escalating on its own.
        severity=Severity.HIGH,
        provenance=Provenance.CAG_FINDING,
        citation="Works certified complete without a verifiable asset on the ground.",
        requires=("photo_present", "progress_pct", "expenditure_to_date"),
        predicate=lambda f: (
            (f["photo_present"] == 0)
            & (f["progress_pct"] >= COMPLETE_PROGRESS_PCT)
            & (f["expenditure_to_date"] > 0)
        ),
        reason=lambda r: (
            f"Reported {float(r['progress_pct']):.0f}% complete with "
            f"{_money(float(r['expenditure_to_date']))} paid, but no asset photograph is on "
            "record. A missing photograph may be a reporting gap rather than a missing asset "
            "-- field verification is needed."
        ),
        factors=("photo_present", "progress_pct", "expenditure_to_date", "status"),
        targets="ghost_work",
    ),
    Rule(
        code="split_payment_near_ceiling",
        description="Many small payments summing to just under the per-work ceiling.",
        family=EvidenceFamily.FINANCIAL,
        severity=Severity.MEDIUM,
        provenance=Provenance.ASSUMED,
        citation="PROJECT ASSUMPTION: splitting to stay below a scrutiny threshold. The "
        "ceiling itself is unverified -- see domain.PER_WORK_CEILING.",
        requires=("n_payments", "expenditure_to_date"),
        predicate=lambda f: (
            (f["n_payments"] >= SPLIT_PAYMENT_MIN_COUNT)
            & (f["expenditure_to_date"] >= PER_WORK_CEILING.value * SPLIT_PAYMENT_CEILING_BAND[0])
            & (f["expenditure_to_date"] <= PER_WORK_CEILING.value * SPLIT_PAYMENT_CEILING_BAND[1])
        ),
        reason=lambda r: (
            f"{int(r['n_payments'])} payments totalling {_money(float(r['expenditure_to_date']))}, "
            f"which is {float(r['expenditure_to_date']) / PER_WORK_CEILING.value * 100:.0f}% of the "
            "assumed per-work ceiling."
        ),
        factors=("n_payments", "expenditure_to_date", "max_payment_gap_days"),
        targets="split_payment",
    ),
    Rule(
        code="potentially_ineligible_description",
        description="The description matches a category outside the scheme's scope.",
        family=EvidenceFamily.COMPLIANCE,
        severity=Severity.HIGH,
        provenance=Provenance.GUIDELINE_CLAUSE,
        citation="MPLADS Guidelines 2023 -- ineligible categories. Clause not yet verified "
        "against the primary document (B-03).",
        requires=("description",),
        predicate=_ineligible_mask,
        reason=lambda r: (
            f'Description mentions "{_matched_keyword(str(r["description"]))}", which falls under '
            f"the {_INELIGIBLE_BY_KEYWORD.get(_matched_keyword(str(r['description'])) or '', 'restricted')} "
            "category. Eligibility turns on the purpose and beneficiary, which this check cannot "
            "establish -- requires review."
        ),
        factors=("description", "sector", "work_type"),
        targets="ineligible_work",
    ),
    Rule(
        code="agency_concentration",
        description="One implementing agency holds a disproportionate share of the district.",
        family=EvidenceFamily.NETWORK,
        severity=Severity.MEDIUM,
        provenance=Provenance.PEER_DERIVED,
        citation="Agency share of district works, computed from this dataset.",
        requires=("agency_district_share",),
        predicate=lambda f: f["agency_district_share"] >= CONCENTRATION_SHARE,
        reason=lambda r: (
            f"This agency executes {float(r['agency_district_share']) * 100:.0f}% of the "
            f"district's works (concentration index {float(r['agency_hhi']):.2f})."
            if pd.notna(r.get("agency_hhi"))
            else f"This agency executes {float(r['agency_district_share']) * 100:.0f}% of the "
            "district's works."
        ),
        factors=("agency_district_share", "agency_hhi", "n_works_same_agency"),
        targets="agency_concentration",
    ),
    Rule(
        code="sanction_delay_above_peers",
        description="Recommendation-to-sanction lag sits in the extreme tail of comparable works.",
        family=EvidenceFamily.COMPLIANCE,
        severity=Severity.LOW,
        provenance=Provenance.PEER_DERIVED,
        citation=(
            "Percentile within (sector, work_type, state) peers computed from this dataset. "
            f"Replaced an absolute {SANCTION_WINDOW_DAYS.value}-day window (ASSUMED, never "
            "verified) that sat at the 64th percentile of its own distribution -- median 62 "
            "days, p75 86 -- and so fired on 36.1% of the corpus. If a real guideline window "
            "is ever sourced (open question D-09) the absolute check belongs back beside this "
            "one as a separate rule: 'breached the statutory window' and 'slower than "
            "comparable works' are different findings."
        ),
        requires=("sanction_delay_peer_percentile",),
        predicate=lambda f: f["sanction_delay_peer_percentile"] >= PEER_DELAY_PERCENTILE,
        reason=lambda r: (
            f"Sanctioned {float(r['days_recommendation_to_sanction']):.0f} days after "
            "recommendation, at the "
            f"{float(r['sanction_delay_peer_percentile']) * 100:.1f}th percentile of "
            "comparable works in this sector and state."
        ),
        factors=(
            "days_recommendation_to_sanction",
            "sanction_delay_peer_percentile",
            "recommended_on",
            "sanction_date",
        ),
    ),
)


# --------------------------------------------------------------------------
# execution
# --------------------------------------------------------------------------
def evaluate_rules(features: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Evaluate every rule over the Gold view.

    Returns (hits, abstentions) as boolean frames indexed by work_id, one
    column per rule. Abstention is tracked separately from not-firing: a rule
    that could not see its inputs has no opinion, and treating that as a pass
    would manufacture false confidence.
    """
    index = pd.Index(features["work_id"], name="work_id")
    hits = pd.DataFrame(False, index=index, columns=[r.code for r in RULES])
    abstained = pd.DataFrame(False, index=index, columns=[r.code for r in RULES])

    for rule in RULES:
        missing = [column for column in rule.requires if column not in features.columns]
        if missing:
            abstained[rule.code] = True
            continue

        can_evaluate = features[list(rule.requires)].notna().all(axis=1).to_numpy()
        abstained[rule.code] = ~can_evaluate

        fired = np.zeros(len(features), dtype=bool)
        if can_evaluate.any():
            subset = features.loc[can_evaluate]
            result = rule.predicate(subset)
            fired[can_evaluate] = np.asarray(result, dtype=bool)
        hits[rule.code] = fired

    return hits, abstained


def _score(severities: list[Severity]) -> float:
    """Saturating combination of hit severities.

    A product of complements rather than a sum: two medium findings should
    outweigh one, but no number of low-severity hits should reach the score of
    a single critical one, and nothing may exceed 1.0.
    """
    if not severities:
        return 0.0
    remaining = 1.0
    for severity in severities:
        remaining *= 1.0 - SEVERITY_WEIGHT[severity]
    return float(min(1.0, 1.0 - remaining))


def run(features: pd.DataFrame, ctx: Any = None) -> list[LayerOutput]:
    """Seam B: one LayerOutput per work, including the silent ones."""
    hits, abstained = evaluate_rules(features)
    by_code = {rule.code: rule for rule in RULES}
    indexed = features.set_index("work_id")
    n_rules = len(RULES)

    outputs: list[LayerOutput] = []
    for work_id in indexed.index:
        row = indexed.loc[work_id]
        fired = [code for code in hits.columns if bool(hits.at[work_id, code])]
        n_abstained = int(abstained.loc[work_id].sum())

        # Deterministic checks are certain when they can see their inputs, so
        # confidence here is simply how much of the rule set could be applied.
        confidence = (n_rules - n_abstained) / n_rules if n_rules else 1.0
        data_quality = float(row.get("data_quality", 1.0))

        if not fired:
            outputs.append(
                LayerOutput(
                    work_id=int(work_id),
                    layer=LAYER,
                    score=0.0,
                    confidence=confidence,
                    data_quality=data_quality,
                    factors={"rules_abstained": n_abstained},
                )
            )
            continue

        reasons: list[Reason] = []
        factors: dict[str, Any] = {"rules_fired": fired, "rules_abstained": n_abstained}
        for code in fired:
            rule = by_code[code]
            values = {
                column: (None if pd.isna(row.get(column)) else row.get(column))
                for column in rule.factors
                if column in indexed.columns
            }
            reasons.append(
                Reason(
                    code=rule.code,
                    text=rule.reason(row),
                    family=rule.family,
                    severity=rule.severity,
                    provenance=rule.provenance.value,
                    # to_jsonable, not a hand-rolled conversion: these values
                    # come straight out of pandas as numpy scalars, and
                    # json.dumps refuses np.int64. Without it the API raises on
                    # any work that has a rule hit -- which is every work an
                    # investigator would ever open.
                    factors={
                        **to_jsonable(values),
                        "provenance_note": rule.provenance_note,
                    },
                )
            )
            factors[f"rule:{code}"] = True

        outputs.append(
            LayerOutput(
                work_id=int(work_id),
                layer=LAYER,
                score=_score([by_code[code].severity for code in fired]),
                confidence=confidence,
                data_quality=data_quality,
                reasons=tuple(reasons),
                factors=to_jsonable(factors),
            )
        )
    return outputs
