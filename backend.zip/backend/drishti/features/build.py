"""Seam A producer: build the Gold feature view.

One row per `work_id`, every column declared in `contracts.gold`. This is the
only thing seven detection layers consume, so it is also the only place where
a definition can be got wrong once and be wrong everywhere.

Two principles run through the file.

**Peer-relative, not global.** An expensive metro flyover and an expensive
rural culvert are not comparable, and a global threshold flags the wrong one.
Cost outlyingness is a percentile within (sector, work_type, state) peers, and
where a peer group is too small to say anything the value is null rather than
a number computed from four neighbours. The SoR ratio is still emitted, but it
rests on an assumed benchmark (finding R-05) and evidence must lead with the
percentile.

**Missing is null, never zero.** A work with no coordinates has
`geo_in_district = null`, not 0 — the difference between "outside the
district" and "we do not know" is the difference between an alert and a
question. `data_quality` counts what is absent so fusion can discount the
whole row.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

from ..config import settings
from ..contracts.gold import (
    GOLD_COLUMNS,
    GOLD_FEATURES,
    PEER_GROUP_KEYS,
    validate_frame,
)
from ..contracts.labels import assert_no_label_leakage
from ..domain import SOR_UNIT_COST
from ..textsim import normalize_text, script_profile
from ..util import haversine_km, point_in_bbox, safe_ratio

__all__ = ["FeatureBuildResult", "build_features", "MIN_PEER_GROUP"]

# Below this, a percentile is arithmetic rather than evidence. "The 99th
# percentile of four works" tells an investigator nothing.
MIN_PEER_GROUP = 5

_SCORING_DATE = pd.Timestamp("2026-04-01")
_DAYS_PER_MONTH = 30.0


@dataclass
class FeatureBuildResult:
    """The Gold frame plus what the build learned about it."""

    features: pd.DataFrame
    problems: list[str]
    peer_group_stats: dict[str, Any]

    @property
    def ok(self) -> bool:
        return not self.problems

    def describe(self) -> str:
        lines = [
            f"gold feature view: {len(self.features):,} works x {len(self.features.columns)} columns",
            f"  contract          {'OK' if self.ok else 'VIOLATED'}",
            f"  peer groups       {self.peer_group_stats['n_groups']:,} "
            f"({self.peer_group_stats['n_usable']:,} with >= {MIN_PEER_GROUP} members)",
            f"  works with a peer percentile  "
            f"{self.peer_group_stats['coverage']:.1%}",
            f"  data_quality      median {self.features['data_quality'].median():.3f}, "
            f"min {self.features['data_quality'].min():.3f}",
        ]
        for problem in self.problems:
            lines.append(f"  ! {problem}")
        return "\n".join(lines)


# --------------------------------------------------------------------------
# payment-derived features
# --------------------------------------------------------------------------
def _payment_features(works: pd.DataFrame, payments: pd.DataFrame) -> pd.DataFrame:
    """Aggregate payment behaviour per work.

    `has_pre_sanction_payment` is computed here rather than in L0 because it
    is a fact about the records, not a judgement about them. The rule that
    decides what it means lives in the rules engine.
    """
    if payments.empty:
        index = pd.Index(works["work_id"], name="work_id")
        return pd.DataFrame(index=index).assign(
            expenditure_to_date=0.0,
            n_payments=0,
            advance_ratio=0.0,
            time_to_first_payment=np.nan,
            max_payment_gap_days=np.nan,
            has_pre_sanction_payment=0,
            vendor_id=np.nan,
        )

    joined = payments.merge(
        works[["work_id", "sanction_date"]], on="work_id", how="left", validate="many_to_one"
    )
    joined["payment_date"] = pd.to_datetime(joined["payment_date"])
    joined["sanction_date"] = pd.to_datetime(joined["sanction_date"])
    joined["days_from_sanction"] = (joined["payment_date"] - joined["sanction_date"]).dt.days
    joined["is_advance"] = (joined["payment_type"] == "advance").astype(float)
    joined["is_pre_sanction"] = joined["days_from_sanction"] < 0

    grouped = joined.groupby("work_id")
    features = pd.DataFrame(
        {
            "expenditure_to_date": grouped["amount"].sum(),
            "n_payments": grouped["amount"].size(),
            "time_to_first_payment": grouped["days_from_sanction"].min(),
            "has_pre_sanction_payment": grouped["is_pre_sanction"].any().astype("int8"),
        }
    )
    advance_value = grouped.apply(
        lambda g: float((g["amount"] * g["is_advance"]).sum()), include_groups=False
    )
    features["advance_ratio"] = (advance_value / features["expenditure_to_date"]).fillna(0.0)

    # Longest silence between consecutive payments: a long gap on a part-paid
    # work is a different signal from a work that simply has few payments.
    gaps = (
        joined.sort_values(["work_id", "payment_date"])
        .groupby("work_id")["days_from_sanction"]
        .apply(lambda s: float(s.diff().max()) if len(s) > 1 else np.nan)
    )
    features["max_payment_gap_days"] = gaps

    # Payee on the largest payment: the vendor most exposed to this work.
    largest = joined.loc[joined.groupby("work_id")["amount"].idxmax()]
    features["vendor_id"] = largest.set_index("work_id")["vendor_id"]

    return features


# --------------------------------------------------------------------------
# progress-derived features
# --------------------------------------------------------------------------
def _progress_features(progress: pd.DataFrame) -> pd.DataFrame:
    """Velocity and acceleration from the progress update sequence.

    Velocity is percentage points per 30 days across the observed span, not
    between the last two updates: a single late update would otherwise swamp
    the signal. Acceleration needs three updates and is null below that,
    rather than being reported as zero change.
    """
    if progress.empty:
        return pd.DataFrame(
            columns=["progress_velocity", "progress_acceleration"],
            index=pd.Index([], name="work_id"),
        )

    ordered = progress.copy()
    ordered["update_date"] = pd.to_datetime(ordered["update_date"])
    ordered = ordered.sort_values(["work_id", "update_date"])

    def _rates(group: pd.DataFrame) -> pd.Series:
        if len(group) < 2:
            return pd.Series({"progress_velocity": 0.0, "progress_acceleration": 0.0})
        days = (group["update_date"] - group["update_date"].iloc[0]).dt.days.to_numpy(dtype=float)
        values = group["progress_pct"].to_numpy(dtype=float)
        span = days[-1] - days[0]
        velocity = (values[-1] - values[0]) / max(span, 1.0) * _DAYS_PER_MONTH

        acceleration = 0.0
        if len(group) >= 3:
            midpoint = len(group) // 2
            first_span = max(days[midpoint] - days[0], 1.0)
            second_span = max(days[-1] - days[midpoint], 1.0)
            first = (values[midpoint] - values[0]) / first_span * _DAYS_PER_MONTH
            second = (values[-1] - values[midpoint]) / second_span * _DAYS_PER_MONTH
            acceleration = second - first
        return pd.Series(
            {"progress_velocity": velocity, "progress_acceleration": acceleration}
        )

    return ordered.groupby("work_id")[["update_date", "progress_pct"]].apply(
        _rates, include_groups=False
    )


# --------------------------------------------------------------------------
# network features
# --------------------------------------------------------------------------
def _eigenvector_centrality(
    rows: np.ndarray, cols: np.ndarray, n_rows: int, n_cols: int, iterations: int = 50
) -> np.ndarray:
    """Eigenvector centrality of agencies in the MP-agency bipartite graph.

    Power iteration on the agency-agency co-occurrence implied by shared
    members, done in numpy rather than pulling in networkx -- the detection
    core must run on numpy and pandas alone (ADR-0001). An agency scores high
    when it works for many members who themselves work with many agencies.
    """
    if n_rows == 0 or n_cols == 0 or len(rows) == 0:
        return np.zeros(n_cols, dtype=float)

    incidence = np.zeros((n_rows, n_cols), dtype=np.float32)
    np.add.at(incidence, (rows, cols), 1.0)

    vector = np.ones(n_cols, dtype=np.float32) / np.sqrt(n_cols)
    for _ in range(iterations):
        # A^T (A v) avoids materialising the dense agency-agency matrix.
        nxt = incidence.T @ (incidence @ vector)
        norm = np.linalg.norm(nxt)
        if norm < 1e-12:
            return np.zeros(n_cols, dtype=float)
        nxt = nxt / norm
        if np.allclose(nxt, vector, atol=1e-9):
            vector = nxt
            break
        vector = nxt
    return np.abs(vector).astype(float)


def _network_features(works: pd.DataFrame) -> pd.DataFrame:
    """Concentration and centrality, all peer-relative to the district."""
    per_district = works.groupby("district_id")["work_id"].size().rename("district_works")
    per_pair = (
        works.groupby(["district_id", "agency_id"])["work_id"].size().rename("agency_works")
    )

    pair_frame = per_pair.reset_index().merge(
        per_district.reset_index(), on="district_id", how="left"
    )
    pair_frame["share"] = pair_frame["agency_works"] / pair_frame["district_works"]

    # Herfindahl-Hirschman index of agency shares within each district.
    hhi = (
        pair_frame.assign(sq=lambda f: f["share"] ** 2)
        .groupby("district_id")["sq"]
        .sum()
        .rename("agency_hhi")
    )

    # A share computed over a handful of works is arithmetic, not evidence.
    small = per_district[per_district < 10].index
    features = works[["work_id", "district_id", "agency_id", "mp_id"]].merge(
        pair_frame[["district_id", "agency_id", "share", "agency_works"]],
        on=["district_id", "agency_id"],
        how="left",
    )
    features = features.merge(hhi.reset_index(), on="district_id", how="left")
    features.loc[features["district_id"].isin(small), ["share", "agency_hhi"]] = np.nan

    # MP-agency affinity: how much of a member's portfolio one agency holds.
    mp_totals = works.groupby("mp_id")["work_id"].size()
    mp_agency = works.groupby(["mp_id", "agency_id"])["work_id"].size().rename("n")
    affinity = (mp_agency / mp_totals).rename("mp_agency_affinity").reset_index()
    features = features.merge(affinity, on=["mp_id", "agency_id"], how="left")
    thin_mps = mp_totals[mp_totals < 5].index
    features.loc[features["mp_id"].isin(thin_mps), "mp_agency_affinity"] = np.nan

    mp_codes, _ = pd.factorize(works["mp_id"])
    agency_codes, agency_index = pd.factorize(works["agency_id"])
    centrality = _eigenvector_centrality(
        mp_codes, agency_codes, int(mp_codes.max()) + 1, len(agency_index)
    )
    centrality_by_agency = pd.Series(centrality, index=agency_index, name="agency_centrality")
    features["agency_centrality"] = features["agency_id"].map(centrality_by_agency).fillna(0.0)

    return features.rename(
        columns={"share": "agency_district_share", "agency_works": "n_works_same_agency"}
    ).set_index("work_id")[
        [
            "agency_district_share",
            "agency_hhi",
            "agency_centrality",
            "mp_agency_affinity",
            "n_works_same_agency",
        ]
    ]


# --------------------------------------------------------------------------
# geography, text, assets
# --------------------------------------------------------------------------
def _geo_features(works: pd.DataFrame, districts: pd.DataFrame) -> pd.DataFrame:
    joined = works[["work_id", "district_id", "latitude", "longitude"]].merge(
        districts[["district_id", "centroid_lat", "centroid_lon", "bbox_half_deg"]],
        on="district_id",
        how="left",
    )

    has_coordinates = joined["latitude"].notna() & joined["longitude"].notna()
    inside = pd.Series(pd.NA, index=joined.index, dtype="Int8")
    distance = pd.Series(np.nan, index=joined.index, dtype=float)

    for position in np.flatnonzero(has_coordinates.to_numpy()):
        row = joined.iloc[position]
        half = float(row["bbox_half_deg"]) if pd.notna(row["bbox_half_deg"]) else 0.5
        bbox = (
            float(row["centroid_lat"]) - half,
            float(row["centroid_lon"]) - half,
            float(row["centroid_lat"]) + half,
            float(row["centroid_lon"]) + half,
        )
        inside.iloc[position] = int(
            point_in_bbox(float(row["latitude"]), float(row["longitude"]), bbox)
        )
        distance.iloc[position] = haversine_km(
            float(row["latitude"]),
            float(row["longitude"]),
            float(row["centroid_lat"]),
            float(row["centroid_lon"]),
        )

    # .to_numpy() is load-bearing, not stylistic. `inside` and `distance`
    # carry `joined`'s positional index; handing them to a DataFrame with
    # index=work_id makes pandas *align* rather than assign, silently shifting
    # every value by one row and destroying the signal without raising. That
    # bug made injected geographic displacement -- a 3.7 degree move -- read as
    # identical to the base population.
    return pd.DataFrame(
        {
            "geo_in_district": inside.to_numpy(),
            # bbox is weaker than point-in-polygon and the evidence card must
            # say so rather than implying a boundary test that did not happen.
            "geo_method": np.where(has_coordinates.to_numpy(), "bbox", "unknown"),
            "distance_to_district_centroid_km": distance.round(2).to_numpy(),
        },
        index=pd.Index(joined["work_id"], name="work_id"),
    )


def _asset_features(works: pd.DataFrame, photos: pd.DataFrame) -> pd.DataFrame:
    index = pd.Index(works["work_id"], name="work_id")
    if photos.empty:
        return pd.DataFrame(index=index).assign(
            photo_present=0,
            phash=pd.NA,
            phash_duplicate_count=0,
            exif_latitude=np.nan,
            exif_longitude=np.nan,
            exif_consistent=pd.NA,
        )

    primary = photos.drop_duplicates("work_id").set_index("work_id")
    hash_counts = photos["phash"].value_counts()

    features = pd.DataFrame(index=index)
    features["photo_present"] = index.isin(primary.index).astype("int8")
    features["phash"] = primary["phash"].reindex(index)
    # Other works sharing this hash. Zero when the photo is unique.
    features["phash_duplicate_count"] = (
        features["phash"].map(hash_counts).fillna(0).astype("int64") - features["photo_present"]
    ).clip(lower=0)
    features["exif_latitude"] = primary["exif_lat"].reindex(index)
    features["exif_longitude"] = primary["exif_lon"].reindex(index)

    coordinates = works.set_index("work_id")[["latitude", "longitude"]].reindex(index)
    comparable = (
        features["exif_latitude"].notna()
        & features["exif_longitude"].notna()
        & coordinates["latitude"].notna()
    )
    drift = np.hypot(
        features["exif_latitude"] - coordinates["latitude"],
        features["exif_longitude"] - coordinates["longitude"],
    )
    consistent = pd.Series(pd.NA, index=index, dtype="Int8")
    consistent[comparable] = (drift[comparable] < 0.05).astype("int8")
    features["exif_consistent"] = consistent
    return features


def _text_features(works: pd.DataFrame) -> pd.DataFrame:
    descriptions = works["description"].fillna("")
    profiles = descriptions.map(script_profile)
    language = profiles.map(
        lambda p: "hi"
        if p["devanagari"] > 0.6
        else ("en" if p["latin"] > 0.9 else ("mixed" if p["devanagari"] > 0 else "unknown"))
    )
    # .to_numpy() for the same reason as in _geo_features: assigning a
    # positionally-indexed Series against a work_id index makes pandas align
    # rather than assign.
    return pd.DataFrame(
        {
            "description": descriptions.astype("string").to_numpy(),
            "description_lang": language.astype("string").to_numpy(),
            "description_length": descriptions.map(
                lambda t: len(normalize_text(t))
            ).astype("int64").to_numpy(),
        },
        index=pd.Index(works["work_id"], name="work_id"),
    )


# --------------------------------------------------------------------------
# the build
# --------------------------------------------------------------------------
def _temporal_features(
    works: pd.DataFrame, payments: pd.DataFrame, progress: pd.DataFrame
) -> pd.DataFrame:
    """Time-series shape, assembled in `features.temporal`.

    Kept in its own module because two of the five held-out patterns are
    temporal, and the argument that each feature is *general* rather than
    pattern-targeted needs to live next to the code making it.
    """
    from .temporal import payment_rhythm, peer_survival, progress_shape, sanction_local_density

    index = pd.Index(works["work_id"], name="work_id")
    frame = pd.DataFrame(index=index)
    frame = frame.join(progress_shape(progress)).join(payment_rhythm(payments))
    frame["sanction_local_density"] = sanction_local_density(works)
    frame["peer_survival_at_age"] = peer_survival(works, _SCORING_DATE)
    return frame


def _peer_percentile(frame: pd.DataFrame, value_column: str) -> tuple[pd.Series, dict[str, Any]]:
    """Percentile of a value within its peer group, null for thin groups."""
    grouped = frame.groupby(list(PEER_GROUP_KEYS), dropna=False)[value_column]
    sizes = grouped.transform("size")
    percentile = grouped.rank(pct=True, method="average")
    percentile = percentile.where(sizes >= MIN_PEER_GROUP)

    group_sizes = frame.groupby(list(PEER_GROUP_KEYS), dropna=False).size()
    stats = {
        "n_groups": int(len(group_sizes)),
        "n_usable": int((group_sizes >= MIN_PEER_GROUP).sum()),
        "coverage": float(percentile.notna().mean()),
        "keys": list(PEER_GROUP_KEYS),
        "min_group_size": MIN_PEER_GROUP,
    }
    return percentile, stats


def build_features(
    works: pd.DataFrame,
    payments: pd.DataFrame,
    progress: pd.DataFrame,
    photos: pd.DataFrame,
    districts: pd.DataFrame,
    constituencies: pd.DataFrame,
    states: pd.DataFrame,
) -> FeatureBuildResult:
    """Compute every column of the Gold contract."""
    base = works.copy()
    base["sanction_date"] = pd.to_datetime(base["sanction_date"])
    base["recommended_on"] = pd.to_datetime(base["recommended_on"])
    base["expected_completion_date"] = pd.to_datetime(base["expected_completion_date"])
    base["actual_completion_date"] = pd.to_datetime(base["actual_completion_date"])

    # ---- reference joins ----
    state_names = dict(zip(states["state_id"], states["name"], strict=True))
    constituency_names = dict(
        zip(constituencies["constituency_id"], constituencies["name"], strict=True)
    )
    base["state"] = base["state_id"].map(state_names).astype("string")
    base["constituency"] = base["constituency_id"].map(constituency_names).astype("string")

    # ---- derived tables ----
    payment_features = _payment_features(base, payments)
    progress_features = _progress_features(progress)
    network_features = _network_features(base)
    geo_features = _geo_features(base, districts)
    asset_features = _asset_features(base, photos)
    text_features = _text_features(base)

    gold = base.set_index("work_id")
    for frame in (
        payment_features,
        progress_features,
        network_features,
        geo_features,
        asset_features,
        text_features,
    ):
        gold = gold.join(frame, how="left", rsuffix="_dup")
    gold = gold.drop(columns=[c for c in gold.columns if c.endswith("_dup")])
    gold = gold.reset_index()

    # ---- financial ----
    gold["expenditure_to_date"] = gold["expenditure_to_date"].fillna(0.0)
    gold["n_payments"] = gold["n_payments"].fillna(0).astype("int64")
    gold["advance_ratio"] = gold["advance_ratio"].fillna(0.0)
    gold["has_pre_sanction_payment"] = gold["has_pre_sanction_payment"].fillna(0).astype("int8")

    gold["unit_cost"] = safe_ratio(gold["sanctioned_cost"], gold["quantity"], default=np.nan)
    benchmark = gold["work_type"].map({k: v.value for k, v in SOR_UNIT_COST.items()})
    gold["unit_cost_vs_sor"] = safe_ratio(gold["unit_cost"], benchmark, default=np.nan)
    gold["cost_deviation_ratio"] = safe_ratio(
        gold["expenditure_to_date"], gold["sanctioned_cost"], default=0.0
    )
    gold["estimated_to_sanctioned_ratio"] = safe_ratio(
        gold["sanctioned_cost"], gold["estimated_cost"], default=np.nan
    )

    percentile, peer_stats = _peer_percentile(gold, "unit_cost")
    gold["unit_cost_peer_percentile"] = percentile.round(4)

    # ---- execution ----
    expenditure_pct = safe_ratio(gold["expenditure_to_date"], gold["sanctioned_cost"], 0.0) * 100.0
    gold["spend_progress_gap"] = (expenditure_pct - gold["progress_pct"]).round(2)
    gold["progress_velocity"] = gold["progress_velocity"].fillna(0.0).round(3)
    gold["progress_acceleration"] = gold["progress_acceleration"].fillna(0.0).round(3)

    # ---- temporal ----
    gold["days_since_sanction"] = (_SCORING_DATE - gold["sanction_date"]).dt.days.astype(float)
    gold["days_recommendation_to_sanction"] = (
        gold["sanction_date"] - gold["recommended_on"]
    ).dt.days.astype(float)
    # Peer-relative, for the same reason unit cost is. The absolute 75-day
    # window it replaced in `sanction_window_exceeded` is an ASSUMED constant
    # sitting at the 64th percentile of this very distribution (median 62,
    # p75 86), so it fired on 36.1% of the corpus -- a rule cutting through
    # the middle of its own data is measuring "typical", not "exceptional".
    delay_percentile, _ = _peer_percentile(gold, "days_recommendation_to_sanction")
    gold["sanction_delay_peer_percentile"] = delay_percentile.round(4)

    # ---- temporal shape (L5) ----
    shape = _temporal_features(works, payments, progress)
    for column in shape.columns:
        gold[column] = shape[column].reindex(gold["work_id"]).to_numpy().round(4)
    # March, the closing month of the Indian fiscal year. The `& (day >= 1)`
    # that used to sit here was vacuous -- every date has a day >= 1 -- so it
    # read as a narrowing filter while narrowing nothing, and the Seam A
    # description said "final 30 days" when the column has always meant "all
    # 31 days of March". The description now matches; the column does not
    # move, because `year_end_bunching` is held out (R-03) and sharpening a
    # feature against a held-out pattern is the targeting that rule forbids.
    gold["is_year_end_sanction"] = (gold["sanction_date"].dt.month == 3).astype("int8")
    gold["payment_velocity"] = safe_ratio(
        gold["expenditure_to_date"] * _DAYS_PER_MONTH,
        gold["days_since_sanction"].clip(lower=1.0),
        default=0.0,
    ).round(2)

    # ---- compliance context ----
    per_mp = gold.groupby("mp_id").apply(
        lambda g: pd.Series(
            {
                "mp_sc_share_pct": 100.0
                * float((g["sanctioned_cost"] * g["is_sc_area"]).sum())
                / max(float(g["sanctioned_cost"].sum()), 1.0),
                "mp_st_share_pct": 100.0
                * float((g["sanctioned_cost"] * g["is_st_area"]).sum())
                / max(float(g["sanctioned_cost"].sum()), 1.0),
            }
        ),
        include_groups=False,
    )
    gold = gold.merge(per_mp.reset_index(), on="mp_id", how="left")
    gold["is_sc_area"] = gold["is_sc_area"].astype("int8")
    gold["is_st_area"] = gold["is_st_area"].astype("int8")
    gold["photo_present"] = gold["photo_present"].fillna(0).astype("int8")
    gold["phash_duplicate_count"] = gold["phash_duplicate_count"].fillna(0).astype("int64")
    gold["financial_year"] = gold["financial_year"].astype("int64")

    # ---- data quality, computed last so it sees every gap ----
    optional = [spec.name for spec in GOLD_FEATURES if not spec.required]
    present = [column for column in optional if column in gold.columns]
    gold["n_missing_fields"] = gold[present].isna().sum(axis=1).astype("int64")
    gold["data_quality"] = (1.0 - gold["n_missing_fields"] / max(len(present), 1)).round(4)

    # ---- contract ----
    missing = [column for column in GOLD_COLUMNS if column not in gold.columns]
    for column in missing:
        gold[column] = pd.NA
    gold = gold[list(GOLD_COLUMNS)]

    assert_no_label_leakage(list(gold.columns))
    problems = validate_frame(gold)
    if missing:
        problems.append(f"columns filled with nulls because nothing computed them: {missing}")

    return FeatureBuildResult(features=gold, problems=problems, peer_group_stats=peer_stats)


def build_from_seeds() -> FeatureBuildResult:
    """Build from the parquet written by `drishti seed` and `drishti ingest`."""
    seeds = settings.paths.seeds
    required = [
        "synth_work", "synth_payment", "synth_progress", "synth_photo",
        "synth_district", "silver_constituency", "silver_state",
    ]
    absent = [name for name in required if not (seeds / f"{name}.parquet").is_file()]
    if absent:
        raise FileNotFoundError(
            f"missing seed tables: {absent}. Run `drishti ingest` then `drishti seed` first."
        )
    read = lambda name: pd.read_parquet(seeds / f"{name}.parquet")  # noqa: E731
    return build_features(
        works=read("synth_work"),
        payments=read("synth_payment"),
        progress=read("synth_progress"),
        photos=read("synth_photo"),
        districts=read("synth_district"),
        constituencies=read("silver_constituency"),
        states=read("silver_state"),
    )
