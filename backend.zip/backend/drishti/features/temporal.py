"""Temporal shape features for L5.

Two of the five held-out patterns are temporal -- `year_end_bunching` and
`progress_reversal` -- which makes this the most dangerous module in the
project to write. Nothing here may be designed to catch either. Every feature
is a **general** property of a time series or of a point process, chosen
because it is a standard statistic, and the fact that a reversal is rough or
that fiscal-year bunching is clustered has to emerge as generalisation or not
at all. This is L3's discipline (ADR-0011) applied to time.

The specific temptations declined, recorded so a later reader can check the
work rather than take it on trust:

* **Not** `n_negative_progress_increments`. That is `progress_reversal` with a
  different name. `progress_roughness` measures how much the series zigzags,
  and a strictly increasing stop-start series scores high on it too.
* **Not** "was this sanctioned in March". `is_year_end_sanction` already exists
  in the Gold view and is deliberately left out of L5's feature block.
  `sanction_local_density` measures clustering around *any* date, so bunching
  in July counts exactly as much.

ADR-0002 rejected recurrent models here on the grounds that a work carries
6-12 events. Measured: median 4 progress updates and 3 payments. The rejection
stands, and these are classical statistics -- second differences, coefficients
of variation, a Ripley-style local density, and a Kaplan-Meier survival curve.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

__all__ = [
    "TEMPORAL_FEATURES",
    "kaplan_meier",
    "payment_rhythm",
    "peer_survival",
    "progress_shape",
    "sanction_local_density",
]

# The columns this module contributes to the Gold view.
TEMPORAL_FEATURES: tuple[str, ...] = (
    "progress_roughness",
    "progress_increment_cv",
    "payment_interval_cv",
    "sanction_local_density",
    "peer_survival_at_age",
)

# Half-width of the window used for local sanction density, in days. A month
# either side: short enough that a genuine cluster stands out, long enough that
# ordinary administrative batching does not look like one.
DENSITY_WINDOW_DAYS = 30.0

# Survival is estimated within (sector, work_type). State is dropped from the
# peer key that the cost features use, because completion time varies by what
# is being built far more than by where.
SURVIVAL_GROUP_KEYS = ("sector", "work_type")
MIN_SURVIVAL_GROUP = 20


# --------------------------------------------------------------------------
# progress trajectory shape
# --------------------------------------------------------------------------
def progress_shape(progress: pd.DataFrame) -> pd.DataFrame:
    """How irregular a work's reported progress series is.

    `progress_roughness` is the mean absolute second difference of the
    percentage series, normalised by its total span. It is the standard
    smoothness measure for a short series: a straight climb scores 0 however
    steep, and anything that changes pace scores above it.

    `progress_increment_cv` is the dispersion of the increments, scaled by
    their mean *absolute* size rather than their mean. Using the signed mean
    would divide by something near zero whenever a series ends where it
    started, and turn a flat record into an infinite anomaly.

    Both need three updates to mean anything and are null below that. A work
    with two updates has no shape, and reporting 0.0 would claim it was
    perfectly smooth.
    """
    empty = pd.DataFrame(
        columns=["progress_roughness", "progress_increment_cv"],
        index=pd.Index([], name="work_id"),
        dtype=float,
    )
    if progress.empty:
        return empty

    ordered = progress.copy()
    ordered["update_date"] = pd.to_datetime(ordered["update_date"])
    ordered = ordered.sort_values(["work_id", "update_date"])

    def _shape(group: pd.DataFrame) -> pd.Series:
        values = group["progress_pct"].to_numpy(dtype=float)
        if len(values) < 3:
            return pd.Series(
                {"progress_roughness": np.nan, "progress_increment_cv": np.nan}
            )
        increments = np.diff(values)
        span = float(np.abs(values[-1] - values[0]))
        roughness = float(np.abs(np.diff(increments)).mean()) / max(span, 1.0)
        scale = float(np.abs(increments).mean())
        cv = float(increments.std()) / scale if scale > 1e-9 else np.nan
        return pd.Series(
            {"progress_roughness": roughness, "progress_increment_cv": cv}
        )

    return ordered.groupby("work_id")[["update_date", "progress_pct"]].apply(
        _shape, include_groups=False
    )


# --------------------------------------------------------------------------
# payment rhythm
# --------------------------------------------------------------------------
def payment_rhythm(payments: pd.DataFrame) -> pd.DataFrame:
    """Burstiness of the gaps between a work's payments.

    The coefficient of variation of inter-payment intervals: 0 for a perfectly
    regular schedule, rising as payments clump. A general point-process
    statistic, and the payment analogue of `progress_roughness`.

    Needs three payments -- two give a single interval, which has no dispersion.
    """
    empty = pd.DataFrame(
        columns=["payment_interval_cv"], index=pd.Index([], name="work_id"), dtype=float
    )
    if payments.empty:
        return empty

    ordered = payments.copy()
    ordered["payment_date"] = pd.to_datetime(ordered["payment_date"])
    ordered = ordered.sort_values(["work_id", "payment_date"])

    def _rhythm(group: pd.DataFrame) -> float:
        dates = group["payment_date"].to_numpy()
        if len(dates) < 3:
            return np.nan
        gaps = np.diff(dates).astype("timedelta64[D]").astype(float)
        mean = gaps.mean()
        return float(gaps.std() / mean) if mean > 1e-9 else np.nan

    result = ordered.groupby("work_id")[["payment_date"]].apply(
        _rhythm, include_groups=False
    )
    return result.to_frame("payment_interval_cv")


# --------------------------------------------------------------------------
# local density of an MP's sanctions
# --------------------------------------------------------------------------
def sanction_local_density(works: pd.DataFrame) -> pd.Series:
    """How clustered this work's sanction is among the same MP's sanctions.

    A Ripley-K-style local statistic: count the MP's other sanctions falling
    within `DENSITY_WINDOW_DAYS` either side, then divide by how many would be
    expected if that MP's sanctions were spread evenly across their active
    span. 1.0 means "as clustered as chance", above that means bunched.

    Deliberately calendar-blind. It has no notion of a fiscal year, a quarter
    or a month, so a cluster in July registers exactly as strongly as one in
    March -- which is what keeps it a general measure rather than a detector
    for a held-out pattern.
    """
    index = pd.Index(works["work_id"], name="work_id")
    if works.empty or "mp_id" not in works.columns:
        return pd.Series(np.nan, index=index, name="sanction_local_density")

    frame = works[["work_id", "mp_id", "sanction_date"]].copy()
    frame["sanction_date"] = pd.to_datetime(frame["sanction_date"])
    density = np.full(len(frame), np.nan)
    positions = {work_id: i for i, work_id in enumerate(frame["work_id"])}

    for _, group in frame.groupby("mp_id", dropna=False):
        days = group["sanction_date"].to_numpy(dtype="datetime64[D]").astype(float)
        n = len(days)
        if n < 3:
            continue
        span = float(days.max() - days.min())
        if span <= 0:
            # Every sanction on one day: maximally clustered, and dividing by a
            # zero span would say nothing at all.
            for work_id in group["work_id"]:
                density[positions[work_id]] = float(n)
            continue
        order = np.sort(days)
        expected = max((n - 1) * (2.0 * DENSITY_WINDOW_DAYS) / span, 1e-9)
        left = np.searchsorted(order, days - DENSITY_WINDOW_DAYS, side="left")
        right = np.searchsorted(order, days + DENSITY_WINDOW_DAYS, side="right")
        observed = (right - left - 1).astype(float)  # exclude the work itself
        for work_id, value in zip(group["work_id"], observed / expected, strict=True):
            density[positions[work_id]] = float(value)

    return pd.Series(density, index=index, name="sanction_local_density")


# --------------------------------------------------------------------------
# survival
# --------------------------------------------------------------------------
def kaplan_meier(
    durations: np.ndarray, events: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Kaplan-Meier survival estimate. Returns (times, survival).

    `events` is 1 where the duration ends in completion and 0 where the work is
    still running, i.e. right-censored. Censoring is the whole point: an
    incomplete work tells us the duration exceeded its current age, and
    dropping those would bias every estimate toward the works that finish fast.

    Written out rather than taken from lifelines: the detection core runs on
    numpy and pandas alone (ADR-0001).
    """
    durations = np.asarray(durations, dtype=float)
    events = np.asarray(events, dtype=float)
    keep = np.isfinite(durations) & (durations >= 0)
    durations, events = durations[keep], events[keep]
    if len(durations) == 0:
        return np.array([]), np.array([])

    order = np.argsort(durations, kind="stable")
    durations, events = durations[order], events[order]

    times = np.unique(durations[events > 0])
    if len(times) == 0:
        return np.array([0.0]), np.array([1.0])

    survival = np.empty(len(times))
    running = 1.0
    for i, t in enumerate(times):
        at_risk = float((durations >= t).sum())
        died = float(((durations == t) & (events > 0)).sum())
        if at_risk > 0:
            running *= 1.0 - died / at_risk
        survival[i] = running
    return times, survival


def peer_survival(works: pd.DataFrame, scoring_date: pd.Timestamp) -> pd.Series:
    """Probability a comparable work is still incomplete at this work's age.

    Fitted per `SURVIVAL_GROUP_KEYS` from every work in the group -- completed
    ones as events, incomplete ones as censored -- then read off at the age of
    each **incomplete** work.

    A low value is the finding: 0.02 means only 2% of comparable works were
    still running this long. That is a general lateness measure, not a
    prediction of fraud.

    Completed works get null rather than a number. Their survival is a fact
    about their own outcome, and scoring a work against evidence of how it
    turned out is the kind of circularity `Leakage.POST_OUTCOME` exists to
    prevent. Null here means "the question does not apply", which is what
    abstention is for.
    """
    index = pd.Index(works["work_id"], name="work_id")
    needed = {"sanction_date", "actual_completion_date", *SURVIVAL_GROUP_KEYS}
    if works.empty or not needed <= set(works.columns):
        return pd.Series(np.nan, index=index, name="peer_survival_at_age")

    frame = works[["work_id", *SURVIVAL_GROUP_KEYS]].copy()
    sanction = pd.to_datetime(works["sanction_date"])
    completion = pd.to_datetime(works["actual_completion_date"])
    is_complete = completion.notna()

    age = (completion.fillna(scoring_date) - sanction).dt.days.astype(float)
    frame["duration"] = age.to_numpy()
    frame["event"] = is_complete.astype(float).to_numpy()
    frame["is_complete"] = is_complete.to_numpy()

    out = np.full(len(frame), np.nan)
    positions = {work_id: i for i, work_id in enumerate(frame["work_id"])}

    for _, group in frame.groupby(list(SURVIVAL_GROUP_KEYS), dropna=False):
        if len(group) < MIN_SURVIVAL_GROUP:
            continue
        times, survival = kaplan_meier(
            group["duration"].to_numpy(), group["event"].to_numpy()
        )
        if len(times) == 0:
            continue
        open_works = group[~group["is_complete"]]
        if open_works.empty:
            continue
        ages = open_works["duration"].to_numpy(dtype=float)
        # Step function: survival at the last event time at or before the age.
        slot = np.searchsorted(times, ages, side="right") - 1
        values = np.where(slot >= 0, survival[np.clip(slot, 0, None)], 1.0)
        for work_id, value in zip(open_works["work_id"], values, strict=True):
            out[positions[work_id]] = float(value)

    return pd.Series(out, index=index, name="peer_survival_at_age")
