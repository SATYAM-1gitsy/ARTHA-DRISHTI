"""Seam A producer: the Gold feature view every detector consumes."""

from .build import MIN_PEER_GROUP, FeatureBuildResult, build_features, build_from_seeds

__all__ = ["MIN_PEER_GROUP", "FeatureBuildResult", "build_features", "build_from_seeds"]
