"""Numeric and structural helpers shared by every layer.

Depends on numpy only. The Build Manual's fallback strategy (Manual 12.4)
routes every "if you don't have PyOD / rapidfuzz / NetworkX / PostGIS" path
through this module, so it must import on a machine with nothing but numpy.
"""

from __future__ import annotations

import json
import math
import random
from collections.abc import Iterable, Sequence
from datetime import date, datetime
from typing import Any

import numpy as np

__all__ = [
    "set_seed",
    "minmax",
    "winsorize",
    "robust_z",
    "percentile_rank",
    "ecdf_tail",
    "ecod_scores",
    "safe_ratio",
    "DisjointSet",
    "haversine_km",
    "point_in_bbox",
    "to_jsonable",
    "dumps",
]

EPS = 1e-12
# Scale factor making MAD a consistent estimator of sigma for normal data.
MAD_TO_SIGMA = 1.4826
EARTH_RADIUS_KM = 6371.0088


# --------------------------------------------------------------------------
# reproducibility
# --------------------------------------------------------------------------
def set_seed(seed: int) -> None:
    """Seed every RNG the project may touch.

    torch is seeded only when installed, so this stays importable in the
    numpy-only fallback environment.
    """
    random.seed(seed)
    np.random.seed(seed)
    try:  # pragma: no cover - depends on optional install
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


# --------------------------------------------------------------------------
# normalization
# --------------------------------------------------------------------------
def _as_float_array(x: Sequence[float] | np.ndarray) -> np.ndarray:
    return np.asarray(x, dtype=float).ravel()


def minmax(x: Sequence[float] | np.ndarray) -> np.ndarray:
    """Scale to [0, 1]. A constant vector maps to all zeros, not NaN.

    NaNs are ignored when computing the range and returned as 0.0, so a
    detector never emits NaN into the Layer Output Contract.
    """
    a = _as_float_array(x)
    if a.size == 0:
        return a
    finite = a[np.isfinite(a)]
    if finite.size == 0:
        return np.zeros_like(a)
    lo, hi = float(finite.min()), float(finite.max())
    if hi - lo < EPS:
        return np.zeros_like(a)
    out = (a - lo) / (hi - lo)
    return np.clip(np.nan_to_num(out, nan=0.0), 0.0, 1.0)


def winsorize(
    x: Sequence[float] | np.ndarray, lower: float = 0.01, upper: float = 0.99
) -> np.ndarray:
    """Clip to the given quantiles.

    Blunts single extreme values that would otherwise dominate a min-max
    normalization or drag a peer-group baseline.
    """
    a = _as_float_array(x)
    if a.size == 0:
        return a
    finite = a[np.isfinite(a)]
    if finite.size == 0:
        return a
    lo = float(np.quantile(finite, lower))
    hi = float(np.quantile(finite, upper))
    return np.clip(a, lo, hi)


def robust_z(x: Sequence[float] | np.ndarray) -> np.ndarray:
    """Median/MAD z-score.

    Preferred over mean/std because a peer group containing the very anomaly
    we are hunting would otherwise inflate its own baseline and hide it.
    """
    a = _as_float_array(x)
    if a.size == 0:
        return a
    finite = a[np.isfinite(a)]
    if finite.size == 0:
        return np.zeros_like(a)
    med = float(np.median(finite))
    deviations = np.abs(finite - med)
    mad = float(np.median(deviations))
    if mad >= EPS:
        return np.nan_to_num((a - med) / (MAD_TO_SIGMA * mad), nan=0.0)

    # MAD is exactly zero whenever more than half the peer group shares one
    # value -- common in MPLADS, where many works of a type carry an identical
    # sanctioned amount. Falling back to the standard deviation here would be
    # self-defeating: the outlier we are hunting inflates that scale itself
    # and masks its own deviation. The mean absolute deviation from the median
    # is far less sensitive to it, so the outlier still separates.
    mean_ad = float(deviations.mean())
    if mean_ad >= EPS:
        return np.nan_to_num((a - med) / mean_ad, nan=0.0)

    sd = float(finite.std())
    if sd < EPS:
        return np.zeros_like(a)
    return np.nan_to_num((a - med) / sd, nan=0.0)


def percentile_rank(x: Sequence[float] | np.ndarray) -> np.ndarray:
    """Fraction of the sample at or below each value, in (0, 1].

    The peer-relative primitive. "This work's unit cost sits at the 97th
    percentile of its sector-and-state peers" is evidence a District officer
    can act on; a raw z-score is not. Ties share an averaged rank.
    """
    a = _as_float_array(x)
    n = a.size
    if n == 0:
        return a
    order = np.argsort(a, kind="mergesort")
    ranks = np.empty(n, dtype=float)
    ranks[order] = np.arange(1, n + 1, dtype=float)
    uniq, inv, counts = np.unique(a, return_inverse=True, return_counts=True)
    sums = np.zeros(uniq.size, dtype=float)
    np.add.at(sums, inv, ranks)
    ranks = (sums / counts)[inv]
    return ranks / n


def ecdf_tail(x: Sequence[float] | np.ndarray) -> np.ndarray:
    """Two-sided empirical tail probability per observation, in (0, 1].

    The core of ECOD: a value's outlyingness is how little of the sample lies
    further out than it does. Small means extreme. Assumes no distribution,
    and stays interpretable -- 0.01 reads as "only 1% of peers are this far
    out or further".
    """
    a = _as_float_array(x)
    n = a.size
    if n == 0:
        return a
    valid = np.isfinite(a)
    out = np.ones(n, dtype=float)
    if not valid.any():
        return out
    v = a[valid]
    m = v.size
    ordered = np.sort(v)
    left = np.searchsorted(ordered, v, side="right") / m
    right = 1.0 - np.searchsorted(ordered, v, side="left") / m
    out[valid] = np.maximum(np.minimum(left, right), 1.0 / m)
    return out


def ecod_scores(matrix: np.ndarray) -> np.ndarray:
    """Per-row ECOD-style outlier score from a 2-D feature matrix.

    Aggregates -log(tail probability) across columns, then min-max normalizes
    so the result satisfies the Layer Output Contract's [0, 1] requirement.
    Columns are scored independently -- that is ECOD's assumption, and also
    why its per-feature contributions read as evidence.
    """
    m = np.asarray(matrix, dtype=float)
    if m.ndim != 2:
        raise ValueError(f"ecod_scores expects a 2-D matrix, got shape {m.shape}")
    if m.size == 0 or m.shape[0] == 0:
        return np.zeros(m.shape[0], dtype=float)
    contributions = np.zeros_like(m)
    for j in range(m.shape[1]):
        contributions[:, j] = -np.log(ecdf_tail(m[:, j]))
    return minmax(contributions.sum(axis=1))


def safe_ratio(
    numerator: float | np.ndarray,
    denominator: float | np.ndarray,
    default: float = 0.0,
) -> float | np.ndarray:
    """Divide without ever emitting inf or NaN.

    Cost ratios are built from fields that are legitimately zero or missing in
    real MPLADS extracts, and an inf propagating into a feature column poisons
    every downstream model silently.
    """
    num = np.asarray(numerator, dtype=float)
    den = np.asarray(denominator, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        out = np.where(np.abs(den) < EPS, default, num / den)
    out = np.nan_to_num(out, nan=default, posinf=default, neginf=default)
    return float(out) if out.ndim == 0 else out


# --------------------------------------------------------------------------
# clustering primitive
# --------------------------------------------------------------------------
class DisjointSet:
    """Union-find with path compression and union by rank.

    Turns pairwise duplicate-work scores into duplicate clusters without
    pulling in scipy or networkx.
    """

    __slots__ = ("_parent", "_rank")

    def __init__(self, items: Iterable[Any] = ()) -> None:
        self._parent: dict[Any, Any] = {}
        self._rank: dict[Any, int] = {}
        for item in items:
            self.add(item)

    def add(self, item: Any) -> None:
        if item not in self._parent:
            self._parent[item] = item
            self._rank[item] = 0

    def find(self, item: Any) -> Any:
        self.add(item)
        root = item
        while self._parent[root] != root:
            root = self._parent[root]
        while self._parent[item] != root:  # path compression
            self._parent[item], item = root, self._parent[item]
        return root

    def union(self, a: Any, b: Any) -> bool:
        """Merge two sets. Returns False if they were already joined."""
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return False
        if self._rank[ra] < self._rank[rb]:
            ra, rb = rb, ra
        self._parent[rb] = ra
        if self._rank[ra] == self._rank[rb]:
            self._rank[ra] += 1
        return True

    def clusters(self) -> dict[Any, list[Any]]:
        """Root -> members, for every set with at least one element."""
        out: dict[Any, list[Any]] = {}
        for item in self._parent:
            out.setdefault(self.find(item), []).append(item)
        return out


# --------------------------------------------------------------------------
# geospatial (PostGIS fallback)
# --------------------------------------------------------------------------
def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in kilometres."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = p2 - p1
    dlam = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlam / 2) ** 2
    return 2 * EARTH_RADIUS_KM * math.asin(math.sqrt(min(1.0, a)))


def point_in_bbox(
    lat: float, lon: float, bbox: tuple[float, float, float, float]
) -> bool:
    """Point-in-bounding-box: the geo_in_district fallback without PostGIS.

    bbox is (min_lat, min_lon, max_lat, max_lon). Deliberately weaker than
    point-in-polygon -- it will pass some points outside the real district
    boundary, so callers must record which method was used and the evidence
    card must not overstate its confidence.
    """
    min_lat, min_lon, max_lat, max_lon = bbox
    if not (math.isfinite(lat) and math.isfinite(lon)):
        return False
    return min_lat <= lat <= max_lat and min_lon <= lon <= max_lon


# --------------------------------------------------------------------------
# json
# --------------------------------------------------------------------------
def to_jsonable(obj: Any) -> Any:
    """Recursively convert numpy and datetime types into JSON-native ones.

    Response models and evidence cards carry values that came out of numpy,
    and json.dumps refuses np.float64 and np.int64. Non-finite floats become
    null rather than the invalid JSON literal NaN.
    """
    if obj is None or isinstance(obj, (str, bool, int)):
        return obj
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, np.bool_):
        return bool(obj)
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        value = float(obj)
        return value if math.isfinite(value) else None
    if isinstance(obj, np.ndarray):
        return [to_jsonable(v) for v in obj.tolist()]
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [to_jsonable(v) for v in obj]
    return str(obj)


def dumps(obj: Any, **kwargs: Any) -> str:
    """json.dumps that never trips over numpy scalars."""
    return json.dumps(to_jsonable(obj), **kwargs)
