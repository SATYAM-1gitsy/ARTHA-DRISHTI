"""Evaluation: the harness that turns "trust us" into numbers.

Rule-visible and held-out results are computed separately and never pooled.
See `harness.EvaluationReport.pooled_metrics` for why that is enforced in code
rather than left to convention.
"""

from .harness import (
    EvaluationReport,
    IndependentResult,
    LabelSet,
    LayerResult,
    build_label_sets,
    evaluate_independent,
    evaluate_scores,
    run_evaluation,
    write_report,
)
from .metrics import (
    CalibrationMetrics,
    RankingMetrics,
    average_precision,
    calibration,
    precision_at_k,
    rank_metrics,
    recall_at_k,
    roc_auc,
)

__all__ = [
    "EvaluationReport",
    "IndependentResult",
    "evaluate_independent",
    "LabelSet",
    "LayerResult",
    "build_label_sets",
    "evaluate_scores",
    "run_evaluation",
    "write_report",
    "CalibrationMetrics",
    "RankingMetrics",
    "average_precision",
    "calibration",
    "precision_at_k",
    "rank_metrics",
    "recall_at_k",
    "roc_auc",
]
