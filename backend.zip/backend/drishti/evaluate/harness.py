"""The evaluation harness.

Turns "trust us" into numbers, and — more importantly — keeps the numbers
honest about what they are.

**Rule-visible and held-out results are never pooled.** If the generator
injects `pre_sanction_payment` and L0 has a `pre_sanction_payment` rule, recall
on that pattern measures a rule agreeing with its own injector, not detection
(finding R-03). Both are computed because the first is a useful pipeline check,
but `EvaluationReport` has no combined field and `pooled_metrics()` raises with
an explanation rather than returning a number. A mistake that is impossible to
make accidentally is worth more than a convention everybody agrees with.

**Three categories of evidence, not two.** Splitting results into "held-out"
and "rule-visible" was not sufficient once a *targeted* detector landed. L4
detects duplicates, no held-out pattern is textual, and so L4's marginal value
on held-out PR-AUC is negative at every weight -- measured, monotonically. That
is not L4 failing; it is held-out PR-AUC measuring generalisation to unseen
patterns, which a targeted detector trades against by construction.

So a third category is reported: **independent-corpus** results, measured on
hand-written labelled data that the generator never touched. It is neither
circular like rule-visible nor a generalisation test like held-out -- it is a
direct capability measurement, and it is where a targeted detector earns its
place.

**Ablation measures marginal value, not presence.** Every layer is scored
alone, and leave-one-out gives what each actually contributes to the full
stack. A layer that changes nothing when removed has not earned its place,
however sophisticated it is.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from datetime import UTC
from typing import Any

import numpy as np
import pandas as pd

from ..config import settings
from ..contracts.labels import PatternRecall
from ..domain import FRAUD_PATTERNS, PatternVisibility
from ..storage import read_gold
from ..util import dumps
from .metrics import (
    DEFAULT_K,
    CalibrationMetrics,
    RankingMetrics,
    average_precision,
    calibration,
    precision_at_k,
    rank_metrics,
    recall_at_k,
)

__all__ = [
    "IndependentResult",
    "evaluate_independent",
    "independent_with_reason",
    "LabelSet",
    "LayerResult",
    "EvaluationReport",
    "build_label_sets",
    "evaluate_scores",
    "run_evaluation",
]

log = logging.getLogger(__name__)

_BY_NAME = {p.name: p for p in FRAUD_PATTERNS}


@dataclass(frozen=True)
class LabelSet:
    """One evaluation target, carrying whether its numbers may be quoted."""

    name: str
    visibility: PatternVisibility
    work_ids: frozenset[int]

    @property
    def quotable(self) -> bool:
        """Whether a figure computed against this set is a detection claim.

        Only held-out patterns qualify. Rule-visible recall says a rule and its
        injector agree -- a correctness check on the pipeline, and worthless as
        evidence the system detects anything.
        """
        return self.visibility is PatternVisibility.HELD_OUT

    @property
    def caveat(self) -> str:
        return (
            "held-out: no detector was written against these patterns"
            if self.quotable
            else "RULE-VISIBLE: a rule agreeing with its own injector. "
            "Pipeline check only -- not a detection claim."
        )


@dataclass
class LayerResult:
    """One entry in the ablation table."""

    name: str
    layers: tuple[str, ...]
    held_out: RankingMetrics
    rule_visible: RankingMetrics
    seconds: float

    @property
    def headline(self) -> float:
        """The one number worth comparing across variants: held-out PR-AUC."""
        return self.held_out.pr_auc


@dataclass
class CombinerResult:
    """One entry in the combiner comparison.

    The comparison holds layer outputs and weights fixed and varies only the
    arithmetic, so a difference here is attributable to the combination rule
    and nothing else.

    `mean_pattern_lift` is the honesty column. Block 13's design was informed
    by held-out labels, so its held-out PR-AUC is optimistically biased. This
    scores each held-out pattern on its own, with the other four patterns'
    works removed, and averages the lift over that pattern's base rate. A gain
    carried by one pattern shows up here as an unchanged mean; a real
    improvement in the combination rule lifts all of them.
    """

    name: str
    pr_auc: float
    precision_at_500: float
    recall_at_2000: float
    mean_pattern_lift: float
    pattern_lift: dict[str, float] = field(default_factory=dict)
    is_active: bool = False

    def describe(self) -> str:
        marker = " <- in use" if self.is_active else ""
        return (
            f"{self.name:<22} PR-AUC {self.pr_auc:.4f}  P@500 {self.precision_at_500:>6.1%}"
            f"  R@2000 {self.recall_at_2000:>6.1%}  mean pattern lift "
            f"{self.mean_pattern_lift:>5.1f}x{marker}"
        )


@dataclass
class IndependentResult:
    """A capability measured on data the generator never produced.

    The only evidence that is neither circular nor a generalisation test.
    """

    name: str
    layer: str
    corpus: str
    method: str
    baseline: str
    roc_auc: float
    baseline_roc_auc: float
    f1: float
    baseline_f1: float
    n_items: int

    @property
    def gain(self) -> float:
        return self.roc_auc - self.baseline_roc_auc

    @property
    def justified(self) -> bool:
        return self.gain > 0.10

    def describe(self) -> str:
        verdict = "justified" if self.justified else "does not beat its baseline"
        return (
            f"{self.name}: ROC-AUC {self.roc_auc:.3f} vs {self.baseline} "
            f"{self.baseline_roc_auc:.3f} (+{self.gain:.3f}) on {self.n_items} "
            f"hand-labelled items -- {verdict}"
        )


def independent_with_reason() -> tuple[list[IndependentResult], str | None]:
    """Independent-corpus results, and why there are none when there are none.

    L4's *only* quotable justification lives in this category (ADR-0010), and
    it used to vanish from the report without a word on any machine where
    `sentence-transformers` is absent -- which is every machine except the
    ml-worker, including the one the pipeline runs on by default. A reader saw
    `"independent": []` and had no way to tell "measured, found nothing" from
    "never ran". Those are opposite conclusions about whether L4 has earned
    its weight, so the reason travels with the result.
    """
    try:
        from ..encoders import EncoderConfig, get_encoder
        from ..encoders.evaluate import (
            evaluate_similarity,
            lexical_baseline,
            load_corpus,
        )
    except ImportError as exc:
        reason = (
            f"not measured: the encoder is unavailable here ({exc}). It ships in "
            "the ml-worker image -- reproduce with `drishti jobs evaluate_l4`."
        )
        log.warning("independent corpora skipped -- %s", reason)
        return [], reason

    try:
        items = load_corpus()
        encoder = get_encoder(EncoderConfig(require_gpu=False))
        encoded = encoder.encode([i["text"] for i in items])
        semantic = evaluate_similarity(items, encoder.similarity(encoded.embeddings), "semantic")
        lexical = lexical_baseline(items)
    except Exception as exc:  # noqa: BLE001 - the encoder ships in the ml-worker only
        reason = (
            f"not measured: {type(exc).__name__}: {exc}. Reproduce where the "
            "encoder lives with `drishti jobs evaluate_l4`."
        )
        log.warning("independent corpora skipped -- %s", reason)
        return [], reason

    return [
        IndependentResult(
            name="L4 multilingual duplicate detection",
            layer="duplicate",
            corpus="description_pairs.json (hand-written)",
            method="multilingual bi-encoder",
            baseline="lexical token_set_ratio",
            roc_auc=semantic.roc_auc,
            baseline_roc_auc=lexical.roc_auc,
            f1=semantic.f1,
            baseline_f1=lexical.f1,
            n_items=len(items),
        )
    ], None


def evaluate_independent() -> list[IndependentResult]:
    """Measure capabilities against hand-written corpora.

    Currently one: L4 semantic duplicate detection on
    data/fixtures/description_pairs.json, which was written by hand and shares
    nothing with the generator.
    """
    return independent_with_reason()[0]


@dataclass
class EvaluationReport:
    """Everything the harness measured.

    Deliberately has no combined metric field. See `pooled_metrics`.
    """

    held_out: RankingMetrics
    rule_visible: RankingMetrics
    per_pattern: list[PatternRecall]
    calibration: CalibrationMetrics
    ablation: list[LayerResult] = field(default_factory=list)
    independent: list[IndependentResult] = field(default_factory=list)
    # Why `independent` is empty, when it is. "measured, found nothing" and
    # "never ran" are opposite conclusions about whether a targeted layer has
    # earned its weight, and an empty list alone cannot tell them apart.
    independent_unavailable: str | None = None
    combiners: list[CombinerResult] = field(default_factory=list)
    n_works: int = 0
    layers_run: tuple[str, ...] = ()
    combiner: str = ""
    generated_at: str = ""

    def pooled_metrics(self) -> None:
        """Deliberately unavailable.

        Pooling rule-visible and held-out results produces a number that looks
        like detection performance and is not. If you need a single headline,
        use `held_out` -- it is the only one that carries a claim.
        """
        raise NotImplementedError(
            "Rule-visible and held-out results must not be pooled (finding R-03). "
            "A rule agreeing with its own injector is not detection. "
            "Quote report.held_out; report.rule_visible is a pipeline check."
        )

    @property
    def quotable_headline(self) -> str:
        return (
            f"held-out PR-AUC {self.held_out.pr_auc:.3f} "
            f"({self.held_out.pr_auc_lift:.1f}x prevalence), "
            f"P@500 {self.held_out.precision_at.get(500, float('nan')):.1%}"
        )

    def marginal_value(self) -> dict[str, float]:
        """What each layer contributes, by leave-one-out on held-out PR-AUC."""
        full = next((r for r in self.ablation if r.name == "all layers"), None)
        if full is None:
            return {}
        out: dict[str, float] = {}
        for result in self.ablation:
            if result.name.startswith("without "):
                layer = result.name.removeprefix("without ")
                out[layer] = full.headline - result.headline
        return out

    def to_dict(self) -> dict[str, Any]:
        return {
            "generated_at": self.generated_at,
            "n_works": self.n_works,
            "layers_run": list(self.layers_run),
            "held_out": {
                "quotable": True,
                "note": "no detector was written against these patterns",
                "n_positive": self.held_out.n_positive,
                "prevalence": round(self.held_out.prevalence, 5),
                "pr_auc": round(self.held_out.pr_auc, 4),
                "pr_auc_lift": round(self.held_out.pr_auc_lift, 2),
                "roc_auc": round(self.held_out.roc_auc, 4),
                "precision_at": {str(k): round(v, 4) for k, v in self.held_out.precision_at.items()},
                "recall_at": {str(k): round(v, 4) for k, v in self.held_out.recall_at.items()},
                "lift_at": {str(k): round(v, 3) for k, v in self.held_out.lift_at.items()},
                "false_positives_per_100": {
                    str(k): round(v, 1) for k, v in self.held_out.false_positives_per_100.items()
                },
            },
            "rule_visible": {
                "quotable": False,
                "note": "a rule agreeing with its own injector -- pipeline check only",
                "n_positive": self.rule_visible.n_positive,
                "pr_auc": round(self.rule_visible.pr_auc, 4),
                "precision_at": {
                    str(k): round(v, 4) for k, v in self.rule_visible.precision_at.items()
                },
            },
            "per_pattern": [
                {
                    "pattern": r.pattern,
                    "visibility": r.visibility.value,
                    "quotable": r.quotable,
                    "n_injected": r.n_injected,
                    "n_detected": r.n_detected,
                    "recall": round(r.recall, 4),
                }
                for r in self.per_pattern
            ],
            "calibration": {
                "brier": round(self.calibration.brier, 5),
                "mean_predicted": round(self.calibration.mean_predicted, 4),
                "mean_observed": round(self.calibration.mean_observed, 4),
                "assessment": self.calibration.bias,
                "note": "the fused score is a priority ordering, not a probability",
                "bins": self.calibration.bins,
            },
            "ablation": [
                {
                    "variant": r.name,
                    "layers": list(r.layers),
                    "held_out_pr_auc": round(r.held_out.pr_auc, 4),
                    "held_out_p_at_500": round(r.held_out.precision_at.get(500, float("nan")), 4),
                    "held_out_r_at_2000": round(r.held_out.recall_at.get(2000, float("nan")), 4),
                    "seconds": round(r.seconds, 2),
                }
                for r in self.ablation
            ],
            "marginal_value_held_out_pr_auc": {
                k: round(v, 4) for k, v in self.marginal_value().items()
            },
            "combiners": {
                "in_use": self.combiner,
                "note": (
                    "layer outputs and weights held fixed; only the arithmetic varies. "
                    "mean_pattern_lift is leave-one-pattern-out and is the figure that "
                    "survives the design having been informed by held-out labels"
                ),
                "compared": [
                    {
                        "combiner": r.name,
                        "in_use": r.is_active,
                        "held_out_pr_auc": round(r.pr_auc, 4),
                        "held_out_p_at_500": round(r.precision_at_500, 4),
                        "held_out_r_at_2000": round(r.recall_at_2000, 4),
                        "mean_pattern_lift": round(r.mean_pattern_lift, 2),
                        "pattern_lift": {k: round(v, 2) for k, v in r.pattern_lift.items()},
                    }
                    for r in self.combiners
                ],
            },
            "independent": [
                {
                    "quotable": True,
                    "note": "measured on hand-written data the generator never produced",
                    "capability": r.name,
                    "layer": r.layer,
                    "corpus": r.corpus,
                    "method": r.method,
                    "baseline": r.baseline,
                    "roc_auc": round(r.roc_auc, 4),
                    "baseline_roc_auc": round(r.baseline_roc_auc, 4),
                    "gain": round(r.gain, 4),
                    "justified": r.justified,
                    "n_items": r.n_items,
                }
                for r in self.independent
            ],
            "independent_unavailable": self.independent_unavailable,
        }

    def render(self) -> str:
        lines = [
            f"evaluation -- {self.n_works:,} works, layers: {', '.join(self.layers_run)}",
            "",
            "  HELD-OUT PATTERNS  (no detector written against these -- quotable)",
            f"    {self.held_out.n_positive:,} positives, prevalence {self.held_out.prevalence:.2%}",
            f"    {self.held_out.summary_row(500)}",
            "",
            "  RULE-VISIBLE PATTERNS  (pipeline check only -- NOT a detection claim)",
            f"    {self.rule_visible.n_positive:,} positives, prevalence "
            f"{self.rule_visible.prevalence:.2%}",
            f"    {self.rule_visible.summary_row(500)}",
            "",
            "  per pattern",
        ]
        for result in sorted(
            self.per_pattern, key=lambda r: (not r.quotable, -r.recall)
        ):
            lines.append(f"    {result.describe()}")

        lines += [
            "",
            "  calibration",
            f"    Brier {self.calibration.brier:.4f} | mean predicted "
            f"{self.calibration.mean_predicted:.3f} vs observed "
            f"{self.calibration.mean_observed:.3f} -- {self.calibration.bias}",
            "    (the fused score is a priority ordering, not a probability)",
        ]

        if self.combiners:
            lines += [
                "",
                "  combiners  (same layer outputs, same weights -- only the arithmetic varies)",
            ]
            for result in self.combiners:
                lines.append(f"    {result.describe()}")
            lines.append(
                "    mean pattern lift is leave-one-pattern-out: a gain carried by one"
            )
            lines.append("    pattern leaves it flat.")

        if self.independent:
            lines += [
                "",
                "  INDEPENDENT CORPORA  (hand-written, generator never touched -- quotable)",
            ]
            for result in self.independent:
                lines.append(f"    {result.describe()}")
        elif self.independent_unavailable:
            # Silence here would read as "measured, found nothing", which is the
            # opposite of what happened. See `independent_with_reason`.
            lines += [
                "",
                "  INDEPENDENT CORPORA  (hand-written, generator never touched -- quotable)",
                f"    {self.independent_unavailable}",
            ]

        if self.ablation:
            lines += ["", "  ablation -- held-out PR-AUC", ""]
            lines.append(f"    {'variant':<28} {'PR-AUC':>8} {'P@500':>8} {'R@2000':>8} {'secs':>7}")
            lines.append("    " + "-" * 63)
            for result in self.ablation:
                lines.append(
                    f"    {result.name:<28} {result.held_out.pr_auc:>8.3f} "
                    f"{result.held_out.precision_at.get(500, float('nan')):>7.1%} "
                    f"{result.held_out.recall_at.get(2000, float('nan')):>7.1%} "
                    f"{result.seconds:>7.1f}"
                )
            marginal = self.marginal_value()
            if marginal:
                lines += ["", "  marginal value (full stack minus that layer)"]
                for layer, delta in sorted(marginal.items(), key=lambda kv: -kv[1]):
                    verdict = "earns its place" if delta > 0.005 else "adds nothing measurable"
                    lines.append(f"    {layer:<20} {delta:+.4f}  {verdict}")
        return "\n".join(lines)


def build_label_sets(labels: pd.DataFrame) -> tuple[LabelSet, LabelSet]:
    """Split ground truth into the two sets that must never be pooled."""
    held = labels[labels["visibility"] == PatternVisibility.HELD_OUT.value]
    visible = labels[labels["visibility"] == PatternVisibility.RULE_VISIBLE.value]
    return (
        LabelSet("held-out", PatternVisibility.HELD_OUT, frozenset(held["work_id"].astype(int))),
        LabelSet(
            "rule-visible",
            PatternVisibility.RULE_VISIBLE,
            frozenset(visible["work_id"].astype(int)),
        ),
    )


def _labels_for(work_ids: Sequence[int], target: LabelSet) -> np.ndarray:
    return np.array([1 if int(w) in target.work_ids else 0 for w in work_ids], dtype=int)


def ranking_score(primary: np.ndarray, tiebreak: np.ndarray | None = None) -> np.ndarray:
    """The order the review queue actually presents, as a rankable score.

    `api.store` sorts the queue by `(overall_risk, confidence)` descending, so
    a thinly-evidenced work never outranks a corroborated one at the same
    score. The harness ranked on `overall_risk` alone, which measured an
    ordering no reviewer is ever shown -- and the gap is not academic here,
    because L0 emits a handful of discrete scores: 3,445 works (17% of the
    corpus) share the single value 0.354284, and `R@2000` is read from inside
    that block.

    Returns a dense rank over the key, so works that are identical on *both*
    fields still tie. That matters: `average_precision` breaks ties
    pessimistically on purpose, and inventing an order for genuinely
    indistinguishable works would quietly hand back the protection that gives.

    Rank-based metrics only. `calibration` must see the raw score, not this.
    """
    values = np.asarray(primary, dtype=float)
    if tiebreak is None:
        return values
    second = np.nan_to_num(np.asarray(tiebreak, dtype=float), nan=0.0)
    key = np.stack([np.nan_to_num(values, nan=0.0), second], axis=1)
    # np.unique sorts rows lexicographically ascending, so `inverse` is already
    # a dense ascending rank in which equal (risk, confidence) pairs collide.
    _, inverse = np.unique(key, axis=0, return_inverse=True)
    return inverse.reshape(-1).astype(float)


def _aligned(frame: pd.Series | None, index: pd.Index) -> np.ndarray | None:
    return None if frame is None else frame.reindex(index).to_numpy(dtype=float)


def evaluate_scores(
    scores: pd.Series,
    labels: pd.DataFrame,
    ks: Sequence[int] = DEFAULT_K,
    tiebreak: pd.Series | None = None,
) -> tuple[RankingMetrics, RankingMetrics]:
    """Rank metrics for held-out and rule-visible, computed separately.

    `tiebreak` is the queue's secondary sort key -- confidence, in the shipped
    ordering. Omitting it measures a ranking the product does not present.
    """
    held, visible = build_label_sets(labels)
    work_ids = scores.index.to_numpy()
    values = ranking_score(scores.to_numpy(dtype=float), _aligned(tiebreak, scores.index))
    return (
        rank_metrics(values, _labels_for(work_ids, held), ks),
        rank_metrics(values, _labels_for(work_ids, visible), ks),
    )


def _per_pattern_recall(
    scores: pd.Series,
    labels: pd.DataFrame,
    k: int = 2000,
    tiebreak: pd.Series | None = None,
) -> list[PatternRecall]:
    """Recall per pattern, each carrying whether it may be quoted."""
    ordered = pd.Series(
        ranking_score(scores.to_numpy(dtype=float), _aligned(tiebreak, scores.index)),
        index=scores.index,
    )
    top = set(ordered.sort_values(ascending=False).head(k).index.astype(int))
    results: list[PatternRecall] = []
    for pattern, group in labels.groupby("pattern"):
        spec = _BY_NAME.get(str(pattern))
        if spec is None:
            continue
        injected = set(group["work_id"].astype(int))
        results.append(
            PatternRecall(
                pattern=str(pattern),
                visibility=spec.visibility,
                n_injected=len(injected),
                n_detected=len(injected & top),
            )
        )
    return results


def _combiner_comparison(
    scored: pd.DataFrame, labels: pd.DataFrame
) -> list[CombinerResult]:
    """Re-fuse the persisted layer scores under every available combiner.

    Cheap -- it reads `layer_scores` from the scored frame rather than re-running
    detectors -- so the comparison ships with every evaluation instead of living
    in a one-off script that rots.

    Layer weights are held at their configured values throughout. This measures
    the combination rule; re-tuning weights against held-out PR-AUC would fit
    the only honest metric the project has.
    """
    import json as _json

    from ..score.combine import COMBINERS, fit_calibration

    if "layer_scores" not in scored.columns or scored.empty:
        return []

    rows = [_json.loads(str(payload)) for payload in scored["layer_scores"]]
    work_ids = scored["work_id"].to_numpy()
    weights = settings.fusion.weights
    calibration = fit_calibration(rows)

    held = labels[labels["visibility"] == PatternVisibility.HELD_OUT.value]
    held_ids = set(held["work_id"].astype(int))
    if not held_ids:
        return []
    truth = np.array([int(w) in held_ids for w in work_ids], dtype=float)

    # Same secondary sort key the queue uses, so the row marked "in use" is the
    # same number as the headline above it. Confidence comes from corroborating
    # evidence families, not from the fused score, so it is identical under
    # every combiner -- the comparison still varies the arithmetic and nothing
    # else.
    tiebreak = (
        scored["confidence"].to_numpy(dtype=float)
        if "confidence" in scored.columns
        else None
    )

    results: list[CombinerResult] = []
    for name in sorted(COMBINERS):
        combiner = COMBINERS[name]
        if name == "calibrated_noisy_or":
            fused = np.array(
                [combiner(row, weights, calibration) for row in rows], dtype=float
            )
        else:
            fused = np.array([combiner(row, weights) for row in rows], dtype=float)
        ranked = ranking_score(fused, tiebreak)

        # Leave-one-pattern-out: score each held-out pattern against the clean
        # population, with the other held-out patterns' works removed so they
        # cannot count as false positives.
        lifts: dict[str, float] = {}
        for pattern in sorted(held["pattern"].unique()):
            target = set(held.loc[held["pattern"] == pattern, "work_id"].astype(int))
            others = held_ids - target
            keep = np.array([int(w) not in others for w in work_ids])
            y = np.array([int(w) in target for w in work_ids], dtype=float)[keep]
            base = y.mean()
            if base <= 0:
                continue
            lifts[str(pattern)] = average_precision(ranked[keep], y) / base

        results.append(
            CombinerResult(
                name=name,
                pr_auc=average_precision(ranked, truth),
                precision_at_500=precision_at_k(ranked, truth, 500),
                recall_at_2000=recall_at_k(ranked, truth, 2000),
                mean_pattern_lift=float(np.mean(list(lifts.values()))) if lifts else 0.0,
                pattern_lift=lifts,
                is_active=name == settings.fusion.combiner,
            )
        )
    return results


def _ablation(
    features: pd.DataFrame, labels: pd.DataFrame, ks: Sequence[int]
) -> list[LayerResult]:
    """Each layer alone, the full stack, and leave-one-out.

    Leave-one-out is what answers "does this layer earn its place?". A layer
    whose removal changes nothing has not, however sophisticated it is.

    **Every detector runs exactly once**, not once per variant. Eleven variants
    over five layers used to mean eleven full detector passes over the whole
    population, and the answers were identical every time: Seam B requires a
    layer to read only the Gold view, so its output cannot depend on which
    other layers are in the subset. Only the fusion differs, so only the fusion
    is repeated. This is a straight ~10x on `drishti eval` and on the test
    fixture that calls it, and it changes no number the harness reports.
    """
    from ..contracts.layer import LayerOutput
    from ..score.fusion import load_layers, score_population

    available, _ = load_layers()
    if not available:
        return []

    # One pass per detector, timed, so a variant can still report what it would
    # cost to run rather than only what the re-fusion cost.
    cached: dict[str, list[LayerOutput]] = {}
    layer_seconds: dict[str, float] = {}
    for name, runner in available.items():
        started = time.perf_counter()
        try:
            cached[name] = list(runner(features, None))
        except Exception as exc:  # noqa: BLE001 - matches score_population's contract
            log.error("layer %s failed during ablation (%s) -- excluded", name, exc)
            continue
        layer_seconds[name] = time.perf_counter() - started

    def replay(name: str) -> Callable:
        """Hand back this layer's already-computed output, ignoring arguments."""
        outputs = cached[name]
        return lambda _features, _ctx=None: outputs

    runners = {name: replay(name) for name in cached}
    variants: list[tuple[str, dict[str, Callable]]] = [
        (f"{name} only", {name: runner}) for name, runner in runners.items()
    ]
    if len(runners) > 1:
        variants.append(("all layers", dict(runners)))
        for name in runners:
            variants.append(
                ("without " + name, {k: v for k, v in runners.items() if k != name})
            )

    results: list[LayerResult] = []
    for label, subset in variants:
        started = time.perf_counter()
        outcome = score_population(features, layers=subset)
        assessments = outcome.assessments
        scores = pd.Series({a.work_id: a.overall_risk for a in assessments}).sort_index()
        confidence = pd.Series({a.work_id: a.confidence for a in assessments}).sort_index()
        held, visible = evaluate_scores(scores, labels, ks, tiebreak=confidence)
        results.append(
            LayerResult(
                name=label,
                layers=tuple(sorted(subset)),
                held_out=held,
                rule_visible=visible,
                seconds=(time.perf_counter() - started)
                + sum(layer_seconds.get(name, 0.0) for name in subset),
            )
        )
    return results


def run_evaluation(
    *, with_ablation: bool = True, ks: Sequence[int] = DEFAULT_K
) -> EvaluationReport:
    """Evaluate the current scored population against ground truth."""
    from datetime import datetime

    gold_path = settings.paths.out / "gold.parquet"
    risk_path = settings.paths.out / "risk_score.parquet"
    labels_path = settings.paths.seeds / "fraud_label.parquet"
    missing = [str(p) for p in (gold_path, risk_path, labels_path) if not p.is_file()]
    if missing:
        raise FileNotFoundError(
            f"missing {missing}. Run `drishti seed`, `drishti features` and `drishti score`."
        )

    features = read_gold(gold_path)
    scored = pd.read_parquet(risk_path)
    labels = pd.read_parquet(labels_path)

    # Which layers actually contributed, read from the persisted layer_scores
    # rather than from the module registry: the report must describe the run
    # that produced these scores, not whatever happens to be importable now.
    import json as _json

    contributing: set[str] = set()
    for payload in scored["layer_scores"].head(2000):
        contributing.update(_json.loads(str(payload)))

    indexed = scored.set_index("work_id").sort_index()
    scores = indexed["overall_risk"]
    # The queue is ordered by (risk, confidence); measuring risk alone reports
    # on a ranking nobody is shown. See `ranking_score`.
    confidence = indexed["confidence"] if "confidence" in indexed.columns else None
    held, visible = evaluate_scores(scores, labels, ks, tiebreak=confidence)

    # Calibration is measured against *all* injected works, held-out and
    # rule-visible together. That is legitimate here where pooling ranking
    # metrics is not: calibration asks "does a 0.8 score mean 80%?", which is
    # a property of the score itself rather than a detection claim.
    independent, independent_reason = independent_with_reason()

    all_injected = set(labels["work_id"].astype(int))
    truth = np.array([1 if int(w) in all_injected else 0 for w in scores.index], dtype=int)

    return EvaluationReport(
        held_out=held,
        rule_visible=visible,
        per_pattern=_per_pattern_recall(scores, labels, tiebreak=confidence),
        calibration=calibration(scores.to_numpy(dtype=float), truth),
        ablation=_ablation(features, labels, ks) if with_ablation else [],
        independent=independent,
        independent_unavailable=independent_reason,
        combiners=_combiner_comparison(scored, labels),
        n_works=len(scores),
        layers_run=tuple(sorted(contributing)),
        combiner=settings.fusion.combiner,
        generated_at=datetime.now(UTC).isoformat(timespec="seconds"),
    )


def write_report(report: EvaluationReport) -> str:
    """Persist the report next to the scores it describes."""
    path = settings.paths.out / "metrics.json"
    path.write_text(dumps(report.to_dict(), indent=2), encoding="utf-8")
    return str(path)
