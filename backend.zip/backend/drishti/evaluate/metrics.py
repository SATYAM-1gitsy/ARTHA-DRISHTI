"""Ranking and calibration metrics, in numpy.

Chosen for a problem with ~7% prevalence and a human reviewer at the other
end, which rules several popular metrics out:

* **ROC-AUC is not the headline.** At low prevalence it stays flattering while
  the queue fills with false positives, because it is dominated by the vast
  true-negative mass an investigator never looks at. It is reported as a
  secondary figure only.
* **Accuracy is not reported at all.** Predicting "clean" for every work
  scores 93% here and is worthless.
* **Precision@K is the metric that matches the job.** A District officer works
  a queue of finite length; what matters is how much of the top K is worth
  their morning.

`false_positives_per_100_reviewed` exists because it is the number an officer
actually experiences, and it makes a bad queue impossible to dress up.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field

import numpy as np

__all__ = [
    "RankingMetrics",
    "CalibrationMetrics",
    "average_precision",
    "roc_auc",
    "precision_at_k",
    "recall_at_k",
    "rank_metrics",
    "calibration",
    "DEFAULT_K",
]

# Queue depths a reviewer might plausibly work: a morning, a day, a week.
DEFAULT_K: tuple[int, ...] = (50, 100, 200, 500, 1000, 2000)


def _validate(scores: np.ndarray, labels: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    scores = np.asarray(scores, dtype=float)
    labels = np.asarray(labels, dtype=int)
    if scores.shape != labels.shape:
        raise ValueError(f"scores {scores.shape} and labels {labels.shape} disagree")
    if scores.size == 0:
        raise ValueError("cannot evaluate an empty ranking")
    if not np.isin(labels, (0, 1)).all():
        raise ValueError("labels must be 0 or 1")
    return scores, labels


def average_precision(scores: np.ndarray, labels: np.ndarray) -> float:
    """Area under the precision-recall curve, by the step-wise definition.

    The right summary for imbalanced detection: unlike ROC-AUC its baseline is
    the prevalence, so a PR-AUC of 0.30 at 7% prevalence is visibly a 4x lift
    rather than a number that looks poor.

    Ties are broken by taking the worst case -- all tied items counted at the
    end of their block -- so a detector that assigns one score to a thousand
    works cannot inflate its result by luck of ordering.
    """
    scores, labels = _validate(scores, labels)
    positives = int(labels.sum())
    if positives == 0:
        return float("nan")

    order = np.argsort(-scores, kind="mergesort")
    sorted_scores = scores[order]
    sorted_labels = labels[order]

    # Worst-case tie handling: advance the cumulative counts to the end of each
    # block of equal scores before reading precision off.
    boundaries = np.flatnonzero(np.diff(sorted_scores)) + 1
    ends = np.append(boundaries, len(sorted_scores))

    true_positives = np.cumsum(sorted_labels)
    total = 0.0
    previous_recall = 0.0
    for end in ends:
        recall = true_positives[end - 1] / positives
        precision = true_positives[end - 1] / end
        total += (recall - previous_recall) * precision
        previous_recall = recall
    return float(total)


def roc_auc(scores: np.ndarray, labels: np.ndarray) -> float:
    """Secondary only. See the module docstring for why it is not the headline."""
    scores, labels = _validate(scores, labels)
    positives = int(labels.sum())
    negatives = int(len(labels) - positives)
    if positives == 0 or negatives == 0:
        return float("nan")

    order = np.argsort(scores, kind="mergesort")
    ranks = np.empty(len(scores), dtype=float)
    ranks[order] = np.arange(1, len(scores) + 1, dtype=float)
    unique, inverse, counts = np.unique(scores, return_inverse=True, return_counts=True)
    sums = np.zeros(unique.size, dtype=float)
    np.add.at(sums, inverse, ranks)
    ranks = (sums / counts)[inverse]
    rank_sum = ranks[labels == 1].sum()
    return float((rank_sum - positives * (positives + 1) / 2) / (positives * negatives))


def precision_at_k(scores: np.ndarray, labels: np.ndarray, k: int) -> float:
    scores, labels = _validate(scores, labels)
    k = min(k, len(scores))
    if k <= 0:
        return float("nan")
    top = np.argsort(-scores, kind="mergesort")[:k]
    return float(labels[top].sum() / k)


def recall_at_k(scores: np.ndarray, labels: np.ndarray, k: int) -> float:
    scores, labels = _validate(scores, labels)
    positives = int(labels.sum())
    if positives == 0:
        return float("nan")
    k = min(k, len(scores))
    top = np.argsort(-scores, kind="mergesort")[:k]
    return float(labels[top].sum() / positives)


@dataclass
class RankingMetrics:
    """How well a ranking puts the right works at the top."""

    n: int
    n_positive: int
    prevalence: float
    pr_auc: float
    roc_auc: float
    precision_at: dict[int, float] = field(default_factory=dict)
    recall_at: dict[int, float] = field(default_factory=dict)
    f1_at: dict[int, float] = field(default_factory=dict)
    lift_at: dict[int, float] = field(default_factory=dict)
    false_positives_per_100: dict[int, float] = field(default_factory=dict)

    @property
    def pr_auc_lift(self) -> float:
        """PR-AUC against the only baseline that means anything: prevalence."""
        return self.pr_auc / self.prevalence if self.prevalence > 0 else float("nan")

    def summary_row(self, k: int = 500) -> str:
        return (
            f"PR-AUC {self.pr_auc:.3f} ({self.pr_auc_lift:.1f}x prevalence) | "
            f"P@{k} {self.precision_at.get(k, float('nan')):.1%} | "
            f"R@{k} {self.recall_at.get(k, float('nan')):.1%} | "
            f"lift {self.lift_at.get(k, float('nan')):.1f}x | "
            f"{self.false_positives_per_100.get(k, float('nan')):.0f} false positives "
            f"per 100 reviewed"
        )


def rank_metrics(
    scores: np.ndarray, labels: np.ndarray, ks: Sequence[int] = DEFAULT_K
) -> RankingMetrics:
    """Every ranking metric at once."""
    scores, labels = _validate(scores, labels)
    n = len(scores)
    positives = int(labels.sum())
    prevalence = positives / n if n else 0.0

    metrics = RankingMetrics(
        n=n,
        n_positive=positives,
        prevalence=prevalence,
        pr_auc=average_precision(scores, labels),
        roc_auc=roc_auc(scores, labels),
    )
    for k in ks:
        if k > n:
            continue
        precision = precision_at_k(scores, labels, k)
        recall = recall_at_k(scores, labels, k)
        metrics.precision_at[k] = precision
        metrics.recall_at[k] = recall
        metrics.f1_at[k] = (
            2 * precision * recall / (precision + recall)
            if (precision + recall) > 0
            else 0.0
        )
        metrics.lift_at[k] = precision / prevalence if prevalence > 0 else float("nan")
        metrics.false_positives_per_100[k] = 100.0 * (1.0 - precision)
    return metrics


@dataclass
class CalibrationMetrics:
    """How far the score is from being a probability.

    The fused score is a *priority ordering*, not a calibrated probability, and
    nothing in the pipeline yet claims otherwise. These figures are reported so
    the gap is measured rather than assumed -- they are the baseline Block 13's
    calibration has to improve on, and until then the score must not be read as
    "a 0.8 work is 80% likely to be a problem".
    """

    brier: float
    mean_predicted: float
    mean_observed: float
    bins: list[dict[str, float]] = field(default_factory=list)

    @property
    def is_calibrated(self) -> bool:
        """Within 5 points on average. Currently expected to be False."""
        return abs(self.mean_predicted - self.mean_observed) < 0.05

    @property
    def bias(self) -> str:
        gap = self.mean_predicted - self.mean_observed
        if abs(gap) < 0.05:
            return "roughly calibrated"
        return "over-confident" if gap > 0 else "under-confident"


def calibration(
    scores: np.ndarray, labels: np.ndarray, n_bins: int = 10
) -> CalibrationMetrics:
    """Brier score and a reliability curve."""
    scores, labels = _validate(scores, labels)
    brier = float(np.mean((scores - labels) ** 2))

    edges = np.linspace(0.0, 1.0, n_bins + 1)
    bins: list[dict[str, float]] = []
    for index in range(n_bins):
        low, high = edges[index], edges[index + 1]
        mask = (scores >= low) & (scores < high if index < n_bins - 1 else scores <= high)
        if not mask.any():
            continue
        bins.append(
            {
                "low": float(low),
                "high": float(high),
                "n": int(mask.sum()),
                "mean_predicted": float(scores[mask].mean()),
                "observed_rate": float(labels[mask].mean()),
            }
        )

    return CalibrationMetrics(
        brier=brier,
        mean_predicted=float(scores.mean()),
        mean_observed=float(labels.mean()),
        bins=bins,
    )
