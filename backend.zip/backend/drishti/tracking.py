"""Experiment tracking, with tracking failures treated as non-fatal.

Every model experiment must record enough to be reproduced: dataset version,
feature version, code commit, seed, GPU configuration, hyperparameters,
metrics, timings and the artifact. That is what turns "our model got 0.87"
into a claim someone else can check.

The design rule here is that **tracking must never fail a run**. A down MLflow
sidecar costs a metric log; raising from it would cost an hour of training.
Every public function swallows tracking errors and records them, and `run()`
works identically whether MLflow is installed, reachable, or neither.
"""

from __future__ import annotations

import logging
import os
import platform
import subprocess
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any

from .config import settings
from .gpu import detect as detect_gpu
from .util import to_jsonable

__all__ = ["RunContext", "git_commit", "environment_tags", "run", "is_available"]

log = logging.getLogger(__name__)

try:
    import mlflow

    MLFLOW_IMPORT_ERROR: str | None = None
except ImportError as exc:  # pragma: no cover - depends on optional install
    mlflow = None  # type: ignore[assignment]
    MLFLOW_IMPORT_ERROR = str(exc)


def is_available() -> bool:
    """Whether tracking is both installed and switched on."""
    return mlflow is not None and settings.tracking.enabled


def git_commit() -> str:
    """Short commit hash, or 'unknown' outside a work tree.

    A metric without the commit that produced it is not reproducible, so this
    is recorded on every run rather than left to the caller to remember.
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
            cwd=os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    return "unknown"


def environment_tags() -> dict[str, str]:
    """Everything about this machine that could change a result."""
    report = detect_gpu()
    return {
        "git_commit": git_commit(),
        "host": platform.node(),
        "python": platform.python_version(),
        "seed": str(settings.seed),
        "gpu": report.device_name or "cpu",
        "gpu_usable": str(report.usable),
        "torch": report.torch_version or "absent",
        "cuda_build": report.cuda_build or "none",
        "mixed_precision": settings.gpu.mixed_precision,
    }


@dataclass
class RunContext:
    """Handle passed to the body of a tracked run.

    Collects params, metrics and artifacts, forwarding each to MLflow when it
    is available and always retaining them locally so a caller can assert on
    what was logged even with no tracking server in sight -- which is what
    makes this testable.
    """

    name: str
    params: dict[str, Any] = field(default_factory=dict)
    metrics: dict[str, float] = field(default_factory=dict)
    tags: dict[str, str] = field(default_factory=dict)
    artifacts: list[str] = field(default_factory=list)
    tracked: bool = False
    errors: list[str] = field(default_factory=list)
    started_at: float = field(default_factory=time.perf_counter)

    @property
    def elapsed_seconds(self) -> float:
        return time.perf_counter() - self.started_at

    def log_params(self, **params: Any) -> None:
        self.params.update(params)
        self._forward(lambda: mlflow.log_params(to_jsonable(params)))

    def log_metrics(self, step: int | None = None, **metrics: float) -> None:
        numeric = {k: float(v) for k, v in metrics.items() if v is not None}
        self.metrics.update(numeric)
        if numeric:
            self._forward(lambda: mlflow.log_metrics(numeric, step=step))

    def set_tags(self, **tags: str) -> None:
        stringified = {k: str(v) for k, v in tags.items()}
        self.tags.update(stringified)
        self._forward(lambda: mlflow.set_tags(stringified))

    def log_artifact(self, path: str) -> None:
        self.artifacts.append(str(path))
        self._forward(lambda: mlflow.log_artifact(str(path)))

    def _forward(self, action) -> None:
        if not self.tracked:
            return
        try:
            action()
        except Exception as exc:  # noqa: BLE001 - tracking must never fail a run
            message = f"{type(exc).__name__}: {exc}"
            self.errors.append(message)
            log.warning("tracking call failed (continuing): %s", message)


@contextmanager
def run(name: str, **params: Any) -> Iterator[RunContext]:
    """Track an experiment run.

    Yields a RunContext whether or not MLflow is installed or reachable, so
    calling code needs no conditional. `context.tracked` says which happened.

    A run duration is always recorded, because "the deep model won by 0.004
    PR-AUC and took 40x longer" is the comparison that actually decides
    whether to keep it.
    """
    context = RunContext(name=name)

    if is_available():
        try:
            mlflow.set_tracking_uri(settings.tracking.tracking_uri)
            mlflow.set_experiment(settings.tracking.experiment)
            mlflow.start_run(run_name=name)
            context.tracked = True
        except Exception as exc:  # noqa: BLE001 - a down sidecar is not fatal
            message = f"{type(exc).__name__}: {exc}"
            context.errors.append(message)
            log.warning(
                "MLflow unreachable at %s (%s) -- continuing untracked",
                settings.tracking.tracking_uri,
                message,
            )
    elif mlflow is None:
        context.errors.append(f"mlflow not installed: {MLFLOW_IMPORT_ERROR}")
    else:
        context.errors.append("tracking disabled by configuration")

    context.set_tags(**environment_tags())
    if params:
        context.log_params(**params)

    try:
        yield context
    except Exception:
        context.set_tags(status="failed")
        raise
    else:
        context.set_tags(status="completed")
    finally:
        context.log_metrics(duration_seconds=context.elapsed_seconds)
        if context.tracked:
            try:
                mlflow.end_run()
            except Exception as exc:  # noqa: BLE001
                context.errors.append(f"{type(exc).__name__}: {exc}")
