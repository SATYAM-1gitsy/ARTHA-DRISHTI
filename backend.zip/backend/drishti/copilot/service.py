"""Answering a question, with Gemini when it is configured and without it otherwise.

**Retrieval always runs; generation is a phrasing layer over it.** The model is
never asked what the guidelines say — it is handed the clauses retrieval found
and asked to phrase them. That ordering is what stops the copilot inventing a
guideline, which for a government accountability tool is the worst thing it
could do: an invented clause arrives wearing the same authority as a real one.

**It does not adjudicate.** The system instruction forbids deciding whether a
work is fraudulent, and every answer carries the clauses it rests on so a
reader can check it. The project's whole stance is that it flags for review and
never issues a verdict; a chat box is exactly where that would erode first.

The key is read from `GEMINI_API_KEY` in the environment or `.env` and is never
logged, echoed into a response, or persisted.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any

from .corpus import GuidelineChunk, get_corpus

__all__ = [
    "CopilotAnswer",
    "CopilotStatus",
    "answer_question",
    "diagnose",
    "explain_work",
    "gemini_model",
    "llm_available",
]

log = logging.getLogger(__name__)

# Free tier at time of writing. Overridable for when the name changes.
DEFAULT_GEMINI_MODEL = "gemini-2.0-flash"
GEMINI_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models"
REQUEST_TIMEOUT_S = 20.0


def gemini_model() -> str:
    """The configured model, read per call rather than at import.

    `GEMINI_MODEL` used to be bound once when this module was first imported,
    which meant a deployment that set it *after* the first import -- or an
    operator changing it in `.env` while the API was up -- kept talking to the
    old model with nothing to show why. `api_key()` already reads per call;
    these two now behave the same way.
    """
    return os.environ.get("GEMINI_MODEL", "").strip() or DEFAULT_GEMINI_MODEL


# Backwards-compatible alias. Prefer `gemini_model()`.
GEMINI_MODEL = DEFAULT_GEMINI_MODEL

SYSTEM_RULES = (
    "You are a research assistant inside an Indian government audit tool for the "
    "MPLAD Scheme. Follow these rules exactly.\n"
    "1. Answer ONLY from the numbered guideline extracts supplied below. If they "
    "do not answer the question, say so plainly and stop. Never supply a clause, "
    "number, figure or rule from your own knowledge.\n"
    "2. Cite the paragraph number for every factual claim, like (Para 3.12).\n"
    "3. Never state or imply that a work, official or Member is fraudulent, "
    "corrupt, or in breach. This system flags works for human review and does not "
    "issue verdicts. Describe what the guidelines require and what would need "
    "checking.\n"
    "4. Be brief. Three or four sentences unless asked for more.\n"
    "5. If the extracts are from an older edition, do not claim they are current."
)


def api_key() -> str | None:
    """The configured key, or None. `config` already loads `.env`."""
    key = os.environ.get("GEMINI_API_KEY") or os.environ.get("LLM_API_KEY")
    return key.strip() or None if key else None


def llm_available() -> bool:
    return api_key() is not None


@dataclass
class CopilotAnswer:
    """An answer, what it rests on, and how it was produced."""

    question: str
    answer: str
    sources: list[dict[str, Any]] = field(default_factory=list)
    generated_by: str = "retrieval"
    corpus: str = ""
    warning: str | None = None
    disclaimer: str = (
        "Guidance retrieved from the scheme guidelines for review. It is not "
        "legal advice and not a finding about any work, official or Member."
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "question": self.question,
            "answer": self.answer,
            "sources": self.sources,
            "generated_by": self.generated_by,
            "corpus": self.corpus,
            "warning": self.warning,
            "disclaimer": self.disclaimer,
        }


def _extracts(hits: list[tuple[GuidelineChunk, float]]) -> str:
    return "\n\n".join(f"[{chunk.citation}]\n{chunk.text}" for chunk, _ in hits)


def _retrieval_answer(hits: list[tuple[GuidelineChunk, float]]) -> str:
    """The offline answer: the clauses themselves, most relevant first.

    Deliberately not a summary. Without a model there is nothing that can
    safely compress a legal clause, and handing over the text unaltered is
    always correct even when it is less comfortable to read.
    """
    lines = ["The most relevant passages in the guidelines:"]
    for chunk, _ in hits:
        lines.append(f"\n{chunk.citation}\n{chunk.text}")
    return "\n".join(lines)


# What Google's `error.details[].reason` means, and what fixes it. The reason
# code is a short enum -- never the request body, never the key -- so it is
# safe to log and safe to show an operator.
#
# This table exists because the copilot used to log a bare status code. A 403
# on this API has three unrelated causes with three unrelated fixes, and
# "Gemini returned 403" tells an operator which of them applies: none. On the
# reference project the answer was API_KEY_SERVICE_BLOCKED -- a valid key on a
# project with the Generative Language API switched off -- and no amount of
# regenerating the key would ever have fixed it.
_REMEDY: dict[str, str] = {
    "API_KEY_SERVICE_BLOCKED": (
        "this key is not allowed to call the Gemini API. Since September 2026 that "
        "API only accepts 'authorization' keys -- API keys bound to a Google Cloud "
        "service account -- and rejects the older standard keys. A standard key "
        "cannot be repaired by editing its restrictions: the Cloud console greys "
        "'Gemini API' out with 'requires authentication with a service account-bound "
        "API key'. Create a replacement at https://aistudio.google.com/apikey, where "
        "new keys are authorization keys automatically. (Less often, on an older key "
        "that did work: the Generative Language API is disabled for its project.)"
    ),
    "API_KEY_INVALID": "the key is not a valid Gemini key. Issue one at https://aistudio.google.com/apikey.",
    "API_KEY_HTTP_REFERRER_BLOCKED": "the key is restricted to browser referrers; a server call cannot use it.",
    "API_KEY_IP_ADDRESS_BLOCKED": "the key is IP-restricted and this host is not on the allowlist.",
    "SERVICE_DISABLED": "the Generative Language API is disabled for this Google Cloud project.",
    "RATE_LIMIT_EXCEEDED": "the free-tier rate limit was hit. It resets on its own; retry shortly.",
    "RESOURCE_EXHAUSTED": "the free-tier quota is exhausted for now. It resets on its own.",
}


def _diagnose_error(status_code: int, body: Any) -> str:
    """Turn Google's error body into one actionable sentence.

    Only the status code, the status enum and the reason code are read. The
    message text and anything else in the body are ignored: a body can echo
    the request, and the request carries guideline extracts.
    """
    reason = ""
    google_status = ""
    if isinstance(body, dict):
        error = body.get("error")
        if isinstance(error, dict):
            google_status = str(error.get("status") or "")
            for detail in error.get("details") or []:
                if isinstance(detail, dict) and str(detail.get("@type", "")).endswith("ErrorInfo"):
                    reason = str(detail.get("reason") or "")
                    break
    if reason in _REMEDY:
        return f"HTTP {status_code} {reason}: {_REMEDY[reason]}"
    if status_code == 404:
        return (
            f"HTTP 404: no model named {gemini_model()!r} is available to this key. "
            "Set GEMINI_MODEL to one the key can reach."
        )
    if status_code == 429:
        return f"HTTP 429: rate-limited or out of free-tier quota. {_REMEDY['RESOURCE_EXHAUSTED']}"
    parts = [f"HTTP {status_code}"]
    if google_status:
        parts.append(google_status)
    if reason:
        parts.append(reason)
    return " ".join(parts)


def _ask_gemini(question: str, extracts: str) -> tuple[str | None, str | None]:
    """Phrase an answer from the extracts.

    Returns `(text, problem)`. Exactly one is set: on success the phrased
    answer, on failure a one-sentence diagnosis of what to fix. Any failure
    degrades to the retrieval answer rather than surfacing an error -- the
    clauses are the substance, and the model is a convenience -- but the
    *reason* now travels with the degraded answer instead of being swallowed.
    """
    key = api_key()
    if key is None:
        return None, None
    try:
        import httpx
    except ImportError:  # pragma: no cover - httpx ships with fastapi
        return None, "httpx is not installed, so the model cannot be reached."

    payload = {
        "systemInstruction": {"parts": [{"text": SYSTEM_RULES}]},
        "contents": [
            {
                "role": "user",
                "parts": [
                    {
                        "text": (
                            f"Question: {question}\n\n"
                            f"Guideline extracts:\n{extracts}\n\n"
                            "Answer using only these extracts, citing paragraph numbers."
                        )
                    }
                ],
            }
        ],
        "generationConfig": {"temperature": 0.1, "maxOutputTokens": 500},
    }
    try:
        with httpx.Client(timeout=REQUEST_TIMEOUT_S) as client:
            response = client.post(
                f"{GEMINI_ENDPOINT}/{gemini_model()}:generateContent",
                headers={"x-goog-api-key": key},  # header, not a query string
                json=payload,
            )
        if response.status_code != 200:
            # The body can echo the request, so only the status code and the
            # reason enum are read out of it -- never the message or the body.
            try:
                body = response.json()
            except Exception:  # noqa: BLE001 - a non-JSON error body is still an error
                body = None
            problem = _diagnose_error(response.status_code, body)
            log.warning("Gemini call failed -- %s. Falling back to retrieval.", problem)
            return None, problem
        candidates = response.json().get("candidates") or []
        if not candidates:
            reason = "the model returned no candidate (most often a safety block on the prompt)."
            log.warning("Gemini call failed -- %s Falling back to retrieval.", reason)
            return None, reason
        parts = candidates[0].get("content", {}).get("parts") or []
        text = "".join(part.get("text", "") for part in parts).strip()
        if text:
            return text, None
        return None, "the model returned an empty answer."
    except Exception as exc:  # noqa: BLE001 - the copilot must never take a request down
        problem = f"could not reach the Gemini endpoint ({type(exc).__name__})."
        log.warning("Gemini call failed -- %s Falling back to retrieval.", problem)
        return None, problem


def _fallback_warning(problem: str | None) -> str:
    """Why this answer was not phrased by the model.

    Two different situations used to produce the same sentence. With no key
    configured, "Set GEMINI_API_KEY for a phrased answer" is the right advice.
    With a key configured that is being *refused*, it is actively wrong -- it
    tells an operator to set a variable they have already set, and hides the
    fact that the key needs fixing rather than supplying.
    """
    if problem is None:
        return (
            "Answered by retrieval. Set GEMINI_API_KEY for a phrased answer; "
            "the clauses below are the same either way."
        )
    return (
        f"Answered by retrieval: a key is configured but the model call failed -- {problem} "
        "The clauses below are unaffected; retrieval never depends on the model."
    )


def answer_question(question: str, k: int = 4) -> CopilotAnswer:
    """Answer a guidelines question from the corpus, phrased by Gemini if configured."""
    corpus = get_corpus()
    if not corpus.available:
        return CopilotAnswer(
            question=question,
            answer=(
                "No guidelines document is loaded, so there is nothing to answer from. "
                "Rather than answer from memory, which is how an invented clause gets "
                "presented as official, the copilot stops here."
            ),
            generated_by="unavailable",
            warning=corpus.unavailable,
        )

    hits = corpus.search(question, k=k)
    if not hits:
        return CopilotAnswer(
            question=question,
            answer="Nothing in the loaded guidelines matches that question closely enough to cite.",
            generated_by="retrieval",
            corpus=corpus.source,
        )

    sources = [chunk.to_dict() | {"relevance": round(score, 4)} for chunk, score in hits]
    generated, problem = _ask_gemini(question, _extracts(hits))
    return CopilotAnswer(
        question=question,
        answer=generated or _retrieval_answer(hits),
        sources=sources,
        generated_by="gemini" if generated else "retrieval",
        corpus=corpus.source,
        warning=None if generated else _fallback_warning(problem),
    )


@dataclass
class CopilotStatus:
    """Whether the copilot can do each of the two things it does.

    Retrieval and generation fail independently and for unrelated reasons, and
    the copilot is designed to keep working when generation is gone. That makes
    "is it working?" the wrong question and this the right one.
    """

    corpus_available: bool
    corpus_source: str
    n_chunks: int
    corpus_problem: str | None
    key_configured: bool
    key_source: str | None
    model: str
    generation_ok: bool
    generation_problem: str | None

    @property
    def ok(self) -> bool:
        """Retrieval is what the copilot promises. Generation is a bonus."""
        return self.corpus_available

    def render(self) -> str:
        lines = ["copilot", ""]
        mark = "OK  " if self.corpus_available else "FAIL"
        lines.append(f"  [{mark}] guidelines corpus")
        if self.corpus_available:
            lines.append(f"         {self.n_chunks:,} citable clauses from {self.corpus_source}")
        else:
            lines.append(f"         {self.corpus_problem}")

        if not self.key_configured:
            lines.append("  [ -- ] gemini generation: no key configured")
            lines.append(
                "         Retrieval answers on its own. Set GEMINI_API_KEY in .env "
                "for phrased answers."
            )
        elif self.generation_ok:
            lines.append("  [OK  ] gemini generation")
            lines.append(f"         model {self.model}, key from {self.key_source}")
        else:
            lines.append("  [FAIL] gemini generation")
            lines.append(f"         key from {self.key_source}, model {self.model}")
            lines.append(f"         {self.generation_problem}")
            lines.append(
                "         The copilot still answers from retrieval; only the phrasing is lost."
            )
        lines.append("")
        lines.append(
            "The copilot is usable."
            if self.ok
            else "The copilot cannot answer: there is no corpus to answer from."
        )
        return "\n".join(lines)


def diagnose(*, probe: bool = True) -> CopilotStatus:
    """Check retrieval and generation, and say precisely what to fix.

    `probe=True` makes one real, minimal call to the model -- a two-token
    prompt carrying no project data -- because the failures that matter here
    (a blocked API, a restricted key, an exhausted quota) are all invisible
    until something is actually sent.
    """
    corpus = get_corpus()
    key = api_key()
    source = None
    if key is not None:
        source = "GEMINI_API_KEY" if os.environ.get("GEMINI_API_KEY", "").strip() else "LLM_API_KEY"

    generation_ok = False
    problem: str | None = None
    if key is None:
        problem = "no key configured"
    elif probe:
        # Deliberately not a guideline extract: a reachability check must not
        # be the thing that sends project text to a third party.
        text, problem = _ask_gemini(
            "Reply with the single word: ok", "No extracts; this is a connectivity check."
        )
        generation_ok = text is not None
    else:
        # Not probed is not the same as failed, and saying nothing here would
        # render as a failure with no cause.
        problem = "not probed -- run `drishti copilot` to make a live call"

    return CopilotStatus(
        corpus_available=corpus.available,
        corpus_source=corpus.source,
        n_chunks=len(corpus.chunks),
        corpus_problem=corpus.unavailable,
        key_configured=key is not None,
        key_source=source,
        model=gemini_model(),
        generation_ok=generation_ok,
        generation_problem=problem,
    )


def explain_work(risk: dict[str, Any], k: int = 3) -> CopilotAnswer:
    """Turn one work's findings into a plain-language brief.

    Built from the reasons the detectors already produced -- the copilot never
    re-judges the work, it only phrases what the evidence card says and pulls
    the guideline clauses a reviewer would check against.
    """
    reasons = risk.get("reasons") or []
    findings = "; ".join(str(r.get("text", "")) for r in reasons[:6]) or "no findings recorded"
    question = f"Which guideline provisions relate to: {findings}"

    corpus = get_corpus()
    hits = corpus.search(question, k=k) if corpus.available else []
    sources = [chunk.to_dict() | {"relevance": round(score, 4)} for chunk, score in hits]

    band = str(risk.get("band", "unknown"))
    summary = (
        f"Work #{risk.get('work_id')} is in the {band} band with "
        f"{len(reasons)} recorded finding(s): {findings}. "
        "This is a prioritisation for review, not a finding of wrongdoing."
    )

    generated, problem = _ask_gemini(
        "Summarise these observations for a district officer in three sentences, "
        "state what should be verified, and do not say whether anything is fraudulent. "
        f"Observations: {findings}",
        _extracts(hits) if hits else "No guideline extracts available.",
    )
    warning = corpus.unavailable if not corpus.available else None
    if generated is None and problem is not None:
        warning = "; ".join(filter(None, [warning, _fallback_warning(problem)]))
    return CopilotAnswer(
        question=question,
        answer=generated or summary,
        sources=sources,
        generated_by="gemini" if generated else "retrieval",
        corpus=corpus.source,
        warning=warning,
    )
