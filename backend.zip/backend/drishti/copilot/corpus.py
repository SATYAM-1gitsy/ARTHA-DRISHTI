"""The guidelines corpus: chunk it, and find the clause that answers a question.

Retrieval uses `textsim.TfidfLite`, which the project already owns, rather than
adding a vector store. At 81 pages the corpus is a few hundred chunks — exact
cosine over that is microseconds, and a dependency that only pays for itself at
a million documents is not worth the install on a machine whose parquet engine
was blocked by a security policy last week.

**Chunks are clause-shaped, not fixed-width.** The guidelines are numbered
(`2.5`, `3.12`, `3.21.2`) and that numbering is what makes an answer citable.
Splitting on clause boundaries means a retrieved chunk can say "Para 3.12"
truthfully; splitting every 500 characters would produce fragments that cite
nothing and cannot be checked.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

import numpy as np

from ..config import settings
from ..textsim import TfidfLite, normalize_text

__all__ = ["GuidelineChunk", "GuidelineCorpus", "get_corpus"]

# A numbered clause opening a line: "2.5", "3.21.2", "10.1" ...
_CLAUSE = re.compile(r"^\s*(\d{1,2}(?:\.\d{1,2}){1,3})\s+(?=\S)", re.MULTILINE)
_PAGE_BREAK = "===PAGE==="

# Below this a "chunk" is a heading or a stray line, not a clause worth citing.
MIN_CHUNK_CHARS = 120


@dataclass(frozen=True)
class GuidelineChunk:
    """One citable passage."""

    clause: str
    text: str
    page: int
    source: str

    @property
    def citation(self) -> str:
        label = f"Para {self.clause}" if self.clause else "unnumbered passage"
        return f"{self.source}, {label} (p. {self.page})"

    def to_dict(self) -> dict[str, object]:
        return {
            "clause": self.clause,
            "page": self.page,
            "source": self.source,
            "citation": self.citation,
            "text": self.text,
        }


@dataclass
class GuidelineCorpus:
    """Chunked guidelines plus the index that searches them."""

    chunks: list[GuidelineChunk] = field(default_factory=list)
    source: str = ""
    unavailable: str | None = None
    _index: TfidfLite | None = field(default=None, repr=False)
    _matrix: np.ndarray | None = field(default=None, repr=False)

    @property
    def available(self) -> bool:
        return bool(self.chunks)

    def search(self, question: str, k: int = 4) -> list[tuple[GuidelineChunk, float]]:
        """The k most relevant clauses, best first.

        Returns an empty list rather than raising when no corpus is loaded, so
        a caller can report "no guidelines available" instead of failing.
        """
        if not self.available or self._index is None or self._matrix is None:
            return []
        query = self._index.transform([normalize_text(question)])
        if query.shape[0] == 0:
            return []
        scores = self._matrix @ query[0]
        order = np.argsort(-scores)[:k]
        return [
            (self.chunks[int(i)], float(scores[int(i)]))
            for i in order
            if scores[int(i)] > 0
        ]


def _split_pages(raw: str) -> list[str]:
    return raw.split(_PAGE_BREAK) if _PAGE_BREAK in raw else [raw]


def _chunk(raw: str, source: str) -> list[GuidelineChunk]:
    """Split into numbered clauses, carrying the page each one starts on."""
    chunks: list[GuidelineChunk] = []
    for page_number, page in enumerate(_split_pages(raw), start=1):
        matches = list(_CLAUSE.finditer(page))
        if not matches:
            continue
        for position, match in enumerate(matches):
            start = match.start()
            end = matches[position + 1].start() if position + 1 < len(matches) else len(page)
            body = " ".join(page[start:end].split())
            if len(body) < MIN_CHUNK_CHARS:
                continue
            chunks.append(
                GuidelineChunk(
                    clause=match.group(1),
                    text=body,
                    page=page_number,
                    source=source,
                )
            )
    return chunks


def _source_label(directory: Path) -> str:
    """Read the edition off SOURCE.md rather than guessing it.

    The file this project retrieved sits under a `/uploads/2023/` path and is
    the **June 2016** edition. Citing the path's year would put a false
    citation in front of a reviewer, so the label comes from the note written
    beside the document.
    """
    note = directory / "SOURCE.md"
    if note.is_file():
        for line in note.read_text(encoding="utf-8").splitlines():
            if line.lower().startswith("| **edition**"):
                cells = [c.strip().strip("*") for c in line.split("|") if c.strip()]
                if len(cells) >= 2:
                    return f"MPLADS Guidelines (MoSPI, {cells[1]})"
    return "MPLADS Guidelines (MoSPI)"


def load_corpus(directory: Path | None = None) -> GuidelineCorpus:
    """Load and index whatever guidelines are on disk.

    An absent corpus is an expected state, not an error: open question D-09 was
    unresolved for the project's whole life, and the copilot has to say so
    rather than fail.
    """
    root = directory or (settings.paths.data / "guidelines")
    if not root.is_dir():
        return GuidelineCorpus(
            unavailable=(
                f"no guidelines corpus at {root}. Place the MPLADS Guidelines there "
                "with a SOURCE.md recording the edition and where it came from."
            )
        )

    text_files = sorted(root.glob("*.txt"))
    if not text_files:
        return GuidelineCorpus(
            unavailable=(
                f"{root} holds no extracted text. A PDF alone is not searchable -- "
                "extract it to .txt beside the original."
            )
        )

    source = _source_label(root)
    chunks: list[GuidelineChunk] = []
    for path in text_files:
        chunks.extend(_chunk(path.read_text(encoding="utf-8", errors="replace"), source))

    if not chunks:
        return GuidelineCorpus(
            unavailable="the guidelines text contains no numbered clauses to cite.",
            source=source,
        )

    index = TfidfLite().fit([normalize_text(c.text) for c in chunks])
    matrix = index.transform([normalize_text(c.text) for c in chunks])
    return GuidelineCorpus(chunks=chunks, source=source, _index=index, _matrix=matrix)


@lru_cache(maxsize=1)
def get_corpus() -> GuidelineCorpus:
    """Process-wide corpus. Chunking 81 pages per request would be waste."""
    return load_corpus()
