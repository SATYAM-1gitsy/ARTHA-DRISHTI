"""The analyst copilot — Blueprint §6, §10 and differentiator §16.6.

Two halves, and the split is the point.

**Retrieval is local and always available.** The guidelines corpus is chunked
and searched with the project's own `TfidfLite`, so "what does the scheme say
about X" returns real clauses with page numbers on a machine with no API key,
no network and no model. That is the part an officer can rely on.

**Generation is optional and never authoritative.** When `GEMINI_API_KEY` is
set, retrieved clauses are passed to Gemini to be phrased as an answer. The
model may only summarise what retrieval found; it is told, and the response
shape enforces, that every claim carries a clause citation and that it must not
decide whether a work is fraudulent. Without a key the endpoint still answers,
returning the clauses themselves.

That ordering matters for a government accountability tool. A copilot that
invents a guideline clause is worse than no copilot, because the invention
arrives wearing the same authority as the real thing — the exact failure
`domain.Sourced` exists to prevent everywhere else in this project.
"""

from .corpus import GuidelineChunk, GuidelineCorpus, get_corpus
from .service import (
    CopilotAnswer,
    CopilotStatus,
    answer_question,
    diagnose,
    explain_work,
    gemini_model,
    llm_available,
)

__all__ = [
    "CopilotAnswer",
    "CopilotStatus",
    "GuidelineChunk",
    "GuidelineCorpus",
    "answer_question",
    "diagnose",
    "explain_work",
    "gemini_model",
    "get_corpus",
    "llm_available",
]
