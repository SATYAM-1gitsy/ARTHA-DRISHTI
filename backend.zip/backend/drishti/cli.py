"""The task runner. Replaces the Makefile.

Audit finding R-08: the Build Manual makes `make e2e` the team's daily
integration heartbeat, but `make` is not installed on the team's Windows
machines, so that heartbeat would never have run for anyone. This exposes the
same verbs through Python, which every teammate already has:

    python -m drishti doctor      environment check
    python -m drishti gpu         accelerator report
    python -m drishti up          docker compose up
    python -m drishti api         run the API directly (no docker)
    python -m drishti worker      run a Celery worker on this machine
    python -m drishti jobs <t>    enqueue a task and print its result
    python -m drishti fixtures    rebuild the committed contract fixtures
    python -m drishti ingest      load the real allocation file (bronze -> silver)
    python -m drishti seed        generate synthetic MPLADS data
    python -m drishti features    build the gold feature view
    python -m drishti score       run detectors and fusion
    python -m drishti eval        evaluate against ground truth
    python -m drishti e2e         ingest -> seed -> features -> score -> gate
    python -m drishti test        run the test suite

Verbs for stages that do not exist yet exit 2 and name the block that builds
them. A stub that silently succeeds is worse than one that refuses.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from collections.abc import Callable
from pathlib import Path

from . import __version__
from .config import settings
from .gpu import detect as detect_gpu
from .gpu import require_cuda
from .storage import check_parquet

# Stage -> the block that implements it. Keeps the roadmap visible at the
# command line instead of only in a document.
PENDING: dict[str, str] = {
    "seed": "Block 4 (synthetic generator)",
    "features": "Block 5 (gold feature builder)",
}

OK = "  ok   "
WARN = " warn  "
FAIL = " FAIL  "


def _print(status: str, label: str, detail: str = "") -> None:
    line = f"[{status}] {label}"
    if detail:
        line += f" -- {detail}"
    print(line)


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


# --------------------------------------------------------------------------
# verbs
# --------------------------------------------------------------------------
def cmd_doctor(args: argparse.Namespace) -> int:
    """Check that this machine can actually run the project."""
    print(f"drishti {__version__} -- environment check\n")
    failures = 0

    version = sys.version_info
    if version >= (3, 11):
        _print(OK, "python", f"{version.major}.{version.minor}.{version.micro}")
    else:
        _print(FAIL, "python", f"{version.major}.{version.minor} -- need 3.11+")
        failures += 1

    for module, required in (
        ("numpy", True),
        ("pandas", True),
        ("fastapi", False),
        ("pytest", False),
        ("celery", False),
        ("mlflow", False),
    ):
        try:
            mod = __import__(module)
            _print(OK, module, getattr(mod, "__version__", "installed"))
        except ImportError:
            if required:
                _print(FAIL, module, "not installed (required)")
                failures += 1
            else:
                _print(WARN, module, "not installed (optional for now)")

    # Every stage from `seed` onward persists to parquet, so a broken engine
    # stops the pipeline rather than degrading it. Checked by round trip, not
    # by import: pyarrow imports fine on a machine whose Application Control
    # policy blocks its _parquet extension, and the resulting failure surfaces
    # far from its cause.
    parquet = check_parquet()
    if parquet.usable:
        _print(OK, "parquet", parquet.summary())
    else:
        _print(FAIL, "parquet", parquet.summary())
        for problem in parquet.problems:
            _print(WARN, "  engine", problem)
        failures += 1

    report = detect_gpu()
    if report.usable:
        _print(OK, "gpu", report.summary())
    elif report.torch_installed:
        _print(WARN, "gpu", report.summary())
    else:
        _print(WARN, "gpu", "torch not installed -- numpy-only fallback path")

    for tool, required in (("node", False), ("npm", False), ("docker", False), ("git", True)):
        path = shutil.which(tool)
        if path:
            _print(OK, tool, path)
        elif required:
            _print(FAIL, tool, "not on PATH (required)")
            failures += 1
        else:
            _print(WARN, tool, "not on PATH")

    if shutil.which("docker"):
        probe = subprocess.run(
            ["docker", "info", "--format", "{{.ServerVersion}}"],
            capture_output=True,
            text=True,
        )
        if probe.returncode == 0:
            _print(OK, "docker daemon", probe.stdout.strip())
        else:
            _print(WARN, "docker daemon", "not running -- start Docker Desktop before `drishti up`")

    # A deployment concern, surfaced here rather than as a failing unit test:
    # a fresh clone that copied .env.example is running on a public password.
    if "change-me" in settings.database_url:
        _print(WARN, "db password", "still the .env.example placeholder -- change it before deploying")
    else:
        _print(OK, "db password", "set from .env")

    raw = settings.paths.raw
    xlsx = list(raw.glob("*.xlsx"))
    if xlsx:
        _print(OK, "raw data", f"{len(xlsx)} file(s) in {raw}")
    else:
        _print(WARN, "raw data", f"no .xlsx in {raw}")

    print()
    if failures:
        print(f"{failures} blocking problem(s).")
        return 1
    print("Environment is usable.")
    return 0


def cmd_gpu(args: argparse.Namespace) -> int:
    """Report the accelerator, optionally failing if it is unusable."""
    report = detect_gpu()
    if args.json:
        from .util import dumps

        print(dumps(report.to_dict(), indent=2))
    else:
        print(report.summary())
        for problem in report.problems:
            print(f"\n  ! {problem}")
    if args.require:
        try:
            require_cuda(report)
        except RuntimeError as exc:
            print(f"\n{exc}", file=sys.stderr)
            return 1
    return 0


def cmd_up(args: argparse.Namespace) -> int:
    """Bring the stack up with docker compose."""
    if not shutil.which("docker"):
        print("docker is not on PATH.", file=sys.stderr)
        return 1
    command = ["docker", "compose", "up"]
    if args.detach:
        command.append("-d")
    if args.build:
        command.append("--build")
    return subprocess.run(command, cwd=_repo_root()).returncode


def cmd_api(args: argparse.Namespace) -> int:
    """Run the API directly, without docker."""
    try:
        import uvicorn
    except ImportError:
        print("uvicorn is not installed: pip install -r backend/requirements.txt", file=sys.stderr)
        return 1
    uvicorn.run(
        "drishti.api.app:app",
        host=args.host or settings.api_host,
        port=args.port or settings.api_port,
        reload=args.reload,
    )
    return 0


def cmd_worker(args: argparse.Namespace) -> int:
    """Run a Celery worker on this machine.

    The containerised ml-worker is the normal path. This exists for debugging
    a task without a rebuild, and for running GPU work natively when the
    NVIDIA Container Toolkit is unavailable.
    """
    from .tasks.app import app as celery_app

    if celery_app is None:
        print("celery is not installed: pip install -r backend/requirements.txt", file=sys.stderr)
        return 1
    queues = args.queues or f"{settings.celery.default_queue},{settings.celery.gpu_queue}"
    report = detect_gpu()
    print(f"broker  {settings.redis_url}")
    print(f"queues  {queues}")
    print(f"gpu     {report.summary()}\n")
    celery_app.worker_main(
        ["worker", "--loglevel=info", f"--concurrency={args.concurrency}", f"--queues={queues}"]
    )
    return 0


def cmd_jobs(args: argparse.Namespace) -> int:
    """Enqueue a task and wait for its result.

    Useful as a one-command check that the broker, the worker and the GPU are
    all wired together: `drishti jobs gpu_probe`.
    """
    from .tasks.app import app as celery_app
    from .tasks.jobs import TASK_NAMES
    from .util import dumps

    if celery_app is None:
        print("celery is not installed", file=sys.stderr)
        return 1
    if args.task not in TASK_NAMES:
        print(f"unknown task {args.task!r}. Available: {sorted(TASK_NAMES)}", file=sys.stderr)
        return 1

    try:
        result = celery_app.send_task(TASK_NAMES[args.task])
    except Exception as exc:  # noqa: BLE001
        print(f"cannot reach the broker at {settings.redis_url}: {exc}", file=sys.stderr)
        return 1

    print(f"enqueued {TASK_NAMES[args.task]} as {result.id}")
    if not args.wait:
        return 0
    try:
        payload = result.get(timeout=args.timeout)
    except Exception as exc:  # noqa: BLE001
        print(f"job did not complete: {exc}", file=sys.stderr)
        return 1
    print(dumps(payload, indent=2))
    return 0


def cmd_ingest(args: argparse.Namespace) -> int:
    """Load the real allocation file into the reference tables.

    Prints the data-quality report rather than a success message: the point of
    this stage is what it could *not* determine from the source.
    """
    from .pipeline import run_ingest

    outcome = run_ingest(
        to_parquet=not getattr(args, "dry_run", False),
        to_postgres=getattr(args, "postgres", False),
    )
    print(outcome.report.render())
    if outcome.written:
        print()
        for name, target in outcome.written.items():
            print(f"  wrote {name:<20} {target}")
    if not outcome.ok:
        print(
            "\nIngest is NOT usable -- see the reconciliation line above.",
            file=sys.stderr,
        )
        return 1
    return 0


def cmd_fixtures(args: argparse.Namespace) -> int:
    """Rebuild the committed fixtures from the contracts.

    Run this after any contract change -- the fixture and the contract must
    move together or the seats coding against the fixture silently diverge.
    """
    script = _repo_root() / "scripts" / "build_fixtures.py"
    return subprocess.run([sys.executable, str(script)], cwd=_repo_root()).returncode


def cmd_contracts(args: argparse.Namespace) -> int:
    """Print the frozen contracts, so nobody has to read the source to code
    against them."""
    from .contracts.gold import GOLD_COLUMNS, REQUIRED_COLUMNS, leakage_report
    from .contracts.layer import LAYER_NAMES, LAYER_OUTPUT_COLUMNS, EvidenceFamily
    from .contracts.risk import BANDS

    print(f"Seam A  gold feature view   {len(GOLD_COLUMNS)} columns, {len(REQUIRED_COLUMNS)} required")
    if args.verbose:
        for name in GOLD_COLUMNS:
            print(f"          {name}")
    print(f"Seam B  layer output        {list(LAYER_OUTPUT_COLUMNS)}")
    print(f"          layers            {list(LAYER_NAMES)}")
    print(f"          evidence families {[f.value for f in EvidenceFamily]}")
    print("Seam C  risk assessment     overall_risk, confidence, severity, data_quality")
    print(f"          bands             {[b.value for b in BANDS]}")
    print(f"Seam E  leakage classes     {dict((k, len(v)) for k, v in leakage_report().items())}")
    return 0


def cmd_test(args: argparse.Namespace) -> int:
    """Run the test suite."""
    try:
        import pytest  # noqa: F401
    except ImportError:
        print("pytest is not installed: pip install -r backend/requirements.txt", file=sys.stderr)
        return 1
    target = args.target or "backend/drishti/tests"
    command = [sys.executable, "-m", "pytest", target, "-q"]
    if args.verbose:
        command[-1] = "-v"
    return subprocess.run(command, cwd=_repo_root()).returncode


def _pending(stage: str) -> int:
    print(f"`drishti {stage}` is not implemented yet -- {PENDING[stage]}.", file=sys.stderr)
    return 2


def cmd_seed(args: argparse.Namespace) -> int:
    """Generate the synthetic population and its ground truth."""
    from dataclasses import replace

    from .pipeline import run_seed

    # getattr with a default because `e2e` calls this with its own namespace,
    # which carries none of the seed-specific flags.
    config = settings.gen
    overrides = {k: v for k, v in (
        ("n_works", getattr(args, "n_works", None)),
        ("seed", getattr(args, "seed", None)),
        ("inject_rate", getattr(args, "inject_rate", None)),
        ("noise_level", getattr(args, "noise", None)),
    ) if v is not None}
    if overrides:
        config = replace(config, **overrides)

    outcome = run_seed(config, to_parquet=not getattr(args, "dry_run", False))
    print(f"seed={config.seed}  target={config.n_works:,} works" + chr(10))
    for name, count in outcome.dataset.summary.items():
        print(f"  {name:<24} {count:>9,}")
    print()
    print(outcome.report.describe())
    if outcome.written:
        print(chr(10) + f"  wrote {len(outcome.written)} files to {settings.paths.seeds}")
    return 0 if outcome.ok else 1


def cmd_features(args: argparse.Namespace) -> int:
    """Build the Gold feature view."""
    from .pipeline import run_features

    outcome = run_features(to_parquet=not getattr(args, "dry_run", False))
    print(outcome.result.describe())
    if outcome.written:
        print(chr(10) + f"  wrote {outcome.written['gold']}")
    if not outcome.ok:
        print(chr(10) + "Gold view violates the Seam A contract.", file=sys.stderr)
        return 1
    return 0


def cmd_score(args: argparse.Namespace) -> int:
    """Run the detection layers and fuse them into risk assessments."""
    from .pipeline import run_score

    outcome = run_score(
        to_parquet=not getattr(args, "dry_run", False),
        to_api=not getattr(args, "dry_run", False),
    )
    print(outcome.result.describe())
    if outcome.written:
        print(chr(10) + f"  wrote {len(outcome.written)} files")
        for name in sorted(outcome.written):
            print(f"    {name}")
    return 0 if outcome.ok else 1


def cmd_eval(args: argparse.Namespace) -> int:
    """Evaluate the scored population against ground truth."""
    from .evaluate import run_evaluation, write_report

    report = run_evaluation(with_ablation=not getattr(args, "no_ablation", False))
    print(report.render())
    if not getattr(args, "dry_run", False):
        print(chr(10) + f"  wrote {write_report(report)}")
    return 0


def cmd_copilot(args: argparse.Namespace) -> int:
    """Check the copilot, and answer a question with it.

    Exists because the two halves fail for unrelated reasons and neither
    failure is visible from the outside. A blocked API key and an exhausted
    free-tier quota both surface in the UI as "answered by retrieval"; only a
    probe can tell them apart, and only the reason code says which one to fix.
    """
    from .copilot import answer_question, diagnose

    question = getattr(args, "question", None)
    if not question:
        status = diagnose(probe=not getattr(args, "no_probe", False))
        print(status.render())
        return 0 if status.ok else 1

    answer = answer_question(question)
    print(f"Q: {answer.question}\n")
    print(answer.answer)
    if answer.sources:
        print("\nsources")
        for source in answer.sources:
            print(f"  {source['citation']}  (relevance {source.get('relevance')})")
    print(f"\ngenerated_by: {answer.generated_by}")
    if answer.warning:
        print(f"warning: {answer.warning}")
    print(f"\n{answer.disclaimer}")
    return 0


def cmd_e2e(args: argparse.Namespace) -> int:
    """The integration heartbeat: ingest -> seed -> features -> score -> gate.

    `eval` is deliberately not in this chain. It lands in Block 15, and a
    heartbeat that always ends in "not implemented" is a heartbeat the team
    stops reading.

    The acceptance gate is what makes this command mean something today: a
    green pipeline that produces wrong artefacts is worse than a red one, so
    the run is not finished until the assertions pass.
    """
    print("running end-to-end pipeline\n")
    for stage, handler in (
        ("ingest", cmd_ingest),
        ("seed", cmd_seed),
        ("features", cmd_features),
        ("score", cmd_score),
    ):
        print(f"--- {stage} ---")
        code = handler(args)
        if code != 0:
            print(f"\nPipeline stopped at `{stage}`.", file=sys.stderr)
            return code
        print()

    from .acceptance import run_acceptance

    print("--- acceptance ---")
    report = run_acceptance()
    print(report.render())
    return 0 if report.ok else 1


# --------------------------------------------------------------------------
# parser
# --------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="drishti",
        description="ARTHA DRISHTI task runner (replaces the Makefile).",
    )
    parser.add_argument("--version", action="version", version=f"drishti {__version__}")
    sub = parser.add_subparsers(dest="command", metavar="<verb>")

    def add(name: str, handler: Callable[[argparse.Namespace], int], help_text: str):
        sp = sub.add_parser(name, help=help_text)
        sp.set_defaults(handler=handler)
        return sp

    add("doctor", cmd_doctor, "check that this machine can run the project")

    gpu_parser = add("gpu", cmd_gpu, "report the accelerator")
    gpu_parser.add_argument("--json", action="store_true", help="machine-readable output")
    gpu_parser.add_argument("--require", action="store_true", help="exit non-zero if CUDA is unusable")

    up_parser = add("up", cmd_up, "docker compose up")
    up_parser.add_argument("-d", "--detach", action="store_true")
    up_parser.add_argument("--build", action="store_true")

    api_parser = add("api", cmd_api, "run the API without docker")
    api_parser.add_argument("--host", default=None)
    api_parser.add_argument("--port", type=int, default=None)
    api_parser.add_argument("--reload", action="store_true")

    worker_parser = add("worker", cmd_worker, "run a Celery worker on this machine")
    worker_parser.add_argument("--concurrency", type=int, default=2)
    worker_parser.add_argument("--queues", default=None)

    jobs_parser = add("jobs", cmd_jobs, "enqueue a task and print its result")
    jobs_parser.add_argument("task", help="ping | gpu_probe | gpu_benchmark")
    jobs_parser.add_argument("--no-wait", dest="wait", action="store_false")
    jobs_parser.add_argument("--timeout", type=int, default=300)

    ingest_parser = add("ingest", cmd_ingest, "load the real allocation file")
    ingest_parser.add_argument("--postgres", action="store_true", help="also upsert into Postgres")
    ingest_parser.add_argument("--dry-run", action="store_true", help="report only, write nothing")

    add("fixtures", cmd_fixtures, "rebuild the committed contract fixtures")

    contracts_parser = add("contracts", cmd_contracts, "print the frozen contracts")
    contracts_parser.add_argument("-v", "--verbose", action="store_true")

    test_parser = add("test", cmd_test, "run the test suite")
    test_parser.add_argument("target", nargs="?", default=None)
    test_parser.add_argument("-v", "--verbose", action="store_true")

    seed_parser = add("seed", cmd_seed, "generate synthetic MPLADS data")
    seed_parser.add_argument("--n-works", type=int, default=None)
    seed_parser.add_argument("--seed", type=int, default=None)
    seed_parser.add_argument("--inject-rate", type=float, default=None)
    seed_parser.add_argument("--noise", type=float, default=None)
    seed_parser.add_argument("--dry-run", action="store_true")
    features_parser = add("features", cmd_features, "build the gold feature view")
    features_parser.add_argument("--dry-run", action="store_true")
    score_parser = add("score", cmd_score, "run detectors and fusion")
    score_parser.add_argument("--dry-run", action="store_true")
    eval_parser = add("eval", cmd_eval, "evaluate against ground truth")
    eval_parser.add_argument("--no-ablation", action="store_true", help="skip the layer ablation")
    eval_parser.add_argument("--dry-run", action="store_true")
    copilot_parser = add("copilot", cmd_copilot, "check the copilot, or ask it a question")
    copilot_parser.add_argument(
        "question", nargs="?", default=None, help="ask this instead of running the check"
    )
    copilot_parser.add_argument(
        "--no-probe",
        action="store_true",
        help="do not make a live call to the model; report configuration only",
    )
    add("e2e", cmd_e2e, "ingest -> seed -> features -> score -> acceptance gate")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "handler", None):
        parser.print_help()
        return 0
    return args.handler(args)
