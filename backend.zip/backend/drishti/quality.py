"""The data-quality report.

A monitoring system that hides its own data problems has no standing to flag
anyone else's. This produces the report that says, in one place, what was
read, what was rejected, what was kept with a caveat, and what remains
unknowable from the source.

The rule throughout is that nothing is imputed silently. A missing allocation
stays missing and is named; a reservation status that cannot be recovered is
marked as inferred rather than asserted.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .ingest.allocation import IngestResult
from .transform.reference import ReferenceTables
from .util import dumps

__all__ = ["QualityReport", "build_report"]


@dataclass
class QualityReport:
    """What the ingest knows about its own inputs."""

    source: str
    generated_at: str
    rows_read: int
    rows_accepted: int
    rows_quarantined: int
    reconciles: bool | None
    declared_total: float | None
    computed_total: float | None
    tables: dict[str, int] = field(default_factory=dict)
    issues: list[dict[str, Any]] = field(default_factory=list)
    notes: list[dict[str, Any]] = field(default_factory=list)
    completeness: dict[str, float] = field(default_factory=dict)

    @property
    def acceptance_rate(self) -> float:
        return self.rows_accepted / self.rows_read if self.rows_read else 0.0

    @property
    def is_usable(self) -> bool:
        """Whether downstream stages should proceed.

        Reconciliation failure is disqualifying in a way that individual row
        defects are not: it means the parse or the extract is wrong, and every
        number computed from it would be wrong too.
        """
        return self.rows_accepted > 0 and self.reconciles is not False

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "generated_at": self.generated_at,
            "rows_read": self.rows_read,
            "rows_accepted": self.rows_accepted,
            "rows_quarantined": self.rows_quarantined,
            "acceptance_rate": round(self.acceptance_rate, 4),
            "reconciles_with_declared_total": self.reconciles,
            "declared_total": self.declared_total,
            "computed_total": self.computed_total,
            "tables": self.tables,
            "completeness": {k: round(v, 4) for k, v in self.completeness.items()},
            "issues": self.issues,
            "notes": self.notes,
            "usable": self.is_usable,
        }

    def render(self) -> str:
        """Human-readable summary for the terminal."""
        lines = [
            f"Data quality -- {Path(self.source).name}",
            "",
            f"  rows read        {self.rows_read}",
            f"  accepted         {self.rows_accepted}  ({self.acceptance_rate:.1%})",
            f"  quarantined      {self.rows_quarantined}",
        ]
        if self.reconciles is None:
            lines.append("  reconciliation   no declared total in the source")
        elif self.reconciles:
            lines.append(f"  reconciliation   OK -- accepted rows sum to {self.declared_total:,.2f}")
        else:
            lines.append(
                f"  reconciliation   MISMATCH -- computed {self.computed_total:,.2f} "
                f"vs declared {self.declared_total:,.2f}"
            )

        lines.append("")
        for name, count in self.tables.items():
            lines.append(f"  {name:<16} {count}")

        if self.completeness:
            lines.append("")
            lines.append("  completeness")
            for column, value in sorted(self.completeness.items(), key=lambda kv: kv[1]):
                marker = "  " if value == 1.0 else " !"
                lines.append(f"   {marker} {column:<24} {value:.1%}")

        flagged = [i for i in self.issues if not i["rejected"]]
        if flagged:
            lines.append("")
            lines.append(f"  kept with a flag ({len(flagged)})")
            for issue in flagged[:10]:
                lines.append(f"     row {issue['source_row']:<5} {issue['code']}: {issue['detail']}")
            if len(flagged) > 10:
                lines.append(f"     ... and {len(flagged) - 10} more")

        if self.notes:
            lines.append("")
            lines.append(f"  unresolved in this source ({len(self.notes)})")
            for note in self.notes:
                lines.append(f"     [{note['code']}]")
                for chunk in _wrap(note["detail"], 84):
                    lines.append(f"       {chunk}")
        return "\n".join(lines)

    def write(self, path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(dumps(self.to_dict(), indent=2), encoding="utf-8")
        return path


def _wrap(text: str, width: int) -> list[str]:
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        if len(current) + len(word) + 1 > width:
            lines.append(current)
            current = word
        else:
            current = f"{current} {word}".strip()
    if current:
        lines.append(current)
    return lines


def build_report(result: IngestResult, tables: ReferenceTables) -> QualityReport:
    """Assemble the report from an ingest and its reference tables."""
    accepted = result.accepted
    computed_total = (
        float(accepted["allocated_amount_raw"].dropna().sum()) if len(accepted) else None
    )

    completeness: dict[str, float] = {}
    total = len(accepted) or 1
    for column in ("sr_no", "state_raw", "mp_name_raw", "constituency_raw", "allocated_amount_raw"):
        if column in accepted.columns:
            completeness[column] = 1.0 - float(accepted[column].isna().sum()) / total

    marked = tables.constituencies["reservation_source"] == "name_marker"
    completeness["constituency_reservation_observed"] = (
        float(marked.sum()) / len(tables.constituencies) if len(tables.constituencies) else 0.0
    )

    return QualityReport(
        source=result.source_path,
        generated_at=datetime.now(UTC).isoformat(timespec="seconds"),
        rows_read=result.n_accepted + result.n_quarantined,
        rows_accepted=result.n_accepted,
        rows_quarantined=result.n_quarantined,
        reconciles=result.reconciles(),
        declared_total=result.declared_total,
        computed_total=computed_total,
        tables=tables.summary,
        issues=[issue.to_dict() for issue in result.issues],
        notes=tables.notes,
        completeness=completeness,
    )


def load_report(path: Path) -> QualityReport:
    """Read a previously written report."""
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return QualityReport(
        source=payload["source"],
        generated_at=payload["generated_at"],
        rows_read=payload["rows_read"],
        rows_accepted=payload["rows_accepted"],
        rows_quarantined=payload["rows_quarantined"],
        reconciles=payload["reconciles_with_declared_total"],
        declared_total=payload["declared_total"],
        computed_total=payload["computed_total"],
        tables=payload["tables"],
        issues=payload["issues"],
        notes=payload["notes"],
        completeness=payload["completeness"],
    )
