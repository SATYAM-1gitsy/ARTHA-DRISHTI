-- Canonical schema. The shared vocabulary for the whole team.
--
-- `work` is the spine: almost every layer scores at work_id granularity, and
-- every other table hangs off it. If you need a new column, add it here first
-- in a PR -- a column invented inside one module is invisible to everyone
-- else and absent from the fixture.
--
-- Verified against postgis/postgis:16-3.4.

BEGIN;

CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS fuzzystrmatch;
CREATE EXTENSION IF NOT EXISTS unaccent;

-- ==========================================================================
-- reference data
-- ==========================================================================
CREATE TABLE IF NOT EXISTS state (
    state_id      serial PRIMARY KEY,
    name          text NOT NULL UNIQUE,
    region        text,
    ls_seats      integer CHECK (ls_seats >= 0)
);

CREATE TABLE IF NOT EXISTS district (
    district_id   serial PRIMARY KEY,
    state_id      integer NOT NULL REFERENCES state(state_id),
    name          text NOT NULL,
    geom          geometry(MultiPolygon, 4326),
    -- Bounding box is the point_in_bbox fallback when no polygon is loaded.
    bbox          box2d,
    sc_pop_pct    numeric(5,2),
    st_pop_pct    numeric(5,2),
    UNIQUE (state_id, name)
);

CREATE TABLE IF NOT EXISTS constituency (
    constituency_id serial PRIMARY KEY,
    state_id        integer NOT NULL REFERENCES state(state_id),
    name            text NOT NULL,
    house           text NOT NULL CHECK (house IN ('LS', 'RS')),
    -- 'SC' | 'ST' | 'GEN' | 'UNKNOWN'. UNKNOWN is a real value, not a gap:
    -- five seats' reservation status is not recoverable from the source
    -- file's name column (audit finding D-03), and guessing would corrupt
    -- every earmark check downstream.
    reservation     text NOT NULL DEFAULT 'UNKNOWN'
                    CHECK (reservation IN ('SC', 'ST', 'GEN', 'UNKNOWN')),
    geom            geometry(MultiPolygon, 4326),
    UNIQUE (state_id, name, house)
);

CREATE TABLE IF NOT EXISTS mp (
    mp_id           serial PRIMARY KEY,
    name            text NOT NULL,
    name_canonical  text NOT NULL,          -- casefolded, punctuation stripped
    house           text NOT NULL CHECK (house IN ('LS', 'RS', 'NOM')),
    constituency_id integer REFERENCES constituency(constituency_id),
    state_id        integer REFERENCES state(state_id),
    -- Term dates make a constituency non-unique over time. NANDED carries two
    -- members in the 18th Lok Sabha after a by-election (finding D-02), so
    -- constituency alone can never be a key.
    term_start      date NOT NULL,
    term_end        date,
    allocated_limit numeric(16,2),
    CHECK (term_end IS NULL OR term_end >= term_start)
);
CREATE INDEX IF NOT EXISTS mp_name_trgm ON mp USING gin (name_canonical gin_trgm_ops);

CREATE TABLE IF NOT EXISTS implementing_agency (
    agency_id       serial PRIMARY KEY,
    name            text NOT NULL,
    name_canonical  text NOT NULL,
    agency_type     text,
    district_id     integer REFERENCES district(district_id),
    registration_no text,
    -- How this record was matched to its canonical form, and how sure we are.
    -- Uncertain merges must stay visible rather than being silently collapsed.
    resolution_method     text CHECK (resolution_method IN ('exact', 'fuzzy', 'embedding', 'manual')),
    resolution_confidence numeric(4,3) CHECK (resolution_confidence BETWEEN 0 AND 1)
);
CREATE INDEX IF NOT EXISTS agency_name_trgm ON implementing_agency USING gin (name_canonical gin_trgm_ops);

CREATE TABLE IF NOT EXISTS vendor (
    vendor_id       serial PRIMARY KEY,
    name            text NOT NULL,
    name_canonical  text NOT NULL,
    gstin           text,
    -- Hashed, never stored raw: DPDP data minimisation.
    pan_hash        text,
    resolution_method     text,
    resolution_confidence numeric(4,3)
);
CREATE INDEX IF NOT EXISTS vendor_name_trgm ON vendor USING gin (name_canonical gin_trgm_ops);

-- ==========================================================================
-- transactional core
-- ==========================================================================
CREATE TABLE IF NOT EXISTS recommendation (
    rec_id          bigserial PRIMARY KEY,
    mp_id           integer NOT NULL REFERENCES mp(mp_id),
    district_id     integer NOT NULL REFERENCES district(district_id),
    constituency_id integer REFERENCES constituency(constituency_id),
    sector          text NOT NULL,
    work_type       text NOT NULL,
    description     text,
    estimated_cost  numeric(16,2) CHECK (estimated_cost >= 0),
    recommended_on  date NOT NULL,
    is_sc_area      boolean NOT NULL DEFAULT false,
    is_st_area      boolean NOT NULL DEFAULT false
);

CREATE TABLE IF NOT EXISTS work (
    work_id                  bigserial PRIMARY KEY,
    rec_id                   bigint REFERENCES recommendation(rec_id),
    district_id              integer NOT NULL REFERENCES district(district_id),
    agency_id                integer REFERENCES implementing_agency(agency_id),
    sector                   text NOT NULL,
    work_type                text NOT NULL,
    description              text,
    sanctioned_cost          numeric(16,2) NOT NULL CHECK (sanctioned_cost >= 0),
    quantity                 numeric(14,2),
    sanction_date            date NOT NULL,
    expected_completion_date date,
    actual_completion_date   date,
    status                   text NOT NULL DEFAULT 'sanctioned'
                             CHECK (status IN ('recommended','sanctioned','in_progress','completed','abandoned')),
    progress_pct             numeric(5,2) NOT NULL DEFAULT 0 CHECK (progress_pct BETWEEN 0 AND 100),
    geom                     geometry(Point, 4326),
    financial_year           integer NOT NULL,
    CHECK (actual_completion_date IS NULL OR actual_completion_date >= sanction_date)
);
CREATE INDEX IF NOT EXISTS work_district_idx ON work(district_id);
CREATE INDEX IF NOT EXISTS work_agency_idx   ON work(agency_id);
CREATE INDEX IF NOT EXISTS work_sanction_idx ON work(sanction_date);
CREATE INDEX IF NOT EXISTS work_peer_idx     ON work(sector, work_type, financial_year);
CREATE INDEX IF NOT EXISTS work_geom_idx     ON work USING gist (geom);

CREATE TABLE IF NOT EXISTS payment (
    payment_id    bigserial PRIMARY KEY,
    work_id       bigint NOT NULL REFERENCES work(work_id) ON DELETE CASCADE,
    vendor_id     integer REFERENCES vendor(vendor_id),
    amount        numeric(16,2) NOT NULL CHECK (amount >= 0),
    payment_date  date NOT NULL,
    voucher_no    text,
    payment_type  text CHECK (payment_type IN ('advance','running','final'))
);
CREATE INDEX IF NOT EXISTS payment_work_idx ON payment(work_id, payment_date);

CREATE TABLE IF NOT EXISTS progress_update (
    update_id           bigserial PRIMARY KEY,
    work_id             bigint NOT NULL REFERENCES work(work_id) ON DELETE CASCADE,
    update_date         date NOT NULL,
    progress_pct        numeric(5,2) NOT NULL CHECK (progress_pct BETWEEN 0 AND 100),
    expenditure_to_date numeric(16,2),
    remarks             text
);
CREATE INDEX IF NOT EXISTS progress_work_idx ON progress_update(work_id, update_date);

CREATE TABLE IF NOT EXISTS asset (
    asset_id   bigserial PRIMARY KEY,
    work_id    bigint NOT NULL REFERENCES work(work_id) ON DELETE CASCADE,
    asset_type text,
    geom       geometry(Point, 4326),
    created_on date
);

CREATE TABLE IF NOT EXISTS asset_photo (
    photo_id    bigserial PRIMARY KEY,
    asset_id    bigint NOT NULL REFERENCES asset(asset_id) ON DELETE CASCADE,
    url         text,
    exif_lat    numeric(10,6),
    exif_lon    numeric(10,6),
    captured_on timestamptz,
    phash       text
);
CREATE INDEX IF NOT EXISTS photo_phash_idx ON asset_photo(phash);

CREATE TABLE IF NOT EXISTS inspection (
    inspection_id       bigserial PRIMARY KEY,
    work_id             bigint NOT NULL REFERENCES work(work_id) ON DELETE CASCADE,
    inspected_on        date NOT NULL,
    inspector_role      text,
    found_progress_pct  numeric(5,2),
    remarks             text
);

CREATE TABLE IF NOT EXISTS document (
    doc_id    bigserial PRIMARY KEY,
    work_id   bigint NOT NULL REFERENCES work(work_id) ON DELETE CASCADE,
    doc_type  text CHECK (doc_type IN ('uc','estimate','bill','inspection','other')),
    url       text,
    ocr_text  text,
    -- OCR is noisy evidence, never ground truth. Confidence travels with it.
    ocr_confidence numeric(4,3)
);

-- ==========================================================================
-- platform output
-- ==========================================================================
CREATE TABLE IF NOT EXISTS risk_score (
    work_id       bigint NOT NULL REFERENCES work(work_id) ON DELETE CASCADE,
    scored_at     timestamptz NOT NULL DEFAULT now(),
    -- The four quantities stay separate (finding R-02). Collapsing them makes
    -- a thin lead and a corroborated finding indistinguishable.
    overall_risk  numeric(5,4) NOT NULL CHECK (overall_risk BETWEEN 0 AND 1),
    confidence    numeric(5,4) NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    data_quality  numeric(5,4) NOT NULL CHECK (data_quality BETWEEN 0 AND 1),
    severity      text NOT NULL CHECK (severity IN ('low','medium','high','critical')),
    band          text NOT NULL CHECK (band IN ('low','medium','high','critical')),
    -- Independent evidence families, not the layer count (finding R-01).
    corroborating_families text[] NOT NULL DEFAULT '{}',
    layer_scores  jsonb NOT NULL DEFAULT '{}',
    reasons       jsonb NOT NULL DEFAULT '[]',
    narrative     text,
    escalated_by_rule text,
    model_version text,
    feature_version text,
    PRIMARY KEY (work_id, scored_at)
);
CREATE INDEX IF NOT EXISTS risk_band_idx ON risk_score(band, overall_risk DESC);

CREATE TABLE IF NOT EXISTS alert (
    alert_id    bigserial PRIMARY KEY,
    work_id     bigint NOT NULL REFERENCES work(work_id) ON DELETE CASCADE,
    category    text NOT NULL,
    severity    text NOT NULL CHECK (severity IN ('low','medium','high','critical')),
    status      text NOT NULL DEFAULT 'open'
                CHECK (status IN ('open','under_review','resolved','dismissed')),
    evidence    jsonb NOT NULL DEFAULT '{}',
    created_at  timestamptz NOT NULL DEFAULT now(),
    assigned_to text
);
CREATE INDEX IF NOT EXISTS alert_status_idx ON alert(status, severity);

CREATE TABLE IF NOT EXISTS alert_review (
    review_id  bigserial PRIMARY KEY,
    alert_id   bigint NOT NULL REFERENCES alert(alert_id) ON DELETE CASCADE,
    reviewed_at timestamptz NOT NULL DEFAULT now(),
    reviewer   text NOT NULL,
    from_status text,
    to_status  text NOT NULL,
    -- A reviewer's outcome is a weak label, not proven fact: a dismissal may
    -- be correct or may be a missed case. Never promoted to ground truth.
    outcome    text CHECK (outcome IN ('confirmed_issue','false_positive',
                                       'insufficient_evidence','duplicate_alert',
                                       'requires_field_inspection')),
    note       text
);

-- Immutable audit log. The accountability tool is itself accountable.
CREATE TABLE IF NOT EXISTS audit_log (
    audit_id   bigserial PRIMARY KEY,
    at         timestamptz NOT NULL DEFAULT now(),
    actor      text NOT NULL,
    action     text NOT NULL,
    entity     text NOT NULL,
    entity_id  text,
    detail     jsonb NOT NULL DEFAULT '{}'
);

-- ==========================================================================
-- ground truth (Seam E)
-- ==========================================================================
-- Never joined into any feature view. Evaluation and supervised training only,
-- and rule-visible rows are never pooled with held-out ones (finding R-03).
CREATE TABLE IF NOT EXISTS fraud_label (
    label_id   bigserial PRIMARY KEY,
    work_id    bigint NOT NULL REFERENCES work(work_id) ON DELETE CASCADE,
    pattern    text NOT NULL,
    injected   boolean NOT NULL DEFAULT true,
    visibility text NOT NULL CHECK (visibility IN ('rule_visible','held_out')),
    severity   text NOT NULL,
    source     text NOT NULL DEFAULT 'synthetic_injection'
               CHECK (source IN ('synthetic_injection','rule_derived',
                                 'human_review','confirmed_finding')),
    parameters jsonb NOT NULL DEFAULT '{}',
    UNIQUE (work_id, pattern)
);

COMMIT;
