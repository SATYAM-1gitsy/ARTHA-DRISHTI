"""Text normalization and similarity without heavy NLP dependencies.

The fallback for rapidfuzz, sentence-transformers and FAISS (Manual 12.4).
The interface is deliberately the same shape a real embedding model exposes
(fit a corpus, transform to vectors, cosine between vectors) so L4 can be
upgraded to a multilingual bi-encoder by swapping the backend, not by
rewriting the detector.

Descriptions in MPLADS extracts mix English, Hindi and regional languages,
often within a single row, so normalization here selects characters by Unicode
category rather than by str.isalnum() -- see normalize_text for why that
distinction decides whether Devanagari survives or is silently shredded.
"""

from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter
from collections.abc import Iterable, Sequence
from difflib import SequenceMatcher

import numpy as np

__all__ = [
    "normalize_text",
    "tokens",
    "char_ngrams",
    "jaccard",
    "token_sort_ratio",
    "token_set_ratio",
    "cosine",
    "TfidfLite",
    "script_profile",
]

_WS = re.compile(r"\s+")
_DEVANAGARI = (0x0900, 0x097F)


def normalize_text(text: str | None) -> str:
    """Casefold, strip punctuation, collapse whitespace. Script-preserving.

    NFKC first so composed and decomposed forms of the same Indic grapheme
    compare equal, and so full-width or stylised Latin folds to plain ASCII.

    Character classes are selected by Unicode category, not by str.isalnum().
    That distinction is load-bearing: Devanagari vowel signs, the virama and
    the nukta are combining marks (categories Mn/Mc), for which isalnum()
    returns False. Dropping them shatters every Hindi word into fragments --
    "सड़क" becomes "सड क" -- while every test on English strings still passes.

    Categories kept: L* (letters), N* (numbers), M* (combining marks).
    Cf (ZWJ / ZWNJ) is removed without leaving a space, since it joins rather
    than separates. Everything else becomes a space.
    """
    if not text:
        return ""
    s = unicodedata.normalize("NFKC", str(text)).casefold()
    out: list[str] = []
    for ch in s:
        category = unicodedata.category(ch)
        if category[0] in ("L", "N", "M"):
            out.append(ch)
        elif category == "Cf":
            continue
        else:
            out.append(" ")
    return _WS.sub(" ", "".join(out)).strip()


def tokens(text: str | None) -> list[str]:
    """Whitespace tokens of the normalized string."""
    norm = normalize_text(text)
    return norm.split() if norm else []


def char_ngrams(text: str | None, n: int = 3) -> list[str]:
    """Character n-grams of the normalized string.

    Useful where transliteration varies ("Panchayat" / "Panchyat") or where a
    language has no whitespace word boundaries the tokenizer respects.
    """
    norm = normalize_text(text)
    if not norm:
        return []
    padded = f" {norm} "
    if len(padded) < n:
        return [padded]
    return [padded[i : i + n] for i in range(len(padded) - n + 1)]


def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    """Set overlap in [0, 1]."""
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 1.0
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def token_sort_ratio(a: str | None, b: str | None) -> float:
    """Character-level similarity after sorting tokens, in [0, 1].

    Sorting first makes it order-insensitive; comparing characters rather than
    whole tokens makes it survive spelling drift, which matters because
    transliterated Indian place and body names vary freely across records
    ("panchayat bhavan" / "panchyat bhawan").
    """
    ta, tb = tokens(a), tokens(b)
    if not ta and not tb:
        return 1.0
    if not ta or not tb:
        return 0.0
    return SequenceMatcher(None, " ".join(sorted(ta)), " ".join(sorted(tb))).ratio()


def token_set_ratio(a: str | None, b: str | None) -> float:
    """Order-insensitive lexical similarity in [0, 1]. The rapidfuzz fallback.

    Two routes to a high score, and the better one wins:

      exact token overlap    precise when spellings match, but collapses to
                             zero the moment one word is spelled differently
      character agreement    the mean of sorted-token character similarity and
                             trigram overlap, which survives spelling drift

    Taking the max means a spelling variant is still recognised, while
    requiring trigram support in the second route keeps unrelated strings low
    -- SequenceMatcher alone gives short unrelated phrases an incidental floor
    around 0.27, which is high enough to swamp a duplicate threshold.

    Measured separation on the reference pairs: identical and reordered 1.00,
    near-duplicate 0.87, spelling drift 0.69, unrelated 0.13, cross-language
    0.04.

    Not a semantic measure. Two works described in different languages score
    near zero, which is exactly why L4 must not decide duplication on lexical
    similarity alone.
    """
    ta, tb = tokens(a), tokens(b)
    if not ta and not tb:
        return 1.0
    if not ta or not tb:
        return 0.0
    word = jaccard(ta, tb)
    char = jaccard(char_ngrams(a), char_ngrams(b))
    sort_ratio = token_sort_ratio(a, b)
    return float(max(word, 0.5 * (sort_ratio + char)))


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity between two 1-D vectors, safe on zero vectors."""
    va = np.asarray(a, dtype=float).ravel()
    vb = np.asarray(b, dtype=float).ravel()
    if va.size != vb.size:
        raise ValueError(f"cosine needs equal lengths, got {va.size} and {vb.size}")
    na = float(np.linalg.norm(va))
    nb = float(np.linalg.norm(vb))
    if na < 1e-12 or nb < 1e-12:
        return 0.0
    return float(np.clip(np.dot(va, vb) / (na * nb), -1.0, 1.0))


def script_profile(text: str | None) -> dict[str, float]:
    """Fraction of alphabetic characters by script family.

    Used to answer an audit question the project cannot answer by assumption:
    are the descriptions actually multilingual? Returns fractions for latin,
    devanagari and other, which sum to 1.0 when any letters are present.
    """
    if not text:
        return {"latin": 0.0, "devanagari": 0.0, "other": 0.0}
    latin = deva = other = 0
    for ch in str(text):
        if not ch.isalpha():
            continue
        cp = ord(ch)
        if _DEVANAGARI[0] <= cp <= _DEVANAGARI[1]:
            deva += 1
        elif cp < 0x0250:
            latin += 1
        else:
            other += 1
    total = latin + deva + other
    if total == 0:
        return {"latin": 0.0, "devanagari": 0.0, "other": 0.0}
    return {
        "latin": latin / total,
        "devanagari": deva / total,
        "other": other / total,
    }


class TfidfLite:
    """Minimal TF-IDF vectorizer over word tokens.

    Sublinear term frequency, smoothed inverse document frequency, L2-normalized
    rows -- so a dot product between two rows is already their cosine.

    Dense by design: the corpora here are thousands of short descriptions, not
    millions of documents, and a dense matrix keeps the fallback dependency-free.
    Swap in a bi-encoder when one is available; the fit/transform surface is
    unchanged.
    """

    __slots__ = ("vocabulary_", "idf_", "min_df", "max_features", "_fitted")

    def __init__(self, min_df: int = 1, max_features: int | None = None) -> None:
        if min_df < 1:
            raise ValueError("min_df must be at least 1")
        self.min_df = min_df
        self.max_features = max_features
        self.vocabulary_: dict[str, int] = {}
        self.idf_: np.ndarray = np.zeros(0, dtype=float)
        self._fitted = False

    def fit(self, corpus: Sequence[str | None]) -> TfidfLite:
        docs = [tokens(d) for d in corpus]
        df: Counter[str] = Counter()
        for doc in docs:
            df.update(set(doc))

        kept = [(t, c) for t, c in df.items() if c >= self.min_df]
        # Sort by document frequency then alphabetically so the vocabulary is
        # deterministic across runs -- feature order must be reproducible.
        kept.sort(key=lambda tc: (-tc[1], tc[0]))
        if self.max_features is not None:
            kept = kept[: self.max_features]

        self.vocabulary_ = {term: i for i, (term, _) in enumerate(kept)}
        n_docs = max(1, len(docs))
        idf = np.zeros(len(self.vocabulary_), dtype=float)
        for term, index in self.vocabulary_.items():
            idf[index] = math.log((1.0 + n_docs) / (1.0 + df[term])) + 1.0
        self.idf_ = idf
        self._fitted = True
        return self

    def transform(self, corpus: Sequence[str | None]) -> np.ndarray:
        """Return an (n_docs, n_features) L2-normalized matrix.

        Out-of-vocabulary tokens are dropped; a document with no known token
        yields an all-zero row, and cosine() against it returns 0.0 rather
        than raising.
        """
        if not self._fitted:
            raise RuntimeError("TfidfLite.transform called before fit")
        n_features = len(self.vocabulary_)
        matrix = np.zeros((len(corpus), n_features), dtype=float)
        if n_features == 0:
            return matrix
        for row, doc in enumerate(corpus):
            counts = Counter(tokens(doc))
            for term, count in counts.items():
                index = self.vocabulary_.get(term)
                if index is not None:
                    matrix[row, index] = (1.0 + math.log(count)) * self.idf_[index]
            norm = float(np.linalg.norm(matrix[row]))
            if norm > 1e-12:
                matrix[row] /= norm
        return matrix

    def fit_transform(self, corpus: Sequence[str | None]) -> np.ndarray:
        return self.fit(corpus).transform(corpus)

    def similarity_matrix(self, matrix: np.ndarray) -> np.ndarray:
        """Pairwise cosine over L2-normalized rows.

        O(n^2) in memory. Callers must block candidates first (same district,
        amount band, time window) -- see Manual 12.2 on the duplicate
        detector's failure mode.
        """
        m = np.asarray(matrix, dtype=float)
        if m.ndim != 2:
            raise ValueError(f"expected a 2-D matrix, got shape {m.shape}")
        return np.clip(m @ m.T, -1.0, 1.0)
